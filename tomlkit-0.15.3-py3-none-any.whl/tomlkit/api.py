from __future__ import annotations

import contextlib
import datetime as _datetime
import re

from collections.abc import Iterable
from collections.abc import Mapping
from typing import IO
from typing import TYPE_CHECKING
from typing import Any
from typing import TypeVar

from tomlkit._utils import parse_rfc3339
from tomlkit._utils import validate_comment
from tomlkit.container import Container
from tomlkit.exceptions import UnexpectedCharError
from tomlkit.items import CUSTOM_ENCODERS
from tomlkit.items import AoT
from tomlkit.items import Array
from tomlkit.items import Bool
from tomlkit.items import Comment
from tomlkit.items import Date
from tomlkit.items import DateTime
from tomlkit.items import DottedKey
from tomlkit.items import Float
from tomlkit.items import InlineTable
from tomlkit.items import Integer
from tomlkit.items import Item as _Item
from tomlkit.items import Key
from tomlkit.items import SingleKey
from tomlkit.items import String
from tomlkit.items import StringType as _StringType
from tomlkit.items import Table
from tomlkit.items import Time
from tomlkit.items import Trivia
from tomlkit.items import Whitespace
from tomlkit.items import item as item
from tomlkit.parser import Parser
from tomlkit.toml_document import TOMLDocument as TOMLDocument


if TYPE_CHECKING:
    from tomlkit.items import Encoder

    E = TypeVar("E", bound=Encoder)


def loads(string: str | bytes) -> TOMLDocument:
    """
    Parses a string into a TOMLDocument.

    Alias for parse().
    """
    return parse(string)


def dumps(data: Mapping[str, Any], sort_keys: bool = False) -> str:
    """
    Dumps a TOMLDocument into a string.
    """
    if isinstance(data, (Table, InlineTable, Container)):
        if not sort_keys:
            return data.as_string()

        return item(data, _sort_keys=True).as_string()

    if isinstance(data, Mapping):
        return item(dict(data), _sort_keys=sort_keys).as_string()

    try:
        # mapping-like wrappers (e.g. dotty_dict's Dotty) delegate
        # ``as_string`` to the document they wrap; rendering it directly
        # preserves the original layout, which re-encoding through a plain
        # dict would lose
        return data.as_string()  # type: ignore[attr-defined]
    except AttributeError as ex:
        msg = f"Expecting Mapping or TOML Table or Container, {type(data)} given"
        raise TypeError(msg) from ex


def load(fp: IO[str] | IO[bytes]) -> TOMLDocument:
    """
    Load toml document from a file-like object.
    """
    return parse(fp.read())


def dump(data: Mapping[str, Any], fp: IO[str], *, sort_keys: bool = False) -> None:
    """
    Dump a TOMLDocument into a writable file stream.

    :param data: a dict-like object to dump
    :param sort_keys: if true, sort the keys in alphabetic order

    :Example:

    >>> with open("output.toml", "w") as fp:
    ...     tomlkit.dump(data, fp)
    """
    fp.write(dumps(data, sort_keys=sort_keys))


def parse(string: str | bytes) -> TOMLDocument:
    """
    Parses a string or bytes into a TOMLDocument.
    """
    return Parser(string).parse()


def document() -> TOMLDocument:
    """
    Returns a new TOMLDocument instance.
    """
    return TOMLDocument()


# Items
_INTEGER_RE = re.compile(
    r"(?:"
    r"0x[0-9a-fA-F](?:_?[0-9a-fA-F])*"  # hex: lowercase prefix only, no sign
    r"|0o[0-7](?:_?[0-7])*"  # octal: lowercase prefix only, no sign
    r"|0b[01](?:_?[01])*"  # binary: lowercase prefix only, no sign
    r"|[+-]?(?:0|[1-9](?:_?[0-9])*)"  # decimal: optional sign, no leading zeros
    r")"
)
"""Valid TOML v1.0.0 integer literals (https://toml.io/en/v1.0.0#integer).

Underscores may only appear between digits; hex/octal/binary use a
lowercase prefix and take no sign, mirroring ``Parser._parse_number``.
"""


def integer(raw: str | int) -> Integer:
    """Create an integer item from a number or string.

    When ``raw`` is a string it must be a valid TOML v1.0.0 integer
    literal; the original text is then preserved verbatim so grouping
    underscores (e.g. ``"1_000"``) survive ``dumps()``. Anything else
    raises ``ValueError``.
    """
    if isinstance(raw, str):
        if not _INTEGER_RE.fullmatch(raw):
            raise ValueError(f"Invalid TOML integer: {raw!r}")
        return Integer(int(raw, 0), Trivia(), raw)
    return item(int(raw))


def float_(raw: str | float) -> Float:
    """Create an float item from a number or string."""
    return item(float(raw))


def boolean(raw: str | bool) -> Bool:
    """Turn `true` or `false` into a boolean item."""
    return item(raw == "true" if isinstance(raw, str) else raw)


def string(
    raw: str,
    *,
    literal: bool = False,
    multiline: bool = False,
    escape: bool = True,
) -> String:
    """Create a string item.

    By default, this function will create *single line basic* strings, but
    boolean flags (e.g. ``literal=True`` and/or ``multiline=True``)
    can be used for personalization.

    For more information, please check the spec: `<https://toml.io/en/v1.0.0#string>`__.

    Dumping produces a TOML string that faithfully represents the given string.
    This includes character escaping for basic strings.
    This behaviour can be disabled by setting ``escape=False``.
    In that case, the given string is used verbatim for the content of the TOML string.
    Please note that this makes you responsible for ensuring the given string does not
    contain any forbidden character or sequence.
    """
    type_ = _StringType.select(literal, multiline)
    return String.from_raw(raw, type_, escape)


def date(raw: str) -> Date:
    """Create a TOML date."""
    value = parse_rfc3339(raw)
    if isinstance(value, _datetime.datetime) or not isinstance(value, _datetime.date):
        raise ValueError("date() only accepts date strings.")

    return item(value)


def time(raw: str) -> Time:
    """Create a TOML time."""
    value = parse_rfc3339(raw)
    if not isinstance(value, _datetime.time):
        raise ValueError("time() only accepts time strings.")

    return item(value)


def datetime(raw: str) -> DateTime:
    """Create a TOML datetime."""
    value = parse_rfc3339(raw)
    if not isinstance(value, _datetime.datetime):
        raise ValueError("datetime() only accepts datetime strings.")

    return item(value)


def array(raw: str = "[]") -> Array:
    """Create an array item for its string representation.

    :Example:

    >>> array("[1, 2, 3]")  # Create from a string
    [1, 2, 3]
    >>> a = array()
    >>> a.extend([1, 2, 3])  # Create from a list
    >>> a
    [1, 2, 3]
    """
    v = value(raw)
    if not isinstance(v, Array):
        raise ValueError(f"Expected an array, got {type(v)}")
    return v


def table(is_super_table: bool | None = None) -> Table:
    """Create an empty table.

    :param is_super_table: if true, the table is a super table

    :Example:

    >>> doc = document()
    >>> foo = table(True)
    >>> bar = table()
    >>> bar.update({'x': 1})
    >>> foo.append('bar', bar)
    >>> doc.append('foo', foo)
    >>> print(doc.as_string())
    [foo.bar]
    x = 1
    """
    return Table(Container(), Trivia(), False, is_super_table)


def inline_table() -> InlineTable:
    """Create an inline table.

    :Example:

    >>> table = inline_table()
    >>> table.update({'x': 1, 'y': 2})
    >>> print(table.as_string())
    {x = 1, y = 2}
    """
    return InlineTable(Container(), Trivia(), new=True)


def aot() -> AoT:
    """Create an array of table.

    :Example:

    >>> doc = document()
    >>> aot = aot()
    >>> aot.append(item({'x': 1}))
    >>> doc.append('foo', aot)
    >>> print(doc.as_string())
    [[foo]]
    x = 1
    """
    return AoT([])


def key(k: str | Iterable[str]) -> Key:
    """Create a key from a string. When a list of string is given,
    it will create a dotted key.

    :Example:

    >>> doc = document()
    >>> doc.append(key('foo'), 1)
    >>> doc.append(key(['bar', 'baz']), 2)
    >>> print(doc.as_string())
    foo = 1
    bar.baz = 2
    """
    if isinstance(k, str):
        return SingleKey(k)
    keys = [SingleKey(_k) for _k in k]
    if len(keys) == 1:
        return keys[0]
    return DottedKey(keys)


def value(raw: str) -> _Item:
    """Parse a simple value from a string.

    :Example:

    >>> value("1")
    1
    >>> value("true")
    True
    >>> value("[1, 2, 3]")
    [1, 2, 3]
    """
    parser = Parser(raw)
    v = parser._parse_value()
    if not parser.end():
        raise parser.parse_error(UnexpectedCharError, char=parser._current)
    return v


def key_value(src: str) -> tuple[Key, _Item]:
    """Parse a key-value pair from a string.

    Anything other than whitespace or a comment after the pair is an error,
    as it is when the same text is given to :func:`parse`.

    :Example:

    >>> key_value("foo = 1")
    (Key('foo'), 1)
    """
    parser = Parser(src)
    k, v = parser._parse_key_value(parse_comment=True)
    if not parser.end():
        raise parser.parse_error(UnexpectedCharError, char=parser._current)
    return k, v


def ws(src: str) -> Whitespace:
    """Create a whitespace from a string."""
    return Whitespace(src, fixed=True)


def nl() -> Whitespace:
    """Create a newline item."""
    return ws("\n")


def comment(string: str) -> Comment:
    """Create a comment item.

    A multiline string produces one ``#``-prefixed line per line so that the
    result is still valid TOML.
    """
    validate_comment(string, multiline=True)
    lines = string.split("\n")
    rendered = "\n".join(f"# {line}" if line else "#" for line in lines)
    return Comment(Trivia(comment_ws="  ", comment=rendered))


def register_encoder(encoder: E) -> E:
    """Add a custom encoder, which should be a function that will be called
    if the value can't otherwise be converted.

    The encoder should return a TOMLKit item or raise a ``ConvertError``.

    Example::

        @register_encoder
        def encode_custom_dict(obj, _parent=None, _sort_keys=False):
            if isinstance(obj, CustomDict):
                tbl = table()
                for key, value in obj.items():
                    # Pass along parameters when encoding nested values
                    tbl[key] = item(value, _parent=tbl, _sort_keys=_sort_keys)
                return tbl
            raise ConvertError("Not a CustomDict")
    """
    CUSTOM_ENCODERS.append(encoder)
    return encoder


def unregister_encoder(encoder: Encoder) -> None:
    """Unregister a custom encoder."""
    with contextlib.suppress(ValueError):
        CUSTOM_ENCODERS.remove(encoder)
