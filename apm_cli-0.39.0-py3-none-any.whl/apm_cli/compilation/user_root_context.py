"""User-scope root-context compilation engine.

Reads global (apply_to-less) instructions from ~/.apm/apm_modules and
writes each active target's user-scope root context file:
  claude  -> ~/.claude/CLAUDE.md  (or $CLAUDE_CONFIG_DIR/CLAUDE.md)
  codex   -> ~/.codex/AGENTS.md  (or $CODEX_HOME/AGENTS.md)
  gemini  -> ~/.gemini/GEMINI.md
  copilot -> ~/.copilot/AGENTS.md
  vscode  -> ~/.copilot/AGENTS.md (same deploy root at user scope)
  cursor  -> ~/.cursor/AGENTS.md
  opencode -> ~/.config/opencode/AGENTS.md

Files are ONLY written when:
1. The target supports user scope (for_scope returns non-None)
2. The target has a recognised compile_family with a root-file mapping
3. Global instructions exist in the module tree
4. The existing file either does not exist OR carries the generated marker

Hand-authored files (no marker) are left untouched. Claude omits individually
verified native rules and protects edited generated roots. Explicit cleanup
removes only an unchanged, fully redundant generated Claude root.
"""

from __future__ import annotations

import logging
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import logging as _logging_module

    from ..integration.targets import TargetProfile
    from ..primitives.models import Instruction

# Root filename by compile_family.  Targets whose compile_family is not in
# this map do not produce a root file (e.g. family=None for agent-skills).
_ROOT_FILENAME: dict[str, str] = {
    "claude": "CLAUDE.md",
    "agents": "AGENTS.md",
    "vscode": "AGENTS.md",
    "gemini": "GEMINI.md",
}


@dataclass(frozen=True)
class UserRootCompileResult:
    """Result for one user-scope root context compilation target."""

    target: str
    path: Path | None
    status: str
    has_critical_security: bool = False


def _resolve_deploy_root(profile: TargetProfile) -> Path:
    """Return the absolute deploy root for a user-scoped TargetProfile.

    After for_scope(user_scope=True):
    * profile.resolved_deploy_root is set   -> use it directly
    * otherwise                             -> Path.home() / profile.root_dir
    """
    if profile.resolved_deploy_root is not None:
        return profile.resolved_deploy_root
    return Path.home() / profile.root_dir


def _finalize_build_id(content: str) -> str:
    """Replace the BUILD_ID_PLACEHOLDER sentinel with a 12-char content hash.

    The hash is computed over all lines EXCEPT the placeholder line so the
    result is deterministic (not self-referential).
    """
    from .build_id import stabilize_build_id

    return stabilize_build_id(content)


def _generate_content(
    instructions: list[Instruction],
    *,
    preserve_scoped_sections: bool = False,
    base_dir: Path | None = None,
) -> str:
    """Generate root context content, retaining scoped sections when supported.

    Embeds the APM-generated marker and a deterministic Build ID so that
    subsequent runs can detect APM-owned files and apply overwrite protection.

    ASCII-only: no Unicode in the generated skeleton; instruction *content*
    is passed through as-is (callers are responsible for encoding checks).
    """
    from .constants import AGENTS_MD_GENERATED_MARKER, BUILD_ID_PLACEHOLDER

    sections: list[str] = [
        AGENTS_MD_GENERATED_MARKER,
        BUILD_ID_PLACEHOLDER,
        "",
    ]

    if preserve_scoped_sections:
        from .template_builder import render_instructions_block

        def emit(instruction: Instruction) -> list[str]:
            return [instruction.content.strip(), ""]

        sections.extend(
            render_instructions_block(
                instructions,
                base_dir=base_dir or Path.cwd(),
                emit_instruction=emit,
            )
        )
    else:
        for instruction in instructions:
            sections.append(instruction.content.strip())
            sections.append("")

    return _finalize_build_id("\n".join(sections))


def discover_global_instructions(
    source_root: Path,
    *,
    logger: _logging_module.Logger | None = None,
    include_scoped: bool = False,
) -> list[Instruction]:
    """Return global instructions and optionally scoped ones from ``apm_modules``.

    Returns an empty list when the ``apm_modules`` tree is absent or carries no
    matching instructions. Results are sorted by file path for determinism so
    callers (the compile engine and the install-time hint) agree on ordering.
    """
    from ..primitives.discovery import discover_primitives

    log = logger or logging.getLogger(__name__)

    apm_modules = source_root / "apm_modules"
    if not apm_modules.is_dir():
        log.debug(
            "user_root_context: apm_modules dir not found at %s -- no global instructions",
            apm_modules,
        )
        return []

    primitives = discover_primitives(str(apm_modules))
    return sorted(
        [instr for instr in primitives.instructions if include_scoped or not instr.apply_to],
        key=lambda instr: str(instr.file_path),
    )


def compile_user_root_contexts(
    targets: Iterable[TargetProfile],
    source_root: Path,
    *,
    dry_run: bool = False,
    clean: bool = False,
    logger: _logging_module.Logger | None = None,
) -> list[UserRootCompileResult]:
    """Compile user-scope root context files from global (apply_to-less) instructions.

    Iterates over *targets*, skipping any that:
    * do not support user scope (for_scope returns None)
    * have no recognised compile_family root-file mapping

    For each remaining target the function discovers global instructions from
    ``source_root / "apm_modules"``, generates content, and writes the root
    file -- unless the existing file is hand-authored (no marker).

    Args:
        targets: Iterable of TargetProfile instances to process.
        source_root: Root of the user's APM installation tree,
            e.g. ``Path.home() / ".apm"``.
        dry_run: When True, no files are written or directories created.
            The returned status values reflect what *would* happen.
        clean: Remove a redundant, unchanged generated Claude user root.
        logger: Optional logger.  Falls back to ``logging.getLogger(__name__)``.

    Returns:
        A list of UserRootCompileResult entries, one per target that was
        evaluated.  Each entry contains ``target``, ``path``, and ``status``.

        Status values:
        * ``"written"``              -- file was created or updated
        * ``"unchanged"``            -- file already matches generated content
        * ``"would-write"``          -- dry_run; file would have been written
        * ``"skipped-no-instructions"`` -- no global instructions found
        * ``"skipped-hand-authored"`` -- existing file has no APM marker
        * ``"skipped-native-rules"`` -- equivalent native rules cover all instructions
        * ``"skipped-redundant"`` -- existing redundant root requires explicit clean
        * ``"skipped-modified"`` / ``"skipped-symlink"`` -- protected existing root
        * ``"removed"`` / ``"would-remove"`` -- explicit redundant-root cleanup
        * ``"error:<msg>"``          -- OS error during read or write
    """
    import yaml

    from ..integration.instruction_integrator import InstructionIntegrator
    from ..utils.path_security import PathTraversalError, ensure_path_within
    from .constants import AGENTS_MD_GENERATED_MARKER
    from .output_writer import CompiledOutputPolicyError, CompiledOutputWriter
    from .root_context_protection import clean_redundant_user_root, protected_user_root_status

    log = logger or logging.getLogger(__name__)

    results: list[UserRootCompileResult] = []
    pending: list[tuple[int, str, Path, str]] = []

    apm_modules = source_root / "apm_modules"
    if not apm_modules.is_dir():
        log.debug(
            "user_root_context: apm_modules dir not found at %s -- no root files written",
            apm_modules,
        )
        return results

    all_instructions = discover_global_instructions(source_root, logger=log, include_scoped=True)
    global_instructions = [instr for instr in all_instructions if not instr.apply_to]
    integrator = InstructionIntegrator()

    for target in targets:
        # Resolve to user scope; None == target does not support user scope
        scoped = target.for_scope(user_scope=True)
        if scoped is None:
            log.debug("user_root_context: %s does not support user scope -- skipping", target.name)
            continue

        family = scoped.compile_family
        if family not in _ROOT_FILENAME:
            log.debug(
                "user_root_context: %s compile_family=%r has no root-file mapping -- skipping",
                scoped.name,
                family,
            )
            continue

        preserve_scoped_sections = scoped.include_scoped_in_user_root_context
        target_instructions = all_instructions if preserve_scoped_sections else global_instructions
        if not target_instructions:
            log.debug(
                "user_root_context: no applicable instructions found in %s -- skipping %s",
                apm_modules,
                scoped.name,
            )
            results.append(UserRootCompileResult(scoped.name, None, "skipped-no-instructions"))
            continue

        deploy_root = _resolve_deploy_root(scoped)
        root_filename = _ROOT_FILENAME[family]
        output_path = deploy_root / root_filename
        try:
            resolved_output_path = ensure_path_within(output_path, deploy_root)
        except PathTraversalError as exc:
            log.warning("user_root_context: unsafe output path for %s: %s", scoped.name, exc)
            results.append(
                UserRootCompileResult(scoped.name, deploy_root / root_filename, f"error:{exc}")
            )
            continue
        if family == "claude" and output_path.is_symlink():
            results.append(UserRootCompileResult(scoped.name, output_path, "skipped-symlink"))
            continue
        output_path = resolved_output_path

        unfiltered_instructions = target_instructions
        if family == "claude":
            try:
                _, coverage_verdict = CompiledOutputWriter().prepare(
                    {output_path: _generate_content(unfiltered_instructions)}
                )
            except CompiledOutputPolicyError:
                results.append(
                    UserRootCompileResult(
                        scoped.name,
                        output_path,
                        "error:critical hidden characters in compiled output",
                        has_critical_security=True,
                    )
                )
                continue
            if coverage_verdict.has_findings:
                log.warning(
                    "user_root_context: selected Claude instructions contain hidden "
                    "characters -- run 'apm audit' to inspect"
                )
            target_instructions = []
            for instruction in unfiltered_instructions:
                try:
                    matched = integrator.deployed_rule_matches(
                        instruction.file_path, scoped, deploy_root
                    )
                except (OSError, UnicodeError, PathTraversalError, yaml.YAMLError) as exc:
                    log.warning(
                        "Cannot verify native rule for %s; retaining compiled fallback. "
                        "Check rule access, content and containment, then rerun: %s",
                        instruction.file_path,
                        exc,
                    )
                    matched = False
                if not matched:
                    target_instructions.append(instruction)

        if not target_instructions:
            status = "skipped-native-rules"
            if output_path.exists():
                try:
                    status = clean_redundant_user_root(
                        output_path,
                        deploy_root,
                        _generate_content(unfiltered_instructions),
                        dry_run=dry_run or not clean,
                    )
                    if not clean and status == "would-remove":
                        status = "skipped-redundant"
                except (OSError, UnicodeError, PathTraversalError) as exc:
                    log.warning("Cannot verify or clean %s: %s", output_path, exc)
                    status = f"error:{exc}"
            results.append(UserRootCompileResult(scoped.name, output_path, status))
            continue

        content = _generate_content(
            target_instructions,
            preserve_scoped_sections=preserve_scoped_sections,
            base_dir=source_root,
        )

        # -- overwrite protection --
        if output_path.exists():
            try:
                existing = output_path.read_text(encoding="utf-8")
            except (OSError, UnicodeError) as exc:
                log.warning("user_root_context: cannot read %s: %s", output_path, exc)
                results.append(UserRootCompileResult(scoped.name, output_path, f"error:{exc}"))
                continue

            if not existing.lstrip().startswith(AGENTS_MD_GENERATED_MARKER):
                log.info(
                    "user_root_context: %s is hand-authored (no APM marker) -- not overwriting",
                    output_path,
                )
                results.append(
                    UserRootCompileResult(scoped.name, output_path, "skipped-hand-authored")
                )
                continue

            if family == "claude":
                protected = protected_user_root_status(output_path, existing)
                if protected is not None:
                    results.append(UserRootCompileResult(scoped.name, output_path, protected))
                    continue

            if existing == content:
                log.debug("user_root_context: %s is unchanged", output_path)
                results.append(UserRootCompileResult(scoped.name, output_path, "unchanged"))
                continue

        if dry_run:
            log.debug("user_root_context: [dry-run] would write %s", output_path)
            results.append(UserRootCompileResult(scoped.name, output_path, "would-write"))
            continue

        index = len(results)
        results.append(UserRootCompileResult(scoped.name, output_path, "pending"))
        pending.append((index, scoped.name, output_path, content))

    if pending:
        try:
            verdict = CompiledOutputWriter().write_many(
                {path: content for _, _, path, content in pending}
            )
        except CompiledOutputPolicyError:
            for index, name, path, _ in pending:
                results[index] = UserRootCompileResult(
                    name,
                    path,
                    "error:critical hidden characters in compiled output",
                    has_critical_security=True,
                )
        except OSError as exc:
            log.warning("user_root_context: failed to write output batch: %s", exc)
            for index, name, path, _ in pending:
                results[index] = UserRootCompileResult(name, path, f"error:{exc}")
        else:
            for index, name, path, _ in pending:
                findings = verdict.findings_by_file.get(str(path), [])
                if findings:
                    log.warning(
                        "user_root_context: %s contains %s hidden character(s) "
                        "-- run 'apm audit --file %s' to inspect",
                        path,
                        len(findings),
                        path,
                    )
                log.debug("user_root_context: wrote %s", path)
                results[index] = UserRootCompileResult(name, path, "written")

    return results
