"""Main compilation orchestration for AGENTS.md generation.

Timestamp generation removed in favor of deterministic Build ID handled after
full content assembly. This keeps repeated compiles byte-identical when source
primitives & constitution are unchanged.
"""

import logging
from dataclasses import dataclass, replace
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, NamedTuple  # noqa: UP035

from ..core import remediation as _advice
from ..core.target_catalog import accepted_target_values, get_target_capability
from ..core.target_detection import (
    CompileTargetType,
    get_dedup_rules_dir,
    should_compile_agents_md,
    should_compile_claude_md,
    should_compile_copilot_instructions_md,
    should_compile_gemini_md,
    target_without_compile_output,
)
from ..primitives.discovery import discover_primitives
from ..primitives.models import Instruction, PrimitiveCollection
from ..utils.path_security import PathTraversalError, ensure_path_within
from ..utils.paths import portable_relpath, resolve_base_and_source_dirs
from ..version import get_version
from .build_id import has_valid_build_id, stabilize_build_id
from .claude_agents_md import (
    claude_md_imports_agents_md,
    is_claude_only_target,
    pin_directory_placements,
    record_compiled_instructions,
    user_claude_md_imports_agents_md,
    without_claude_rule_instructions,
    without_directory_instructions,
)
from .claude_formatter import CLAUDE_HEADER, ClaudeFormatter
from .config_file import apply_compilation_section
from .constants import (
    AGENTS_MD_GENERATED_MARKER,
    BUILD_ID_PLACEHOLDER,
    DISTRIBUTED_AGENTS_MD_GENERATED_MARKER,
    decode_utf8_prefix,
    has_generated_marker_header,
)
from .footer import VALID_AGENTS_MD_MODES, build_generation_footer
from .inventory import CompileInventory
from .link_resolver import resolve_markdown_links, validate_link_targets
from .managed_section import ManagedSectionError
from .output_writer import output_error_message, refuse_unsafe_output
from .root_context_protection import (
    _build_expected_rule_filenames,
    _get_deployed_instruction_filenames,
    _instruction_rule_filename,
    hand_authored_root_context_blocks_write,
)
from .template_builder import (
    TemplateData,
    build_conditional_sections,
    find_chatmode_by_name,
    generate_agents_md_template,
)

if TYPE_CHECKING:
    from .context_optimizer import ContextOptimizer
    from .distributed_compiler import DistributedAgentsCompiler

_logger = logging.getLogger(__name__)


_COPILOT_CAPABILITY = get_target_capability("copilot")
_VSCODE_TARGET_ALIASES = (
    _COPILOT_CAPABILITY.name,
    *(
        alias
        for alias in _COPILOT_CAPABILITY.aliases
        if alias != _COPILOT_CAPABILITY.compile_family
    ),
)
_KNOWN_TARGETS = accepted_target_values("compile") | {"minimal"}
_AGENTS_ROOT_GENERATED_MARKERS = (
    AGENTS_MD_GENERATED_MARKER,
    DISTRIBUTED_AGENTS_MD_GENERATED_MARKER,
)
# Compatibility alias for callers that imported the former module constant.
_COPILOT_ROOT_GENERATED_MARKER = AGENTS_MD_GENERATED_MARKER


def _detect_deployed_instructions(
    rules_dir: Path,
    base_dir: Path,
    warn_fn: Callable[[str], None],
    expected_filenames: set[str] | None = None,
) -> bool:
    """Return True when rules_dir contains at least one rule file safely inside base_dir.

    Shared by the Claude, Copilot, and Antigravity compile paths: each passes
    its own target-specific rules directory (.claude/rules/, .github/instructions/,
    or .agents/rules/) so the detection logic stays in one place (R0801 guard).
    """
    if not rules_dir.is_dir():
        return False
    from ..utils.path_security import PathTraversalError, ensure_path_within

    try:
        ensure_path_within(rules_dir, base_dir)
    except PathTraversalError:
        warn_fn(f"{rules_dir} is a symlink outside the project root -- ignoring")
        return False

    if expected_filenames is not None:
        return any((rules_dir / name).is_file() for name in expected_filenames)
    return any(rules_dir.glob("*.md"))


# Compiler families allowed inside a multi-target frozenset (built by
# _resolve_compile_target() from CLI-validated target names). Kept narrow
# because the frozenset path bypasses _KNOWN_TARGETS validation.
_KNOWN_COMPILE_FAMILIES = frozenset({"agents", "vscode", "claude", "gemini"})


@dataclass
class CompilationConfig:
    """Configuration for AGENTS.md compilation."""

    output_path: str = "AGENTS.md"
    chatmode: str | None = None
    resolve_links: bool = True
    dry_run: bool = False
    with_constitution: bool = True  # Phase 0 feature flag

    # Multi-target compilation settings
    # "vscode" or "agents" -> AGENTS.md + .github/
    # "claude" -> CLAUDE.md + .claude/
    # "all" -> both targets
    # frozenset({"agents","claude"}) -> AGENTS.md + CLAUDE.md (multi-target)
    target: CompileTargetType = "all"

    # Distributed compilation settings (Task 7)
    strategy: str = "distributed"  # "distributed" or "single-file"
    single_agents: bool = False  # Force single-file mode
    trace: bool = False  # Show source attribution and conflicts
    local_only: bool = False  # Ignore dependencies, compile only local primitives
    debug: bool = False  # Show context optimizer analysis and metrics
    min_instructions_per_file: int = (
        1  # Minimum instructions per AGENTS.md file (Minimal Context Principle)
    )
    source_attribution: bool = (
        False  # Include source file comments (opt-in; default off to reduce token overhead)
    )
    clean_orphaned: bool = False  # Remove orphaned AGENTS.md files
    exclude: list[str] = None  # Glob patterns for directories to exclude during compilation

    # Deduplication opt-out (issue #1463): when True, instructions are always
    # included in CLAUDE.md regardless of .claude/rules/ contents.
    # Mirrors --force-instructions / --no-dedup CLI flag.
    no_dedup: bool = False

    # Managed-section mode (issue #1540): update only the APM-owned block
    # inside an existing AGENTS.md instead of overwriting the whole file.
    # Set compilation.agents_md.mode: managed_section in apm.yml to enable.
    agents_md_mode: str = "full"
    agents_md_start_marker: str = "<!-- apm:start -->"
    agents_md_end_marker: str = "<!-- apm:end -->"

    def __post_init__(self):
        """Handle CLI flag precedence after initialization."""
        if self.single_agents:
            self.strategy = "single-file"
        # Initialize exclude list if None
        if self.exclude is None:
            self.exclude = []
        if self.agents_md_mode not in VALID_AGENTS_MD_MODES:
            raise ValueError(
                f"Unknown agents_md.mode {self.agents_md_mode!r}. "
                f"Supported values: {', '.join(repr(mode) for mode in VALID_AGENTS_MD_MODES)}."
            )

    @property
    def managed_section_markers(self) -> tuple[str, str] | None:
        """Return the AGENTS.md managed-section markers when that mode is active."""
        if self.agents_md_mode != "managed_section":
            return None
        return (self.agents_md_start_marker, self.agents_md_end_marker)

    @classmethod
    def from_apm_yml(cls, project_root: Path | None = None, **overrides) -> "CompilationConfig":
        """Create configuration from apm.yml with command-line overrides.

        Args:
            project_root: Directory holding apm.yml (default: the working directory).
            **overrides: Command-line arguments that override config file values.

        Returns:
            CompilationConfig: Configuration with apm.yml values and overrides applied.
        """
        config = cls()

        # Try to load from apm.yml
        try:
            from ..core.scope import manifest_file

            manifest = manifest_file(Path(".") if project_root is None else Path(project_root))
            if manifest.exists():
                from ..utils.yaml_io import load_yaml

                apm_config = load_yaml(manifest) or {}

                # Look for compilation section
                compilation_config = apm_config.get("compilation", {})

                apply_compilation_section(config, compilation_config)
        except Exception as exc:
            _logger.debug("Config loading failed, using defaults: %s", exc)

        # Apply command-line overrides (highest priority)
        for key, value in overrides.items():
            if value is not None:  # Only override if explicitly provided
                setattr(config, key, value)

        # Handle CLI flag precedence
        if config.single_agents:
            config.strategy = "single-file"

        return config


@dataclass
class CompilationResult:
    """Result of AGENTS.md compilation."""

    success: bool
    output_path: str
    content: str
    warnings: list[str]
    errors: list[str]
    stats: dict[str, Any]
    has_critical_security: bool = False


class StaleClaudeDetection(NamedTuple):
    """Result of _detect_stale_claude_md: describes a candidate stale CLAUDE.md.

    Attributes:
        path       -- absolute Path to the candidate CLAUDE.md
        rel        -- portable relative path string (for user-facing messages)
        exists     -- True if the file is present on disk
        has_marker -- True if the file contains CLAUDE_HEADER (APM-generated)
        read_error -- non-None error string if the file exists but could not be read
    """

    path: Path
    rel: str
    exists: bool
    has_marker: bool
    read_error: str | None

    @property
    def is_apm_managed(self) -> bool:
        """Return True when the file is readable and carries APM's marker."""
        return self.exists and self.has_marker and self.read_error is None


def _hand_authored_claude_skip_message(
    rel: str,
    *,
    dry_run: bool = False,
    preview: bool = False,
    duplicate_context: bool = True,
) -> str:
    """Build consistent skip guidance for hand-authored CLAUDE.md files."""
    prefix = "[dry-run] would skip removal" if preview or dry_run else "Skipped removal"
    message = f"{prefix} of {rel}: hand-authored file will not be deleted."
    if duplicate_context:
        message += " Delete or rename it manually if duplicate context is unwanted."
    return message


class AgentsCompiler:
    """Main compiler for generating AGENTS.md files."""

    def __init__(self, base_dir: str = ".", source_dir: str | None = None):
        """Initialize the compiler.

        Args:
            base_dir (str): Base directory for compilation -- where AGENTS.md /
                CLAUDE.md outputs are written and the relative root for
                placement decisions.  Defaults to the current directory.
            source_dir (Optional[str]): Where primitives (``.apm/``,
                ``apm_modules/``) and source files are discovered.  Defaults to
                ``base_dir`` for back-compat; set explicitly when ``apm
                compile --root`` redirects writes but sources remain in
                ``$PWD``.
        """
        self.base_dir, self.source_dir = resolve_base_and_source_dirs(base_dir, source_dir)
        self._resolved_base_dir = self.base_dir.resolve()
        self.warnings: list[str] = []
        self.errors: list[str] = []
        self._logger = None
        self._distributed_placement: dict[Path, tuple[Instruction, ...]] | None = None
        self._distributed_context_optimizer: ContextOptimizer | None = None
        self._source_inventory: CompileInventory | None = None
        self._deploy_inventory: CompileInventory | None = None
        self._protected_root_context_paths: set[Path] = set()
        self._agents_md_outputs: set[Path] = set()
        self._claude_consumes_agents_md = False

    def _log(self, method: str, message: str, **kwargs):
        """Delegate to logger if available, else no-op."""
        if self._logger:
            getattr(self._logger, method)(message, **kwargs)

    def _get_distributed_placement(
        self,
        config: CompilationConfig,
        primitives: PrimitiveCollection,
        compiler: "DistributedAgentsCompiler",
    ) -> dict[Path, list[Instruction]]:
        """Compute placement once per compile and return an isolated projection."""
        if self._distributed_placement is None:
            directory_map = compiler.analyze_directory_structure(primitives.instructions)
            placement = compiler.determine_agents_placement(
                primitives.instructions,
                directory_map,
                min_instructions=config.min_instructions_per_file,
                debug=config.debug,
            )
            self._distributed_placement = {
                path: tuple(instructions) for path, instructions in placement.items()
            }
            self._distributed_context_optimizer = compiler.context_optimizer
        elif self._distributed_context_optimizer is not None:
            # Reporting for every target must use the analysis that produced
            # the shared placement, even though each target has its own compiler.
            compiler.context_optimizer = self._distributed_context_optimizer

        return {
            path: list(instructions) for path, instructions in self._distributed_placement.items()
        }

    def compile(
        self,
        config: CompilationConfig,
        primitives: PrimitiveCollection | None = None,
        logger=None,
        root_outputs: frozenset[str] | None = None,
    ) -> CompilationResult:
        """Compile AGENTS.md and/or CLAUDE.md based on target configuration.

        Args:
            config (CompilationConfig): Compilation configuration.
            primitives (Optional[PrimitiveCollection]): Primitives to use, or None to discover.
            root_outputs: Root artifact families to return. Defaults to all routed families.

        Returns:
            CompilationResult: Result of the compilation.
        """
        self.warnings.clear()
        self.errors.clear()
        self._protected_root_context_paths.clear()
        self._agents_md_outputs.clear()
        self._logger = logger
        # Placement is valid only for this invocation's primitive snapshot.
        self._distributed_placement = None
        self._distributed_context_optimizer = None
        self._source_inventory = CompileInventory.collect(
            self.source_dir, exclude_patterns=config.exclude
        )
        self._deploy_inventory = (
            self._source_inventory
            if self.source_dir == self.base_dir and not config.exclude
            else CompileInventory.collect(self.base_dir)
        )
        try:
            if primitives is None:
                if config.local_only:
                    primitives = discover_primitives(
                        str(self.source_dir),
                        exclude_patterns=config.exclude,
                        inventory=self._source_inventory,
                    )
                else:
                    from ..primitives.discovery import discover_primitives_with_dependencies

                    primitives = discover_primitives_with_dependencies(
                        str(self.source_dir),
                        exclude_patterns=config.exclude,
                        inventory=self._source_inventory,
                    )

            if isinstance(config.target, frozenset):
                invalid_families = config.target - _KNOWN_COMPILE_FAMILIES
                if invalid_families:
                    self.errors.append(
                        "Unknown compilation target family in multi-target set: "
                        f"{', '.join(sorted(invalid_families))}. "
                        "Expected subset of: "
                        f"{', '.join(sorted(_KNOWN_COMPILE_FAMILIES))}"
                    )
                    return CompilationResult(
                        success=False,
                        output_path="",
                        content="",
                        warnings=self.warnings.copy(),
                        errors=self.errors.copy(),
                        stats={},
                    )
                routing_target = config.target
            else:
                routing_target = (
                    "vscode" if config.target in _VSCODE_TARGET_ALIASES else config.target
                )

                if routing_target not in _KNOWN_TARGETS and config.target not in _KNOWN_TARGETS:
                    self.errors.append(
                        f"Unknown compilation target: {config.target!r}. "
                        f"Expected one of: {', '.join(sorted(set(_KNOWN_TARGETS)))}"
                    )
                    return CompilationResult(
                        success=False,
                        output_path="",
                        content="",
                        warnings=self.warnings.copy(),
                        errors=self.errors.copy(),
                        stats={},
                    )

            results: list[CompilationResult] = []
            requested_outputs = (
                frozenset({"agents", "claude", "gemini"}) if root_outputs is None else root_outputs
            )

            agents_failed = False
            # Claude reads these AGENTS.md outputs, so compile records their coverage.
            self._claude_consumes_agents_md = "claude" in requested_outputs and (
                should_compile_claude_md(routing_target)
            )
            if "agents" in requested_outputs and should_compile_agents_md(routing_target):
                agents_result = self._compile_agents_md(config, primitives)
                results.append(agents_result)
                agents_failed = not agents_result.success

            # CLAUDE.md imports the AGENTS.md just written; after a failed
            # AGENTS.md batch no shim may point at a missing file (#4787).
            if (
                "claude" in requested_outputs
                and should_compile_claude_md(routing_target)
                and not agents_failed
            ):
                results.append(self._compile_claude_md(config, primitives))

            if "gemini" in requested_outputs and should_compile_gemini_md(routing_target):
                results.append(self._compile_gemini_md(config, primitives))

            # Targets without a compile family (skills-only, experimental) use
            # only the integration layer and have no root-context output.
            if not results:
                if logger and (no_output := target_without_compile_output(config.target)):
                    logger.progress(
                        f"{no_output.name} -- no compile outputs, skipping",
                        symbol="info",
                    )
                return CompilationResult(
                    success=True,
                    output_path="",
                    content="",
                    warnings=self.warnings.copy(),
                    errors=self.errors.copy(),
                    stats={},
                )

            # Merge results from all targets
            return self._merge_results(results)

        except Exception as e:
            self.errors.append(f"Compilation failed: {e!s}")
            return CompilationResult(
                success=False,
                output_path="",
                content="",
                warnings=self.warnings.copy(),
                errors=self.errors.copy(),
                stats={},
            )

    def _compile_agents_md(
        self, config: CompilationConfig, primitives: PrimitiveCollection
    ) -> CompilationResult:
        """Compile AGENTS.md files (VSCode/Copilot target).

        Args:
            config (CompilationConfig): Compilation configuration.
            primitives (PrimitiveCollection): Primitives to compile.

        Returns:
            CompilationResult: Result of the AGENTS.md compilation.
        """
        if is_claude_only_target(config.target) and not config.no_dedup:
            claude_primitives = without_claude_rule_instructions(
                primitives, self.base_dir, lambda msg: self._log("warning", msg)
            )
            if claude_primitives is not primitives:
                self._log(
                    "progress",
                    "Instructions already in .claude/rules/ -- omitting them from"
                    " AGENTS.md to avoid duplicate context",
                    symbol="info",
                )
            primitives = claude_primitives
        if is_claude_only_target(config.target) and (
            config.strategy != "distributed" or config.single_agents
        ):
            primitives = without_directory_instructions(
                primitives, lambda msg: self.warnings.append(msg)
            )
        # Handle distributed compilation (Task 7 - new default behavior)
        if config.strategy == "distributed" and not config.single_agents:
            result = self._compile_distributed(config, primitives)
        else:
            # Traditional single-file compilation (backward compatibility)
            result = self._compile_single_file(config, primitives)

        return self._maybe_emit_copilot_root_instructions(config, primitives, result)

    def _compile_distributed(
        self, config: CompilationConfig, primitives: PrimitiveCollection
    ) -> CompilationResult:
        """Compile using distributed AGENTS.md approach (Task 7).

        Args:
            config (CompilationConfig): Compilation configuration.
            primitives (PrimitiveCollection): Primitives to compile.

        Returns:
            CompilationResult: Result of distributed compilation.
        """
        from .distributed_compiler import DistributedAgentsCompiler

        errors = self.validate_primitives(primitives)
        self.errors.extend(errors)

        # Create distributed compiler with exclude patterns.  source_dir
        # carries through so primitive discovery + project-tree scoring
        # honor `apm compile --root` (sources stay in $PWD, writes
        # redirect to base_dir).
        distributed_compiler = DistributedAgentsCompiler(
            str(self.base_dir),
            exclude_patterns=config.exclude,
            source_dir=str(self.source_dir),
            source_inventory=self._source_inventory,
            deploy_inventory=self._deploy_inventory,
            managed_section_markers=config.managed_section_markers,
        )

        # Skip instructions in AGENTS.md when they are already deployed to the
        # target's dedicated rules directory (e.g., .github/instructions/ for Copilot
        # or .agents/rules/ for Antigravity) by `apm install` (avoids duplicate context
        # for agents that read both locations). Mirrors the .claude/rules/ check
        # on the Claude path (issue #1445); shared helper keeps the detection
        # logic in one place (R0801 guard).
        #
        # Target-aware: only dedup when EVERY AGENTS.md consumer also reads the
        # target-specific rules directory. Codex, OpenCode, Windsurf rely solely on
        # AGENTS.md for instructions, so dedup must not fire for those
        # targets (issue #1678).
        # --force-instructions / --no-dedup lets users opt out entirely.
        dedup_coverage = "deployed rules already cover this target"
        if config.no_dedup:
            skip_instructions = False
            self._log(
                "progress",
                "Including instructions in AGENTS.md (--force-instructions overrides deduplication)",
                symbol="info",
            )
        else:
            dedup_rules = get_dedup_rules_dir(config.target)
            if dedup_rules is None:
                skip_instructions = False
            else:
                rules_dir_rel, target_key = dedup_rules
                dep_dir = self.base_dir / rules_dir_rel
                log_dep_dir = f"{rules_dir_rel}/"
                dedup_coverage = f"{log_dep_dir} already covers {target_key.title()}"

                expected_filenames = _build_expected_rule_filenames(target_key, primitives)

                skip_instructions = _detect_deployed_instructions(
                    dep_dir,
                    self.base_dir,
                    lambda msg: self._log("warning", msg),
                    expected_filenames=expected_filenames,
                )
                if skip_instructions:
                    self._log(
                        "progress",
                        f"Instructions already in {log_dep_dir} -- omitting from"
                        " AGENTS.md to avoid duplicate context",
                        symbol="info",
                    )

        # Prepare configuration for distributed compilation
        distributed_config = {
            "min_instructions_per_file": config.min_instructions_per_file,
            # max_depth removed - full project analysis
            "source_attribution": config.source_attribution,
            "debug": config.debug,
            "clean_orphaned": config.clean_orphaned,
            "defer_orphan_cleanup": True,
            "defer_orphan_warnings": config.agents_md_mode == "managed_section",
            "dry_run": config.dry_run,
            "skip_instructions": skip_instructions,
            "with_constitution": config.with_constitution,
            "agents_md_mode": config.agents_md_mode,
            "placement_map": self._get_distributed_placement(
                config,
                primitives,
                distributed_compiler,
            ),
        }
        if is_claude_only_target(config.target):
            distributed_config["placement_map"] = pin_directory_placements(
                distributed_config["placement_map"],
                self.base_dir,
                lambda msg: self.warnings.append(msg),
                source_dir=self.source_dir,
            )

        # Compile distributed
        distributed_result = distributed_compiler.compile_distributed(
            primitives, distributed_config
        )

        if not distributed_result.success:
            self.warnings.extend(distributed_result.warnings)
            self.errors.extend(distributed_result.errors)
            return CompilationResult(
                success=False,
                output_path="",
                content="",
                warnings=self.warnings.copy(),
                errors=self.errors.copy(),
                stats=distributed_result.stats,
            )

        # Emit the user-visible INFO message for suppressed empty-shell placements.
        # Mirrors the CLAUDE.md analogue (agents_compiler.py:785-791).
        # This fires for both normal and dry-run modes so the user understands
        # why certain AGENTS.md files are absent.
        # Under partial suppression (some placements written, some suppressed) the
        # message clarifies that only the *suppressed* placements are absent so
        # users are not confused by the AGENTS.md files that *were* written.
        if distributed_result.suppressed_empty_paths:
            suppressed_count = len(distributed_result.suppressed_empty_paths)
            noun = "file" if suppressed_count == 1 else "files"
            if distributed_result.content_map:
                # Partial suppression: at least one AGENTS.md was written
                self._log(
                    "progress",
                    f"Skipped {suppressed_count} empty AGENTS.md {noun} -- "
                    f"{dedup_coverage}; "
                    "pass --force-instructions to write all AGENTS.md files",
                    symbol="info",
                )
            else:
                # Full suppression: no AGENTS.md written at all
                self._log(
                    "progress",
                    f"AGENTS.md not generated ({suppressed_count} {noun}) -- "
                    f"{dedup_coverage}; "
                    "pass --force-instructions to write AGENTS.md",
                    symbol="info",
                )

        pending_outputs: dict[Path, str] = {}
        preserve_line_endings: dict[Path, bool] = {}
        protected_before = set(self._protected_root_context_paths)
        for agents_path, content in distributed_result.content_map.items():
            try:
                prepared_content = self._prepare_distributed_file(agents_path, content, config)
                if prepared_content is not None:
                    pending_outputs[agents_path] = prepared_content
                    preserve_line_endings[agents_path] = (
                        config.agents_md_mode == "managed_section" and agents_path.is_file()
                    )
            except (OSError, ValueError) as e:
                self.errors.append(f"Failed to write {agents_path}: {e!s}")

        if self.errors:
            self.warnings.extend(distributed_result.warnings)
            self.errors.extend(distributed_result.errors)
            return CompilationResult(
                success=False,
                output_path="",
                content="",
                warnings=self.warnings.copy(),
                errors=self.errors.copy(),
                stats=distributed_result.stats,
            )

        cleanup_paths = distributed_result.orphaned_files
        managed_orphans: list[Path] = []
        if config.agents_md_mode == "managed_section":
            cleanup_paths = []
            for path in distributed_result.orphaned_files:
                if self._has_managed_section_markers(path, config):
                    managed_orphans.append(path)
                else:
                    cleanup_paths.append(path)
            if config.clean_orphaned and config.dry_run and cleanup_paths:
                self.warnings.extend(
                    distributed_compiler._cleanup_orphaned_files(cleanup_paths, dry_run=True)
                )
            if managed_orphans:
                self.warnings.append(self._managed_orphan_retention_warning(managed_orphans))
            if not config.clean_orphaned and cleanup_paths:
                self.warnings.extend(distributed_compiler._generate_orphan_warnings(cleanup_paths))

        # Display professional compilation output only after the canonical
        # preparation gate, so previews include exactly the eligible write set.
        compilation_results = distributed_compiler.get_compilation_results_for_display(
            config.dry_run
        )
        if compilation_results and pending_outputs:
            compilation_results = replace(
                compilation_results,
                placement_summaries=[
                    summary
                    for summary in compilation_results.placement_summaries
                    if summary.path / "AGENTS.md" in pending_outputs
                ],
                optimization_stats=replace(
                    compilation_results.optimization_stats,
                    total_agents_files=len(pending_outputs),
                ),
            )
            if config.debug or config.trace:
                output = distributed_compiler.output_formatter.format_verbose(compilation_results)
            elif config.dry_run:
                output = distributed_compiler.output_formatter.format_dry_run(compilation_results)
            else:
                output = distributed_compiler.output_formatter.format_default(compilation_results)
            self._log("progress", output)

        # Handle dry-run mode after the canonical preparation gate so its
        # reported placements match the files a real compile can write.
        protected_agents_paths = self._protected_root_context_paths - protected_before
        protected_agents_count = len(protected_agents_paths)
        skipped_agents_count = len(distributed_result.content_map) - len(pending_outputs)
        nested_git_skips = max(0, skipped_agents_count - protected_agents_count)
        distributed_result.stats["root_context_files_protected"] = protected_agents_count
        if config.dry_run:
            self._agents_md_outputs.update(pending_outputs)
            distributed_result.stats["agents_files_generated"] = len(pending_outputs)
            distributed_result.stats["nested_git_placements_skipped"] = nested_git_skips
            return CompilationResult(
                success=len(self.errors) == 0,
                output_path="Preview mode - no files written",
                content=self._generate_placement_summary(distributed_result, pending_outputs),
                warnings=(self.warnings + distributed_result.warnings),
                errors=self.errors + distributed_result.errors,
                stats=distributed_result.stats,
            )

        # Write distributed AGENTS.md files
        successful_writes = 0
        if pending_outputs:
            from .output_writer import CompiledOutputPolicyError, CompiledOutputWriter

            try:
                CompiledOutputWriter(self.base_dir).write_many(
                    pending_outputs,
                    preserve_line_endings=preserve_line_endings,
                )
                successful_writes = len(pending_outputs)
                self._agents_md_outputs.update(pending_outputs)
            except (OSError, CompiledOutputPolicyError) as exc:
                self.errors.append(f"Failed to write distributed output batch: {exc}")
        if successful_writes and self._claude_consumes_agents_md:
            record_compiled_instructions(
                self.base_dir,
                {
                    placement.agents_path: [] if skip_instructions else placement.instructions
                    for placement in distributed_result.placements
                    if placement.agents_path in pending_outputs
                },
            )

        if not self.errors and config.clean_orphaned and cleanup_paths:
            cleanup_messages = distributed_compiler._cleanup_orphaned_files(cleanup_paths)
            self.warnings.extend(cleanup_messages)
        # Update stats with actual files written
        distributed_result.stats["agents_files_generated"] = successful_writes
        distributed_result.stats["nested_git_placements_skipped"] = nested_git_skips

        # Merge warnings and errors
        self.warnings.extend(distributed_result.warnings)
        self.errors.extend(distributed_result.errors)

        # Create summary for backward compatibility
        summary_content = self._generate_distributed_summary(distributed_result, config)

        return CompilationResult(
            success=len(self.errors) == 0,
            output_path=f"Distributed: {successful_writes} AGENTS.md files",
            content=summary_content,
            warnings=self.warnings.copy(),
            errors=self.errors.copy(),
            stats=distributed_result.stats,
        )

    def _compile_single_file(
        self, config: CompilationConfig, primitives: PrimitiveCollection
    ) -> CompilationResult:
        """Compile using traditional single-file approach (backward compatibility).

        Args:
            config (CompilationConfig): Compilation configuration.
            primitives (PrimitiveCollection): Primitives to compile.

        Returns:
            CompilationResult: Result of single-file compilation.
        """
        # Validate primitives
        validation_errors = self.validate_primitives(primitives)
        if validation_errors:
            self.errors.extend(validation_errors)

        # Generate template data
        template_data = self._generate_template_data(primitives, config)

        # Generate final output
        content = self.generate_output(template_data, config)

        # Write output file (constitution injection handled externally in CLI)
        output_file = self.base_dir / config.output_path
        output_path = str(output_file)
        refuse_unsafe_output(
            output_file, self.base_dir, managed=config.agents_md_mode == "managed_section"
        )
        write_blocked = (
            config.agents_md_mode != "managed_section"
            and self._hand_authored_root_context_blocks_write(output_file)
        )
        errors_before = len(self.errors)
        if not config.dry_run and not write_blocked:
            self._write_output_file_with_config(output_path, content, config)
        written = len(self.errors) == errors_before
        if not write_blocked and written and output_file.name == "AGENTS.md":
            self._agents_md_outputs.add(output_file)
            if not config.dry_run and self._claude_consumes_agents_md:
                record_compiled_instructions(
                    self.base_dir, {output_file: list(primitives.instructions)}
                )

        # Compile statistics
        stats = self._compile_stats(primitives, template_data)
        stats["agents_root_context_write_blocked"] = int(write_blocked)
        stats["root_context_files_protected"] = int(write_blocked)

        return CompilationResult(
            success=len(self.errors) == 0,
            output_path=output_path,
            content=content,
            warnings=self.warnings.copy(),
            errors=self.errors.copy(),
            stats=stats,
        )

    def _detect_stale_claude_md(
        self,
    ) -> StaleClaudeDetection:
        """Detect whether a stale APM-generated CLAUDE.md exists at the project root.

        Returns a StaleClaudeDetection with fields:
            path      -- absolute Path to the candidate CLAUDE.md
            rel       -- portable relative path string (for user-facing messages)
            exists    -- True if the file is present on disk
            has_marker -- True if the file contains CLAUDE_HEADER (APM-generated)
            read_error -- non-None error string if the file exists but could not be read

        Both the dry-run preview block and the live removal block share this
        helper so the read + marker-detect + rel computation lives in one place.
        """
        root_claude_md = self.base_dir / "CLAUDE.md"
        rel = portable_relpath(root_claude_md, self.base_dir)
        if not root_claude_md.exists():
            return StaleClaudeDetection(root_claude_md, rel, False, False, None)
        if root_claude_md.is_symlink():
            return StaleClaudeDetection(
                root_claude_md,
                rel,
                True,
                False,
                f"Retained {rel}: root context symlinks are not removed by --clean.",
            )
        try:
            ensure_path_within(root_claude_md, self.base_dir)
            with root_claude_md.open("rb") as fh:
                # CLAUDE_HEADER is emitted on the first line; 4 KiB is ample.
                content = decode_utf8_prefix(fh.read(4096))
        except (OSError, PathTraversalError, UnicodeDecodeError) as exc:
            return StaleClaudeDetection(
                root_claude_md, rel, True, False, f"Could not read {rel}: {exc!s}"
            )
        return StaleClaudeDetection(
            root_claude_md,
            rel,
            True,
            has_generated_marker_header(content, (CLAUDE_HEADER,)),
            None,
        )

    def _compile_claude_md(
        self, config: CompilationConfig, primitives: PrimitiveCollection
    ) -> CompilationResult:
        """Compile CLAUDE.md files that import AGENTS.md (Claude Code target).

        Instructions reach Claude through the AGENTS.md outputs compiled just
        before this step (#3939); path-scoped ones stay in ``.claude/rules/``.
        Each CLAUDE.md imports its sibling ``@AGENTS.md`` so both load on
        every Claude Code version, plus dependency memory at the root.

        Args:
            config (CompilationConfig): Compilation configuration.
            primitives (PrimitiveCollection): Primitives to compile.

        Returns:
            CompilationResult: Result of the CLAUDE.md compilation.
        """
        errors = self.validate_primitives(primitives)
        self.errors.extend(errors)

        claude_formatter = ClaudeFormatter(str(self.base_dir), source_dir=str(self.source_dir))
        # No AGENTS.md output means .claude/rules/ already covers every instruction.
        skip_instructions = bool(primitives.instructions) and not self._agents_md_outputs
        root_agents_written = self.base_dir / "AGENTS.md" in self._agents_md_outputs
        claude_result = claude_formatter.format_agents_md_imports(
            primitives,
            self._agents_md_outputs,
            {
                "source_attribution": config.source_attribution,
                "include_constitution": not root_agents_written,
            },
        )

        user_imports = {
            path
            for path in claude_result.content_map
            if user_claude_md_imports_agents_md(path, self.base_dir)
        }
        claude_result.content_map = {
            path: content
            for path, content in claude_result.content_map.items()
            if path not in user_imports
        }
        protected_claude_paths = {
            path
            for path in claude_result.content_map
            if self._hand_authored_root_context_blocks_write(path)
        }
        if protected_claude_paths or user_imports:
            retained = protected_claude_paths | user_imports
            claude_result.content_map = {
                path: content
                for path, content in claude_result.content_map.items()
                if path not in retained
            }
            claude_result.placements = [
                placement
                for placement in claude_result.placements
                if placement.claude_path not in retained
            ]
            claude_result.stats = claude_formatter._compile_stats(
                claude_result.placements, primitives
            )
            for path in sorted(protected_claude_paths):
                agents_md = path.parent / "AGENTS.md"
                if agents_md in self._agents_md_outputs and not claude_md_imports_agents_md(
                    path, self.base_dir
                ):
                    rel = portable_relpath(path, self.base_dir)
                    self.warnings.append(
                        f"Claude Code will not load {portable_relpath(agents_md, self.base_dir)}"
                        f" while {rel} does not import it: add '@AGENTS.md' to {rel}."
                    )

        # NOTE: Claude commands are now generated at install time via CommandIntegrator,
        # not at compile time. This keeps behavior consistent with VSCode prompt integration.

        # Merge warnings and errors (no command result anymore)
        all_warnings = self.warnings + claude_result.warnings
        all_errors = self.errors + claude_result.errors

        # Fires when content moved to .claude/rules/ or no source primitives remain.
        # Dry-run preview, live removal, and formatter suppression share this signal.
        would_emit_no_claude_md = len(claude_result.content_map) == 0
        orphan_reason = (
            "instructions now live in .claude/rules/"
            if skip_instructions
            else "no source primitives remain"
        )

        # Handle dry-run mode
        if config.dry_run:
            # Generate preview summary
            count = len(claude_result.placements)
            preview_lines = [
                f"CLAUDE.md Preview: Would generate {count} {'file' if count == 1 else 'files'}"
            ]
            # Surface the deduplication skip so dry-run is self-explanatory
            # for scripted consumers (otherwise "Would generate 0 files"
            # looks like a no-op or a bug). The same skip appears in the
            # non-dry-run path via the dedicated INFO log line.
            if skip_instructions:
                preview_lines.append(
                    "  (instructions section skipped: .claude/rules/ already "
                    "populated -- avoids duplicate content in Claude Code's "
                    "context window)"
                )
            for claude_path in claude_result.content_map.keys():  # noqa: SIM118
                rel_path = portable_relpath(claude_path, self.base_dir)
                preview_lines.append(f"  {rel_path}")
            # Preview stale CLAUDE.md removal so --dry-run --clean is self-explanatory.
            # Read the file here (safe in dry-run: we never mutate it) to check for
            # the APM marker, mirroring the Copilot root-instructions convention.
            # Only show the preview when no CLAUDE.md would be written -- a project
            # WITH a constitution emits a CLAUDE.md and should NOT show a removal preview.
            if would_emit_no_claude_md and config.clean_orphaned and not user_imports:
                det = self._detect_stale_claude_md()
                if det.exists:
                    if det.read_error is not None:
                        all_warnings.append(det.read_error)
                        # Emit via logger so it surfaces on the distributed dry-run path
                        # (cli.py does `pass` on dry-run success and never prints
                        # result.content -- issue #1729 fix).
                        self._log("warning", det.read_error)
                    elif det.is_apm_managed:
                        removal_msg = f"[dry-run] would remove stale {det.rel} -- {orphan_reason}"
                        preview_lines.append(f"  {removal_msg}")
                        # Emit the preview through the logger so it reaches the terminal
                        # on the distributed dry-run path (cli.py does `pass` on dry-run
                        # success and never prints result.content -- issue #1729 fix).
                        self._log(
                            "progress",
                            removal_msg,
                            symbol="info",
                        )
                    else:
                        # Hand-authored CLAUDE.md (no APM marker): the live --clean run
                        # would skip deletion and warn. Surface the same intent in
                        # dry-run so users are not surprised by the live outcome.
                        hand_authored_preview = _hand_authored_claude_skip_message(
                            det.rel,
                            preview=True,
                            duplicate_context=skip_instructions,
                        )
                        preview_lines.append(f"  {hand_authored_preview}")
                        all_warnings.append(
                            _hand_authored_claude_skip_message(
                                det.rel,
                                dry_run=True,
                                duplicate_context=skip_instructions,
                            )
                        )
                        # Emit via logger so it surfaces on the distributed dry-run path
                        # (cli.py does `pass` on dry-run success and never prints
                        # result.content -- issue #1729 fix).
                        self._log("progress", hand_authored_preview, symbol="info")

            stats = claude_result.stats.copy()
            stats["root_context_files_protected"] = len(protected_claude_paths)
            return CompilationResult(
                success=len(all_errors) == 0,
                output_path="Preview mode - CLAUDE.md",
                content="\n".join(preview_lines),
                warnings=all_warnings,
                errors=all_errors,
                stats=stats,
            )

        # Write CLAUDE.md files
        files_written = 0
        critical_security_found = False
        from .output_writer import CompiledOutputPolicyError, CompiledOutputWriter

        writer = CompiledOutputWriter(self.base_dir)
        pending_outputs: dict[Path, str] = {}
        for claude_path, content in claude_result.content_map.items():
            final_content = content
            if config.with_constitution and not root_agents_written:
                try:
                    from .injector import ConstitutionInjector

                    injector = ConstitutionInjector(str(claude_path.parent))
                    final_content, _, _ = injector.inject(
                        content, with_constitution=True, output_path=claude_path
                    )
                except Exception as exc:
                    _logger.debug("Constitution injection failed for %s: %s", claude_path, exc)
            pending_outputs[claude_path] = final_content
        try:
            verdict = writer.write_many(pending_outputs)
            files_written = len(pending_outputs)
            for filename, findings in verdict.findings_by_file.items():
                all_warnings.append(
                    f"CLAUDE.md contains {len(findings)} hidden character(s) "
                    f"-- run 'apm audit --file {filename}' to inspect"
                )
        except CompiledOutputPolicyError as exc:
            critical_security_found = True
            all_errors.append(str(exc))
        except OSError as exc:
            all_errors.append(f"Failed to write CLAUDE.md output batch: {exc!s}")

        # Update stats
        stats = claude_result.stats.copy()
        stats["claude_files_written"] = files_written
        stats["root_context_files_protected"] = len(protected_claude_paths)
        stats["claude_empty_due_to_no_primitives"] = (
            would_emit_no_claude_md and not skip_instructions
        )
        stats["claude_native_rules_only"] = would_emit_no_claude_md and skip_instructions

        if would_emit_no_claude_md:
            if protected_claude_paths:
                no_output_message = (
                    "CLAUDE.md not generated -- protected hand-authored file retained"
                )
            elif user_imports:
                no_output_message = "CLAUDE.md retained -- it already imports @AGENTS.md"
            elif skip_instructions:
                no_output_message = (
                    "CLAUDE.md not generated -- Claude Code reads .claude/rules/"
                    " directly, no further action needed"
                )
            else:
                no_output_message = "CLAUDE.md not generated -- no source primitives remain"
            self._log("progress", no_output_message, symbol="info")
            # Remove a stale APM-generated CLAUDE.md when --clean is set.
            # A hand-authored file (no CLAUDE_HEADER marker) is never deleted;
            # a warning is emitted instead to match the Copilot-root convention.
            # Dry-run mode returns earlier in this method, so this live block is
            # only reached when NOT in dry-run; no config.dry_run guard is needed.
            # Gate on clean_orphaned so plain `apm compile` (no --clean) does NO
            # extra disk I/O and emits NO stale-file warnings (non-destructive by design).
            if config.clean_orphaned and not (protected_claude_paths or user_imports):
                det = self._detect_stale_claude_md()
                if det.exists:
                    if det.read_error is not None:
                        all_warnings.append(det.read_error)
                        self._log("warning", det.read_error)
                    elif det.is_apm_managed:
                        try:
                            ensure_path_within(det.path, self.base_dir)
                            det.path.unlink()  # safe: containment + APM marker confirmed above
                            # success() uses its own default symbol; no symbol= kwarg
                            # needed (unlike the progress() calls elsewhere here).
                            self._log(
                                "success",
                                f"Removed stale {det.rel} -- {orphan_reason}",
                            )
                        except (OSError, PathTraversalError) as exc:
                            warning = f"Could not remove {det.rel}: {exc!s}"
                            all_warnings.append(warning)
                            self._log("warning", warning)
                    else:
                        warning = _hand_authored_claude_skip_message(
                            det.rel,
                            duplicate_context=skip_instructions,
                        )
                        all_warnings.append(warning)
                        self._log("warning", warning)
        elif files_written > 0:
            noun = "file" if files_written == 1 else "files"
            self._log(
                "progress",
                f"Generated {files_written} CLAUDE.md {noun} (imports AGENTS.md)",
                symbol="success",
            )

        # Generate summary content for result object
        summary_lines = [
            f"# CLAUDE.md Compilation Summary",  # noqa: F541
            f"",  # noqa: F541
            f"Generated {files_written} CLAUDE.md files:",
        ]
        for placement in claude_result.placements:
            rel_path = portable_relpath(placement.claude_path, self.base_dir)
            summary_lines.append(f"- {rel_path} (imports AGENTS.md)")

        return CompilationResult(
            success=len(all_errors) == 0,
            output_path=f"CLAUDE.md: {files_written} files",
            content="\n".join(summary_lines),
            warnings=all_warnings,
            errors=all_errors,
            stats=stats,
            has_critical_security=critical_security_found,
        )

    def _compile_gemini_md(
        self, config: CompilationConfig, primitives: PrimitiveCollection
    ) -> CompilationResult:
        """Compile GEMINI.md stub that imports AGENTS.md.

        Gemini CLI supports ``@./path`` import syntax, so GEMINI.md is a
        thin wrapper that pulls in AGENTS.md at load time.  The actual
        instruction roll-up is handled by the AGENTS.md pipeline (which
        is always compiled alongside via ``should_compile_agents_md``).

        Args:
            config: Compilation configuration.
            primitives: Primitives to compile.

        Returns:
            CompilationResult for the GEMINI.md compilation.
        """
        from .gemini_formatter import GeminiFormatter

        gemini_formatter = GeminiFormatter(str(self.base_dir))
        gemini_result = gemini_formatter.format_distributed(primitives, dry_run=config.dry_run)

        protected_gemini_paths = {
            path
            for path in gemini_result.content_map
            if self._hand_authored_root_context_blocks_write(path)
        }
        if protected_gemini_paths:
            gemini_result.content_map = {
                path: content
                for path, content in gemini_result.content_map.items()
                if path not in protected_gemini_paths
            }
            gemini_result.placements = [
                placement
                for placement in gemini_result.placements
                if placement.gemini_path not in protected_gemini_paths
            ]
            gemini_result.stats["gemini_files_generated"] = len(gemini_result.placements)

        all_warnings = self.warnings + gemini_result.warnings
        all_errors = self.errors + gemini_result.errors

        if config.dry_run:
            count = len(gemini_result.placements)
            return CompilationResult(
                success=len(all_errors) == 0,
                output_path="Preview mode - GEMINI.md",
                content=(
                    "GEMINI.md Preview: Would generate stub importing AGENTS.md"
                    if count
                    else "GEMINI.md Preview: Would generate 0 files"
                ),
                warnings=all_warnings,
                errors=all_errors,
                stats={
                    **gemini_result.stats,
                    "root_context_files_protected": len(protected_gemini_paths),
                },
            )

        files_written = 0
        from .output_writer import CompiledOutputPolicyError, CompiledOutputWriter

        writer = CompiledOutputWriter(self.base_dir)
        try:
            writer.write_many(gemini_result.content_map)
            files_written = len(gemini_result.content_map)
        except (OSError, CompiledOutputPolicyError) as exc:
            all_errors.append(f"Failed to write GEMINI.md output batch: {exc!s}")

        stats = gemini_result.stats.copy()
        stats["gemini_files_written"] = files_written
        stats["root_context_files_protected"] = len(protected_gemini_paths)

        if files_written:
            self._log("progress", "Generated GEMINI.md (imports AGENTS.md)")
        elif protected_gemini_paths:
            self._log(
                "progress",
                "GEMINI.md not generated -- protected hand-authored root file retained",
                symbol="info",
            )

        return CompilationResult(
            success=len(all_errors) == 0,
            output_path=f"GEMINI.md: {files_written} files",
            content=f"Generated {files_written} GEMINI.md stub importing AGENTS.md",
            warnings=all_warnings,
            errors=all_errors,
            stats=stats,
        )

    def _merge_results(self, results: list[CompilationResult]) -> CompilationResult:
        """Merge multiple compilation results into a single result.

        Combines warnings, errors, stats, and content from multiple target
        compilations into a unified result.

        Args:
            results (List[CompilationResult]): List of compilation results to merge.

        Returns:
            CompilationResult: Merged compilation result.
        """
        if not results:
            return CompilationResult(
                success=True, output_path="", content="", warnings=[], errors=[], stats={}
            )

        if len(results) == 1:
            return results[0]

        # Merge all results
        merged_warnings: list[str] = []
        merged_errors: list[str] = []
        merged_stats: dict[str, Any] = {}
        output_paths: list[str] = []
        content_parts: list[str] = []

        for result in results:
            merged_warnings.extend(result.warnings)
            merged_errors.extend(result.errors)

            # Merge stats with prefixes to avoid collisions
            for key, value in result.stats.items():
                if key in merged_stats:
                    # Handle numeric stats by summing
                    if isinstance(value, (int, float)) and isinstance(
                        merged_stats[key], (int, float)
                    ):
                        merged_stats[key] = merged_stats[key] + value
                else:
                    merged_stats[key] = value

            if result.output_path:
                output_paths.append(result.output_path)
            if result.content:
                content_parts.append(result.content)

        # Determine overall success
        overall_success = all(r.success for r in results)

        return CompilationResult(
            success=overall_success,
            output_path=" | ".join(output_paths) if output_paths else "",
            content="\n\n---\n\n".join(content_parts) if content_parts else "",
            warnings=list(dict.fromkeys(merged_warnings)),
            errors=list(dict.fromkeys(merged_errors)),
            stats=merged_stats,
            has_critical_security=any(r.has_critical_security for r in results),
        )

    def validate_primitives(self, primitives: PrimitiveCollection) -> list[str]:
        """Validate primitives for compilation.

        Args:
            primitives (PrimitiveCollection): Collection of primitives to validate.

        Returns:
            List[str]: List of validation errors.
        """
        errors = []

        # Validate each primitive
        for primitive in primitives.all_primitives():
            primitive_errors = primitive.validate()
            if primitive_errors:
                # Source files live under source_dir; relativise display
                # paths against it so `apm compile --root` doesn't render
                # absolute or `../../` paths in warning messages.
                file_path = portable_relpath(primitive.file_path, self.source_dir)

                for error in primitive_errors:
                    # Treat validation errors as warnings instead of hard errors
                    # This allows compilation to continue with incomplete primitives
                    self.warnings.append(f"{file_path}: {error}")

            # Validate markdown links in each primitive's content using its own directory as base
            if hasattr(primitive, "content") and primitive.content:
                primitive_dir = primitive.file_path.parent
                link_errors = validate_link_targets(primitive.content, primitive_dir)
                if link_errors:
                    file_path = portable_relpath(primitive.file_path, self.source_dir)

                    for link_error in link_errors:
                        self.warnings.append(f"{file_path}: {link_error}")

        return errors

    def generate_output(self, template_data: TemplateData, config: CompilationConfig) -> str:
        """Generate the final AGENTS.md output.

        Args:
            template_data (TemplateData): Data for template generation.
            config (CompilationConfig): Compilation configuration.

        Returns:
            str: Generated AGENTS.md content.
        """
        content = generate_agents_md_template(template_data, config.agents_md_mode)

        # Resolve markdown links if enabled
        if config.resolve_links:
            content = resolve_markdown_links(content, self.base_dir)

        return content

    def _generate_template_data(
        self, primitives: PrimitiveCollection, config: CompilationConfig
    ) -> TemplateData:
        """Generate template data from primitives and configuration.

        Args:
            primitives (PrimitiveCollection): Discovered primitives.
            config (CompilationConfig): Compilation configuration.

        Returns:
            TemplateData: Template data for generation.
        """
        # Build instructions content.  source_dir keeps `<!-- Source: -->`
        # display paths relative to the user's working directory when
        # `apm compile --root` redirects writes elsewhere.
        instructions_content = build_conditional_sections(
            primitives.instructions, source_dir=self.source_dir
        )

        # Metadata (version only; timestamp intentionally omitted for determinism)
        version = get_version()

        # Handle chatmode content
        chatmode_content = None
        if config.chatmode:
            chatmode = find_chatmode_by_name(primitives.chatmodes, config.chatmode)
            if chatmode:
                chatmode_content = chatmode.content
            else:
                self.warnings.append(f"Chatmode '{config.chatmode}' not found")

        return TemplateData(
            instructions_content=instructions_content,
            version=version,
            chatmode_content=chatmode_content,
        )

    def _maybe_emit_copilot_root_instructions(
        self,
        config: CompilationConfig,
        primitives: PrimitiveCollection,
        result: CompilationResult,
    ) -> CompilationResult:
        """Generate .github/copilot-instructions.md for Copilot-capable targets.

        Skip semantics: if the file already exists without the APM-generated
        marker, it is treated as hand-authored and left untouched. The
        ``copilot_root_instructions_skipped`` stat captures this case
        explicitly so callers can distinguish it from a genuine no-op
        (``copilot_root_instructions_unchanged``) or an unrouted target.
        """
        routing_target = "vscode" if config.target in _VSCODE_TARGET_ALIASES else config.target
        output_path = self.base_dir / ".github" / "copilot-instructions.md"
        if not should_compile_copilot_instructions_md(routing_target):
            self._cleanup_copilot_root_instructions(output_path, result, dry_run=config.dry_run)
            result.stats.setdefault("copilot_root_instructions_generated", 0)
            result.stats.setdefault("copilot_root_instructions_written", 0)
            result.stats.setdefault("copilot_root_instructions_unchanged", 0)
            result.stats.setdefault("copilot_root_instructions_skipped", 0)
            result.stats.setdefault("copilot_root_instructions_removed", 0)
            return result

        global_instructions = sorted(
            [instruction for instruction in primitives.instructions if not instruction.apply_to],
            key=lambda instruction: portable_relpath(instruction.file_path, self.base_dir),
        )
        if global_instructions and not config.no_dedup:
            rules_dir = self.base_dir / ".github" / "instructions"
            expected_filenames = _build_expected_rule_filenames(
                "copilot",
                primitives,
                instructions=global_instructions,
            )
            deployed_filenames = _get_deployed_instruction_filenames(
                rules_dir,
                self.base_dir,
                lambda msg: self._log("warning", msg),
                expected_filenames=expected_filenames,
            )
            if deployed_filenames:
                remaining_instructions = [
                    instruction
                    for instruction in global_instructions
                    if _instruction_rule_filename("copilot", instruction) not in deployed_filenames
                ]
                omitted_count = len(global_instructions) - len(remaining_instructions)
                if omitted_count:
                    self._log(
                        "progress",
                        f"Omitting {omitted_count} global instruction(s) already deployed "
                        "to .github/instructions/ from copilot-instructions.md",
                        symbol="info",
                    )
                global_instructions = remaining_instructions

        if not global_instructions:
            self._cleanup_copilot_root_instructions(output_path, result, dry_run=config.dry_run)
            result.stats.setdefault("copilot_root_instructions_generated", 0)
            result.stats.setdefault("copilot_root_instructions_written", 0)
            result.stats.setdefault("copilot_root_instructions_unchanged", 0)
            result.stats.setdefault("copilot_root_instructions_skipped", 0)
            result.stats.setdefault("copilot_root_instructions_removed", 0)
            return result

        content = self._generate_copilot_root_instructions_content(global_instructions, config)

        result.stats["copilot_root_instructions_generated"] = 1
        result.stats.setdefault("copilot_root_instructions_skipped", 0)
        result.stats.setdefault("copilot_root_instructions_removed", 0)
        result.stats.setdefault("copilot_root_instructions_written", 0)
        result.stats.setdefault("copilot_root_instructions_unchanged", 0)

        # Inspect any existing file BEFORE the dry-run early-exit so that
        # `--dry-run` faithfully reports what a real run would do (skip vs
        # write vs unchanged). Reading the file here is safe in dry-run mode
        # because we never mutate it.
        try:
            refuse_unsafe_output(output_path, self.base_dir, managed=False)
            existing = output_path.read_text(encoding="utf-8") if output_path.exists() else None
        except OSError as exc:
            message = output_error_message("Failed to read", output_path, exc)
            self.errors.append(message)
            result.errors.append(message)
            result.success = False
            return result

        if existing is not None and not has_generated_marker_header(
            existing,
            (AGENTS_MD_GENERATED_MARKER,),
        ):
            rel_path = portable_relpath(output_path, self.base_dir)
            advice = _advice.ROOT_INSTRUCTIONS_HAND_AUTHORED.bind(marker=AGENTS_MD_GENERATED_MARKER)
            result.warnings.append(
                f"Skipped {rel_path}: hand-authored file will not be overwritten. "
                f"{advice.sentence()}"
            )
            # The file was never compared to new content; record as
            # 'skipped', not 'unchanged'. Also reset 'generated' since no
            # output was actually emitted (or would be, on a real run).
            result.stats["copilot_root_instructions_generated"] = 0
            result.stats["copilot_root_instructions_written"] = 0
            result.stats["copilot_root_instructions_skipped"] = 1
            result.stats["copilot_root_instructions_unchanged"] = 0
            return result

        if existing == content:
            result.stats["copilot_root_instructions_written"] = 0
            result.stats["copilot_root_instructions_unchanged"] = 1
            return result

        if config.dry_run:
            return result

        try:
            from .output_writer import CompiledOutputPolicyError, CompiledOutputWriter

            verdict = CompiledOutputWriter(self.base_dir).write(output_path, content)
            actionable = verdict.critical_count + verdict.warning_count
            if actionable:
                result.warnings.append(
                    f"copilot-instructions.md contains {actionable} hidden character(s) "
                    f"-- run 'apm audit --file {output_path}' to inspect"
                )
            result.stats["copilot_root_instructions_written"] = 1
            result.stats["copilot_root_instructions_unchanged"] = 0
            return result
        except CompiledOutputPolicyError as exc:
            result.has_critical_security = True
            message = str(exc)
            self.errors.append(message)
            result.errors.append(message)
            result.success = False
            result.stats["copilot_root_instructions_written"] = 0
            return result
        except OSError as exc:
            message = f"Failed to write {output_path}: {exc}"
            self.errors.append(message)
            result.errors.append(message)
            result.success = False
            result.stats["copilot_root_instructions_written"] = 0
            result.stats.setdefault("copilot_root_instructions_unchanged", 0)
            return result

    def _generate_copilot_root_instructions_content(
        self,
        instructions,
        config: CompilationConfig,
    ) -> str:
        """Generate root Copilot instructions content from global instruction primitives."""
        # Functional marker and Build ID are always present (injection/drift/cleanup coupling).
        sections = [
            AGENTS_MD_GENERATED_MARKER,
            BUILD_ID_PLACEHOLDER,
        ]
        if config.source_attribution:
            sections.append(f"<!-- APM Version: {get_version()} -->")
        sections.append("")

        for instruction in instructions:
            # instruction.file_path is a source-tree file; relativise it
            # against source_dir so `apm compile --root` never leaks
            # `../../` or absolute deploy-relative paths into the
            # `<!-- Source: -->` provenance comments (sources stay in $PWD
            # while writes redirect to base_dir).
            rel_path = portable_relpath(instruction.file_path, self.source_dir)
            if config.source_attribution:
                sections.append(f"<!-- Source: {rel_path} -->")
            sections.append(instruction.content.strip())
            if config.source_attribution:
                sections.append(f"<!-- End source: {rel_path} -->")
            sections.append("")

        if config.source_attribution:
            sections.extend(build_generation_footer())

        content = "\n".join(sections)
        if config.resolve_links:
            content = resolve_markdown_links(content, self.base_dir)
        return self._finalize_build_id(content)

    def _finalize_build_id(self, content: str) -> str:
        """Replace the build-id placeholder with a deterministic content hash."""
        return stabilize_build_id(content)

    def _cleanup_copilot_root_instructions(
        self,
        output_path: Path,
        result: CompilationResult,
        *,
        dry_run: bool = False,
    ) -> CompilationResult:
        """Remove stale generated Copilot root instructions when no longer applicable."""
        if output_path.is_symlink():
            result.warnings.append(
                f"Retained {portable_relpath(output_path, self.base_dir)}: "
                "symbolic links are not removed during Copilot instruction cleanup."
            )
            result.stats.setdefault("copilot_root_instructions_removed", 0)
            return result

        if not output_path.exists():
            result.stats.setdefault("copilot_root_instructions_removed", 0)
            return result

        try:
            refuse_unsafe_output(output_path, self.base_dir, managed=False)
            existing = output_path.read_text(encoding="utf-8")
            if not has_generated_marker_header(existing, (AGENTS_MD_GENERATED_MARKER,)):
                result.stats.setdefault("copilot_root_instructions_removed", 0)
                return result
            if not has_valid_build_id(existing):
                result.warnings.append(
                    f"Retained {portable_relpath(output_path, self.base_dir)}: "
                    "the generated marker is present, but the Build ID does not match "
                    "the current content. Review it and delete or rename it manually "
                    "if duplicate context is unwanted."
                )
                result.stats.setdefault("copilot_root_instructions_removed", 0)
                return result

            ensure_path_within(output_path, self.base_dir)
            if dry_run:
                result.warnings.append(
                    f"[dry-run] would remove stale "
                    f"{portable_relpath(output_path, self.base_dir)} -- "
                    "generated Copilot instructions are no longer required."
                )
                result.stats.setdefault("copilot_root_instructions_removed", 0)
                return result

            output_path.unlink()
            result.stats["copilot_root_instructions_removed"] = 1
            return result
        except (OSError, PathTraversalError) as exc:
            message = output_error_message("Failed to remove stale", output_path, exc)
            self.errors.append(message)
            result.errors.append(message)
            result.success = False
            result.stats.setdefault("copilot_root_instructions_removed", 0)
            return result

    def _write_output_file(self, output_path: str, content: str) -> None:
        """Write the generated content to the output file (full-file mode).

        Args:
            output_path (str): Path to write the output.
            content (str): Content to write.
        """
        from .output_writer import CompiledOutputWriter

        try:
            CompiledOutputWriter(self.base_dir).write(Path(output_path), content)
        except OSError as e:
            self.errors.append(f"Failed to write output file {output_path}: {e!s}")

    def _write_output_file_with_config(
        self, output_path: str, content: str, config: "CompilationConfig"
    ) -> None:
        """Write generated content, honouring agents_md_mode from config.

        In ``full`` mode (default) the entire file is replaced.
        In ``managed_section`` mode only the text between the configured
        start/end markers is replaced; everything else is preserved.

        Args:
            output_path (str): Path to write the output.
            content (str): Generated content for this compilation.
            config (CompilationConfig): Compilation configuration.
        """
        from .output_writer import CompiledOutputWriter

        target = Path(output_path)
        content = self._prepare_output_content_with_config(output_path, content, config)
        try:
            CompiledOutputWriter(self.base_dir).write(
                target,
                content,
                preserve_line_endings=config.agents_md_mode == "managed_section"
                and target.is_file(),
            )
        except OSError as e:
            self.errors.append(f"Failed to write output file {output_path}: {e!s}")

    def _prepare_output_content_with_config(
        self, output_path: str, content: str, config: "CompilationConfig"
    ) -> str:
        """Build managed-section or full content without mutating disk."""
        from .managed_section import apply_managed_section

        if config.agents_md_mode == "managed_section":
            target = Path(output_path)
            if target.is_symlink():
                raise ManagedSectionError(
                    f"{target} is a symlink. Managed-section output must be a regular file."
                )
            ensure_path_within(target, self.base_dir)
            if not target.is_file():
                raise ManagedSectionError(
                    f"{target} does not exist yet. "
                    "Create it with the managed-section markers first, "
                    "or set agents_md.mode: full in apm.yml for initial generation."
                )
            with target.open(encoding="utf-8", newline="") as handle:
                existing = handle.read()
            try:
                content = apply_managed_section(
                    existing,
                    content,
                    config.agents_md_start_marker,
                    config.agents_md_end_marker,
                )
            except ManagedSectionError as exc:
                raise ManagedSectionError(f"[{target}] {exc}") from exc
        elif config.agents_md_mode not in VALID_AGENTS_MD_MODES:
            raise ValueError(
                f"Unknown agents_md.mode {config.agents_md_mode!r}. "
                f"Supported values: {', '.join(repr(mode) for mode in VALID_AGENTS_MD_MODES)}."
            )

        return content

    def _compile_stats(
        self, primitives: PrimitiveCollection, template_data: TemplateData
    ) -> dict[str, Any]:
        """Compile statistics about the compilation.

        Args:
            primitives (PrimitiveCollection): Discovered primitives.
            template_data (TemplateData): Generated template data.

        Returns:
            Dict[str, Any]: Compilation statistics.
        """
        return {
            "primitives_found": primitives.count(),
            "chatmodes": len(primitives.chatmodes),
            "instructions": len(primitives.instructions),
            "contexts": len(primitives.contexts),
            "content_length": len(template_data.instructions_content),
            # timestamp removed
            "version": template_data.version,
        }

    def _prepare_distributed_file(
        self, agents_path: Path, content: str, config: CompilationConfig
    ) -> str | None:
        """Build one eligible distributed AGENTS.md output without mutating disk.

        Args:
            agents_path (Path): Path to write the AGENTS.md file.
            content (str): Content to write.
            config (CompilationConfig): Compilation configuration.
        """
        deploy_inventory = self._deploy_inventory or CompileInventory.collect(self.base_dir)
        nested_root = deploy_inventory.nested_repository_root_for(agents_path.parent)
        if nested_root is not None:
            agents_rel = portable_relpath(agents_path, self.base_dir)
            root_rel = portable_relpath(nested_root, self.base_dir)
            self.warnings.append(
                f"Skipping AGENTS.md at {agents_rel}: nested Git repository "
                f"{root_rel} belongs to a separate repository. "
                f"{_advice.NESTED_REPOSITORY_SKIPPED.bind(root=nested_root).sentence()}"
            )
            return None
        if (
            config.agents_md_mode != "managed_section"
            and self._hand_authored_root_context_blocks_write(agents_path)
        ):
            return None
        refuse_unsafe_output(
            agents_path, self.base_dir, managed=config.agents_md_mode == "managed_section"
        )
        try:
            ensure_path_within(agents_path, self.base_dir)

            # Handle constitution injection for distributed files
            final_content = content

            if config.with_constitution:
                # Try to inject constitution if available
                try:
                    from .injector import ConstitutionInjector

                    injector = ConstitutionInjector(str(agents_path.parent))
                    final_content, c_status, c_hash = injector.inject(  # noqa: RUF059
                        content, with_constitution=True, output_path=agents_path
                    )
                except Exception as exc:
                    _logger.debug("Constitution injection failed for %s: %s", agents_path, exc)

            if config.agents_md_mode == "managed_section":
                if agents_path.is_file():
                    return self._prepare_output_content_with_config(
                        str(agents_path), final_content, config
                    )
                return self._new_managed_section_content(final_content, config)
            return final_content

        except OSError as e:
            raise OSError(f"Failed to prepare distributed AGENTS.md file {agents_path}: {e!s}")  # noqa: B904

    def _hand_authored_root_context_blocks_write(
        self,
        path: Path,
    ) -> bool:
        """Return whether an existing project-root file must be retained."""
        return hand_authored_root_context_blocks_write(
            path,
            base_dir=self.base_dir,
            resolved_base_dir=self._resolved_base_dir,
            protected_paths=self._protected_root_context_paths,
            warnings=self.warnings,
        )

    @staticmethod
    def _new_managed_section_content(content: str, config: CompilationConfig) -> str:
        """Wrap a new distributed output so future managed compiles reconcile it."""
        managed_content = content.rstrip("\n")
        return (
            f"{config.agents_md_start_marker}\n{managed_content}\n{config.agents_md_end_marker}\n"
        )

    @staticmethod
    def _has_managed_section_markers(path: Path, config: CompilationConfig) -> bool:
        """Treat any marker-bearing orphan as hand-authored managed content."""
        try:
            with path.open(encoding="utf-8", newline="") as handle:
                content = handle.read()
        except OSError:
            return True
        return config.agents_md_start_marker in content or config.agents_md_end_marker in content

    def _managed_orphan_retention_warning(self, managed_orphans: list[Path]) -> str:
        """Describe protected managed orphans and the required manual action."""
        paths = [portable_relpath(path, self.base_dir) for path in managed_orphans]
        if len(paths) == 1:
            return (
                f"Retained managed AGENTS.md orphan: {paths[0]} -- "
                "remove it manually when its team-owned content is no longer needed"
            )
        displayed_paths = ", ".join(paths[:5])
        remainder = "" if len(paths) <= 5 else f", and {len(paths) - 5} more"
        return (
            f"Retained {len(paths)} managed AGENTS.md orphans: {displayed_paths}{remainder} -- "
            "remove them manually when their team-owned content is no longer needed"
        )

    def _write_distributed_file(
        self, agents_path: Path, content: str, config: CompilationConfig
    ) -> None:
        """Write one distributed file through the canonical writer."""
        from .output_writer import CompiledOutputWriter

        prepared_content = self._prepare_distributed_file(agents_path, content, config)
        if prepared_content is None:
            return

        CompiledOutputWriter(self.base_dir).write(
            agents_path,
            prepared_content,
            preserve_line_endings=config.agents_md_mode == "managed_section"
            and agents_path.is_file(),
        )

    def _display_placement_preview(self, distributed_result) -> None:
        """Display placement preview for --show-placement mode.

        Args:
            distributed_result: Result from distributed compilation.
        """
        self._log("progress", "Distributed AGENTS.md Placement Preview:")
        self._log("progress", "")

        for placement in distributed_result.placements:
            rel_path = portable_relpath(placement.agents_path, self.base_dir)
            self._log("verbose_detail", f"{rel_path}")
            self._log("verbose_detail", f"   Instructions: {len(placement.instructions)}")
            self._log(
                "verbose_detail", f"   Patterns: {', '.join(sorted(placement.coverage_patterns))}"
            )
            if placement.source_attribution:
                sources = set(placement.source_attribution.values())
                self._log("verbose_detail", f"   Sources: {', '.join(sorted(sources))}")
            self._log("verbose_detail", "")

    def _display_trace_info(self, distributed_result, primitives: PrimitiveCollection) -> None:
        """Display detailed trace information for --trace mode.

        Args:
            distributed_result: Result from distributed compilation.
            primitives (PrimitiveCollection): Full primitive collection.
        """
        self._log("progress", "Distributed Compilation Trace:")
        self._log("progress", "")

        for placement in distributed_result.placements:
            rel_path = portable_relpath(placement.agents_path, self.base_dir)
            self._log("verbose_detail", f"{rel_path}")

            for instruction in placement.instructions:
                source = getattr(instruction, "source", "local")
                # instruction.file_path is a source-tree file; relativise
                # against source_dir so `apm compile --root` produces
                # human-readable paths in verbose output.
                inst_path = portable_relpath(instruction.file_path, self.source_dir)

                self._log(
                    "verbose_detail",
                    f"   * {instruction.apply_to or 'no pattern'} <- {source} {inst_path}",
                )
            self._log("verbose_detail", "")

    def _generate_placement_summary(
        self, distributed_result, output_paths: dict[Path, str] | None = None
    ) -> str:
        """Generate a text summary of placement results.

        Args:
            distributed_result: Result from distributed compilation.

        Returns:
            str: Text summary of placements.
        """
        lines = ["Distributed AGENTS.md Placement Summary:", ""]

        eligible_paths = None if output_paths is None else set(output_paths)
        for placement in distributed_result.placements:
            if eligible_paths is not None and placement.agents_path not in eligible_paths:
                continue
            rel_path = portable_relpath(placement.agents_path, self.base_dir)
            lines.append(f"{rel_path}")
            lines.append(f"   Instructions: {len(placement.instructions)}")
            lines.append(f"   Patterns: {', '.join(sorted(placement.coverage_patterns))}")
            lines.append("")

        total = (
            len(distributed_result.placements) if eligible_paths is None else len(eligible_paths)
        )
        lines.append(f"Total AGENTS.md files: {total}")
        return "\n".join(lines)

    def _generate_distributed_summary(self, distributed_result, config: CompilationConfig) -> str:
        """Generate a summary of distributed compilation results.

        Args:
            distributed_result: Result from distributed compilation.
            config (CompilationConfig): Compilation configuration.

        Returns:
            str: Summary content.
        """
        lines = [
            "# Distributed AGENTS.md Compilation Summary",
            "",
            f"Generated {len(distributed_result.placements)} AGENTS.md files:",
            "",
        ]

        for placement in distributed_result.placements:
            rel_path = portable_relpath(placement.agents_path, self.base_dir)
            lines.append(f"- {rel_path} ({len(placement.instructions)} instructions)")

        lines.extend(
            [
                "",
                f"Total instructions: {distributed_result.stats.get('total_instructions_placed', 0)}",
                f"Total patterns: {distributed_result.stats.get('total_patterns_covered', 0)}",
                "",
                _advice.SINGLE_AGENTS_COMPILATION.sentence(),
            ]
        )

        return "\n".join(lines)


def compile_agents_md(
    primitives: PrimitiveCollection | None = None,
    output_path: str = "AGENTS.md",
    chatmode: str | None = None,
    dry_run: bool = False,
    base_dir: str = ".",
) -> str:
    """Generate AGENTS.md with conditional sections.

    Args:
        primitives (Optional[PrimitiveCollection]): Primitives to use, or None to discover.
        output_path (str): Output file path. Defaults to "AGENTS.md".
        chatmode (str): Specific chatmode to use, or None for default.
        dry_run (bool): If True, don't write output file. Defaults to False.
        base_dir (str): Base directory for compilation. Defaults to current directory.

    Returns:
        str: Generated AGENTS.md content.
    """
    # Create configuration - use single-file mode for backward compatibility
    config = CompilationConfig(
        output_path=output_path,
        chatmode=chatmode,
        dry_run=dry_run,
        strategy="single-file",  # Force single-file mode for backward compatibility
    )

    # Create compiler and compile
    compiler = AgentsCompiler(base_dir)
    result = compiler.compile(config, primitives)

    if not result.success:
        raise RuntimeError(f"Compilation failed: {'; '.join(result.errors)}")

    return result.content
