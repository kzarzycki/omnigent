"""Distributed AGENTS.md compilation system following the Minimal Context Principle.

This module implements hierarchical directory-based distribution to generate multiple
AGENTS.md files across a project's directory structure, following the AGENTS.md standard
for nested agent context files.
"""

import builtins
import logging
from collections import defaultdict
from collections.abc import MutableMapping
from dataclasses import dataclass, field
from pathlib import Path

from ..core.remediation import ORPHANED_AGENTS_MD
from ..output.formatters import CompilationFormatter
from ..output.models import CompilationResults
from ..primitives.models import Instruction, PrimitiveCollection
from ..utils.paths import portable_relpath, resolve_base_and_source_dirs
from ..version import get_version
from .constants import (
    BUILD_ID_PLACEHOLDER,
    DISTRIBUTED_AGENTS_MD_GENERATED_MARKER,
    has_generated_marker_header,
)
from .constitution import find_constitution
from .context_optimizer import ContextOptimizer
from .footer import build_generation_footer
from .inventory import CompileInventory
from .link_resolver import UnifiedLinkResolver
from .template_builder import (
    build_attributed_instructions,
)

_logger = logging.getLogger(__name__)

# Marker present in every APM-generated distributed AGENTS.md.
# Used to gate --clean deletion: files without this marker are
# hand-authored and must never be removed automatically.
#
# Public (no leading underscore) because it is a stable contract surface:
# it gates file deletion and is depended on by tests. Mirrors the public
# CLAUDE_HEADER marker on the Claude path.
AGENTS_MD_GENERATED_MARKER = DISTRIBUTED_AGENTS_MD_GENERATED_MARKER

# Cleanup deliberately differs from ContextOptimizer's placement exclusions:
# cleanup must retain its marker-gated orphan scope while avoiding control trees.
_CLEANUP_SKIP_DIRS = frozenset(
    {
        ".git",
        ".apm",
        "node_modules",
        "__pycache__",
        ".pytest_cache",
        "apm_modules",
    }
)

# CRITICAL: Shadow Click commands to prevent namespace collision
set = builtins.set
list = builtins.list
dict = builtins.dict


@dataclass
class DirectoryMap:
    """Mapping of directory structure analysis."""

    directories: builtins.dict[
        Path, builtins.set[str]
    ]  # directory -> set of applicable file patterns
    depth_map: builtins.dict[Path, int]  # directory -> depth level
    parent_map: builtins.dict[Path, Path | None]  # directory -> parent directory

    def get_max_depth(self) -> int:
        """Get maximum depth in the directory structure."""
        return max(self.depth_map.values()) if self.depth_map else 0


@dataclass
class PlacementResult:
    """Result of AGENTS.md placement analysis."""

    agents_path: Path
    instructions: builtins.list[Instruction]
    inherited_instructions: builtins.list[Instruction] = field(default_factory=list)
    coverage_patterns: builtins.set[str] = field(default_factory=set)
    source_attribution: builtins.dict[str, str] = field(
        default_factory=dict
    )  # instruction_id -> source


@dataclass
class CompilationResult:
    """Result of distributed AGENTS.md compilation."""

    success: bool
    placements: builtins.list[PlacementResult]
    content_map: builtins.dict[Path, str]  # agents_path -> content
    warnings: builtins.list[str] = field(default_factory=list)
    errors: builtins.list[str] = field(default_factory=list)
    stats: builtins.dict[str, float] = field(default_factory=dict)  # Support optimization metrics
    orphaned_files: builtins.list[Path] = field(default_factory=list)
    # Paths suppressed because they would have been header/footer-only shells
    # (skip_instructions=True, no constitution).  Exposed for callers that
    # need to emit a user-visible INFO message or perform --clean removal.
    suppressed_empty_paths: builtins.list[Path] = field(default_factory=list)

    @property
    def all_suppressed(self) -> bool:
        """Return True when every planned AGENTS.md placement was suppressed."""
        return bool(self.suppressed_empty_paths) and not self.content_map


class DistributedAgentsCompiler:
    """Main compiler for generating distributed AGENTS.md files."""

    def __init__(
        self,
        base_dir: str = ".",
        exclude_patterns: builtins.list[str] | None = None,
        source_dir: str | None = None,
        source_inventory: CompileInventory | None = None,
        deploy_inventory: CompileInventory | None = None,
        managed_section_markers: tuple[str, str] | None = None,
    ):
        """Initialize the distributed AGENTS.md compiler.

        Args:
            base_dir (str): Base directory for compilation -- root used to
                construct AGENTS.md write paths.  Defaults to the current
                directory.
            exclude_patterns (Optional[List[str]]): Glob patterns for
                directories to exclude.
            source_dir (Optional[str]): Where primitives and the project
                tree are scanned for placement scoring.  Defaults to
                ``base_dir`` for back-compat; set explicitly when ``apm
                compile --root`` redirects writes but sources remain in
                ``$PWD``.
            source_inventory: Shared source-tree filesystem snapshot.
            deploy_inventory: Shared deploy-tree snapshot for orphan cleanup.
            managed_section_markers: Configured AGENTS.md managed-section
                markers, passed to placement so mixed-ownership files stay
                authored content.
        """
        self.base_dir, self.source_dir = resolve_base_and_source_dirs(base_dir, source_dir)
        self._exclude_patterns = exclude_patterns
        self._owns_source_inventory = source_inventory is None
        self._owns_deploy_inventory = deploy_inventory is None
        self._source_inventory = source_inventory
        self._deploy_inventory = deploy_inventory

        self.warnings: builtins.list[str] = []
        self.errors: builtins.list[str] = []
        self.total_files_written = 0
        self.context_optimizer = ContextOptimizer(
            str(self.source_dir),
            exclude_patterns=exclude_patterns,
            inventory=self._source_inventory,
            managed_section_markers=managed_section_markers,
        )
        self.link_resolver = UnifiedLinkResolver(self.source_dir)
        self.output_formatter = CompilationFormatter()
        self._placement_map = None

    def _refresh_owned_inventories(self) -> None:
        """Refresh direct-construction snapshots at the start of a compile."""
        if self._owns_source_inventory:
            self._source_inventory = CompileInventory.collect(
                self.source_dir, exclude_patterns=self._exclude_patterns
            )
        if self._owns_deploy_inventory:
            self._deploy_inventory = (
                self._source_inventory
                if self.base_dir == self.source_dir and not self._exclude_patterns
                else CompileInventory.collect(self.base_dir)
            )
        self.context_optimizer._inventory = self._source_inventory

    def _deploy_inventory_for_cleanup(self) -> CompileInventory:
        """Return the deploy snapshot, collecting it lazily for direct callers."""
        if self._deploy_inventory is None:
            if self.base_dir == self.source_dir and not self._exclude_patterns:
                self._source_inventory = self._source_inventory or CompileInventory.collect(
                    self.source_dir, exclude_patterns=self._exclude_patterns
                )
                self._deploy_inventory = self._source_inventory
            else:
                self._deploy_inventory = CompileInventory.collect(self.base_dir)
        return self._deploy_inventory

    def _source_to_base(self, path: Path) -> Path:
        """Map a path rooted at source_dir to the equivalent base_dir path.

        Returns *path* unchanged when source_dir == base_dir (the default
        case) or when *path* is not under source_dir (defensive fallback).
        """
        if self.source_dir == self.base_dir:
            return path
        try:
            rel = path.resolve().relative_to(self.source_dir.resolve())
        except (ValueError, OSError):
            return path
        return self.base_dir / rel

    def compile_distributed(
        self, primitives: PrimitiveCollection, config: dict | None = None
    ) -> CompilationResult:
        """Compile primitives into distributed AGENTS.md files.

        Args:
            primitives (PrimitiveCollection): Collection of primitives to compile.
            config (Optional[dict]): Configuration for distributed compilation.
                - clean_orphaned (bool): Remove orphaned AGENTS.md files. Default: False
                - dry_run (bool): Preview mode, don't write files. Default: False

        Returns:
            CompilationResult: Result of the distributed compilation.
        """
        self.warnings.clear()
        self.errors.clear()
        self._refresh_owned_inventories()

        try:
            # Configuration with defaults aligned to Minimal Context Principle
            config = config or {}
            min_instructions = config.get(
                "min_instructions_per_file", 1
            )  # Default to 1 for minimal context
            source_attribution = config.get("source_attribution", True)
            debug = config.get("debug", False)
            clean_orphaned = config.get("clean_orphaned", False)
            defer_orphan_cleanup = config.get("defer_orphan_cleanup", False)
            defer_orphan_warnings = config.get("defer_orphan_warnings", False)
            dry_run = config.get("dry_run", False)
            # True when apm install has already deployed instructions to
            # .github/instructions/; omitting them here avoids Copilot reading
            # duplicate content from both AGENTS.md and .github/instructions/.
            skip_instructions = config.get("skip_instructions", False)
            # Mirrors CompilationConfig.with_constitution: when False, the writer
            # skips constitution injection, so the emptiness predicate must agree.
            with_constitution = config.get("with_constitution", True)
            agents_md_mode = config.get("agents_md_mode", "full")

            # Phase 0: Context Link Resolution
            # Register all context files and compile referenced ones
            self.link_resolver.register_contexts(primitives)

            # Build list of files to scan for context references
            all_files_to_scan = []
            all_files_to_scan.extend([i.file_path for i in primitives.instructions])
            all_files_to_scan.extend([c.file_path for c in primitives.chatmodes])

            # Include installed agents/prompts from .github/
            github_agents_dir = self.base_dir / ".github" / "agents"
            github_prompts_dir = self.base_dir / ".github" / "prompts"
            if github_agents_dir.exists():
                all_files_to_scan.extend(github_agents_dir.glob("*.agent.md"))
            if github_prompts_dir.exists():
                all_files_to_scan.extend(github_prompts_dir.glob("*.prompt.md"))

            # Phase 0: Validate context references (optional - for reporting)
            if debug:
                referenced_contexts = self.link_resolver.get_referenced_contexts(all_files_to_scan)
                if referenced_contexts:
                    self.warnings.append(
                        f"Found {len(referenced_contexts)} referenced context files"
                    )

            placement_map = config.get("placement_map")
            if placement_map is None:
                # Phase 1: Directory structure analysis
                directory_map = self.analyze_directory_structure(primitives.instructions)

                # Phase 2: Determine optimal AGENTS.md placement
                placement_map = self.determine_agents_placement(
                    primitives.instructions,
                    directory_map,
                    min_instructions=min_instructions,
                    debug=debug,
                )
            else:
                # Reporting must describe the placement used by this invocation,
                # including when a caller reuses this compiler with a new map.
                self._placement_map = placement_map

            # Phase 3: Generate distributed AGENTS.md files
            placements = self.generate_distributed_agents_files(
                placement_map, primitives, source_attribution=source_attribution
            )

            # Phase 3b: Build content map, suppressing placements that would be
            # header/footer-only shells when skip_instructions is True.
            #
            # Suppression fires only when ALL of these hold:
            #   1. skip_instructions is True (instructions already in
            #      .github/instructions/; dedup is active)
            #   2. The placement's body would be empty -- i.e. there are no
            #      instructions to include AND no constitution in the placement
            #      directory that would be injected at write time.
            #
            # Placements carrying non-instruction content (constitution present,
            # non-empty instructions list that somehow survives) are kept.
            # Multi-target builds where skip_instructions=False are unaffected.
            content_map: builtins.dict[Path, str] = {}
            suppressed_paths: builtins.list[Path] = []
            # Cache constitution-existence per directory for the duration of this
            # compile so repeated placements under the same tree do not re-read the
            # same constitution file from disk (O(placements) reads -> O(dirs)).
            constitution_cache: builtins.dict[Path, bool] = {}

            for p in placements:
                # Decide suppression BEFORE generating content: a suppressed
                # placement is never written, so generating + link-resolving its
                # content would be wasted work.
                if skip_instructions and self._is_placement_empty_shell(
                    p,
                    with_constitution=with_constitution,
                    constitution_cache=constitution_cache,
                ):
                    suppressed_paths.append(p.agents_path)
                    _logger.debug(
                        "AGENTS.md suppressed (would-be-empty shell, instructions already"
                        " in .github/instructions/): %s",
                        p.agents_path,
                    )
                    continue
                content_map[p.agents_path] = self._generate_agents_content(
                    p,
                    primitives,
                    skip_instructions=skip_instructions,
                    source_attribution=source_attribution,
                    agents_md_mode=agents_md_mode,
                )

            # Phase 4: Handle orphaned file cleanup.
            # generated_paths = ALL placement paths (written + suppressed this run).
            # suppressed_set (built inside _find_orphaned_agents_files) promotes
            # suppressed paths to orphan candidates. Deletion remains --clean-only,
            # while non-clean compiles retain actionable orphan diagnostics.
            # Marker-gated: hand-authored files are never deleted.
            generated_paths = [p.agents_path for p in placements]
            orphaned_files = self._find_orphaned_agents_files(
                generated_paths,
                suppressed_empty_paths=suppressed_paths,
            )

            if orphaned_files and not defer_orphan_warnings:
                # Without --clean, tell the user how to remove orphans.  With
                # --clean, the cleanup step reports what was (or would be)
                # removed, so a "run --clean" instruction would be stale.
                if not clean_orphaned:
                    self.warnings.extend(self._generate_orphan_warnings(orphaned_files))
                elif dry_run:
                    self.warnings.extend(self._cleanup_orphaned_files(orphaned_files, dry_run=True))
                # Standalone callers retain the established cleanup behavior.
                # AgentsCompiler defers cleanup until its full write preflight has
                # succeeded, preserving all-or-nothing distributed writes.
                elif not defer_orphan_cleanup:
                    self.warnings.extend(self._cleanup_orphaned_files(orphaned_files))

            # Phase 5: Validate coverage
            coverage_validation = self._validate_coverage(placements, primitives.instructions)
            if coverage_validation:
                self.warnings.extend(coverage_validation)

            # Compile statistics
            stats = self._compile_distributed_stats(placements, primitives, content_map=content_map)
            # Every placement was suppressed by dedup: an explained skip, not zero output (#4209).
            stats["agents_md_suppressed_by_dedup"] = 0 if content_map else len(suppressed_paths)

            # Optional: Get referenced contexts for reporting (doesn't copy)
            try:
                # Collect all files from placements for context reference scanning.
                # PlacementResult has no `agents` attr; the old loop was dead code.
                all_files_to_scan = []
                for placement in placements:
                    for instruction in placement.instructions:
                        all_files_to_scan.append(instruction.file_path)

                referenced_contexts = self.link_resolver.get_referenced_contexts(all_files_to_scan)
                stats["contexts_referenced"] = len(referenced_contexts)
            except Exception:
                stats["contexts_referenced"] = 0

            return CompilationResult(
                success=len(self.errors) == 0,
                placements=placements,
                content_map=content_map,
                warnings=self.warnings.copy(),
                errors=self.errors.copy(),
                stats=stats,
                suppressed_empty_paths=suppressed_paths,
                orphaned_files=orphaned_files,
            )

        except Exception as e:
            self.errors.append(f"Distributed compilation failed: {e!s}")
            return CompilationResult(
                success=False,
                placements=[],
                content_map={},
                warnings=self.warnings.copy(),
                errors=self.errors.copy(),
                stats={},
            )

    def analyze_directory_structure(self, instructions: builtins.list[Instruction]) -> DirectoryMap:
        """Analyze project directory structure based on instruction patterns.

        Args:
            instructions (List[Instruction]): List of instructions to analyze.

        Returns:
            DirectoryMap: Analysis of the directory structure.
        """
        directories: builtins.dict[Path, builtins.set[str]] = defaultdict(set)
        depth_map: builtins.dict[Path, int] = {}
        parent_map: builtins.dict[Path, Path | None] = {}

        # Analyze each instruction's applyTo pattern
        for instruction in instructions:
            if not instruction.apply_to:
                continue

            pattern = instruction.apply_to

            # Extract directory paths from pattern
            dirs = self._extract_directories_from_pattern(pattern)

            for dir_path in dirs:
                abs_dir = self.base_dir / dir_path
                directories[abs_dir].add(pattern)

                # Calculate depth and parent relationships
                depth = len(abs_dir.resolve().relative_to(self.base_dir.resolve()).parts)
                depth_map[abs_dir] = depth

                if depth > 0:
                    parent_dir = abs_dir.parent
                    parent_map[abs_dir] = parent_dir
                    # Ensure parent is also tracked
                    if parent_dir not in directories:
                        directories[parent_dir] = set()
                else:
                    parent_map[abs_dir] = None

        # Add base directory
        directories[self.base_dir].update(
            instruction.apply_to for instruction in instructions if instruction.apply_to
        )
        depth_map[self.base_dir] = 0
        parent_map[self.base_dir] = None

        return DirectoryMap(
            directories=dict(directories), depth_map=depth_map, parent_map=parent_map
        )

    def determine_agents_placement(
        self,
        instructions: builtins.list[Instruction],
        directory_map: DirectoryMap,
        min_instructions: int = 1,
        debug: bool = False,
    ) -> builtins.dict[Path, builtins.list[Instruction]]:
        """Determine optimal AGENTS.md file placement using Context Optimization Engine.

        Following the Minimal Context Principle and Context Optimization, creates
        focused AGENTS.md files that minimize context pollution while maximizing
        relevance for agents working in specific directories.

        Args:
            instructions (List[Instruction]): List of instructions to place.
            directory_map (DirectoryMap): Directory structure analysis.
            min_instructions (int): Minimum instructions (default 1 for minimal context).
            max_depth (int): Maximum depth for placement.

        Returns:
            Dict[Path, List[Instruction]]: Optimized mapping of directory paths to instructions.
        """
        # Use the Context Optimization Engine for intelligent placement.
        # The optimizer scans source_dir, so the returned placement keys
        # are rooted at source_dir; translate them to base_dir below so
        # writes land at the deploy root when source_dir != base_dir
        # (`apm compile --root`).
        optimized_placement = self.context_optimizer.optimize_instruction_placement(
            instructions,
            verbose=debug,
            enable_timing=debug,  # Enable timing when debug mode is on
        )
        if optimized_placement and self.source_dir != self.base_dir:
            optimized_placement = {
                self._source_to_base(p): v for p, v in optimized_placement.items()
            }

        # Special case: if no instructions but constitution exists, create root placement
        if not optimized_placement:
            from .constitution import find_constitution

            constitution_path = find_constitution(Path(self.source_dir))
            if constitution_path.exists():
                # Create an empty placement for the root directory to enable verbose output
                optimized_placement = {Path(self.base_dir): []}

        # Store optimization results for output formatting later
        # Update with proper dry run status in the final result
        self._placement_map = optimized_placement

        # Remove the verbose warning log - we'll show this in professional output instead

        # Filter out directories with too few instructions if specified
        if min_instructions > 1:
            filtered_placement = {}
            for dir_path, dir_instructions in optimized_placement.items():
                if len(dir_instructions) >= min_instructions or dir_path == self.base_dir:
                    filtered_placement[dir_path] = dir_instructions
                else:
                    # Move instructions to parent directory
                    parent_dir = dir_path.parent if dir_path != self.base_dir else self.base_dir
                    if parent_dir not in filtered_placement:
                        filtered_placement[parent_dir] = []
                    filtered_placement[parent_dir].extend(dir_instructions)

            return filtered_placement

        return optimized_placement

    def generate_distributed_agents_files(
        self,
        placement_map: builtins.dict[Path, builtins.list[Instruction]],
        primitives: PrimitiveCollection,
        source_attribution: bool = True,
    ) -> builtins.list[PlacementResult]:
        """Generate distributed AGENTS.md file contents.

        Args:
            placement_map (Dict[Path, List[Instruction]]): Directory to instructions mapping.
            primitives (PrimitiveCollection): Full primitive collection.
            source_attribution (bool): Whether to include source attribution.

        Returns:
            List[PlacementResult]: List of placement results with content.
        """
        placements = []

        # Special case: if no instructions but constitution exists, create root placement
        if not placement_map:
            from .constitution import find_constitution

            constitution_path = find_constitution(Path(self.source_dir))
            if constitution_path.exists():
                # Create a root placement for constitution-only projects
                root_path = Path(self.base_dir)
                agents_path = root_path / "AGENTS.md"

                placement = PlacementResult(
                    agents_path=agents_path,
                    instructions=[],  # No instructions, just constitution
                    coverage_patterns=set(),  # No patterns since no instructions
                    source_attribution={"constitution": "constitution.md"}
                    if source_attribution
                    else {},
                )

                placements.append(placement)
        else:
            # Normal case: create placements for each entry in placement_map
            for dir_path, instructions in placement_map.items():
                agents_path = dir_path / "AGENTS.md"

                # Build source attribution map if enabled
                source_map = {}
                if source_attribution:
                    for instruction in instructions:
                        source_info = getattr(instruction, "source", "local")
                        source_map[str(instruction.file_path)] = source_info

                # Extract coverage patterns
                patterns = set()
                for instruction in instructions:
                    if instruction.apply_to:
                        patterns.add(instruction.apply_to)

                placement = PlacementResult(
                    agents_path=agents_path,
                    instructions=instructions,
                    coverage_patterns=patterns,
                    source_attribution=source_map,
                )

                placements.append(placement)

        return placements

    def get_compilation_results_for_display(
        self, is_dry_run: bool = False
    ) -> CompilationResults | None:
        """Get compilation results for CLI display integration.

        Args:
            is_dry_run: Whether this is a dry run.

        Returns:
            CompilationResults if available, None otherwise.
        """
        if self._placement_map:
            # Generate fresh compilation results with correct dry run status
            compilation_results = self.context_optimizer.get_compilation_results(
                self._placement_map, is_dry_run=is_dry_run
            )

            # Merge distributed compiler's warnings (like orphan warnings) with optimizer warnings
            all_warnings = compilation_results.warnings + self.warnings

            # Create new compilation results with merged warnings
            from ..output.models import CompilationResults

            return CompilationResults(
                project_analysis=compilation_results.project_analysis,
                optimization_decisions=compilation_results.optimization_decisions,
                placement_summaries=compilation_results.placement_summaries,
                optimization_stats=compilation_results.optimization_stats,
                warnings=all_warnings,
                errors=compilation_results.errors + self.errors,
                is_dry_run=is_dry_run,
            )
        return None

    def _extract_directories_from_pattern(self, pattern: str) -> builtins.list[Path]:
        """Extract potential directory paths from a file pattern.

        Args:
            pattern (str): File pattern like "src/**/*.py" or "docs/*.md"

        Returns:
            List[Path]: List of directory paths that could contain matching files.
        """
        directories = []

        # Remove filename part and wildcards to get directory structure
        # Examples:
        # "src/**/*.py" -> ["src"]
        # "docs/*.md" -> ["docs"]
        # "**/*.py" -> ["."] (current directory)
        # "*.py" -> ["."] (current directory)

        if pattern.startswith("**/"):
            # Global pattern - applies to all directories
            directories.append(Path("."))
        elif "/" in pattern:
            # Extract directory part
            dir_part = pattern.split("/")[0]
            if not dir_part.startswith("*"):
                directories.append(Path(dir_part))
            else:
                directories.append(Path("."))
        else:
            # No directory part - applies to current directory
            directories.append(Path("."))

        return directories

    def _find_best_directory(
        self, instruction: Instruction, directory_map: DirectoryMap, max_depth: int
    ) -> Path:
        """Find the best directory for placing an instruction.

        Args:
            instruction (Instruction): Instruction to place.
            directory_map (DirectoryMap): Directory structure analysis.
            max_depth (int): Maximum allowed depth.

        Returns:
            Path: Best directory path for the instruction.
        """
        if not instruction.apply_to:
            return self.base_dir

        pattern = instruction.apply_to
        best_dir = self.base_dir
        best_specificity = 0

        for dir_path in directory_map.directories:
            # Skip directories that are too deep
            if directory_map.depth_map.get(dir_path, 0) > max_depth:
                continue

            # Check if this directory could contain files matching the pattern
            if pattern in directory_map.directories[dir_path]:
                # Prefer more specific (deeper) directories
                specificity = directory_map.depth_map.get(dir_path, 0)
                if specificity > best_specificity:
                    best_specificity = specificity
                    best_dir = dir_path

        return best_dir

    def _generate_agents_content(
        self,
        placement: PlacementResult,
        primitives: PrimitiveCollection,
        *,
        skip_instructions: bool = False,
        source_attribution: bool = True,
        agents_md_mode: str = "full",
    ) -> str:
        """Generate AGENTS.md content for a specific placement.

        Args:
            placement (PlacementResult): Placement result with instructions.
            primitives (PrimitiveCollection): Full primitive collection.
            skip_instructions (bool): When True, omit instruction content because
                it is already deployed to .github/instructions/ by ``apm install``
                (avoids duplicate context for Copilot, which reads both locations).
            source_attribution (bool): Controls the opt-in cosmetic annotations
                (APM version comment, generated-by footer), mirroring the
                CLAUDE.md path.  Distinct from ``placement.source_attribution``,
                which is the per-instruction source map.
            agents_md_mode: Root AGENTS.md ownership mode. Subdirectory files
                always use full-file ownership wording.

        Returns:
            str: Generated AGENTS.md content.
        """
        sections = []

        # Header with source attribution
        sections.append("# AGENTS.md")
        sections.append(AGENTS_MD_GENERATED_MARKER)
        sections.append(BUILD_ID_PLACEHOLDER)
        if source_attribution:
            sections.append(f"<!-- APM Version: {get_version()} -->")

        # Add source attribution summary if enabled
        if placement.source_attribution:
            sources = set(placement.source_attribution.values())
            if len(sources) > 1:
                sections.append(f"<!-- Sources: {', '.join(sorted(sources))} -->")
            else:
                sections.append(f"<!-- Source: {list(sources)[0] if sources else 'local'} -->")

        sections.append("")

        # Instructions section: skipped when already deployed to .github/instructions/
        # by ``apm install`` to avoid Copilot reading duplicate content from both
        # AGENTS.md and .github/instructions/.
        if not skip_instructions:
            sections.extend(
                build_attributed_instructions(
                    placement.instructions,
                    placement.source_attribution,
                    self.source_dir,
                )
            )

        # Footer is opt-in (cosmetic).
        if source_attribution:
            is_root = placement.agents_path.parent == self.base_dir
            footer_mode = agents_md_mode if is_root else "full"
            sections.extend(build_generation_footer(footer_mode))

        content = "\n".join(sections)

        # Resolve context links in the generated content
        content = self.link_resolver.resolve_links_for_compilation(
            content=content,
            source_file=placement.agents_path.parent,
            compiled_output=placement.agents_path,
        )

        return content

    def _is_placement_empty_shell(
        self,
        placement: PlacementResult,
        *,
        with_constitution: bool = True,
        constitution_cache: MutableMapping[Path, bool] | None = None,
    ) -> bool:
        """Return True when a placement would produce a content-free AGENTS.md shell.

        This method is only called when ``skip_instructions=True`` (instructions
        are already in ``.github/instructions/`` and will be omitted from output).
        Given that, the only content that could make a placement non-empty is a
        constitution injected at write time.

        Uses the placement model rather than string-parsing rendered content so
        the check stays correct regardless of header/footer layout changes.

        The ``with_constitution`` flag mirrors ``CompilationConfig.with_constitution``
        and resolves the predicate/writer disagreement: if ``--no-constitution`` was
        passed (``with_constitution=False``), the writer will skip injection even when
        a constitution file exists, so the predicate must agree and report "empty".

        Target logic:
            empty = not (with_constitution and constitution_exists(placement.agents_path.parent))

        Args:
            placement: The placement to evaluate.
            with_constitution: Whether the caller will inject a constitution at
                write time (mirrors ``CompilationConfig.with_constitution``).
                Defaults to True for back-compat.
            constitution_cache: Optional mutable mapping keyed by placement
                directory, used to memoize constitution-existence checks across
                placements within a single ``compile_distributed()`` call so the
                same directory is not read from disk repeatedly. When omitted,
                the check reads from disk directly (back-compat for direct callers).

        Returns:
            bool: True if writing this placement would produce a content-free file.
        """
        # When with_constitution is False the writer skips injection regardless of
        # what is on disk, so short-circuit without touching the filesystem.
        if not with_constitution:
            return True

        # ConstitutionInjector uses agents_path.parent as its base_dir, so mirror
        # that here. Memoize per directory to avoid repeated disk I/O in large
        # repos with many placements sharing a tree.
        directory = placement.agents_path.parent
        if constitution_cache is not None and directory in constitution_cache:
            has_constitution = constitution_cache[directory]
        else:
            has_constitution = find_constitution(directory).is_file()
            if constitution_cache is not None:
                constitution_cache[directory] = has_constitution

        return not has_constitution

    def _validate_coverage(
        self,
        placements: builtins.list[PlacementResult],
        all_instructions: builtins.list[Instruction],
    ) -> builtins.list[str]:
        """Validate that all instructions are covered by placements.

        Args:
            placements (List[PlacementResult]): Generated placements.
            all_instructions (List[Instruction]): All available instructions.

        Returns:
            List[str]: List of coverage warnings.
        """
        warnings = []
        placed_instructions = set()

        for placement in placements:
            placed_instructions.update(str(inst.file_path) for inst in placement.instructions)

        all_instruction_paths = set(str(inst.file_path) for inst in all_instructions)

        missing_instructions = all_instruction_paths - placed_instructions
        if missing_instructions:
            warnings.append(
                f"Instructions not placed in any AGENTS.md: {', '.join(missing_instructions)}"
            )

        return warnings

    @staticmethod
    def _file_has_apm_marker(path: Path) -> bool:
        """Return whether *path* has the APM marker as an exact header line.

        Reads only a bounded prefix of the file to avoid loading large AGENTS.md
        files entirely into memory.  Returns False on any OSError (the caller
        should skip the file).
        """
        if path.is_symlink():
            return False
        try:
            with path.open("rb") as fh:
                prefix = fh.read(4096).decode("utf-8", errors="replace")
            return has_generated_marker_header(prefix, (AGENTS_MD_GENERATED_MARKER,))
        except OSError:
            return False

    def _find_orphaned_agents_files(
        self,
        generated_paths: builtins.list[Path],
        suppressed_empty_paths: builtins.list[Path] | None = None,
    ) -> builtins.list[Path]:
        """Find existing AGENTS.md files that weren't generated in the current compilation.

        When ``suppressed_empty_paths`` is provided (non-empty list), those paths
        are also considered candidate orphans so that ``--clean`` can remove stale
        empty shells left by a previous run.  Only files bearing the APM-generated
        marker are ever returned; hand-authored AGENTS.md files are silently skipped.

        Args:
            generated_paths: AGENTS.md placement paths considered part of the current
                run — these are ALL placement paths (written OR suppressed as empty
                shells), NOT necessarily files that were written to disk.  Paths in
                this list are excluded from orphan candidates so that previously
                written files belonging to an active placement are never flagged for
                cleanup.  Do not pass only the written subset, or stale-but-active
                placements will be incorrectly treated as orphans.
            suppressed_empty_paths: AGENTS.md paths suppressed this run because
                they would have been header/footer-only shells (skip_instructions
                active, no constitution).  Pass an empty list or None when
                ``--clean`` is not in effect.

        Returns:
            List of APM-generated AGENTS.md files that should be cleaned up.
        """
        orphaned_files = []
        generated_set = set(generated_paths)
        suppressed_set = set(suppressed_empty_paths or [])
        deploy_inventory = self._deploy_inventory_for_cleanup()
        for nested_root in sorted(deploy_inventory.nested_repository_roots):
            _logger.debug(
                "Skipping nested Git repository during orphan cleanup: %s",
                portable_relpath(nested_root, self.base_dir),
            )
        cleanup_directories = {
            entry.path: (entry.relative_path, entry.file_names)
            for entry in deploy_inventory.directories
        }
        for suppressed_path in suppressed_set:
            try:
                relative_path = suppressed_path.parent.relative_to(self.base_dir)
            except ValueError:
                continue
            cleanup_directories.setdefault(suppressed_path.parent, (relative_path, ()))

        for directory_path, (relative_path, files) in sorted(cleanup_directories.items()):
            if any(part in _CLEANUP_SKIP_DIRS for part in relative_path.parts):
                continue
            if "AGENTS.md" not in files:
                continue
            if deploy_inventory.nested_repository_root_for(directory_path) is not None:
                continue

            agents_file = directory_path / "AGENTS.md"
            # Candidate: either a traditional orphan (not in current run)
            # or a suppressed empty shell (skip_instructions active).
            is_traditional_orphan = agents_file not in generated_set
            is_suppressed_empty = agents_file in suppressed_set

            if not is_traditional_orphan and not is_suppressed_empty:
                continue

            # Marker gate: only touch APM-generated files.  Hand-authored
            # AGENTS.md files (no marker) are never candidates for cleanup.
            # Read only a bounded prefix to limit I/O on large files.
            if not self._file_has_apm_marker(agents_file):
                continue

            orphaned_files.append(agents_file)

        return orphaned_files

    def _generate_orphan_warnings(self, orphaned_files: builtins.list[Path]) -> builtins.list[str]:
        """Generate warning messages for orphaned AGENTS.md files.

        Args:
            orphaned_files (List[Path]): List of orphaned files to warn about.

        Returns:
            List[str]: List of warning messages.
        """
        warning_messages = []

        if not orphaned_files:
            return warning_messages

        # Professional warning format with readable list for multiple files
        if len(orphaned_files) == 1:
            rel_path = portable_relpath(orphaned_files[0], self.base_dir)
            warning_messages.append(
                f"Orphaned AGENTS.md found: {rel_path} - {ORPHANED_AGENTS_MD.clause()}"
            )
        else:
            # For multiple files, create a single multi-line warning message
            file_list = []
            for file_path in orphaned_files[:5]:  # Show first 5
                rel_path = portable_relpath(file_path, self.base_dir)
                file_list.append(f"  * {rel_path}")
            if len(orphaned_files) > 5:
                file_list.append(f"  * ...and {len(orphaned_files) - 5} more")

            # Create one cohesive warning message
            files_text = "\n".join(file_list)
            warning_messages.append(
                f"Found {len(orphaned_files)} orphaned AGENTS.md files:\n{files_text}\n"
                f"  {ORPHANED_AGENTS_MD.sentence()}"
            )

        return warning_messages

    def _cleanup_orphaned_files(
        self, orphaned_files: builtins.list[Path], dry_run: bool = False
    ) -> builtins.list[str]:
        """Actually remove orphaned AGENTS.md files.

        Only APM-generated files (those bearing ``AGENTS_MD_GENERATED_MARKER``)
        are removed.  Hand-authored files are skipped silently and recorded at
        DEBUG level only -- no user-facing message is appended to the returned
        list.  (The marker gate is also applied in ``_find_orphaned_agents_files``,
        so reaching the skip branch here is a defense-in-depth path for direct
        callers and is not expected in normal operation.)

        Args:
            orphaned_files: Orphaned files to remove (should be pre-screened by
                ``_find_orphaned_agents_files``).
            dry_run: If True, report what would be removed without deleting.

        Returns:
            List of cleanup status messages.
        """
        cleanup_messages = []

        if not orphaned_files:
            return cleanup_messages

        if dry_run:
            # In dry-run mode, just report what would be cleaned
            cleanup_messages.append(
                f"Would clean up {len(orphaned_files)} orphaned AGENTS.md files"
            )
            for file_path in orphaned_files:
                rel_path = portable_relpath(file_path, self.base_dir)
                cleanup_messages.append(f"  * {rel_path}")
        else:
            # Actually perform the cleanup
            cleanup_messages.append(f"Cleaning up {len(orphaned_files)} orphaned AGENTS.md files")
            removed_count = 0
            for file_path in orphaned_files:
                rel_path: str | None = None
                try:
                    rel_path = portable_relpath(file_path, self.base_dir)
                    # Defense-in-depth: re-check the marker before deleting.
                    # Read only a bounded prefix (same helper as _find_orphaned_agents_files).
                    if not self._file_has_apm_marker(file_path):
                        # _find_orphaned_agents_files already marker-gates, so
                        # this branch is unreachable in normal operation.  Emit
                        # at debug level only to avoid a stray user-facing
                        # warning (and the double-prefix it would get).
                        _logger.debug("Skipped %s: hand-authored file -- not removing", rel_path)
                        continue
                    file_path.unlink()
                    removed_count += 1
                    cleanup_messages.append(f"  + Removed {rel_path}")
                except Exception as e:
                    # rel_path is None if portable_relpath itself raised; fall back to
                    # the raw path so the error message is always informative.
                    display = rel_path if rel_path is not None else str(file_path)
                    cleanup_messages.append(f"  x Failed to remove {display}: {e!s}")
            if removed_count == 0:
                cleanup_messages.append("  [i] 0 files removed (all skipped)")

        return cleanup_messages

    def _compile_distributed_stats(
        self,
        placements: builtins.list[PlacementResult],
        primitives: PrimitiveCollection,
        *,
        content_map: builtins.dict[Path, str] | None = None,
    ) -> builtins.dict[str, float]:
        """Compile statistics about the distributed compilation with optimization metrics.

        Args:
            placements (List[PlacementResult]): All placements analyzed (written + suppressed).
            primitives (PrimitiveCollection): Full primitive collection.
            content_map: Mapping of agents_path -> content for placements that will actually
                be written (i.e. excluding suppressed empty-shell placements).  When provided,
                ``agents_files_generated`` reflects the number of files that will be written
                rather than the number of placements analyzed (which overcounts under
                skip_instructions deduplication).  Defaults to None for back-compat with
                direct callers that do not pass the content map.

        Returns:
            Dict[str, float]: Compilation statistics including optimization metrics.
        """
        total_instructions = sum(len(p.instructions) for p in placements)
        total_patterns = sum(len(p.coverage_patterns) for p in placements)

        # agents_files_generated: number of files that will actually be written.
        # When content_map is provided (normal compile_distributed() path), use its
        # length so suppressed empty-shell placements are not counted.  Fall back to
        # len(placements) for back-compat with callers that do not pass content_map.
        files_generated = len(content_map) if content_map is not None else len(placements)

        # Get optimization metrics
        placement_map = {Path(p.agents_path.parent): p.instructions for p in placements}
        optimization_stats = self.context_optimizer.get_optimization_stats(placement_map)

        # Combine traditional stats with optimization metrics
        stats = {
            "agents_files_generated": files_generated,
            # Total placements analyzed (includes suppressed empty-shell placements).
            # Useful for audit/debug: agents_files_generated <= placements_analyzed.
            "placements_analyzed": len(placements),
            "total_instructions_placed": total_instructions,
            "total_patterns_covered": total_patterns,
            "primitives_found": primitives.count(),
            "chatmodes": len(primitives.chatmodes),
            "instructions": len(primitives.instructions),
            "contexts": len(primitives.contexts),
        }

        # Add optimization metrics from OptimizationStats object
        if optimization_stats:
            stats.update(
                {
                    "average_context_efficiency": optimization_stats.average_context_efficiency,
                    "pollution_improvement": optimization_stats.pollution_improvement,
                    "baseline_efficiency": optimization_stats.baseline_efficiency,
                    "placement_accuracy": optimization_stats.placement_accuracy,
                    "generation_time_ms": optimization_stats.generation_time_ms,
                    "total_agents_files": optimization_stats.total_agents_files,
                    "directories_analyzed": optimization_stats.directories_analyzed,
                }
            )

        return stats
