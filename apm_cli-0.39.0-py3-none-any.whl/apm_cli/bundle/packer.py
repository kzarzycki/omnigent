"""Bundle packer  -- creates self-contained APM bundles from the resolved dependency tree."""

import shutil
from dataclasses import dataclass, field
from pathlib import Path

from apm_cli.core.scope import manifest_file

from ..core.remediation import PACK_INSTALLED_FILES_MISSING, PACK_LOCKFILE_MISSING
from ..core.target_detection import detect_target
from ..deps.lockfile import LockFile, resolve_lockfile_path_for_read
from ..models.apm_package import APMPackage
from ..utils.archive import (
    projected_archive_path,
    validate_archive_format,
    write_tar_archive,
    write_zip_archive,
)
from ..utils.atomic_io import write_text_lf
from .attest import verify_attested_file
from .credential_files import refuse_credential_files
from .formats import BundleFormat, coerce_bundle_format
from .lockfile_enrichment import _filter_files_by_target, enrich_lockfile_for_pack


@dataclass
class PackResult:
    """Result of a pack operation."""

    bundle_path: Path
    files: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    lockfile_enriched: bool = False
    mapped_count: int = 0
    path_mappings: dict[str, str] = field(default_factory=dict)


def _bundle_file_paths(
    project_root: Path, unique_files: list[str], path_mappings: dict[str, str]
) -> list[str]:
    """List every bundle-relative file path, expanding deployed directories."""
    paths: list[str] = []
    for rel_path in unique_files:
        src = project_root / path_mappings.get(rel_path, rel_path)
        if src.is_symlink():
            continue
        if not src.is_dir():
            paths.append(rel_path)
            continue
        base = rel_path.rstrip("/")
        paths.extend(
            f"{base}/{child.relative_to(src).as_posix()}"
            for child in sorted(src.rglob("*"))
            if child.is_file() and not child.is_symlink()
        )
    return paths


def _with_warnings(warnings: list[str], result: PackResult) -> PackResult:
    """Put *warnings* (org policy findings) ahead of the format's own pack warnings."""
    result.warnings[:0] = warnings
    return result


def pack_bundle(
    project_root: Path,
    output_dir: Path,
    fmt: str | BundleFormat | None = None,
    target: str | list[str] | None = None,
    archive: bool = False,
    archive_format: str = "zip",
    dry_run: bool = False,
    force: bool = False,
    logger=None,
) -> PackResult:
    """Create a self-contained bundle from installed APM dependencies.

    Args:
        project_root: Root of the project containing ``apm.lock.yaml`` and ``apm.yml``.
        output_dir: Directory where the bundle will be created.
        fmt: Bundle format -- ``"claude-plugin"`` (legacy Claude bundle;
            ``"plugin"`` and ``"claude"`` are compatibility aliases),
            ``"agent-plugin"`` (portable Agent Plugins v1), or ``"apm"``
            (legacy APM bundle). ``None`` routes through the preferred-format
            seam in ``bundle.formats``.
        target: Target filter  -- ``"copilot"``, ``"claude"``, ``"all"``, a list of
            target strings (e.g. ``["claude", "vscode"]``), or *None*
            (auto-detect from apm.yml / project structure).
        archive: If *True*, produce a ``.zip`` (or ``.tar.gz`` when *archive_format* is ``"tar.gz"``) and remove the directory.
        archive_format: Archive format when *archive* is True -- ``"zip"`` (default) or ``"tar.gz"``.
        dry_run: If *True*, resolve the file list but write nothing to disk.
        force: On collision (plugin format), last writer wins.

    Returns:
        :class:`PackResult` describing what was (or would be) produced.

    Raises:
        FileNotFoundError: If ``apm.lock.yaml`` is missing.
        ValueError: If deployed files referenced in the lockfile are missing on disk,
            or org policy refuses a locked dependency.
    """
    bundle_format = coerce_bundle_format(fmt)
    # Org policy that refuses a dependency refuses to ship its content too.
    from .pack_policy import pack_policy_preflight

    policy_warnings = pack_policy_preflight(Path(project_root), logger)

    if bundle_format is BundleFormat.AGENT_PLUGIN:
        from .agent_plugin_exporter import export_agent_plugin_bundle

        return _with_warnings(
            policy_warnings,
            export_agent_plugin_bundle(
                project_root=project_root,
                output_dir=output_dir,
                target=target,
                archive=archive,
                archive_format=archive_format,
                dry_run=dry_run,
                force=force,
                logger=logger,
            ),
        )
    if bundle_format is BundleFormat.CLAUDE_PLUGIN:
        from .claude_plugin_exporter import export_claude_plugin_bundle

        return _with_warnings(
            policy_warnings,
            export_claude_plugin_bundle(
                project_root=project_root,
                output_dir=output_dir,
                target=target,
                archive=archive,
                archive_format=archive_format,
                dry_run=dry_run,
                force=force,
                logger=logger,
            ),
        )

    lockfile_path = resolve_lockfile_path_for_read(project_root, read_only=dry_run)
    lockfile = LockFile.read(lockfile_path)
    if lockfile is None:
        raise FileNotFoundError(f"apm.lock.yaml not found -- {PACK_LOCKFILE_MISSING.clause()}.")

    # 2. Read apm.yml for name / version / config target
    apm_yml_path = manifest_file(project_root)
    skill_md_path = project_root / "SKILL.md"
    is_hybrid_root = apm_yml_path.exists() and skill_md_path.exists()
    try:
        package = APMPackage.from_apm_yml(apm_yml_path)
        pkg_name = package.name
        pkg_version = package.version or "0.0.0"
        from apm_cli.models.apm_package import package_target_selection

        config_target = package_target_selection(package)

        # HYBRID author guard: apm.yml.description and SKILL.md
        # description serve different consumers (human-facing CLI/search
        # vs. agent-runtime invocation matcher) and are NOT merged. If
        # the author shipped a SKILL.md description but left
        # apm.yml.description blank, the human-facing surfaces (apm view,
        # apm search, marketplace listings) will degrade silently while
        # Claude/Copilot still invoke the skill correctly. Warn loudly
        # at pack time -- this is the publish gate for the AUTHOR.
        if is_hybrid_root and not package.description and logger:
            try:
                from apm_cli.utils.yaml_io import load_frontmatter

                with open(skill_md_path, encoding="utf-8") as _f:
                    _skill_post = load_frontmatter(_f)
                _skill_desc = _skill_post.metadata.get("description")
            except Exception:
                _skill_desc = None
            if _skill_desc:
                logger.warning(
                    "apm.yml is missing 'description'. SKILL.md has its own "
                    "description, but that is for agent invocation -- not "
                    "for 'apm view' or search. Add a short tagline to "
                    'apm.yml:  description: "One-line human summary"'
                )

        # Guard: reject local-path dependencies (non-portable)
        for dep_ref in package.get_apm_dependencies():
            if dep_ref.is_local:
                raise ValueError(
                    f"Cannot pack -- apm.yml contains local path dependency: "
                    f"{dep_ref.local_path}\n"
                    f"Local dependencies are for development only. Replace them with "
                    f"remote references (e.g., 'owner/repo') before packing."
                )
    except ValueError:
        raise
    except FileNotFoundError:
        pkg_name = project_root.resolve().name
        pkg_version = "0.0.0"
        config_target = None

    # 3. Resolve effective target
    if isinstance(target, list):
        # List from CLI (e.g. --target claude,copilot) passes through directly
        effective_target = target
    elif isinstance(config_target, list) and target is None:
        # Canonical list from either apm.yml target spelling.
        effective_target = config_target
    else:
        effective_target, _reason = detect_target(
            project_root,
            explicit_target=target,
            config_target=config_target if isinstance(config_target, str) else None,
        )
        # For packing purposes, "minimal" means nothing to pack  -- treat as "all"
        if effective_target == "minimal":
            effective_target = "all"

    # 4. Collect deployed_files from all dependencies, filtered by target.
    #    Skip local-source entries: these include the synthesized root self-entry
    #    (local_path == ".") and any local-path manifest deps. Local content is
    #    not portable and is bundled separately via the project's own files
    #    (or rejected outright at L89-97 for manifest-declared local deps).
    all_deployed: list[str] = []
    # Provenance map: deployed-path -> (attested SHA-256, dependency label).
    # ``deployed_file_hashes`` is keyed by the on-disk deployed path recorded
    # at install time (see install/phases/lockfile.compute_deployed_hashes), so
    # verification below must look up the on-disk path, not the bundle path.
    deployed_hashes: dict[str, str] = {}
    hash_dep_labels: dict[str, str] = {}
    for dep in lockfile.get_all_dependencies():
        if dep.source == "local":
            continue
        all_deployed.extend(dep.deployed_files)
        for _dpath, _dhash in dep.deployed_file_hashes.items():
            deployed_hashes[_dpath] = _dhash
            hash_dep_labels[_dpath] = dep.repo_url

    filtered_files, path_mappings = _filter_files_by_target(all_deployed, effective_target)
    # Deduplicate while preserving order
    seen = set()
    unique_files: list[str] = []
    for f in filtered_files:
        if f not in seen:
            seen.add(f)
            unique_files.append(f)
    # Claude rules #3939 compiles into AGENTS.md still ship as rules (#4005).
    from .claude_routed_rules import (
        merged_routed_claude_rules,
        routed_claude_rules,
        write_routed_claude_rules,
    )

    rendered_rules = routed_claude_rules(lockfile, project_root, effective_target)
    rendered_files = merged_routed_claude_rules(
        rendered_rules, {path: project_root / path_mappings.get(path, path) for path in seen}
    )

    # 5. Verify each path is safe (no traversal) and exists on disk
    project_root_resolved = project_root.resolve()
    missing: list[str] = []
    for rel_path in unique_files:
        # Guard against absolute paths or path-traversal entries in deployed_files
        p = Path(rel_path)
        if p.is_absolute() or ".." in p.parts:
            raise ValueError(f"Refusing to pack unsafe path from lockfile: {rel_path!r}")
        # For cross-target mapped files, verify the original (on-disk) path
        disk_path = path_mappings.get(rel_path, rel_path)
        abs_path = project_root / disk_path
        if not abs_path.resolve().is_relative_to(project_root_resolved):
            raise ValueError(f"Refusing to pack path that escapes project root: {disk_path!r}")
        # deployed_files may reference directories (ending with /)
        if not abs_path.exists():
            missing.append(disk_path)
    if missing:
        raise ValueError(
            f"The following deployed files are missing on disk -- "
            f"{PACK_INSTALLED_FILES_MISSING.clause()}:\n" + "\n".join(f"  - {m}" for m in missing)
        )
    refuse_credential_files(_bundle_file_paths(project_root, unique_files, path_mappings))

    # Dry-run: return file list without writing anything
    if dry_run:
        bundle_name = f"{pkg_name}-{pkg_version}"
        bundle_path = (
            projected_archive_path(output_dir, bundle_name, archive_format)
            if archive
            else output_dir / bundle_name
        )
        return PackResult(
            bundle_path=bundle_path,
            files=[*unique_files, *rendered_files],
            warnings=list(policy_warnings),
            lockfile_enriched=True,
            mapped_count=len(path_mappings),
            path_mappings=path_mappings,
        )

    # 5b. Scan files for hidden characters before bundling.
    # Intentionally non-blocking (warn only) — pack is an authoring tool.
    # Critical findings here mean the author's own source files contain
    # hidden characters. We surface them so the author can fix before
    # publishing, but don't block the bundle. Consumers are protected by
    # install/unpack which block on critical.
    from ..security.gate import WARN_POLICY, SecurityGate
    from ..utils.console import _rich_warning

    _scan_findings_total = 0
    for rel_path in unique_files:
        disk_path = path_mappings.get(rel_path, rel_path)
        src = project_root / disk_path
        if src.is_symlink():
            continue
        if src.is_dir():
            verdict = SecurityGate.scan_files(src, policy=WARN_POLICY)
            _scan_findings_total += len(verdict.all_findings)
        elif src.is_file():
            verdict = SecurityGate.scan_text(
                src.read_text(encoding="utf-8", errors="replace"),
                str(src),
                policy=WARN_POLICY,
            )
            _scan_findings_total += len(verdict.all_findings)
    if _scan_findings_total:
        _warn_msg = (
            f"Bundle contains {_scan_findings_total} hidden character(s) across source files "
            f"-- run 'apm audit' to inspect before publishing"
        )
        if logger:
            logger.warning(_warn_msg)
        else:
            _rich_warning(_warn_msg)

    # 6. Build output directory
    bundle_dir = output_dir / f"{pkg_name}-{pkg_version}"
    bundle_dir.mkdir(parents=True, exist_ok=True)
    bundle_dir_resolved = bundle_dir.resolve()

    # 7. Copy files preserving directory structure.
    #    Provenance gate (#2013): each dependency file recorded in the lockfile
    #    is verified against its attested SHA-256 before it enters the bundle --
    #    the same integrity guarantee the plugin format enforces, applied to the
    #    default/most-used ``apm`` format. Files with no recorded hash (older
    #    lockfiles) pack without verification; a mismatch fails loud.
    for rel_path in unique_files:
        # For cross-target mapped files, read from the original disk path
        disk_path = path_mappings.get(rel_path, rel_path)
        src = project_root / disk_path
        if src.is_symlink():
            continue  # Never bundle symlinks
        dest = bundle_dir / rel_path
        # Defense-in-depth: verify mapped destination stays inside the bundle
        if not dest.resolve().is_relative_to(bundle_dir_resolved):
            raise ValueError(f"Refusing to write outside bundle directory: {rel_path!r}")
        if src.is_dir():
            from ..security.gate import ignore_non_content

            # Verify each contained file's attested hash and re-assert
            # containment per child. copytree already drops symlinks via
            # ignore_non_content, but the walk guards against a directory
            # symlink whose target escapes the project root regardless of the
            # walker's version-specific symlink-following behaviour.
            disk_base = disk_path.rstrip("/")
            for child in sorted(src.rglob("*")):
                if not child.is_file() or child.is_symlink():
                    continue
                if not child.resolve().is_relative_to(project_root_resolved):
                    raise ValueError(
                        f"Refusing to pack path that escapes project root: "
                        f"{child.relative_to(project_root)!r}"
                    )
                child_key = f"{disk_base}/{child.relative_to(src).as_posix()}"
                verify_attested_file(
                    child,
                    deployed_hashes.get(child_key),
                    hash_dep_labels.get(child_key, "dependency"),
                    child_key,
                )
            shutil.copytree(src, dest, dirs_exist_ok=True, ignore=ignore_non_content)
        else:
            verify_attested_file(
                src,
                deployed_hashes.get(disk_path),
                hash_dep_labels.get(disk_path, "dependency"),
                disk_path,
            )
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest, follow_symlinks=False)

    write_routed_claude_rules(bundle_dir, rendered_files)
    if rendered_rules:
        import copy
        import hashlib

        from ..core.deployment_ledger import DeploymentLedgerCodec

        provenance = DeploymentLedgerCodec.from_lockfile(lockfile)
        lockfile = copy.deepcopy(lockfile)
        for dep in lockfile.get_all_dependencies():
            added = rendered_rules.get(dep.get_unique_key())
            if not added:
                continue
            hashes = dict(dep.deployed_file_hashes)
            for rel_path, text in added.items():
                digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
                hashes[rel_path] = f"sha256:{digest}"
            DeploymentLedgerCodec.replace_legacy_owner(
                lockfile,
                dep.get_unique_key(),
                [*dep.deployed_files, *added],
                hashes,
                provenance=provenance,
            )

    # 8. Enrich lockfile copy and write to bundle
    enriched_yaml = enrich_lockfile_for_pack(lockfile, bundle_format.lock_value, effective_target)
    write_text_lf(bundle_dir / "apm.lock.yaml", enriched_yaml)

    result = PackResult(
        bundle_path=bundle_dir,
        files=[*unique_files, *rendered_files],
        lockfile_enriched=True,
        mapped_count=len(path_mappings),
        path_mappings=path_mappings,
    )

    # 10. Archive if requested
    if archive:
        validate_archive_format(archive_format)
        archive_path = projected_archive_path(
            output_dir, f"{pkg_name}-{pkg_version}", archive_format
        )
        if archive_format == "tar.gz":
            write_tar_archive(bundle_dir, archive_path)
        else:
            write_zip_archive(bundle_dir, archive_path)
        shutil.rmtree(bundle_dir)
        result.bundle_path = archive_path

    return _with_warnings(policy_warnings, result)
