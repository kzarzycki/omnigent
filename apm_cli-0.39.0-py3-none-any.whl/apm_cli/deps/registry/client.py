"""HTTP client for the dedicated registry API.

Implements docs/proposals/registry-api.md §5:

- ``GET /v1/packages/{owner}/{repo}/versions`` — list versions
- ``GET /v1/packages/{owner}/{repo}/versions/{version}/download`` — fetch archive

- ``PUT /v1/packages/{owner}/{repo}/versions/{version}`` — publish

Design notes:

- All endpoints use ``Authorization: Bearer <token>`` when an env-var token is
  configured for the registry. Anonymous fetch is the fallback (§6.2 rule 2).
- Errors surface as ``RegistryError`` carrying the HTTP status and a parsed
  RFC 7807 Problem Details body when present. The install path turns 401/403
  into the §6.2 remediation message at a higher level.
- No HTTP cache layer — ``Cache-Control: max-age=60`` from the server is
  advisory only. In-process memoization can be added later.
"""

from __future__ import annotations

import contextlib
import ipaddress
import json
import urllib.parse
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import requests

from ...utils.credential_rendering import redact_url_userinfo
from ...utils.diagnostics import printable_ascii_text
from ...utils.http_credentials import (
    REFUSED_HOP_LIMIT,
    REFUSED_METHOD_CHANGE,
    REFUSED_OUTSIDE_BASE_PATH,
    CredentialScopedSession,
    RedirectRefusedError,
    origin_bound_refusal,
    origin_bounded_request,
    origin_label,
)
from .auth import RegistryAuthContext

# Untrusted registry JSON is read incrementally with a hard byte cap so a
# multi-GB body cannot OOM the client before any parse runs, and decoded with
# a widened except so a deep-nested body (RecursionError) or non-UTF-8 body
# (UnicodeDecodeError) fails CLOSED as a RegistryError instead of escaping the
# install path uncaught. Mirrors marketplace/client.py::_read_capped_json.
_MAX_REGISTRY_JSON_BYTES = 10 * 1024 * 1024  # 10 MiB
_MAX_PROBLEM_JSON_BYTES = 256 * 1024  # RFC 7807 error bodies are small
_REGISTRY_CHUNK_BYTES = 64 * 1024
_REGISTRY_JSON_ERRORS = (ValueError, json.JSONDecodeError, RecursionError, UnicodeDecodeError)


def _read_capped_body(
    response: requests.Response,
    url: str | None,
    *,
    max_bytes: int = _MAX_REGISTRY_JSON_BYTES,
) -> bytes:
    """Read a response body incrementally, capping total bytes.

    Works for both streamed (``stream=True``) and buffered responses: a
    buffered response's ``iter_content`` replays the cached body. Raises
    ``RegistryError`` if the advertised or actual size exceeds ``max_bytes``.
    Always closes the response.
    """
    with contextlib.suppress(ValueError, TypeError):
        declared = int(response.headers.get("Content-Length", ""))
        if declared > max_bytes:
            raise RegistryError(
                f"registry body exceeds {max_bytes} byte cap (declared {declared})",
                url=url,
            )
    chunks: list[bytes] = []
    total = 0
    try:
        for chunk in response.iter_content(chunk_size=_REGISTRY_CHUNK_BYTES):
            if not chunk:
                continue
            total += len(chunk)
            if total > max_bytes:
                raise RegistryError(
                    f"registry body exceeds {max_bytes} byte cap",
                    url=url,
                )
            chunks.append(chunk)
    except requests.RequestException as exc:
        raise RegistryError(
            f"transport error reading registry body: {exc}",
            url=url,
        ) from exc
    finally:
        with contextlib.suppress(Exception):
            response.close()
    return b"".join(chunks)


def _decode_capped_json(response: requests.Response, endpoint: str, url: str | None) -> Any:
    """Read a capped body and decode it as JSON, failing closed as RegistryError."""
    raw = _read_capped_body(response, url)
    try:
        return json.loads(raw.decode("utf-8"))
    except _REGISTRY_JSON_ERRORS as exc:
        raise RegistryError(
            f"registry returned non-JSON for {endpoint}: {exc}",
            url=url,
        ) from exc


def _safe_problem_json(response: requests.Response) -> dict[str, Any]:
    """Best-effort parse of a small RFC 7807 error body; never raises.

    A hostile 4xx body (deep-nested JSON -> RecursionError, oversized int
    -> ValueError, non-UTF-8 -> UnicodeDecodeError, or a body over the small
    problem cap -> RegistryError) degrades to ``{}`` rather than masking the
    real HTTP error with a parse crash on the install path.
    """
    if "json" not in (response.headers.get("Content-Type", "") or ""):
        return {}
    try:
        raw = _read_capped_body(response, response.url, max_bytes=_MAX_PROBLEM_JSON_BYTES)
        problem = json.loads(raw.decode("utf-8"))
    except (*_REGISTRY_JSON_ERRORS, RegistryError):
        return {}
    return problem if isinstance(problem, dict) else {}


class RegistryError(Exception):
    """A registry HTTP call failed.

    ``status`` is the HTTP status code (or ``None`` for transport-level
    failures); ``problem`` is the parsed RFC 7807 body when available.
    """

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        problem: dict[str, Any] | None = None,
        url: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.problem = problem or {}
        self.url = url


@dataclass(frozen=True)
class VersionEntry:
    """One row from ``GET /v1/packages/.../versions``."""

    version: str
    digest: str
    published_at: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> VersionEntry:
        version = payload.get("version")
        digest = payload.get("digest")
        if not isinstance(version, str) or not version:
            raise RegistryError(f"malformed version entry (missing 'version'): {payload!r}")
        if not isinstance(digest, str) or not digest:
            raise RegistryError(f"malformed version entry (missing 'digest') for {version!r}")
        # ``published_at`` is the spec-canonical key (snake_case throughout
        # — see registry-http-api.md §3.1). The client is intentionally
        # strict: a server that emits ``publishedAt`` (camelCase) is non-
        # conformant. Accepting both would mask spec drift; reject silently
        # by reading only the canonical name.
        published = payload.get("published_at")
        if not isinstance(published, str) or not published:
            raise RegistryError(f"malformed version entry (missing 'published_at') for {version!r}")
        return cls(
            version=version,
            digest=digest,
            published_at=published,
        )


@dataclass(frozen=True)
class PublishResult:
    """Response from ``PUT /v1/packages/.../versions/{version}``."""

    package: str  # "owner/repo"
    version: str
    digest: str  # "sha256:abc123..."
    published_at: str | None = None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> PublishResult:
        package = payload.get("package")
        version = payload.get("version")
        digest = payload.get("digest")
        if not isinstance(package, str) or not package:
            raise RegistryError(f"malformed publish response (missing 'package'): {payload!r}")
        if not isinstance(version, str) or not version:
            raise RegistryError(f"malformed publish response (missing 'version'): {payload!r}")
        if not isinstance(digest, str) or not digest:
            raise RegistryError(f"malformed publish response (missing 'digest'): {payload!r}")
        published = payload.get("published_at")
        return cls(
            package=package,
            version=version,
            digest=digest,
            published_at=published if isinstance(published, str) else None,
        )


_DEFAULT_TIMEOUT = (10, 60)  # (connect, read) seconds


def _validate_registry_transport(url: str) -> urllib.parse.ParseResult:
    """Return a parsed registry URL after enforcing the transport boundary."""
    parsed = urllib.parse.urlparse(url)
    if not parsed.hostname:
        raise ValueError("registry URL must include a host")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("registry URLs must not contain credentials")
    if parsed.query or parsed.fragment:
        raise ValueError("registry URLs must not contain query strings or fragments")
    if parsed.scheme == "https":
        return parsed
    if parsed.scheme == "http" and parsed.hostname:
        host = parsed.hostname.lower()
        try:
            is_loopback = ipaddress.ip_address(host).is_loopback
        except ValueError:
            is_loopback = host == "localhost"
        if is_loopback:
            return parsed
    raise ValueError("registry URLs must use HTTPS (HTTP is allowed only for loopback testing)")


class RegistryClient:
    """Minimal HTTP client for the registry API.

    One client per registry URL. Stateless aside from the auth context — safe
    to instantiate per install or share for an entire resolution graph.
    """

    def __init__(
        self,
        base_url: str,
        auth: RegistryAuthContext,
        *,
        session: requests.Session | None = None,
        timeout: tuple[float, float] | None = None,
    ) -> None:
        if not base_url:
            raise ValueError("base_url is required")
        parsed = _validate_registry_transport(base_url)
        if parsed.scheme == "http" and auth.auth_header() is not None:
            raise ValueError("registry credentials must not be sent over HTTP")
        # Strip trailing slash so we can join cleanly.
        self._base_url = base_url.rstrip("/")
        self._auth = auth
        self._session = session or CredentialScopedSession()
        self._timeout = timeout or _DEFAULT_TIMEOUT

    @property
    def base_url(self) -> str:
        return self._base_url

    def _headers(self, accept: str = "application/json") -> dict[str, str]:
        headers = {"Accept": accept}
        headers.update(self._auth.headers())
        return headers

    def _url(self, path: str) -> str:
        if not path.startswith("/"):
            path = "/" + path
        return f"{self._base_url}{path}"

    def _request(
        self,
        method: str,
        path: str,
        *,
        accept: str = "application/json",
        stream: bool = False,
    ) -> requests.Response:
        url = self._url(path)
        response = self._send(method, url, headers=self._headers(accept=accept), stream=stream)
        return self._raise_for_status(response, url)

    def _send(
        self,
        method: str,
        url: str,
        *,
        headers: dict[str, str],
        data: bytes | None = None,
        stream: bool = False,
    ) -> requests.Response:
        """Send through the origin-bounded redirect owner, mapping its errors."""
        try:
            return origin_bounded_request(
                self._session,
                method,
                url,
                base_url=self._base_url,
                headers=headers,
                data=data,
                timeout=self._timeout,
                stream=stream,
            )
        except RedirectRefusedError as exc:
            status = getattr(exc.response, "status_code", None)
            raise RegistryError(
                _redirect_refusal_message(exc, method, self._base_url),
                status=status,
                url=url,
            ) from exc
        except requests.RequestException as exc:
            raise RegistryError(
                f"transport error talking to registry: {printable_ascii_text(str(exc))}",
                url=url,
            ) from exc

    @staticmethod
    def _raise_for_status(response: requests.Response, url: str) -> requests.Response:
        """Raise ``RegistryError`` for any non-2xx (an unfollowed 3xx included)."""
        if response.status_code >= 300:
            problem = _safe_problem_json(response)
            raise RegistryError(
                _format_error(response.status_code, problem, url),
                status=response.status_code,
                problem=problem,
                url=url,
            )
        return response

    def _response_json(self, response: requests.Response, endpoint: str) -> Any:
        return _decode_capped_json(response, endpoint, response.url)

    # ------------------------------------------------------------------ §5.1
    def list_versions(self, owner: str, repo: str) -> list[VersionEntry]:
        """``GET /v1/packages/{owner}/{repo}/versions``."""
        path = f"/v1/packages/{_quote(owner)}/{_quote(repo)}/versions"
        # stream=True so the untrusted /versions body is read incrementally
        # under the byte cap (a buffered read would OOM before the cap runs).
        response = self._request("GET", path, stream=True)
        payload = self._response_json(response, "/versions")
        raw_versions = payload.get("versions") if isinstance(payload, dict) else None
        if not isinstance(raw_versions, list):
            raise RegistryError(
                f"registry response missing 'versions' array: {payload!r}",
                url=response.url,
            )
        return [VersionEntry.from_dict(row) for row in raw_versions]

    # ------------------------------------------------------------------ §5.2
    def download_archive(
        self,
        owner: str,
        repo: str,
        version: str,
    ) -> tuple[bytes, str]:
        """``GET /v1/packages/{owner}/{repo}/versions/{version}/download``.

        Endpoint is format-neutral; the server replies with ``application/gzip``
        (tar.gz) or ``application/zip`` (Anthropic skills format) and the
        client dispatches on content type.

        Returns ``(body_bytes, content_type)``. Caller is responsible for
        sha256 verification (use ``extractor.verify_sha256``) and for picking
        the right extractor (``extractor.extract_archive`` does this for you).
        """
        path = f"/v1/packages/{_quote(owner)}/{_quote(repo)}/versions/{_quote(version)}/download"
        # Accept both archive types; v1 doesn't constrain via Accept (the
        # publisher chose the format at upload time).
        response = self._request("GET", path, accept="application/gzip, application/zip")
        content_type = (response.headers.get("Content-Type") or "").split(";", 1)[0].strip()
        return response.content, content_type

    def archive_url(self, owner: str, repo: str, version: str) -> str:
        """The canonical ``resolved_url`` for a given (owner, repo, version)."""
        return self._url(
            f"/v1/packages/{_quote(owner)}/{_quote(repo)}/versions/{_quote(version)}/download"
        )

    def fetch_from_url(self, url: str) -> tuple[bytes, str]:
        """Fetch an absolute URL with auth headers (lockfile replay path).

        Unlike ``_request``, this takes a fully-qualified URL (not a path
        relative to ``_base_url``), so the caller controls the exact endpoint.
        Used by ``RegistryPackageResolver.download_from_lockfile`` to fetch
        from the URL recorded in the lockfile without re-querying ``/versions``.
        """
        _validate_registry_transport(url)
        refusal = origin_bound_refusal(url, base_url=self._base_url)
        if refusal == REFUSED_OUTSIDE_BASE_PATH:
            raise RegistryError(
                "lockfile registry URL is outside configured registry path", url=url
            )
        if refusal is not None:
            raise RegistryError("lockfile registry URL does not match configured registry", url=url)
        response = self._send(
            "GET", url, headers=self._headers(accept="application/gzip, application/zip")
        )
        self._raise_for_status(response, url)
        content_type = (response.headers.get("Content-Type") or "").split(";", 1)[0].strip()
        return response.content, content_type

    # ------------------------------------------------------------------ §5.3
    def publish_version(
        self,
        owner: str,
        repo: str,
        version: str,
        archive_bytes: bytes,
    ) -> PublishResult:
        """``PUT /v1/packages/{owner}/{repo}/versions/{version}`` — publish.

        Uploads *archive_bytes* (an ``application/zip`` archive produced by
        ``apm publish``) and returns the registry's 201 response as a
        ``PublishResult``.

        Errors surface as ``RegistryError`` with the HTTP status set:

        - 403 -- caller lacks publish permission for this owner/repo
        - 409 -- version already exists (immutable; republish is rejected)
        - 422 -- server-side lint/validation failed
        """
        path = f"/v1/packages/{_quote(owner)}/{_quote(repo)}/versions/{_quote(version)}"
        url = self._url(path)
        headers = self._headers(accept="application/json")
        headers["Content-Type"] = "application/zip"
        response = self._send("PUT", url, headers=headers, data=archive_bytes)
        self._raise_for_status(response, url)
        body = (response.content or b"").strip()
        if not body:
            # Some registries (e.g. JFrog) return 201 with an empty body.
            import hashlib

            digest = f"sha256:{hashlib.sha256(archive_bytes).hexdigest()}"
            return PublishResult(
                package=f"{owner}/{repo}",
                version=version,
                digest=digest,
                published_at=None,
            )
        payload = self._response_json(response, "PUT /versions")
        return PublishResult.from_dict(payload)


def _quote(s: str) -> str:
    """Percent-encode a path segment, allowing ``.``, ``-``, and ``_`` raw.

    ``_`` is an RFC 3986 unreserved character and must not be percent-encoded;
    omitting it caused owner/repo names containing underscores to be serialised
    as ``%5F`` in registry URLs.
    """
    return urllib.parse.quote(s, safe=".-_")


def _redirect_refusal_message(exc: RedirectRefusedError, method: str, base_url: str) -> str:
    origin = origin_label(base_url)
    status = getattr(exc.response, "status_code", None)
    if exc.reason == REFUSED_METHOD_CHANGE:
        return (
            f"registry answered {method} with HTTP {status}; only 307 and 308 may "
            f"redirect a {method} ({origin}); refusing"
        )
    if exc.reason == REFUSED_HOP_LIMIT:
        return f"registry redirected more than 3 times ({origin}); refusing"
    return f"registry redirected outside the configured registry ({origin}); refusing"


def _format_error(status: int, problem: Mapping[str, Any], url: str) -> str:
    title = problem.get("title") if isinstance(problem, Mapping) else None
    detail = problem.get("detail") if isinstance(problem, Mapping) else None
    body = " - ".join(part for part in (title, detail) if part)
    url = redact_url_userinfo(url)
    if body:
        return f"registry HTTP {status} from {url}: {body}"
    return f"registry HTTP {status} from {url}"
