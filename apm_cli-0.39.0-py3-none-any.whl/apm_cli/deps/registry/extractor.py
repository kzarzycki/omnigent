"""Archive extraction with sha256 verification.

Per docs/proposals/registry-api.md §5.2 and §6.1: the client MUST verify the
sha256 digest of the archive against the value advertised by ``GET /versions``
or recorded in the lockfile *before* extracting. A mismatch fails closed —
this is the only security-critical check on the install path.

Two archive formats are supported, dispatched by Content-Type from
``RegistryClient.download_archive``:

- ``application/zip``  -- zip archive (default; produced by ``apm pack --archive``
  and ``apm publish``)
- ``application/gzip`` -- gzipped tar (legacy; packages published before the zip default)

The ``extract_archive`` dispatcher picks the right path; both formats go
through the shared archive-limits owner in ``apm_cli.utils.archive``
(entry-count and uncompressed-size caps; no absolute paths, path traversal,
links, special files or duplicate entries). The hash is checked against the raw bytes regardless of format —
a wrong-format guess produces a clean error, not a security issue.

Layout: archives are extracted into ``apm_modules/{owner}/{repo}/`` (the same
shape the Git resolver produces after ``git clone``).
"""

from __future__ import annotations

import hashlib
import tarfile
import zipfile
from dataclasses import dataclass
from pathlib import Path

from apm_cli.utils.archive import open_tar_gz, safe_extract_tar, safe_extract_zip


class HashMismatchError(Exception):
    """Raised when an archive's sha256 does not match the expected digest."""


class UnsafeTarballError(Exception):
    """Raised when an archive entry would escape the extraction root.

    Name kept for backward compat; covers both tar and zip cases.
    """


class UnknownArchiveFormatError(Exception):
    """Raised when the archive format can't be inferred from content type or magic bytes."""


@dataclass(frozen=True)
class _ArchiveFormat:
    label: str
    content_types: tuple[str, ...]
    magic: bytes


_TAR_GZIP_FORMAT = _ArchiveFormat(
    label="tar+gzip",
    content_types=(
        "application/gzip",
        "application/x-gzip",
        "application/x-tar+gzip",
    ),
    magic=b"\x1f\x8b",
)
_ZIP_FORMAT = _ArchiveFormat(
    label="zip",
    content_types=(
        "application/zip",
        "application/x-zip-compressed",
    ),
    magic=b"PK\x03\x04",
)
_ARCHIVE_FORMATS = (_TAR_GZIP_FORMAT, _ZIP_FORMAT)
_FORMAT_BY_CONTENT_TYPE = {
    content_type: archive_format
    for archive_format in _ARCHIVE_FORMATS
    for content_type in archive_format.content_types
}


def _detect_format(data: bytes, content_type: str | None) -> _ArchiveFormat:
    """Return the detected archive format.

    Content-Type wins; magic bytes are fallback.
    """
    if content_type:
        ct = content_type.lower().strip()
        archive_format = _FORMAT_BY_CONTENT_TYPE.get(ct)
        if archive_format is not None:
            return archive_format
    # Fallback to magic bytes
    for archive_format in _ARCHIVE_FORMATS:
        if data.startswith(archive_format.magic):
            return archive_format
    raise UnknownArchiveFormatError(
        f"cannot determine archive format from content_type={content_type!r}; "
        f"first bytes were {data[:8]!r}"
    )


def _normalize_digest(digest: str) -> str:
    """Strip the ``sha256:`` / ``sha256=`` prefix if present and lowercase."""
    s = digest.strip().lower()
    for prefix in ("sha256:", "sha256="):
        if s.startswith(prefix):
            return s[len(prefix) :]
    return s


def verify_sha256(data: bytes, expected_digest: str) -> str:
    """Verify *data*'s sha256 matches *expected_digest*.

    Accepts the digest with or without a ``sha256:`` / ``sha256=`` prefix.
    Returns the actual hex digest on success; raises ``HashMismatchError`` on
    mismatch.
    """
    actual = hashlib.sha256(data).hexdigest()
    expected = _normalize_digest(expected_digest)
    if actual != expected:
        raise HashMismatchError(f"archive sha256 mismatch: expected {expected}, got {actual}")
    return actual


def _safe_extract(tar: tarfile.TarFile, dest_root: Path) -> None:
    """Extract *tar* into *dest_root* with the shared archive limits."""
    safe_extract_tar(tar, dest_root, error_type=UnsafeTarballError)


def extract_tarball(
    data: bytes,
    expected_digest: str,
    dest_root: Path,
) -> str:
    """Verify *data*'s sha256 then extract its gzipped tar contents into *dest_root*.

    Returns the actual hex digest of *data* on success. Raises
    ``HashMismatchError`` if the digest doesn't match, or
    ``UnsafeTarballError`` if any member would escape *dest_root*.
    """
    actual = verify_sha256(data, expected_digest)
    import io  # local import — only needed on the install path

    with open_tar_gz(fileobj=io.BytesIO(data), error_type=UnsafeTarballError) as tar:
        _safe_extract(tar, Path(dest_root))
    return actual


def _safe_extract_zip(zf: zipfile.ZipFile, dest_root: Path) -> None:
    """Extract *zf* into *dest_root* with shared zip safety gates."""
    safe_extract_zip(zf, dest_root, error_type=UnsafeTarballError)


def extract_zip(
    data: bytes,
    expected_digest: str,
    dest_root: Path,
) -> str:
    """Verify *data*'s sha256 then extract its zip contents into *dest_root*.

    Returns the actual hex digest of *data* on success. Raises
    ``HashMismatchError`` on mismatch, or ``UnsafeTarballError`` (name kept
    for backward compat) if any member would escape *dest_root*.
    """
    actual = verify_sha256(data, expected_digest)
    import io  # local import — only needed on the install path

    try:
        with zipfile.ZipFile(io.BytesIO(data), mode="r") as zf:
            _safe_extract_zip(zf, Path(dest_root))
    except zipfile.BadZipFile as exc:
        raise UnknownArchiveFormatError(f"malformed zip archive: {exc}") from exc
    return actual


def extract_archive(
    data: bytes,
    expected_digest: str,
    dest_root: Path,
    *,
    content_type: str | None = None,
) -> str:
    """Dispatcher: pick the right extractor based on Content-Type / magic bytes.

    The hash check happens identically for both formats. A mismatch fails
    before extraction even starts; format-detection errors fail before any
    bytes are written.
    """
    fmt = _detect_format(data, content_type)
    if fmt is _TAR_GZIP_FORMAT:
        return extract_tarball(data, expected_digest, dest_root)
    if fmt is _ZIP_FORMAT:
        return extract_zip(data, expected_digest, dest_root)
    # _detect_format raises UnknownArchiveFormatError otherwise; this is
    # belt-and-braces.
    raise UnknownArchiveFormatError(f"unsupported archive format: {fmt.label!r}")
