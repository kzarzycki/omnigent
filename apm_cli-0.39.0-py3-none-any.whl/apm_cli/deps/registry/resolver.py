"""Registry-backed package resolver.

Implements the install-side of docs/proposals/registry-api.md: given a
``DependencyReference`` whose ``source == "registry"``, fetch its tarball from
the configured registry, verify the sha256, extract into the target directory,
and build a ``PackageInfo`` that the rest of the install pipeline consumes
without further changes (per §8 the only new branch is the download itself).

This object satisfies the ``DownloadCallback`` shape used by the existing
resolver: it exposes a ``download_package(dep_ref, target_path, ...)`` method
that returns a ``PackageInfo``. Wiring into the install pipeline is done in
``install/phases/resolve.py`` (separate commit) — this module is a pure unit.
"""

from __future__ import annotations

import hashlib
import shutil
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from ...agent_plugins.errors import AgentPluginError
from ...bundle.local_bundle import route_agent_plugin_package
from ...models.apm_package import PackageInfo, validate_apm_package
from ...models.dependency.reference import DependencyReference
from ...models.dependency.types import GitReferenceType, ResolvedReference
from ...utils.console import _rich_info
from ...utils.credential_rendering import redact_url_userinfo
from ...utils.realpath_win import release_held
from .auth import (
    RegistryAuthContext,
    make_auth_context,
    remediation_message,
)
from .client import RegistryClient, RegistryError, VersionEntry
from .extractor import HashMismatchError, extract_archive, verify_sha256
from .semver import is_semver_range, pick_best


class RegistryResolutionError(Exception):
    """A registry-sourced install failed in a way the user must act on.

    Wraps lower-level errors (auth, hash mismatch, no matching version, missing
    URL) into a single exception type the install pipeline can catch and
    surface with the §6.2 remediation message intact.
    """


def split_registry_identity(repo_url: str) -> tuple[str, str]:
    """Split a registry package identity into ``(owner, repo)`` for the API.

    Registry HTTP API section 1.2: the last ``/``-separated part is the repo
    and everything before it, including any host, is the owner (e.g.
    ``gitlab.com/acme/x`` -> ``("gitlab.com/acme", "x")``). The client
    percent-encodes each part as one path segment. Both install (consumer)
    and ``apm publish`` route through this function.
    """
    parts = [p for p in repo_url.split("/") if p]
    if len(parts) < 2:
        raise RegistryResolutionError(
            f"registry-sourced dep needs an 'owner/repo' identity, got {repo_url!r}"
        )
    if len(parts) == 2:
        return parts[0], parts[1]
    return "/".join(parts[:-1]), parts[-1]


def _clear_install_target(target_path: Path) -> None:
    """Ensure *target_path* is empty (mirrors Git downloader retry semantics)."""
    target_path.mkdir(parents=True, exist_ok=True)
    if not any(target_path.iterdir()):
        return
    release_held(target_path)
    for child in target_path.iterdir():
        if child.is_dir():
            shutil.rmtree(child, ignore_errors=True)
        else:
            child.unlink(missing_ok=True)


def _clean_up_rejected_target(target_path: Path) -> None:
    """Remove *target_path* after a rejected Agent Plugin admission.

    A rejected Agent Plugin (unsupported or foreign ``$schema``) must not
    leave the freshly-extracted registry tree on disk -- mirrors the same
    cleanup-on-reject invariant enforced for the github/artifactory ingress
    in ``deps/_shared.py::_validate_and_load_package``.
    """
    from ...utils.file_ops import robust_rmtree

    if target_path.exists():
        robust_rmtree(target_path, ignore_errors=True)


def _package_info_from_extracted_registry_tree(
    dep_ref: DependencyReference,
    target_path: Path,
    chosen: VersionEntry,
    actual_hash: str,
    client: RegistryClient,
    owner: str,
    repo: str,
) -> tuple[PackageInfo, RegistryResolution]:
    """Validate extracted tree, attach registry URL, return install metadata."""
    if dep_ref.is_virtual and dep_ref.virtual_path and dep_ref.is_virtual_subdirectory():
        sub = target_path / dep_ref.virtual_path
        if not sub.exists():
            raise RegistryResolutionError(
                f"virtual sub-path {dep_ref.virtual_path!r} not found in "
                f"package {dep_ref.repo_url!r} at version {chosen.version}"
            )

    native_detection = None
    try:
        native_detection = route_agent_plugin_package(target_path)
    except AgentPluginError:
        _clean_up_rejected_target(target_path)
        raise
    validation_result = validate_apm_package(
        target_path,
        agent_plugin_detection=native_detection,
    )
    if not validation_result.is_valid:
        errs = "\n  - ".join(validation_result.errors)
        raise RegistryResolutionError(
            f"registry archive for {dep_ref.repo_url!r} did not validate "
            f"as an APM package:\n  - {errs}"
        )
    package = validation_result.package
    if package is None:
        raise RegistryResolutionError(
            f"registry archive for {dep_ref.repo_url!r} validated but produced no package metadata"
        )
    resolved_url = client.archive_url(owner, repo, chosen.version)
    package.source = resolved_url

    reg_resolution = RegistryResolution(
        resolved_url=resolved_url,
        resolved_hash=f"sha256:{actual_hash}",
        version=chosen.version,
    )

    resolved_ref = ResolvedReference(
        original_ref=dep_ref.reference or chosen.version,
        ref_type=GitReferenceType.TAG,
        ref_name=chosen.version,
        resolved_commit=None,
    )

    package_info = PackageInfo(
        package=package,
        install_path=target_path,
        resolved_reference=resolved_ref,
        installed_at=datetime.now().isoformat(),
        dependency_ref=dep_ref,
        package_type=validation_result.package_type,
    )
    return package_info, reg_resolution


def _verify_moved_archive(
    dep_ref: DependencyReference,
    version: str,
    archive_bytes: bytes,
    resolved_hash: str,
    locked_url: str,
    configured_url: str,
) -> None:
    """Accept bytes from the configured registry for a moved locked URL (req-rs-009).

    Runs before the install target is touched, so a mismatch leaves nothing
    extracted (req-lk-013).
    """
    try:
        verify_sha256(archive_bytes, resolved_hash)
    except HashMismatchError as exc:
        actual = hashlib.sha256(archive_bytes).hexdigest()
        raise RegistryResolutionError(
            f"registry archive for {dep_ref.repo_url!r} {version} from the configured "
            f"registry does not match the lockfile; nothing was extracted.\n"
            f"  locked URL:     {locked_url}\n"
            f"  configured URL: {configured_url}\n"
            f"  expected hash:  {resolved_hash}\n"
            f"  actual hash:    sha256:{actual}"
        ) from exc
    _rich_info(
        f"{dep_ref.repo_url} {version}: fetched from configured registry "
        f"{configured_url} instead of lockfile URL {locked_url}; locked hash verified",
        symbol="info",
        soft_wrap=True,
    )


class RegistryPackageResolver:
    """Drop-in download callback that fetches packages from a REST registry.

    One instance per resolution graph is fine — the resolver picks the right
    registry per dep based on ``dep_ref.registry_name`` and the configured
    ``registries`` mapping.
    """

    def __init__(
        self,
        registries: dict[str, str],
        *,
        client_factory: Callable[[str, RegistryAuthContext], RegistryClient] | None = None,
    ) -> None:
        """
        Args:
            registries: Mapping of registry name -> base URL, sourced from the
                top-level ``registries:`` block in apm.yml (merged with user
                config). The ``"default"`` key, if present, may either be a
                string registry name or a string URL — it is consumed at
                routing time, not here, so this map should already be
                normalized to ``{name: url, ...}`` without ``"default"``.
            client_factory: Optional override for ``RegistryClient`` construction.
                Tests inject this to swap in a fake HTTP client.
        """
        self._registries = dict(registries)
        self._client_factory = client_factory or (lambda url, auth: RegistryClient(url, auth))

    def _registry_call(
        self,
        dep_ref: DependencyReference,
        base_url: str,
        fn: Callable[[], Any],
    ) -> Any:
        """Run *fn*; map ``RegistryError`` to ``RegistryResolutionError``."""
        try:
            return fn()
        except RegistryError as exc:
            self._raise_for_http(exc, dep_ref, base_url)
            raise

    # The dep tracker stores a per-dep "resolution result" used by the
    # lockfile writer to fill in resolved_url + resolved_hash. It's exposed
    # via this lookup so the install pipeline can read it after the callback
    # returns. Keyed by ``DependencyReference.get_unique_key()``.
    @property
    def last_resolutions(self) -> dict[str, RegistryResolution]:
        if not hasattr(self, "_last_resolutions"):
            self._last_resolutions = {}
        return self._last_resolutions

    # ------------------------------------------------------------------
    def _resolve_registry_url(self, registry_name: str | None) -> str:
        if not registry_name:
            raise RegistryResolutionError(
                "registry-sourced dep is missing registry_name: no configured "
                "registry serves it. Add the registry that serves this package "
                "to the 'registries:' block in apm.yml"
            )
        url = self._registries.get(registry_name)
        if not url:
            raise RegistryResolutionError(
                f"registry {registry_name!r} is not configured in apm.yml's registries: block"
            )
        return url

    def _build_client(self, registry_name: str, base_url: str) -> RegistryClient:
        auth = make_auth_context(registry_name, base_url)
        return self._client_factory(base_url, auth)

    def _pick_version(
        self, dep_ref: DependencyReference, versions: list[VersionEntry]
    ) -> VersionEntry:
        spec = dep_ref.reference or ""
        if not spec:
            raise RegistryResolutionError(
                f"registry-sourced dep {dep_ref.repo_url!r} has no version "
                f"constraint (version selector required)"
            )
        version_strings = [v.version for v in versions]

        # Exact-string match always wins, before range matching runs. This
        # matters for semver-shaped selectors too: range matching (below)
        # ignores build metadata per the semver spec, so a selector like
        # '1.0.2+fa163e16' would otherwise tie with, and could resolve to,
        # a *different* published build such as '1.0.2+863e11af'. No real
        # range operator ('^', '~', '>=', a wildcard, ...) can ever equal a
        # published version string, so this can't shadow genuine ranges.
        exact = next((v for v in versions if v.version == spec), None)
        if exact is not None:
            return exact

        if not is_semver_range(spec):
            from apm_cli.models.dependency.identity import _looks_like_invalid_semver_range

            if _looks_like_invalid_semver_range(spec):
                # A range-shaped but malformed selector ('^1.0') is a user error,
                # not a literal tag -- reject it clearly instead of exact-matching.
                raise RegistryResolutionError(
                    f"invalid semver range {spec!r} on {dep_ref.repo_url!r}; "
                    f"use a complete range like '^1.0.0' or a published version"
                )
            # Non-semver selector: exact match per the registry HTTP API spec
            # (section 1.3 -- "Non-semver selectors are matched exactly") --
            # already tried above and failed.
            raise RegistryResolutionError(
                f"version {spec!r} not found for {dep_ref.repo_url!r} "
                f"in registry {dep_ref.registry_name!r} "
                f"(available: {', '.join(version_strings) or '<none>'})"
            )
        best = pick_best(spec, version_strings)
        if best is None:
            raise RegistryResolutionError(
                f"no version of {dep_ref.repo_url!r} matches {spec!r} "
                f"in registry {dep_ref.registry_name!r} "
                f"(available: {', '.join(version_strings) or '<none>'})"
            )
        chosen = next((v for v in versions if v.version == best), None)
        if chosen is None:
            raise RegistryResolutionError(
                f"internal error: picked {best!r} but no matching VersionEntry"
            )
        return chosen

    # ------------------------------------------------------------------
    def download_package(
        self,
        repo_ref,  # str | DependencyReference (mirrors GitHubPackageDownloader)
        target_path: Path,
        progress_task_id=None,
        progress_obj=None,
        verbose_callback=None,
    ) -> PackageInfo:
        """Fetch *repo_ref* from its configured registry into *target_path*.

        Mirrors ``GitHubPackageDownloader.download_package``'s signature so
        both can be invoked through the same ``DownloadCallback`` shape in
        ``install/phases/resolve.py``.
        """
        dep_ref = (
            repo_ref
            if isinstance(repo_ref, DependencyReference)
            else DependencyReference.parse(repo_ref)
        )
        if dep_ref.source != "registry":
            raise RegistryResolutionError(
                f"RegistryPackageResolver invoked for non-registry dep "
                f"{dep_ref.repo_url!r} (source={dep_ref.source!r})"
            )

        owner, repo = split_registry_identity(dep_ref.repo_url)
        base_url = self._resolve_registry_url(dep_ref.registry_name)
        client = self._build_client(dep_ref.registry_name, base_url)

        versions = self._registry_call(
            dep_ref,
            base_url,
            lambda: client.list_versions(owner, repo),
        )
        if not versions:
            raise RegistryResolutionError(
                f"registry {dep_ref.registry_name!r} reports no versions for {dep_ref.repo_url!r}"
            )

        chosen = self._pick_version(dep_ref, versions)

        archive_bytes, content_type = self._registry_call(
            dep_ref,
            base_url,
            lambda: client.download_archive(owner, repo, chosen.version),
        )

        _clear_install_target(target_path)

        # extract_archive dispatches on Content-Type (with magic-bytes
        # fallback) -- supports both zip (default) and legacy tar.gz.
        # Hash check happens before any extraction.
        actual_hash = extract_archive(
            archive_bytes,
            chosen.digest,
            target_path,
            content_type=content_type,
        )

        # Subdirectory virtual packages: registry serves the parent tarball;
        # we extract the full tree then validate the requested sub-path exists.
        package_info, reg_resolution = _package_info_from_extracted_registry_tree(
            dep_ref,
            target_path,
            chosen,
            actual_hash,
            client,
            owner,
            repo,
        )
        self.last_resolutions[dep_ref.get_unique_key()] = reg_resolution
        return package_info

    # ------------------------------------------------------------------
    def _lockfile_replay_client(
        self, dep_ref: DependencyReference, resolved_url: str, version: str
    ) -> tuple[RegistryClient, str]:
        """Return the declared registry client and the URL it fetches the locked bytes from.

        Any registry declared in apm.yml may serve the locked bytes; the
        caller verifies them against ``resolved_hash`` (req-rs-009, #4278).
        Each registry's credentials reach only its own archive URL. A URL no
        declared registry serves (a moved endpoint, #4013) is never fetched:
        the locked version comes from the dependency's configured registry.
        """
        owner, repo = split_registry_identity(dep_ref.repo_url)
        locked_name = dep_ref.registry_name
        locked_url = self._resolve_registry_url(locked_name)
        candidates = [(locked_name, locked_url)] + [
            (name, url) for name, url in self._registries.items() if name != locked_name and url
        ]
        for name, base_url in candidates:
            client = self._build_client(name, base_url)
            if client.archive_url(owner, repo, version) == resolved_url:
                return client, resolved_url
        client = self._build_client(locked_name, locked_url)
        return client, client.archive_url(owner, repo, version)

    # ------------------------------------------------------------------
    def download_from_lockfile(
        self,
        dep_ref: DependencyReference,
        target_path: Path,
        *,
        resolved_url: str,
        resolved_hash: str,
        version: str,
    ) -> PackageInfo:
        """Fetch the locked version and verify it against the locked hash.

        This is the npm-install-model lockfile replay path: instead of calling
        ``/versions`` to re-negotiate the best semver match, we fetch the
        locked version from a declared registry and re-verify the bytes
        against ``resolved_hash``. When no declared registry serves the
        locked ``resolved_url`` (a moved endpoint), the configured registry's
        bytes must hash to ``resolved_hash`` before anything is extracted
        (req-rs-009, req-lk-013); the lockfile keeps its recorded URL.  Called by ``apm install`` when the
        lockfile has full replay data and the manifest range still covers the
        locked version.  ``apm update`` bypasses this path entirely via
        ``update_refs=True``.
        """
        client, fetch_url = self._lockfile_replay_client(dep_ref, resolved_url, version)
        try:
            archive_bytes, content_type = client.fetch_from_url(fetch_url)
        except RegistryError as exc:
            self._raise_for_http(exc, dep_ref, fetch_url)
            raise  # unreachable; appeases type checker
        if fetch_url != resolved_url:
            _verify_moved_archive(
                dep_ref, version, archive_bytes, resolved_hash, resolved_url, fetch_url
            )

        _clear_install_target(target_path)
        actual_hash = extract_archive(
            archive_bytes,
            resolved_hash,  # verify against LOCKFILE hash, not API digest
            target_path,
            content_type=content_type,
        )

        if dep_ref.is_virtual and dep_ref.virtual_path and dep_ref.is_virtual_subdirectory():
            sub = target_path / dep_ref.virtual_path
            if not sub.exists():
                raise RegistryResolutionError(
                    f"virtual sub-path {dep_ref.virtual_path!r} not found in "
                    f"package {dep_ref.repo_url!r} at version {version}"
                )

        native_detection = None
        try:
            native_detection = route_agent_plugin_package(target_path)
        except AgentPluginError:
            _clean_up_rejected_target(target_path)
            raise
        validation_result = validate_apm_package(
            target_path,
            agent_plugin_detection=native_detection,
        )
        if not validation_result.is_valid:
            errs = "\n  - ".join(validation_result.errors)
            raise RegistryResolutionError(
                f"registry archive for {dep_ref.repo_url!r} did not validate "
                f"as an APM package:\n  - {errs}"
            )
        package = validation_result.package
        if package is None:
            raise RegistryResolutionError(
                f"registry archive for {dep_ref.repo_url!r} validated but "
                f"produced no package metadata"
            )
        package.source = resolved_url

        reg_resolution = RegistryResolution(
            resolved_url=resolved_url,
            resolved_hash=f"sha256:{actual_hash}",
            version=version,
        )
        resolved_ref = ResolvedReference(
            original_ref=dep_ref.reference or version,
            ref_type=GitReferenceType.TAG,
            ref_name=version,
            resolved_commit=None,
        )
        package_info = PackageInfo(
            package=package,
            install_path=target_path,
            resolved_reference=resolved_ref,
            installed_at=datetime.now().isoformat(),
            dependency_ref=dep_ref,
            package_type=validation_result.package_type,
        )
        self.last_resolutions[dep_ref.get_unique_key()] = reg_resolution
        return package_info

    # ------------------------------------------------------------------
    def _raise_for_http(
        self,
        exc: RegistryError,
        dep_ref: DependencyReference,
        base_url: str,
    ) -> None:
        if exc.status in (401, 403):
            raise RegistryResolutionError(f"{exc}\n{remediation_message(base_url)}") from exc
        if exc.status == 404:
            msg = (
                f"registry {dep_ref.registry_name!r} has no package "
                f"{dep_ref.repo_url!r} (HTTP 404 from {redact_url_userinfo(exc.url)})"
            )
            ref = dep_ref.reference or ""
            if ref and not is_semver_range(ref):
                msg += (
                    f"\nHint: verify the package name and registry configuration. "
                    f"'{ref}' also looks like a git ref, not a semver range; "
                    f"if this package lives on GitHub, use the explicit git form:\n"
                    f"  - git: {dep_ref.repo_url}#{ref}"
                )
            raise RegistryResolutionError(msg) from exc
        raise RegistryResolutionError(str(exc)) from exc


# Carried out-of-band from download_package() so the install pipeline can
# read it when writing the lockfile (resolved_url + resolved_hash). Keeping
# the PackageInfo shape unchanged keeps existing callers byte-identical.
@dataclass(frozen=True, slots=True)
class RegistryResolution:
    resolved_url: str
    resolved_hash: str
    version: str

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return (
            f"RegistryResolution(version={self.version!r}, "
            f"url={self.resolved_url!r}, hash={self.resolved_hash[:24]!r}...)"
        )
