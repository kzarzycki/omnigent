"""Canonical resolution of a locked LOCAL dependency's on-disk source directory.

Both the install resolver (:mod:`apm_cli.deps.apm_resolver`) and the
drift-replay engine (:mod:`apm_cli.install.drift`) must turn a local
dependency's ``local_path`` into the real directory on disk. They MUST
agree byte-for-byte: if they diverge, ``apm audit`` reports drift that
``apm install`` never produced -- or, worse, silently skips drift the
install actually deployed (the failure mode this module was written to
kill).

Anchoring rules (mirroring ``install/phases/local_content.py`` and
``apm_resolver._compute_dep_source_path``, issue #857):

* a direct (root-declared) local dep stores a project-root-relative
  ``local_path`` (``./packages/foo``) and ``resolved_by = None`` -- it
  anchors on ``project_root``;
* a transitive local dep stores a path relative to the package that
  DECLARED it (``../sibling``) plus ``resolved_by`` = that parent's
  ``repo_url`` -- it anchors on the parent's resolved directory,
  recursively up to a root dep;
* an absolute ``local_path`` bypasses anchoring entirely.

No project-root containment clamp is applied here: install deliberately
permits out-of-tree local sources (``apm install ../pkg-a`` from a
monorepo workspace; see ``local_content._copy_local_package``), and the
untrusted-source boundary is the resolver-level expansion/rejection of
``local_path`` deps declared by REMOTE parents (issues #940 / #1571),
enforced upstream before a dep ever reaches the lockfile. Drift simply
mirrors install so audit and install never disagree.

A genuinely corrupt lockfile -- a ``resolved_by`` parent that is missing,
ambiguous, non-local, or part of a cycle -- raises
:class:`LocalResolutionError`. Callers MUST surface that as a hard
failure and never fold it into a benign "cache not populated" skip:
swallowing it is exactly how a resolution bug silently disables drift
detection repo-wide.
"""

from __future__ import annotations

import os
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apm_cli.deps.lockfile import LockedDependency, LockFile


USER_SCOPE_RELATIVE_PATH_ERROR = (
    "relative local paths are not supported at user scope (--global). "
    "Use an absolute path or a remote reference (owner/repo) instead"
)


def local_dep_base_dir(
    local_path: str,
    *,
    declaring_dir: Path | None,
    source_root: Path | None,
    user_scope: bool,
) -> Path | None:
    """Return the directory a dependency's ``local_path`` resolves against.

    The single install-time anchor decision (#857, #4153). A path declared
    by another package anchors on that package's directory at every scope.
    A root-declared path anchors on *source_root* at project scope; at user
    scope the root manifest has no project, so only an absolute path is
    admitted. ``None`` means the path cannot be anchored and the caller
    must fail the dependency with :data:`USER_SCOPE_RELATIVE_PATH_ERROR`.
    """
    if declaring_dir is not None:
        return declaring_dir
    if not user_scope and source_root is not None:
        return source_root
    raw = Path(local_path).expanduser()
    return Path(raw.anchor) if raw.is_absolute() else None


class LocalResolutionError(Exception):
    """A locked local dependency cannot be anchored from the lockfile graph.

    Signals an internally inconsistent lockfile (missing / ambiguous /
    non-local / cyclic ``resolved_by`` parent), NOT a cold cache. It is
    deliberately NOT a subclass of
    :class:`apm_cli.install.drift.CacheMissError` so the drift gate's
    ``except CacheMissError`` soft-skip cannot swallow it.
    """


def resolve_local_dep_dir(
    lock_dep: LockedDependency,
    lockfile: LockFile | None,
    project_root: Path,
    *,
    parent_index: dict[str, tuple[LockedDependency, ...]] | None = None,
    resolved_cache: dict[str, Path] | None = None,
) -> Path:
    """Resolve the on-disk source directory for a locked LOCAL dependency.

    Walks the ``resolved_by`` chain to anchor a transitive ``../sibling``
    path on the directory of the package that declared it, recursively up
    to a root-declared dep which anchors on ``project_root``. Absolute
    ``local_path`` values bypass anchoring.

    The returned path is NOT checked for existence -- that is the caller's
    concern (a missing-but-correctly-resolved source is a cold-cache-like
    condition, distinct from the corrupt-lockfile conditions raised here).

    Raises
    ------
    LocalResolutionError
        If *lock_dep* is not a local dep, has no ``local_path``, or its
        ``resolved_by`` chain references a parent that is missing,
        ambiguous, non-local, or cyclic.
    """
    if lock_dep.replacement is not None and lock_dep.is_local_source:
        return lock_dep.replacement.local_source_path(project_root)
    if not lock_dep.is_local_source or not lock_dep.local_path:
        raise LocalResolutionError(
            f"not a resolvable local dependency: repo_url={lock_dep.repo_url!r} "
            f"source={lock_dep.source!r} local_path={lock_dep.local_path!r}"
        )
    if not lock_dep.resolved_by:
        return _join(project_root.resolve(), lock_dep.local_path)
    index = parent_index if parent_index is not None else build_local_parent_index(lockfile)
    cache = resolved_cache if resolved_cache is not None else {}
    return _resolve_dep_dir(
        lock_dep,
        lockfile,
        project_root.resolve(),
        parent_index=index,
        resolved_cache=cache,
        seen=set(),
    )


def resolve_local_dep_base(
    lock_dep: LockedDependency,
    lockfile: LockFile | None,
    project_root: Path,
    *,
    parent_index: dict[str, tuple[LockedDependency, ...]] | None = None,
) -> Path:
    """Return the directory a locked local dep's ``local_path`` is admitted from.

    Mirrors install: a local replacement is anchored on the consumer root;
    any other local dep on the directory of the package that declared it.
    """
    if lock_dep.replacement is not None:
        return project_root
    return resolve_local_dep_dir(
        replace(lock_dep, local_path="."), lockfile, project_root, parent_index=parent_index
    )


def root_anchored_local_path(
    lock_dep: LockedDependency, lockfile: LockFile | None, project_root: Path
) -> str:
    """Re-spell a locked local dep's ``local_path`` against *project_root*.

    The result names the same directory once the row is root-declared
    (``resolved_by`` cleared), so a ``../sibling`` declared by a parent at
    ``./packages/parent`` becomes ``./packages/sibling``. Raises
    :class:`LocalResolutionError` like :func:`resolve_local_dep_dir`.
    """
    resolved = resolve_local_dep_dir(lock_dep, lockfile, project_root)
    try:
        relative = Path(os.path.relpath(resolved, project_root.resolve())).as_posix()
    except ValueError:
        return resolved.as_posix()
    if relative == "." or relative.startswith("../") or relative == "..":
        return relative
    return f"./{relative}"


def build_local_parent_index(
    lockfile: LockFile | None,
) -> dict[str, tuple[LockedDependency, ...]]:
    """Index local dependencies by repo URL for repeated parent resolution."""
    grouped: dict[str, list[LockedDependency]] = {}
    if lockfile is not None:
        for dependency in lockfile.dependencies.values():
            if dependency.is_local_source:
                grouped.setdefault(dependency.repo_url, []).append(dependency)
    return {repo_url: tuple(dependencies) for repo_url, dependencies in grouped.items()}


def resolve_local_dep_dirs(lockfile: LockFile, project_root: Path) -> dict[str, Path]:
    """Resolve every locked local dependency with one shared index and cache."""
    parent_index = build_local_parent_index(lockfile)
    resolved_cache: dict[str, Path] = {}
    return {
        dependency.get_unique_key(): resolve_local_dep_dir(
            dependency,
            lockfile,
            project_root,
            parent_index=parent_index,
            resolved_cache=resolved_cache,
        )
        for dependency in lockfile.get_package_dependencies()
        if dependency.is_local_source
    }


def _join(anchor: Path, local_path: str) -> Path:
    """Resolve *local_path* against *anchor*, leaving absolute paths alone."""
    raw = Path(local_path).expanduser()
    return raw.resolve() if raw.is_absolute() else (anchor / raw).resolve()


def _resolve_dep_dir(
    dep: LockedDependency,
    lockfile: LockFile | None,
    project_root: Path,
    *,
    parent_index: dict[str, tuple[LockedDependency, ...]],
    resolved_cache: dict[str, Path],
    seen: set[str],
) -> Path:
    """Resolve one dependency, memoizing every parent in its ancestry."""
    key = dep.get_unique_key()
    cached = resolved_cache.get(key)
    if cached is not None:
        return cached
    if dep.replacement is not None and dep.is_local_source:
        resolved = dep.replacement.local_source_path(project_root)
        resolved_cache[key] = resolved
        return resolved
    if not dep.resolved_by:
        resolved = _join(project_root, dep.local_path)
        resolved_cache[key] = resolved
        return resolved

    if key in seen:
        raise LocalResolutionError(
            f"cycle in resolved_by chain at {dep.repo_url!r} "
            f"(local_path={dep.local_path!r}, resolved_by={dep.resolved_by!r})"
        )
    seen.add(key)

    parents = _find_parents(lockfile, dep, parent_index=parent_index)
    parent_dirs = {
        _resolve_dep_dir(
            parent,
            lockfile,
            project_root,
            parent_index=parent_index,
            resolved_cache=resolved_cache,
            seen=seen,
        )
        for parent in parents
    }
    if len(parent_dirs) > 1:
        raise LocalResolutionError(
            f"ambiguous resolved_by parent {dep.resolved_by!r} of {dep.repo_url!r}: "
            f"{len(parents)} local dependencies share that repo_url "
            f"({sorted(p.local_path for p in parents if p.local_path)}) and anchor to "
            f"different directories"
        )
    resolved = _join(parent_dirs.pop(), dep.local_path)
    resolved_cache[key] = resolved
    seen.remove(key)
    return resolved


def _find_parents(
    lockfile: LockFile | None,
    dep: LockedDependency,
    *,
    parent_index: dict[str, tuple[LockedDependency, ...]],
) -> tuple[LockedDependency, ...]:
    """Find the local parent candidates of *dep* by ``repo_url == resolved_by``.

    ``resolved_by`` carries the parent's ``repo_url`` (e.g. ``_local/foo``),
    NOT its ``local_path``; and the lockfile dict is keyed by
    ``get_unique_key()`` (``local_path`` for locals), so the parent cannot
    be looked up by key -- we scan by ``repo_url``. Because ``_local/<name>``
    is basename-derived it is NOT guaranteed unique: one directory reached
    through two relative spellings (``./packages/lib`` from the root and
    ``../lib`` from a sibling) yields several candidates, and the caller
    refuses only when they anchor to different directories.
    """
    if lockfile is None:
        raise LocalResolutionError(
            f"{dep.repo_url!r} declares resolved_by={dep.resolved_by!r} but no "
            "lockfile was supplied to resolve the parent"
        )
    if lockfile.replacements is not None:
        parent = lockfile.get_dependency(dep.resolved_by)
        if parent is None or not parent.is_local_source:
            raise LocalResolutionError(
                f"resolved_by parent {dep.resolved_by!r} of {dep.repo_url!r} is not a locked local source"
            )
        return (parent,)
    matches = parent_index.get(dep.resolved_by, ())
    if not matches:
        raise LocalResolutionError(
            f"resolved_by parent {dep.resolved_by!r} of {dep.repo_url!r} "
            f"(local_path={dep.local_path!r}) is not a local dependency in the lockfile"
        )
    return matches
