"""Vendor-specific URL/API construction for remote git hosts.

Replaces the conditional `if is_github / elif is_ado / else generic` ladders
that used to live in ``download_strategies.build_repo_url`` and the various
``download_*`` methods on :class:`GitHubPackageDownloader`. Each supported
host kind is represented by a small immutable backend object that exposes
URL builders, API URLs, and capability flags. A dispatch function picks the
right backend by consulting :meth:`AuthResolver.classify_host`.

Pattern: Strategy via Protocol + dispatch dict. The three GitHub-family
backends (GitHub, GHE Cloud, GHES) share URL builders through a small
``_GitHubFamilyBase`` to avoid copy/paste; ADO and Generic stand alone.
Adding a new vendor registers one backend with the canonical provider
registry, never a new branch in an ``if/elif`` ladder.

Design constraints (see plan in WIP/host-backends-refactor):

- Backends are stateless: each carries only its :class:`HostInfo`. Ports
  and ssh/https-or-http preferences flow as method arguments so the same
  backend instance can serve every dependency on a given host.
- ``build_clone_*`` returns a credential-free clone URL suitable for
  ``git clone``. Credentials are NEVER embedded in the URL -- they are
  injected via git env (``http.extraheader`` / credential helpers) by
  :class:`AuthResolver`.
- ``build_commits_api_url`` returns ``None`` for hosts where no cheap
  commit-resolution endpoint exists (ADO, generic). Callers fall back to
  the explicit ref string in that case.
- ``build_contents_api_urls`` returns an ordered list of API URL
  candidates. Generic (Gitea/Gogs) hosts return v1 *and* v3 candidates
  for negotiation; GitHub family returns exactly one URL.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from ..core.auth import HostInfo
from ..core.host_providers import (
    classify_host_provider,
    host_backend_factory,
    register_host_backend,
)
from ..models.dependency.host_virtual import repository_path_segments
from ..utils.github_host import (
    build_ado_https_clone_url,
    build_ado_ssh_url,
    build_https_clone_url,
    build_ssh_url,
    default_host,
)

if TYPE_CHECKING:
    from ..core.auth import AuthResolver
    from ..models.apm_package import DependencyReference


# ---------------------------------------------------------------------------
# Protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class HostBackend(Protocol):
    """Vendor-specific URL/API construction for one remote git host kind.

    All concrete backends are immutable dataclasses carrying just the
    :class:`HostInfo` describing the host. Methods take whatever runtime
    inputs they need (e.g. dep_ref) so a single backend
    instance can serve many dependencies on the same host.
    """

    host_info: HostInfo

    @property
    def kind(self) -> str:
        """Host kind: ``"github"``, ``"ghe_cloud"``, ``"ghes"``, ``"ado"``, or ``"generic"``."""
        ...

    @property
    def is_github_family(self) -> bool:
        """True for github.com, *.ghe.com, and configured GHES hosts."""
        ...

    @property
    def is_generic(self) -> bool:
        """True for non-GitHub-family non-ADO hosts (GitLab, Bitbucket, Gitea, ...).

        Used by :meth:`GitHubPackageDownloader._resolve_dep_token` to decide
        whether to defer to git credential helpers instead of using a
        pre-resolved token.
        """
        ...

    def build_clone_https_url(self, dep_ref: DependencyReference) -> str:
        """Build the credential-free HTTPS clone URL.

        Credentials are injected via git env by :class:`AuthResolver`,
        never embedded in the URL.
        """
        ...

    def build_clone_ssh_url(self, dep_ref: DependencyReference) -> str:
        """Build the SSH clone URL."""
        ...

    def build_clone_http_url(self, dep_ref: DependencyReference) -> str:
        """Build a plain HTTP (insecure) clone URL.

        Only used when ``dep_ref.is_insecure`` is true; APM never
        downgrades automatically. ADO raises ValueError because Azure
        DevOps does not accept HTTP at all.
        """
        ...

    def build_commits_api_url(self, dep_ref: DependencyReference, ref: str) -> str | None:
        """Build the URL for the cheap commit-resolution API.

        Returns ``None`` when the host has no equivalent endpoint (ADO,
        generic). Callers then fall back to using ``ref`` directly.
        """
        ...

    def build_contents_api_urls(
        self,
        owner: str,
        repo: str,
        file_path: str,
        ref: str,
    ) -> list[str]:
        """Return ordered Contents-API URL candidates for fetching a file.

        GitHub family returns exactly one URL.  Generic hosts (Gitea/Gogs)
        return v1 then v3 candidates so callers can negotiate the API
        version on 404.
        """
        ...


# ---------------------------------------------------------------------------
# Concrete backends
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _GitHubFamilyBase:
    """Shared composition base for github.com / GHE Cloud / GHES backends.

    Not a Protocol implementer on its own -- concrete subclasses set
    ``kind`` and (optionally) override ``build_commits_api_url`` to use
    the right API base.

    NOTE: not exposed as ``HostBackend`` -- always use a concrete subclass.
    """

    host_info: HostInfo

    @property
    def is_github_family(self) -> bool:
        return True

    @property
    def is_generic(self) -> bool:
        return False

    def build_clone_https_url(self, dep_ref: DependencyReference) -> str:
        return build_https_clone_url(
            self._url_host(dep_ref), dep_ref.repo_url, port=getattr(dep_ref, "port", None)
        )

    def build_clone_ssh_url(self, dep_ref: DependencyReference) -> str:
        return build_ssh_url(
            self._url_host(dep_ref),
            dep_ref.repo_url,
            port=getattr(dep_ref, "port", None),
            user=getattr(dep_ref, "ssh_user", None) or "git",
        )

    def build_clone_http_url(self, dep_ref: DependencyReference) -> str:
        port = getattr(dep_ref, "port", None)
        host = self._url_host(dep_ref)
        netloc = f"{host}:{port}" if port else host
        return f"http://{netloc}/{dep_ref.repo_url}.git"

    def _url_host(self, dep_ref: DependencyReference) -> str:
        # Prefer the host carried on the dependency reference itself, but
        # fall back to ``host_info.host`` when the dep_ref has none. The
        # backend was already classified for this host, so the fallback
        # is safe and makes URL construction robust against partially
        # constructed DependencyReference objects.
        return getattr(dep_ref, "host", None) or self.host_info.host or ""

    def build_commits_api_url(self, dep_ref: DependencyReference, ref: str) -> str | None:
        # GitHub-family commits API: GET {api_base}/repos/{owner}/{repo}/commits/{ref}
        # api_base differs across github.com / *.ghe.com / GHES.
        parts = repository_path_segments(dep_ref.repo_url)
        if len(parts) < 2:
            return None
        owner, repo = parts[0], "/".join(parts[1:])
        # Treat already-resolved 40-char SHAs as a no-op -- caller should
        # short-circuit the network round-trip.
        if re.match(r"^[a-f0-9]{40}$", (ref or "").lower()):
            return None
        return f"{self.host_info.api_base}/repos/{owner}/{repo}/commits/{ref}"

    def build_contents_api_urls(
        self,
        owner: str,
        repo: str,
        file_path: str,
        ref: str,
    ) -> list[str]:
        # GitHub Contents API: a single canonical URL, no version negotiation.
        return [f"{self.host_info.api_base}/repos/{owner}/{repo}/contents/{file_path}?ref={ref}"]


@dataclass(frozen=True)
class GitHubBackend(_GitHubFamilyBase):
    """Backend for github.com (the public GitHub Cloud host)."""

    @property
    def kind(self) -> str:
        return "github"


@dataclass(frozen=True)
class GHECloudBackend(_GitHubFamilyBase):
    """Backend for ``*.ghe.com`` (GitHub Enterprise Cloud -- Data Residency)."""

    @property
    def kind(self) -> str:
        return "ghe_cloud"


@dataclass(frozen=True)
class GHESBackend(_GitHubFamilyBase):
    """Backend for self-hosted GitHub Enterprise Server (configured via GITHUB_HOST)."""

    @property
    def kind(self) -> str:
        return "ghes"


@dataclass(frozen=True)
class ADOBackend:
    """Backend for Azure DevOps (cloud and on-prem server).

    ADO has its own URL builders that take ``ado_organization``,
    ``ado_project``, ``ado_repo`` triplets instead of a flat
    ``owner/repo``. PATs and bearer tokens are injected via git env vars,
    never embedded in the URL.
    """

    host_info: HostInfo

    @property
    def kind(self) -> str:
        return "ado"

    @property
    def is_github_family(self) -> bool:
        return False

    @property
    def is_generic(self) -> bool:
        return False

    def build_clone_https_url(self, dep_ref: DependencyReference) -> str:
        # ADO's HTTPS host comes from the dependency itself; ``host_info``
        # is for classification only.
        host = getattr(dep_ref, "host", None) or self.host_info.host
        if not getattr(dep_ref, "ado_organization", None):
            raise ValueError(
                "ADO dependency is missing ado_organization; cannot construct clone URL"
            )
        return build_ado_https_clone_url(
            dep_ref.ado_organization,
            dep_ref.ado_project,
            dep_ref.ado_repo,
            host=host,
            port=getattr(dep_ref, "port", None),
        )

    def build_clone_ssh_url(self, dep_ref: DependencyReference) -> str:
        if not getattr(dep_ref, "ado_organization", None):
            raise ValueError(
                "ADO dependency is missing ado_organization; cannot construct clone URL"
            )
        return build_ado_ssh_url(dep_ref.ado_organization, dep_ref.ado_project, dep_ref.ado_repo)

    def build_clone_http_url(self, dep_ref: DependencyReference) -> str:
        # ADO does not support plain HTTP clones; surface a clear error
        # instead of building an URL that will fail with a confusing TLS
        # error several layers deeper.
        raise ValueError("Azure DevOps does not support plain HTTP cloning; use HTTPS or SSH.")

    def build_commits_api_url(self, dep_ref: DependencyReference, ref: str) -> str | None:
        # No GitHub-equivalent cheap commit-resolution endpoint is wired
        # for ADO; callers fall back to using ``ref`` directly.
        return None

    def build_contents_api_urls(
        self,
        owner: str,
        repo: str,
        file_path: str,
        ref: str,
    ) -> list[str]:
        # ADO file download goes through ``download_ado_file`` which uses
        # the ADO REST Items API, not the GitHub Contents API. Returning
        # an empty list signals "do not call the Contents API path" so
        # the orchestrator routes through the dedicated ADO method.
        return []


@dataclass(frozen=True)
class GitLabBackend:
    """Backend for GitLab (gitlab.com and self-managed instances).

    GitLab uses REST v4 for both commits and raw file fetches. Clone URLs
    are credential-free; auth is supplied via git env or credential helpers.
    """

    host_info: HostInfo

    @property
    def kind(self) -> str:
        return "gitlab"

    @property
    def is_github_family(self) -> bool:
        return False

    @property
    def is_generic(self) -> bool:
        # Token resolution paths treat GitLab the same as a generic host
        # (defer to credential helpers / GITLAB_* env vars), not as a
        # GitHub-family host.
        return True

    def build_clone_https_url(self, dep_ref: DependencyReference) -> str:
        port = getattr(dep_ref, "port", None)
        host = getattr(dep_ref, "host", None) or self.host_info.host
        return build_https_clone_url(host, dep_ref.repo_url, port=port)

    def build_clone_ssh_url(self, dep_ref: DependencyReference) -> str:
        host = getattr(dep_ref, "host", None) or self.host_info.host
        return build_ssh_url(
            host,
            dep_ref.repo_url,
            port=getattr(dep_ref, "port", None),
            user=getattr(dep_ref, "ssh_user", None) or "git",
        )

    def build_clone_http_url(self, dep_ref: DependencyReference) -> str:
        port = getattr(dep_ref, "port", None)
        host = getattr(dep_ref, "host", None) or self.host_info.host
        netloc = f"{host}:{port}" if port else host
        return f"http://{netloc}/{dep_ref.repo_url}.git"

    def build_commits_api_url(self, dep_ref: DependencyReference, ref: str) -> str | None:
        # GitLab REST v4 commits endpoint: requires URL-encoded "namespace/project".
        if re.match(r"^[a-f0-9]{40}$", (ref or "").lower()):
            return None
        try:
            import urllib.parse as _up

            project = _up.quote(dep_ref.repo_url, safe="")
        except Exception:
            return None
        return f"{self.host_info.api_base}/projects/{project}/repository/commits/{ref}"

    def build_contents_api_urls(
        self,
        owner: str,
        repo: str,
        file_path: str,
        ref: str,
    ) -> list[str]:
        # GitLab raw file: GET /api/v4/projects/{id}/repository/files/{path}/raw?ref=...
        import urllib.parse as _up

        project = _up.quote(f"{owner}/{repo}", safe="")
        encoded_path = _up.quote(file_path, safe="")
        return [
            f"{self.host_info.api_base}/projects/{project}/repository/files/{encoded_path}/raw?ref={ref}"
        ]


@dataclass(frozen=True)
class GenericGitBackend:
    """Backend for non-GitHub non-ADO generic hosts (Gitea, Gogs, Bitbucket).

    These hosts have heterogeneous APIs but support a common shape:
    HTTPS / SSH clones plus a Gitea-compatible Contents API at
    ``/api/v1/`` with a ``/api/v3/`` fallback for v3-only deployments.
    GitLab-class hosts use :class:`GitLabBackend` instead.
    """

    host_info: HostInfo

    @property
    def kind(self) -> str:
        return "generic"

    @property
    def is_github_family(self) -> bool:
        return False

    @property
    def is_generic(self) -> bool:
        return True

    def build_clone_https_url(self, dep_ref: DependencyReference) -> str:
        port = getattr(dep_ref, "port", None)
        host = getattr(dep_ref, "host", None) or self.host_info.host
        return build_https_clone_url(host, dep_ref.repo_url, port=port)

    def build_clone_ssh_url(self, dep_ref: DependencyReference) -> str:
        host = getattr(dep_ref, "host", None) or self.host_info.host
        return build_ssh_url(
            host,
            dep_ref.repo_url,
            port=getattr(dep_ref, "port", None),
            user=getattr(dep_ref, "ssh_user", None) or "git",
        )

    def build_clone_http_url(self, dep_ref: DependencyReference) -> str:
        port = getattr(dep_ref, "port", None)
        host = getattr(dep_ref, "host", None) or self.host_info.host
        netloc = f"{host}:{port}" if port else host
        return f"http://{netloc}/{dep_ref.repo_url}.git"

    def build_commits_api_url(self, dep_ref: DependencyReference, ref: str) -> str | None:
        # No standardized cheap commit-resolution endpoint across generic
        # hosts. Callers fall back to using ``ref`` directly.
        return None

    def build_contents_api_urls(
        self,
        owner: str,
        repo: str,
        file_path: str,
        ref: str,
    ) -> list[str]:
        # Gitea/Gogs Contents API: /api/v1/repos/{owner}/{repo}/contents/{file_path}?ref={ref}
        # Some legacy deployments only expose v3 (mirroring GitHub) -- try both.
        host = self.host_info.host
        return [
            f"https://{host}/api/v1/repos/{owner}/{repo}/contents/{file_path}?ref={ref}",
            f"https://{host}/api/v3/repos/{owner}/{repo}/contents/{file_path}?ref={ref}",
        ]


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------


register_host_backend("github", GitHubBackend)
register_host_backend("ghe_cloud", GHECloudBackend)
register_host_backend("ghes", GHESBackend)
register_host_backend("ado", ADOBackend)
register_host_backend("gitlab", GitLabBackend)
register_host_backend("generic", GenericGitBackend)


def _host_type_for_backend_dispatch(dep_ref: DependencyReference | None) -> str | None:
    """Return a structural host_type from dependency-like refs."""
    return getattr(dep_ref, "host_type", None)


def backend_for(
    dep_ref: DependencyReference | None,
    auth_resolver: AuthResolver,
    *,
    fallback_host: str | None = None,
) -> HostBackend:
    """Pick the right :class:`HostBackend` for *dep_ref*.

    ``auth_resolver.classify_host`` is the single source of truth for
    host kind classification -- this function is a thin dispatch layer
    that wraps the resulting :class:`HostInfo` in a backend object.

    Args:
        dep_ref: The dependency reference. ``None`` is allowed for
            instance-default resolution (uses ``fallback_host`` or
            :func:`default_host`).
        auth_resolver: The :class:`AuthResolver` instance. Used solely
            for the static :meth:`classify_host` method -- no auth
            resolution side effects.
        fallback_host: Host to use when ``dep_ref`` is ``None`` or has
            no host. Defaults to :func:`default_host`.

    Returns:
        The :class:`HostBackend` for the resolved host.
    """
    host_type = _host_type_for_backend_dispatch(dep_ref)
    if dep_ref is not None and dep_ref.host:
        host = dep_ref.host
        port = getattr(dep_ref, "port", None)
    else:
        host = fallback_host or default_host()
        port = None

    info = auth_resolver.classify_host(
        host,
        port=port,
        host_type=host_type,
    )
    if not isinstance(info, HostInfo):
        provider = classify_host_provider(host, host_type=host_type)
        info = HostInfo(
            host=host,
            kind=provider.kind,
            has_public_repos=provider.has_public_repos,
            api_base=provider.build_api_base(host.lower(), port),
            port=port,
            credential_purpose=provider.credential_purpose,
        )
    cls = host_backend_factory(info.kind)
    return cls(host_info=info)


def backend_for_host(
    host: str,
    auth_resolver: AuthResolver,
    *,
    port: int | None = None,
) -> HostBackend:
    """Pick the right :class:`HostBackend` for a bare hostname.

    Variant of :func:`backend_for` for callers that have a host string
    but no :class:`DependencyReference` (e.g. registry probes, marketplace
    builder).
    """
    info = auth_resolver.classify_host(host, port=port)
    cls = host_backend_factory(info.kind)
    return cls(host_info=info)
