"""Single owner of when ``apm.lock.yaml`` reaches disk (#4086).

``LockFile.write`` decides *what* a lockfile holds (generator stamp, legacy
timestamp, no-op detection); this module decides *when* those bytes are
persisted, and by whom.

The writers form a closed set: each :class:`LockfileWriter` names one command
entry point, which declares itself with :func:`lockfile_writer`.  A command
refuses a lockfile it may not rewrite before it records anything, so its write
scope opens only at its first lockfile write.  Inside the scope every
``LockFile.write`` is staged in memory, every ``LockFile.read`` (and
:func:`lockfile_exists`) sees the staged document, and the command commits
the final document once, when it completes.  A command therefore writes the
lockfile at most once, however many phases record state in it.  Nested
writers (``apm update`` running the install service) join the outer one.

A command commits what it staged when it completes, and also when it fails
after changing state: an install that deployed files and then exits non-zero
(a later MCP conflict, a native write failure) keeps the lockfile records of
what reached disk.  Most refusals happen before the first write, so nothing
is staged to commit.  A check refusal raised after staging (an exception
class with ``refuses_commit = True``, such as an org-policy or install-time
audit block, anywhere in the error's cause chain) or an interrupt (Ctrl-C,
or SIGTERM, which the CLI raises as one) discards what was staged; any other
failure, including a non-zero ``sys.exit`` after the first staged write,
commits it.  An install whose transaction rolls its deployed files back
discards what it staged first (:func:`discard_staged_lockfile_writes`), so
the lockfile keeps its pre-command bytes as well (#4282).  Two explicit commit points
flush earlier: :func:`flush_lockfile_writes` runs before state outside APM's
transaction must agree with the lockfile (native plugin registration, user
lifecycle scripts, a command's own durable checkpoint).  State bound to the
committed lockfile waits for the commit through :func:`after_lockfile_commit`.  Removal and rollback
go through :func:`remove_lockfile` and :func:`restore_lockfile_bytes` so a
staged document never resurrects a lockfile a writer deleted or restored.

Staged documents are visible only inside this process; serializing commands
across processes stays with the lifecycle lock (``install/locking.py``).
Outside a writer (library callers, unit tests) ``LockFile.write`` persists
immediately.  ``--frozen`` suppression is decided by ``LockFile.write`` before
it reaches this module, so withheld writes are never staged or flushed.
"""

from __future__ import annotations

import functools
import os
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import ParamSpec, TypeVar

_P = ParamSpec("_P")
_R = TypeVar("_R")


class LockfileWriter(StrEnum):
    """The closed set of command entry points allowed to persist the lockfile.

    ``apm mcp install`` forwards to ``apm install --mcp`` (``INSTALL_MCP``);
    ``apm deps update`` is an ``UPDATE``; ``apm lock`` runs the install
    service in lockfile-only mode under ``LOCK``; ``apm unpack`` records the
    files it wrote under ``UNPACK``.
    """

    INSTALL = "install"
    INSTALL_MCP = "install-mcp"
    INSTALL_BUNDLE = "install-bundle"
    LOCK = "lock"
    UPDATE = "update"
    UNINSTALL = "uninstall"
    PRUNE = "prune"
    COMPILE = "compile"
    UNPACK = "unpack"


class _Removed:
    """Marks a lockfile a writer deleted inside the scope."""


_REMOVED = _Removed()


class StagedDocument:
    """A lockfile document staged as data and serialized only when its text is needed.

    A command can stage several documents for one path before it commits; only
    the text a reader or the commit asks for is ever emitted (#4939). *document*
    is a private plain copy the safe dumper round-trips, so ``render`` returns
    the exact text an eager write would have staged.
    """

    __slots__ = ("_render", "_text", "document")

    def __init__(self, document: object, render: Callable[[object], str]) -> None:
        self.document = document
        self._render = render
        self._text: str | None = None

    def text(self) -> str:
        if self._text is None:
            self._text = self._render(self.document)
        return self._text


@dataclass
class _WriteScope:
    """What one writer has staged since its first lockfile write."""

    writer: LockfileWriter
    pending: dict[Path, str | StagedDocument | _Removed] = field(default_factory=dict)
    after_commit: list[Callable[[], None]] = field(default_factory=list)
    # Run just before the staged documents are written (#4863).
    before_commit: list[Callable[[], None]] = field(default_factory=list)
    # Run when the staged documents never reach disk: a failed commit or an
    # abandoned command (#4664).
    if_uncommitted: list[Callable[[], None]] = field(default_factory=list)
    # False while only provisional corrections are staged: a failure then
    # commits nothing, because the command has not changed state yet.
    changed_state: bool = False


@dataclass
class _Writer:
    writer: LockfileWriter
    scope: _WriteScope | None = None


_active_writer: ContextVar[_Writer | None] = ContextVar("apm_lockfile_writer", default=None)
_provisional: ContextVar[bool] = ContextVar("apm_lockfile_provisional", default=False)


@dataclass
class LockfileWriterObservation:
    """Read-only record of which writers commands declared and which opened a scope."""

    declared: list[LockfileWriter] = field(default_factory=list)
    opened: list[LockfileWriter] = field(default_factory=list)

    def clear(self) -> None:
        self.declared.clear()
        self.opened.clear()


_observers: list[LockfileWriterObservation] = []


@contextmanager
def observe_lockfile_writers() -> Iterator[LockfileWriterObservation]:
    """Observe the single-writer contract without changing it.

    Each outermost :func:`lockfile_write_scope` appends its writer to
    ``declared``; each write scope it opens (its first staged write) appends
    to ``opened``. Nothing about staging or committing changes.
    """
    observation = LockfileWriterObservation()
    _observers.append(observation)
    try:
        yield observation
    finally:
        _observers.remove(observation)


def _key(path: Path) -> Path:
    # Absolute, not resolved: a symlinked lockfile must stay a symlink so the
    # writer can refuse it, and a cwd change later in the command must not
    # move the destination.
    return Path(os.path.abspath(path))


def _scope(*, open_: bool = False) -> _WriteScope | None:
    active = _active_writer.get()
    if active is None:
        return None
    if active.scope is None and open_:
        active.scope = _WriteScope(active.writer)
        for observation in _observers:
            observation.opened.append(active.writer)
    if open_ and not _provisional.get():
        active.scope.changed_state = True
    return active.scope


def _refused(error: BaseException) -> bool:
    """Whether *error*, or an error in its cause/context chain, is a check refusal.

    A refusal (an exception class with ``refuses_commit = True``, such as an
    org-policy block) means the command must commit nothing (#4085).
    """
    seen: set[int] = set()
    pending: list[BaseException] = [error]
    while pending:
        current = pending.pop()
        if id(current) in seen:
            continue
        seen.add(id(current))
        if getattr(type(current), "refuses_commit", False):
            return True
        pending.extend(e for e in (current.__cause__, current.__context__) if e is not None)
    return False


def _commits(error: BaseException) -> bool:
    """Whether a command ending in *error* still commits what it staged.

    A failure after a state change records that change, whether it is raised
    or reported through ``sys.exit``: the scope opens only at the first staged
    write, so staged state means the command already changed state. A check
    refusal (anywhere in the error's cause or context chain) and an interrupt
    abandon the command.
    """
    if _refused(error):
        return False
    return isinstance(error, Exception | SystemExit | _click_exit())


def commits_on_failure(error: BaseException) -> bool:
    """Whether a command failing with *error* still commits what it staged.

    A phase that must leave disk matching the lockfile the failure commits
    (native Claude registration after a failed MCP reconcile, #4329) asks
    here instead of re-deriving the refusal and interrupt rules.
    """
    return _commits(error)


def _click_exit() -> type[BaseException]:
    from click.exceptions import Exit

    return Exit


@contextmanager
def lockfile_write_scope(writer: LockfileWriter) -> Iterator[None]:
    """Run as *writer*: stage its lockfile writes, commit them once on success."""
    if not isinstance(writer, LockfileWriter):
        raise TypeError(f"{writer!r} is not a registered lockfile writer")
    if _active_writer.get() is not None:
        yield
        return
    for observation in _observers:
        observation.declared.append(writer)
    active = _Writer(writer)
    token = _active_writer.set(active)
    try:
        yield
    except BaseException as error:
        if active.scope is not None:
            if active.scope.changed_state and _commits(error):
                _commit_or_abandon(active.scope)
            else:
                _abandon(active.scope)
        raise
    else:
        if active.scope is not None:
            _commit_or_abandon(active.scope, seam=True)
    finally:
        _active_writer.reset(token)


_seam_held = False


def commit_point_seam_for_tests() -> None:
    """Installed-binary fault seam at a command's commit point.

    ``APM_TEST_LOCK_COMMIT=hold:<marker>`` writes *marker* and waits (once per
    process) so a test can signal the command after it changed state and
    staged its lockfile, before it commits; ``APM_TEST_LOCK_COMMIT=kill`` ends
    the process there, as a killed process would, with nothing committed.
    Install reaches it before the transaction releases its deploy journal.
    """
    global _seam_held
    seam = os.environ.get("APM_TEST_LOCK_COMMIT", "")
    if seam == "kill":
        os._exit(137)
    if seam.startswith("hold:") and not _seam_held:
        import time

        _seam_held = True
        Path(seam[len("hold:") :]).write_text("staged\n", encoding="ascii")
        deadline = time.monotonic() + 300
        while time.monotonic() < deadline:
            time.sleep(0.05)


def lockfile_writer(writer: LockfileWriter) -> Callable[[Callable[_P, _R]], Callable[_P, _R]]:
    """Declare a command entry point as the lockfile writer *writer*."""

    def decorate(function: Callable[_P, _R]) -> Callable[_P, _R]:
        @functools.wraps(function)
        def wrapped(*args: _P.args, **kwargs: _P.kwargs) -> _R:
            with lockfile_write_scope(writer):
                return function(*args, **kwargs)

        return wrapped

    return decorate


def stage_lockfile(path: Path, serialized: str | StagedDocument) -> bool:
    """Stage *serialized* for *path* inside a writer; ``False`` outside one.

    ``LockFile.write`` already raised any refusal (symlinked or
    newer-generator lockfile) at the call site.
    """
    scope = _scope(open_=True)
    if scope is None:
        return False
    key = _key(path)
    # Re-insert so commit order follows the latest write.
    scope.pending.pop(key, None)
    scope.pending[key] = serialized
    return True


def _disk_text(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None


def staged_lockfile_text(path: Path) -> str | None:
    """Return the document this command staged for *path*, else its on-disk text.

    ``None`` means no lockfile: never written, or removed by this command.
    """
    scope = _scope()
    if scope is not None:
        staged = scope.pending.get(_key(path))
        if isinstance(staged, _Removed):
            return None
        if isinstance(staged, StagedDocument):
            return staged.text()
        if staged is not None:
            return staged
    return _disk_text(path)


def staged_lockfile_document(path: Path) -> StagedDocument | None:
    """The document this command staged for *path* as data, if it was staged that way."""
    scope = _scope()
    if scope is None:
        return None
    staged = scope.pending.get(_key(path))
    return staged if isinstance(staged, StagedDocument) else None


def staged_document_copy(path: Path) -> dict | None:
    """A private copy of the document staged as data for *path*: its text's parse."""
    from ..utils.yaml_io import copy_plain_tree

    staged = staged_lockfile_document(path)
    if staged is None or not isinstance(staged.document, dict):
        return None
    return copy_plain_tree(staged.document)


def stage_document(path: Path, document: dict) -> bool:
    """Stage plain *document* for *path*, emitted only when its text is needed (#4939).

    ``False`` outside a writer: the caller then writes the text now.
    """
    from .lockfile_container import render_staged_document

    return stage_lockfile(path, StagedDocument(document, render_staged_document))


def has_staged_lockfile(path: Path) -> bool | None:
    """``True``/``False`` when this command staged or removed *path*; else ``None``."""
    scope = _scope()
    if scope is None:
        return None
    staged = scope.pending.get(_key(path))
    if staged is None:
        return None
    return not isinstance(staged, _Removed)


def lockfile_exists(path: Path) -> bool:
    """Whether *path* holds a lockfile, counting what this command staged."""
    staged = has_staged_lockfile(path)
    return path.exists() if staged is None else staged


def remove_lockfile(path: Path) -> None:
    """Delete the lockfile at *path* and anything staged for it."""
    scope = _scope(open_=True)
    if scope is not None:
        key = _key(path)
        scope.pending.pop(key, None)
        scope.pending[key] = _REMOVED
    path.unlink(missing_ok=True)


def restore_lockfile_bytes(path: Path, data: bytes) -> None:
    """Roll *path* back to *data*, discarding anything staged for it."""
    from ..utils.atomic_io import atomic_write_text

    scope = _scope()
    if scope is not None:
        scope.pending.pop(_key(path), None)
    atomic_write_text(path, data.decode("utf-8"), normalize_line_endings=False)


@contextmanager
def provisional_lockfile_writes() -> Iterator[None]:
    """Stage a lockfile correction that commits only with the command's own result.

    A correction staged here (for example restored marketplace provenance)
    reaches disk when the command completes, or with the state change of a
    command that later fails; a command that fails before changing state
    leaves the lockfile byte-identical.
    """
    token = _provisional.set(True)
    try:
        yield
    finally:
        _provisional.reset(token)


@contextmanager
def lockfile_scratch_writes() -> Iterator[None]:
    """Write a private scratch snapshot now, outside the command's lockfile.

    A replay renders a copy of the lockfile into a scratch tree it reads back
    at once; that copy is never the project's lockfile, so it is neither
    staged nor withheld by ``--frozen``.
    """
    from .lockfile import _suppressed_writes

    writer = _active_writer.set(None)
    suppressed = _suppressed_writes.set(None)
    try:
        yield
    finally:
        _suppressed_writes.reset(suppressed)
        _active_writer.reset(writer)


def after_lockfile_commit(action: Callable[[], None], *, first: bool = False) -> None:
    """Run *action* once what this command staged is on disk.

    State bound to the committed lockfile (deployment receipt claims) waits
    for the commit; a discarded or failed commit never runs it. With nothing
    staged, the lockfile on disk is already the committed one. *first* runs
    it before every other action, so a later failing action cannot skip it.
    """
    scope = _scope()
    if scope is None or not scope.pending:
        action()
        return
    if first:
        scope.after_commit.insert(0, action)
    else:
        scope.after_commit.append(action)


def before_lockfile_commit(action: Callable[[], None]) -> None:
    """Run *action* just before what this command staged is written (#4863).

    The deploy journal records there which lockfile it is about to commit,
    so a process killed after the write is not mistaken for an uncommitted
    install. With nothing staged, nothing is about to be written.
    """
    scope = _scope()
    if scope is not None and scope.pending:
        scope.before_commit.append(action)


def unless_lockfile_commits(action: Callable[[], None]) -> bool:
    """Run *action* if what this command staged never reaches disk (#4664).

    A failed lockfile write or an abandoned command (a check refusal, an
    interrupt) runs it; a successful commit drops it. Returns ``False`` when
    nothing is staged: the lockfile on disk is already the committed one.
    """
    scope = _scope()
    if scope is None or not scope.pending:
        return False
    scope.if_uncommitted.append(action)
    return True


def _abandon(scope: _WriteScope) -> None:
    """Run the actions bound to a staged lockfile that will never reach disk."""
    actions, scope.if_uncommitted = scope.if_uncommitted, []
    for action in actions:
        action()


def _commit_or_abandon(scope: _WriteScope, *, seam: bool = False) -> None:
    """Commit *scope*; an error or interrupt at the commit point abandons it."""
    try:
        if seam:
            commit_point_seam_for_tests()
        _commit(scope)
    except BaseException:
        _abandon(scope)
        raise


def discard_staged_lockfile_writes() -> None:
    """Drop everything this command staged, so its writer scope commits nothing.

    The install transaction calls this when it rolls its deployed files back
    to their pre-command bytes (#4282): the lockfile then keeps its
    pre-command bytes too, and state bound to the staged document never binds.
    """
    scope = _scope()
    if scope is None:
        return
    scope.pending.clear()
    scope.after_commit.clear()
    scope.before_commit.clear()
    scope.if_uncommitted.clear()
    scope.changed_state = False


class LockfileCommitError(OSError):
    """The commit point could not write a staged lockfile; names the file."""


def flush_lockfile_writes() -> None:
    """Commit what this command staged now; it keeps staging afterwards."""
    scope = _scope()
    if scope is not None:
        _commit(scope)


def _commit(scope: _WriteScope) -> None:
    from ..utils.atomic_io import atomic_write_text, umask_file_mode
    from .lockfile import ensure_lockfile_writable
    from .lockfile_document import holds_document, same_document

    marks, scope.before_commit = scope.before_commit, []
    if scope.pending:
        for mark in marks:
            mark()
    while scope.pending:
        key = next(iter(scope.pending))
        document = scope.pending[key]
        if isinstance(document, StagedDocument):
            on_disk = holds_document(_disk_text(key), document.document)
            document = document.text()
        elif not isinstance(document, _Removed):
            on_disk = same_document(_disk_text(key), document)
        if not isinstance(document, _Removed) and not on_disk:
            ensure_lockfile_writable(key)
            try:
                atomic_write_text(key, document, new_file_mode=umask_file_mode(key))
            except OSError as exc:
                raise LockfileCommitError(f"Could not generate {key.name}: {exc}") from exc
        del scope.pending[key]
    # The lockfile is on disk: a later failing action must not undo the deploys it records.
    scope.if_uncommitted.clear()
    actions, scope.after_commit = scope.after_commit, []
    for action in actions:
        action()
