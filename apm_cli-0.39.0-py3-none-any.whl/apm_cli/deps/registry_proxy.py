"""Registry-agnostic proxy configuration for APM.

Provides a ``RegistryConfig`` abstraction over VCS proxies (Artifactory,
Nexus, Gitea, etc.) that sit in front of GitHub/GitLab to enable
air-gapped and enterprise-proxy installs.

Environment variables (canonical)::

    PROXY_REGISTRY_URL      -- Full proxy base URL, e.g.
                            ``https://art.example.com/artifactory/github``
    PROXY_REGISTRY_TOKEN    -- Bearer token for the proxy.
    PROXY_REGISTRY_ONLY     -- Set to ``1``/``true``/``yes`` to block all
                            direct VCS downloads.
    PROXY_REGISTRY_ALLOW_HTTP -- Set to ``1`` to authorize sending
                            ``PROXY_REGISTRY_TOKEN`` over ``http://`` to a host
                            that is not loopback or a private network address
                            (intended for trusted internal proxies).

Deprecated aliases (still functional, emit ``DeprecationWarning``)::

    ARTIFACTORY_BASE_URL  -> PROXY_REGISTRY_URL
    ARTIFACTORY_APM_TOKEN -> PROXY_REGISTRY_TOKEN
    ARTIFACTORY_ONLY      -> PROXY_REGISTRY_ONLY

Related: :mod:`apm_cli.deps.registry`
    A separate, additive package source that fetches APM packages over a
    REST contract instead of a VCS proxy. Suitable when the package
    server speaks the APM Registry HTTP API directly rather than acting
    as a transparent Git mirror. Configured per-project in ``apm.yml``
    via the top-level ``registries:`` block; orthogonal to the
    ``PROXY_REGISTRY_*`` env vars documented here. See
    ``docs/src/content/docs/guides/registries.md``.
"""

from __future__ import annotations

import os
import warnings
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol, runtime_checkable
from urllib.parse import urlparse

from apm_cli.core.deprecations import deprecation_message

from ..utils.credential_rendering import redact_url_userinfo

if TYPE_CHECKING:
    from apm_cli.deps.lockfile import LockedDependency


# ---------------------------------------------------------------------------
# RegistryConfig
# ---------------------------------------------------------------------------


@runtime_checkable
class RegistryClient(Protocol):
    """Interface for registry proxy backends.

    Each backend (Artifactory, Nexus, etc.) implements this protocol so
    the download pipeline can fetch files without knowing which registry
    type is in use.
    """

    def fetch_file(
        self,
        owner: str,
        repo: str,
        file_path: str,
        ref: str = "main",
        resilient_get: Callable | None = None,
    ) -> bytes | None:
        """Fetch a single file from the registry.

        Returns raw file bytes on success, or ``None`` when the file
        cannot be fetched (caller should fall back to full-archive
        download).
        """
        ...


@dataclass(frozen=True)
class RegistryConfig:
    """Immutable registry proxy configuration parsed from environment variables.

    Use :meth:`from_env` to construct; do not instantiate directly.

    Attributes
    ----------
    url:
        Full proxy base URL including the path prefix,
        e.g. ``"https://art.example.com/artifactory/github"``.
    host:
        Pure FQDN extracted from *url*,
        e.g. ``"art.example.com"``.
        Suitable for :func:`~apm_cli.core.auth.AuthResolver.classify_host`.
    prefix:
        URL path prefix extracted from *url*,
        e.g. ``"artifactory/github"``.
        Used when constructing download URLs.
    scheme:
        ``"https"`` or ``"http"``.
    token:
        Optional Bearer token for authenticating against the proxy.
    enforce_only:
        When ``True``, direct VCS downloads are blocked -- only the proxy
        may serve packages.
    """

    url: str
    host: str
    prefix: str
    scheme: str
    token: str | None
    enforce_only: bool

    # -- factory ------------------------------------------------------------

    @classmethod
    def from_env(cls) -> RegistryConfig | None:
        """Build a :class:`RegistryConfig` from the current environment.

        Reads the canonical ``PROXY_REGISTRY_*`` variables first; falls
        back to the deprecated ``ARTIFACTORY_*`` aliases (with a
        ``DeprecationWarning`` for each one that is used).

        Returns ``None`` when no registry URL is configured.
        """
        url = os.environ.get("PROXY_REGISTRY_URL", "").strip().rstrip("/")
        if not url:
            art_url = os.environ.get("ARTIFACTORY_BASE_URL", "").strip().rstrip("/")
            if art_url:
                warnings.warn(
                    deprecation_message("artifactory-base-url"),
                    DeprecationWarning,
                    stacklevel=2,
                )
                url = art_url

        if not url:
            _warn_token_without_registry_url()
            return None

        parsed = urlparse(url)
        if parsed.scheme not in ("https", "http"):
            return None
        host = parsed.hostname
        prefix = parsed.path.strip("/")
        if not host or not prefix:
            return None

        token = os.environ.get("PROXY_REGISTRY_TOKEN") or _read_deprecated_token()

        if token and not http_token_allowed(parsed.scheme, host):
            _warn_http_token_withheld(url)
            token = None

        enforce_str = os.environ.get("PROXY_REGISTRY_ONLY", "")
        if not enforce_str:
            enforce_str = _read_deprecated_enforce_only()
        enforce_only = enforce_str.strip().lower() in ("1", "true", "yes")

        return cls(
            url=url,
            host=host,
            prefix=prefix,
            scheme=parsed.scheme,
            token=token,
            enforce_only=enforce_only,
        )

    # -- helpers ------------------------------------------------------------

    def get_headers(self) -> dict:
        """Return HTTP headers for authenticating against this registry."""
        if self.token:
            return {"Authorization": f"Bearer {self.token}"}
        return {}

    def serves(self, scheme: str, host: str) -> bool:
        """Return whether ``scheme://host`` is this registry's own origin."""
        return (scheme or "").lower() == self.scheme.lower() and (
            host or ""
        ).lower() == self.host.lower()

    def headers_for(self, scheme: str, host: str) -> dict:
        """Return registry auth headers only for this registry's own origin.

        A dependency may name any Artifactory-style host (explicit FQDN form
        or a lockfile ``host`` field); the registry token is scoped to the
        configured ``PROXY_REGISTRY_URL`` origin and is never attached to a
        request for a different scheme or host.
        """
        if not self.serves(scheme, host):
            return {}
        return self.get_headers()

    def get_client(self) -> RegistryClient:
        """Return a :class:`RegistryClient` for this configuration.

        Currently returns an Artifactory backend.  When additional
        registry types are needed, this method can inspect the URL or
        a configuration hint to select the right backend.
        """
        from .artifactory_entry import ArtifactoryRegistryClient

        return ArtifactoryRegistryClient(config=self)

    def validate_lockfile_deps(self, locked_deps: list[LockedDependency]) -> list[LockedDependency]:
        """Return locked dependencies that conflict with registry-only mode.

        A *conflict* is a non-local dependency whose host is a direct VCS
        source (``github.com``, GHE Cloud ``*.ghe.com``, or a GHES host
        configured via ``GITHUB_HOST``) while :attr:`enforce_only` is
        ``True``.

        Uses :meth:`~apm_cli.core.auth.AuthResolver.classify_host` rather
        than ad hoc string matching so that GHE Cloud, GHES, and ADO hosts
        are handled correctly.

        Args:
            locked_deps: The list of :class:`LockedDependency` objects from
                an existing lockfile.

        Returns:
            List of :class:`LockedDependency` objects that conflict.  Empty
            when ``enforce_only`` is ``False`` or no conflicts exist.
        """
        if not self.enforce_only:
            return []

        from apm_cli.core.auth import AuthResolver

        conflicts: list[LockedDependency] = []
        for dep in locked_deps:
            if dep.source == "local":
                continue
            host = dep.host or "github.com"
            host_info = AuthResolver.classify_host(host)
            if host_info.kind in ("github", "ghe_cloud", "ghes"):
                conflicts.append(dep)
        return conflicts

    def find_missing_hashes(self, locked_deps: list[LockedDependency]) -> list[LockedDependency]:
        """Return registry-proxy entries that lack a ``content_hash``.

        A missing hash on a proxy entry means a tampered lockfile
        could redirect downloads without detection.  Callers should
        warn or error when this list is non-empty.
        """
        missing: list[LockedDependency] = []
        for dep in locked_deps:
            if dep.source == "local":
                continue
            if dep.registry_prefix and not dep.content_hash:
                missing.append(dep)
        return missing


# ---------------------------------------------------------------------------
# Convenience helper: read enforce-only flag (canonical or deprecated)
# ---------------------------------------------------------------------------


def is_enforce_only() -> bool:
    """Return ``True`` when registry-only mode is active.

    Checks ``PROXY_REGISTRY_ONLY`` first; falls back to the deprecated
    ``ARTIFACTORY_ONLY``.  Does **not** require a full :class:`RegistryConfig`
    to be available -- callers that only need the flag (e.g.
    :class:`~apm_cli.deps.github_downloader.GitHubPackageDownloader`) can
    use this without constructing the full config.
    """
    val = os.environ.get("PROXY_REGISTRY_ONLY", "").strip()
    if not val:
        val = os.environ.get("ARTIFACTORY_ONLY", "").strip()
    return val.lower() in ("1", "true", "yes")


# ---------------------------------------------------------------------------
# Private helpers for deprecated env var reading
# ---------------------------------------------------------------------------


_REGISTRY_URL_MISSING_WARNING = (
    "ARTIFACTORY_APM_TOKEN is ignored without PROXY_REGISTRY_URL; "
    "set PROXY_REGISTRY_URL and PROXY_REGISTRY_TOKEN"
)
_emitted_warnings: set[str] = set()


def http_token_allowed(scheme: str, host: str | None) -> bool:
    """Whether ``PROXY_REGISTRY_TOKEN`` may be sent to ``scheme://host``.

    Always over https. Over http only to a loopback or RFC 1918 private host,
    or when ``PROXY_REGISTRY_ALLOW_HTTP=1`` explicitly authorizes it.
    """
    from apm_cli.utils.net import is_local_network_host

    if (scheme or "").lower() != "http":
        return True
    return is_local_network_host(host) or os.environ.get("PROXY_REGISTRY_ALLOW_HTTP") == "1"


def _warn_http_token_withheld(url: str) -> None:
    """Say once per process that the proxy token is not sent over http."""
    message = (
        f"PROXY_REGISTRY_TOKEN is not sent to {redact_url_userinfo(url)!r}: the URL uses "
        "http:// and the host is not loopback or a private network address. Use "
        "https://, or set PROXY_REGISTRY_ALLOW_HTTP=1 to authorize sending it over http."
    )
    if message in _emitted_warnings:
        return
    _emitted_warnings.add(message)
    from apm_cli.utils.console import _rich_warning

    _rich_warning(message, symbol="warning", err=True)


def _warn_token_without_registry_url() -> None:
    """Warn once per process that a registry token has no registry origin."""
    if not os.environ.get("ARTIFACTORY_APM_TOKEN"):
        return
    if _REGISTRY_URL_MISSING_WARNING in _emitted_warnings:
        return
    _emitted_warnings.add(_REGISTRY_URL_MISSING_WARNING)
    from apm_cli.utils.console import _rich_warning

    _rich_warning(_REGISTRY_URL_MISSING_WARNING)


def _read_deprecated_token() -> str | None:
    token = os.environ.get("ARTIFACTORY_APM_TOKEN")
    if token:
        warnings.warn(
            deprecation_message("artifactory-apm-token"),
            DeprecationWarning,
            stacklevel=3,
        )
    return token


def _read_deprecated_enforce_only() -> str:
    val = os.environ.get("ARTIFACTORY_ONLY", "")
    if val:
        warnings.warn(
            deprecation_message("artifactory-only"),
            DeprecationWarning,
            stacklevel=3,
        )
    return val
