"""Virtual-package validation helpers for ``GitHubPackageDownloader``.

Extracted from ``github_downloader.py`` to keep the downloader module under
the repo's 2400-line cap.  These helpers were added by PR #941 to align
``apm install`` validation with the actual install auth chain (Contents
API directory probe + ``git ls-remote`` fallback) so subdirectory
packages with an explicit ``#ref`` no longer false-fail when the API
token is narrower than the user's git credential helper.

The helpers are module-level functions taking the downloader instance as
the first argument; the public class still exposes
``validate_virtual_package_exists`` as a thin delegating method so test
mocks (``patch("...GitHubPackageDownloader.validate_virtual_package_exists")``)
keep working unchanged.

Security gates (round-2 panel findings)
---------------------------------------
* ``validate_path_segments`` is invoked at the entry point on the
  user-supplied ``virtual_path`` before any URL interpolation, blocking
  ``..`` traversal segments from leaking into Contents API or archive
  URLs.
* The ``ls-remote`` fallback no longer fails open: a successful
  ``ls-remote`` only proves the *ref* exists, so we additionally
  shallow-fetch + ``ls-tree`` to confirm ``vpath`` resolves at that ref
  before returning ``True``.
* For Azure DevOps, credentials (PAT or AAD bearer) are injected via
  ``http.extraheader`` (see ``set_authorization_header_git_env``) and
  never embedded in the clone URL.  This keeps tokens out of the OS
  process table, git's own logs, and any downstream debug output.
"""

from __future__ import annotations

import contextlib
import re
import subprocess
import tempfile
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, NamedTuple

import git
import requests
from git.exc import GitCommandError

from ..config import get_apm_temp_dir
from ..models.dependency.host_virtual import (
    dependency_repository_owner,
    repository_owner_and_repo,
)
from ..utils.git_env import get_git_executable, git_subprocess_error_text, run_git_text
from ..utils.github_host import (
    default_host,
    is_github_hostname,
)
from ..utils.path_security import (
    PathTraversalError,
    safe_rmtree,
    validate_path_segments,
)
from .github_rate_limit import GitHubThrottleError, raise_for_github_throttle

if TYPE_CHECKING:
    from ..models.dependency.reference import DependencyReference
    from .github_downloader import GitHubPackageDownloader


_SHA_RE = re.compile(r"[0-9a-fA-F]{7,40}")


class AttemptSpec(NamedTuple):
    """A single (label, url, env) attempt in the auth-chain."""

    label: str
    url: str
    env: dict


def _is_sha_pin(ref: str) -> bool:
    """Return True when ``ref`` looks like an abbreviated or full git SHA."""
    return bool(_SHA_RE.fullmatch(ref))


def _split_owner_repo(repo_url: str) -> tuple[str, str] | None:
    """Split ``owner/repo`` safely; return ``None`` if the shape is wrong.

    Guards against ``ValueError`` on tuple-unpacking when ``repo_url``
    has no ``/`` (panel round-2 finding 2).
    """
    return repository_owner_and_repo(repo_url)


def validate_virtual_package_exists(
    downloader: GitHubPackageDownloader,
    dep_ref: DependencyReference,
    verbose_callback: Callable[[str], None] | None = None,
    warn_callback: Callable[[str], None] | None = None,
) -> bool:
    """Validate that a virtual package exists at ``dep_ref``.

    Supports virtual files, collections, and subdirectory packages.  For
    subdirectory packages the marker-file probes are a fast positive
    signal; their absence is not a failure -- two fallbacks (Contents API
    directory probe, then ``git ls-remote`` + shallow-fetch path probe
    mirroring the install auth chain) catch packages whose API auth is
    stricter than their git auth.  See PR #941 for the auth-alignment
    rationale.

    Args:
        downloader: The ``GitHubPackageDownloader`` instance providing
            transport, auth, and helper methods.
        dep_ref: Parsed dependency reference for the virtual package.
        verbose_callback: Optional per-probe log callback (verbose mode).
        warn_callback: Optional non-verbose warning callback. Fired
            when the ls-remote + shallow-fetch fallback resolves both
            the ref and the path. Yellow-traffic-light signal: the
            git-credential chain validated a package the API check
            could not, which may indicate a credential-scope mismatch
            an operator must see in default-verbosity CI runs.

    Returns:
        True if the package exists / is accessible, False otherwise.
    """
    if not dep_ref.is_virtual:
        raise ValueError("Can only validate virtual packages with this method")

    ref: str = dep_ref.reference or "main"
    vpath: str = dep_ref.virtual_path

    # SECURITY (round-2 finding 7 + round-3 finding 2): reject traversal
    # segments before any URL interpolation, and reject empty vpath
    # outright. Empty vpath is not a traversal but `git ls-tree
    # FETCH_HEAD ""` is implementation-defined; some git versions emit a
    # root listing and falsely validate any successfully-fetched repo.
    # `reject_empty=True` closes that hole at the entry point.
    try:
        validate_path_segments(vpath, context="virtual path", reject_empty=True)
    except PathTraversalError as exc:
        if verbose_callback:
            verbose_callback(f"  [x] virtual path rejected: {exc}")
        return False

    def _log(msg: str) -> None:
        if verbose_callback:
            verbose_callback(msg)

    def _probe(path: str, raw_only: bool = False) -> bool:
        try:
            downloader.download_raw_file(dep_ref, path, ref, raw_only=raw_only)
            _log(f"  [+] {path}@{ref}")
            return True
        except GitHubThrottleError:
            raise
        except RuntimeError as exc:
            # Marker-file misses on the success path are expected, not
            # errors -- reserve [x] for genuine failures.
            _log(f"  [i] {path}@{ref} ({exc})")
            return False

    def _raw_cdn_first_applies() -> bool:
        """Whether a raw-CDN-only marker sweep is safe and useful here.

        True only for public github.com repositories on the anonymous-first
        path: the CDN is un-metered there, while every Contents API miss
        spends the shared 60/h anonymous budget (microsoft/apm#3283).
        """
        host = dep_ref.host or default_host()
        if dep_ref.is_azure_devops() or not is_github_hostname(host):
            return False
        try:
            return (
                downloader.auth_resolver.uses_public_github_anonymous_first(
                    host,
                    port=dep_ref.port,
                    host_type=dep_ref.host_type,
                )
                is True
            )
        except Exception:
            return False

    _log(f'  [i] Validating virtual package at ref "{ref}": {dep_ref.repo_url}/{vpath}')

    if dep_ref.is_virtual_file():
        return _probe(vpath)

    if dep_ref.is_virtual_subdirectory():
        # Probe order: apm.yml first (a `collections/<name>/apm.yml` is the
        # supported way to express a curated dependency aggregator -- see
        # microsoft/apm#1094), then the standard primitive markers.
        marker_paths = [
            f"{vpath}/apm.yml",
            f"{vpath}/SKILL.md",
            f"{vpath}/plugin.json",
            f"{vpath}/.github/plugin/plugin.json",
            f"{vpath}/.claude-plugin/plugin.json",
            f"{vpath}/.cursor-plugin/plugin.json",
            f"{vpath}/README.md",
        ]

        # Efficiency repair (microsoft/apm#3283, maintainer-approved bounded
        # scope): for public github.com repositories the raw CDN answers
        # marker probes without spending the shared anonymous REST budget,
        # so sweep every candidate marker CDN-only first.  A Claude-plugin
        # layout (manifest at ``.claude-plugin/plugin.json``) previously
        # burned one anonymous Contents API call per earlier-marker miss;
        # the sweep reduces marker validation to zero API calls when any
        # marker is reachable through the raw-file path.  Each miss here is
        # expected, not an error: when the sweep finds nothing, the original
        # per-marker probes below run unchanged, so API-only, private, and
        # enterprise-host validation keeps its exact behavior.
        if _raw_cdn_first_applies():
            for marker_path in marker_paths:
                if _probe(marker_path, raw_only=True):
                    return True

        for marker_path in marker_paths:
            if _probe(marker_path):
                return True

        # Fallback 1: directory-exists probe via Contents API.
        if _directory_exists_at_ref(downloader, dep_ref, vpath, ref, _log):
            return True

        # Fallback 2: explicit ref + git ls-remote + shallow-fetch path
        # probe.  Mirrors install's auth chain so we accept packages
        # whose API auth is stricter than their git auth.  Only kicks in
        # with an explicit, NON-EMPTY ref -- without one, strict
        # validation keeps path typos failing fast on the default
        # branch. Round-3 finding 1: a bare `#` fragment produces
        # `reference == ""`, which `is not None` would let through; the
        # truthy check below rejects it so the fallback is reachable
        # only for explicitly-pinned refs.
        if dep_ref.reference:
            ref_ok, winning_attempt = _ref_exists_via_ls_remote(downloader, dep_ref, ref, _log)
            if ref_ok and winning_attempt is not None:
                # SECURITY (round-2 finding 6): close the fail-open.  ls-remote
                # only confirms the ref exists; we MUST also confirm the
                # subdirectory exists at that ref via a shallow-fetch +
                # ls-tree probe, otherwise a typo'd vpath silently passes
                # validation.  Reuse the WINNING attempt (panel round-3
                # auth-chain bug fix) so we don't fall back to attempts[0].
                if _path_exists_in_tree_at_ref(
                    downloader, dep_ref, vpath, ref, _log, winning_attempt
                ):
                    _log(f'  [+] "{vpath}@{ref}" confirmed via shallow-fetch + ls-tree')
                    if warn_callback is not None:
                        # devx-ux + cli-logging (round-3): name the
                        # security-relevant outcome explicitly. A scoped
                        # PAT may have *correctly* rejected this package
                        # on the API surface; the operator must be able
                        # to distinguish that from a legitimate API hit.
                        warn_callback(
                            f"API validation skipped for {dep_ref.to_canonical()}; "
                            "resolved via git credential fallback. "
                            "Run with --verbose for details."
                        )
                    return True
                _log(
                    f'  [!] ref "{ref}" resolves but "{vpath}" not present in the tree at that ref'
                )
                return False
        return False

    return _probe(vpath)


def _directory_exists_at_ref(
    downloader: GitHubPackageDownloader,
    dep_ref: DependencyReference,
    path: str,
    ref: str,
    log: Callable[[str], None],
) -> bool:
    """Check if a directory exists at ``ref`` via the Contents API.

    Uses the default ``Accept: application/vnd.github+json`` so the
    endpoint returns the directory listing for directories (and file
    metadata for files). Only an array of entry objects confirms a
    directory; file, symlink, and submodule objects do not.

    Returns ``True`` for a directory listing, including an empty array;
    ``False`` for non-directory content, 404, or any error. Only
    implemented for github.com / GHE; non-GitHub hosts return ``False``
    and rely on the marker-file probes above.
    """
    host: str = dep_ref.host or default_host()
    if dep_ref.is_azure_devops() or not is_github_hostname(host):
        log(f"  [i] directory-exists probe skipped (host {host} not supported)")
        return False

    parts = _split_owner_repo(dep_ref.repo_url)
    if parts is None:
        log(f"  [x] repo_url '{dep_ref.repo_url}' missing owner/repo split")
        return False
    owner, repo = parts

    from urllib.parse import quote

    encoded_path = quote(path, safe="/")
    encoded_ref = quote(ref, safe="")

    host_lc = host.lower()
    if host_lc == "github.com":
        api_url = (
            f"https://api.github.com/repos/{owner}/{repo}/contents/{encoded_path}?ref={encoded_ref}"
        )
    elif host_lc.endswith(".ghe.com"):
        api_url = (
            f"https://api.{host}/repos/{owner}/{repo}/contents/{encoded_path}?ref={encoded_ref}"
        )
    else:
        api_url = (
            f"https://{host}/api/v3/repos/{owner}/{repo}/contents/{encoded_path}?ref={encoded_ref}"
        )

    def _request(token: str | None, _git_env: dict[str, str]) -> bool:
        headers: dict[str, str] = {"Accept": "application/vnd.github+json"}
        from ..core.auth import AuthResolver

        headers.update(AuthResolver.github_rest_headers(token))
        response = downloader._resilient_get(
            api_url,
            headers=headers,
            timeout=30,
            retry_throttles=False,
        )
        raise_for_github_throttle(response, host)
        if response.status_code == 200:
            try:
                entries = response.json()
            except ValueError:
                log(f"  [x] {path}@{ref} (invalid Contents API JSON)")
                return False
            if not isinstance(entries, list) or not all(
                isinstance(entry, dict) for entry in entries
            ):
                log(f"  [!] {path}@{ref} (not a directory listing)")
                return False
            log(f"  [+] {path}@{ref} (directory)")
            return True
        response.raise_for_status()
        return False

    try:
        if (
            downloader.auth_resolver.uses_public_github_anonymous_first(
                host,
                port=dep_ref.port,
                host_type=dep_ref.host_type,
            )
            is True
        ):
            return downloader.auth_resolver.try_with_fallback(
                host,
                _request,
                org=owner,
                port=dep_ref.port,
                path=dep_ref.repo_url,
                host_type=dep_ref.host_type,
                unauth_first=True,
            )
        auth_ctx = downloader.auth_resolver.resolve_for_dep(dep_ref)
        return _request(auth_ctx.token, auth_ctx.git_env)
    except GitHubThrottleError:
        raise
    except requests.exceptions.HTTPError as exc:
        status = exc.response.status_code if exc.response is not None else "unknown"
        if status == 404:
            log(f"  [i] {path}@{ref} (HTTP 404)")
        else:
            log(f"  [x] {path}@{ref} (HTTP {status})")
        return False
    except (requests.exceptions.RequestException, RuntimeError) as exc:
        log(f"  [x] {path}@{ref} ({exc})")
        return False


def _build_validation_attempts(
    downloader: GitHubPackageDownloader,
    dep_ref: DependencyReference,
    log: Callable[[str], None],
) -> list[AttemptSpec]:
    """Return the AttemptSpec chain for a probe against ``dep_ref``.

    AuthResolver owns remote-aware credential suppression and host-specific
    header formatting. This helper builds tokenless URLs and labels the
    resulting validation attempts; it never replaces AuthResolver output.

    """
    if dep_ref.is_artifactory():
        return []

    is_insecure: bool = bool(getattr(dep_ref, "is_insecure", False))
    is_ado: bool = dep_ref.is_azure_devops()
    host_info = (
        downloader.auth_resolver.classify_host(
            dep_ref.host,
            port=dep_ref.port,
            host_type=dep_ref.host_type,
        )
        if getattr(dep_ref, "host", None)
        else None
    )
    is_gitlab = host_info is not None and host_info.kind == "gitlab"
    public_github_anonymous_first = bool(
        host_info is not None
        and not is_insecure
        and downloader.auth_resolver.uses_public_github_anonymous_first(
            host_info.host,
            port=dep_ref.port,
            host_type=dep_ref.host_type,
        )
        is True
    )
    if public_github_anonymous_first:
        dep_token = None
        dep_auth_ctx = None
        dep_auth_scheme = "basic"
    else:
        dep_token = downloader._resolve_dep_token(dep_ref)
        dep_auth_ctx = downloader._resolve_dep_auth_ctx(dep_ref)
        dep_auth_scheme = dep_auth_ctx.auth_scheme if dep_auth_ctx else "basic"

    if is_ado:
        ado_url = downloader._build_repo_url(
            dep_ref.repo_url,
            use_ssh=False,
            dep_ref=dep_ref,
        )
        ado_env = (
            downloader.auth_resolver.git_env_for_remote(dep_auth_ctx, ado_url)
            if dep_auth_ctx is not None
            else downloader.auth_resolver.build_noninteractive_git_env(
                base_env=downloader.git_env,
                host_kind="ado",
                preserve_config_isolation=True,
                suppress_credential_helpers=True,
            )
        )
        auth_label = (
            "ADO authenticated HTTPS (bearer header)"
            if dep_auth_scheme == "bearer"
            else (
                "ADO authenticated HTTPS (basic header)"
                if dep_token
                else "ADO HTTPS without resolved credential"
            )
        )
        return [AttemptSpec(auth_label, ado_url, ado_env)]

    attempts: list[AttemptSpec] = []

    # Attempt 1: explicit token, header-injected. Skipped when no token.
    if dep_token:
        if is_ado and dep_auth_scheme == "basic":
            # ADO PAT requires HTTP Basic with base64(":PAT"). A raw
            # Bearer header would 401 every ADO PAT user.
            label = "ADO authenticated HTTPS (basic header)"
        elif is_ado:  # bearer (AAD JWT)
            label = "ADO authenticated HTTPS (bearer header)"
        elif is_gitlab:
            label = "GitLab authenticated HTTPS (basic header)"
        else:
            # Non-ADO: header injection rather than URL embedding so the
            # token never appears in argv or temp .git/config.
            label = "authenticated HTTPS (header)"

        token_url = downloader._build_repo_url(
            dep_ref.repo_url,
            use_ssh=False,
            dep_ref=dep_ref,
        )
        token_env = (
            downloader.auth_resolver.git_env_for_remote(
                dep_auth_ctx,
                token_url,
            )
            if dep_auth_ctx is not None
            else downloader.auth_resolver._build_git_env(
                dep_token,
                scheme=dep_auth_scheme,
                host_kind=host_info.kind if host_info is not None else "github",
                base_env=downloader.git_env,
            )
        )
        attempts.append(AttemptSpec(label, token_url, token_env))

    # Attempt 2: plain HTTPS w/ credential helper (no token, no header).
    plain_url = downloader._build_repo_url(
        dep_ref.repo_url,
        use_ssh=False,
        dep_ref=dep_ref,
    )
    if public_github_anonymous_first:
        plain_env = downloader.auth_resolver.build_public_github_anonymous_git_env(
            base_env=downloader.git_env,
        )
    elif host_info is not None:
        plain_env = downloader.auth_resolver.build_native_git_credential_env(
            host_info,
            plain_url,
        )
    else:
        plain_env = downloader._build_noninteractive_git_env(
            preserve_config_isolation=is_insecure,
            suppress_credential_helpers=is_insecure,
        )
    plain_label = (
        "anonymous GitHub HTTPS"
        if public_github_anonymous_first
        else ("ADO HTTPS without credential" if is_ado else "plain HTTPS w/ credential helper")
    )
    attempts.append(AttemptSpec(plain_label, plain_url, plain_env))

    # Attempt 3 (SSH): only when allowed. StrictHostKeyChecking is
    # intentionally inherited from the user's ssh config; do NOT add
    # `-o StrictHostKeyChecking=no` thinking it's safer -- it isn't.
    if not is_insecure and _ssh_attempt_allowed(downloader):
        try:
            ssh_url = downloader._build_repo_url(
                dep_ref.repo_url,
                use_ssh=True,
                dep_ref=dep_ref,
            )
            ssh_env = dict(plain_env)
            ssh_env["GIT_SSH_COMMAND"] = "ssh -o BatchMode=yes -o ConnectTimeout=10"
            attempts.append(AttemptSpec("SSH", ssh_url, ssh_env))
        except Exception as exc:
            log(f"  [!] SSH URL build skipped: {exc}")

    return attempts


def _ref_exists_via_ls_remote(
    downloader: GitHubPackageDownloader,
    dep_ref: DependencyReference,
    ref: str,
    log: Callable[[str], None],
) -> tuple[bool, AttemptSpec | None]:
    """Check if ``ref`` exists in the remote repo via ``git ls-remote``.

    Lenient fallback for when the Contents API rejects a path with 404
    even though ``git clone`` would succeed -- e.g. SSO-half-authorized
    PATs, fine-grained PAT scope mismatches between API and git
    protocols, or repo policies that gate the Contents API more
    strictly than git.

    For SHA-pinned refs (hex-only, 7-40 chars) the ls-remote call omits
    ``--heads --tags`` because those filters silently drop commit SHAs
    -- the full ref list is scanned for a SHA-prefix match instead.

    Returns:
        ``(True, winning_attempt)`` on the first attempt that resolves
        the ref; ``(False, None)`` if every attempt fails. Callers MUST
        reuse ``winning_attempt`` for any follow-up probe at the same
        ref so the auth-chain promise holds end-to-end (panel round-3:
        if ls-remote succeeded via SSH but the follow-up probe used the
        rejected PAT, the fallback would silently false-reject).
    """
    if dep_ref.is_artifactory():
        return False, None
    is_sha = _is_sha_pin(ref)
    ref_lc = ref.lower()
    g = git.cmd.Git()

    def _run_remote(
        url: str,
        env: dict[str, str],
        *,
        options: tuple[str, ...] = (),
        patterns: tuple[str, ...] = (),
    ) -> str:
        if type(g).__module__.startswith("unittest.mock"):
            return g.ls_remote(*options, url, *patterns, env=env)
        from ..utils.git_env import git_remote_refs

        result = git_remote_refs(url, *patterns, env=env, options=options)
        if result.returncode != 0:
            # auth-delegated: the validated AttemptSpec owns this credential choice.
            raise GitCommandError(
                [get_git_executable(), "ls-remote", *options, url, *patterns],
                result.returncode,
                stderr=result.stderr,
            )
        return result.stdout

    host = dep_ref.host or default_host()
    if (
        not dep_ref.is_insecure
        and downloader.auth_resolver.uses_public_github_anonymous_first(
            host,
            port=dep_ref.port,
            host_type=dep_ref.host_type,
        )
        is True
    ):

        def _public_github_ref_probe(
            token: str | None,
            git_env: dict[str, str],
        ) -> tuple[str, AttemptSpec]:
            probe_env = dict(git_env)
            label = "anonymous GitHub HTTPS"
            if token:
                label = "authenticated GitHub HTTPS"
            url = downloader._build_repo_url(
                dep_ref.repo_url,
                use_ssh=False,
                dep_ref=dep_ref,
            )
            output = (
                _run_remote(url, probe_env)
                if is_sha
                else _run_remote(
                    url,
                    probe_env,
                    options=("--heads", "--tags"),
                    patterns=(ref,),
                )
            )
            return output, AttemptSpec(label, url, probe_env)

        org = dependency_repository_owner(dep_ref)
        try:
            output, attempt = downloader.auth_resolver.try_with_fallback(
                host,
                _public_github_ref_probe,
                org=org,
                port=dep_ref.port,
                path=dep_ref.repo_url,
                host_type=dep_ref.host_type,
                unauth_first=True,
                base_env=downloader.git_env,
            )
            if is_sha:
                matched = bool(
                    output
                    and any(
                        line.split("\t", 1)[0].lower().startswith(ref_lc)
                        for line in output.splitlines()
                        if line
                    )
                )
            else:
                matched = bool(output and output.strip())
            if matched:
                log(f"  [+] ls-remote ok via {attempt.label}")
                return True, attempt
            log(f"  [!] ls-remote returned no matching refs via {attempt.label}")
            return False, None
        except (GitCommandError, OSError) as exc:
            log(
                "  [x] ls-remote failed via anonymous-first GitHub HTTPS: "
                f"{git_subprocess_error_text(exc)}"
            )
            return False, None

    attempts = _build_validation_attempts(downloader, dep_ref, log)
    if not attempts:
        return False, None

    if dep_ref.is_azure_devops():
        primary_attempt = attempts[0]
        winning: list[AttemptSpec] = []

        def _probe_ado(_token: str | None, git_env: dict[str, str]) -> str:
            # auth-delegated: try_with_fallback selects PAT, az bearer, or the
            # path-scoped helper credential carried in git_env.
            output = (
                _run_remote(primary_attempt.url, git_env)
                if is_sha
                else _run_remote(
                    primary_attempt.url,
                    git_env,
                    options=("--heads", "--tags"),
                    patterns=(ref,),
                )
            )
            # The follow-up tree probe must reuse the credential that worked.
            winning[:] = [AttemptSpec(primary_attempt.label, primary_attempt.url, dict(git_env))]
            return output

        try:
            output = downloader.auth_resolver.try_with_fallback(
                dep_ref.host or "dev.azure.com",
                _probe_ado,
                org=dependency_repository_owner(dep_ref),
                port=dep_ref.port,
                path=dep_ref.repo_url,
                host_type=dep_ref.host_type,
                remote_url=primary_attempt.url,
                base_env=downloader.git_env,
            )
        except (GitCommandError, OSError, RuntimeError) as error:
            log(
                f"  [x] ls-remote failed via {primary_attempt.label}: "
                f"{git_subprocess_error_text(error)}"
            )
            return False, None
        winning_attempt = winning[0] if winning else primary_attempt
        matched = bool(
            output
            and (
                any(
                    line.split("\t", 1)[0].lower().startswith(ref_lc)
                    for line in output.splitlines()
                    if line
                )
                if is_sha
                else output.strip()
            )
        )
        if matched:
            log(f"  [+] ls-remote ok via {winning_attempt.label}")
            return True, winning_attempt
        log(f"  [!] ls-remote returned no matching refs via {winning_attempt.label}")
        return False, None

    for attempt in attempts:
        label, url, env = attempt
        try:
            if is_sha:
                # SHA pins: scan the full advertised-refs list.  The
                # ``--heads --tags`` filters scan only ``refs/heads/*``
                # and ``refs/tags/*`` and silently drop commit SHAs.
                output = _run_remote(url, env)
                if output and any(
                    line.split("\t", 1)[0].lower().startswith(ref_lc)
                    for line in output.splitlines()
                    if line
                ):
                    log(f"  [+] ls-remote ok via {label}")
                    return True, attempt
                log(f"  [!] ls-remote returned no SHA match via {label}")
            else:
                output = _run_remote(
                    url,
                    env,
                    options=("--heads", "--tags"),
                    patterns=(ref,),
                )
                if output and output.strip():
                    log(f"  [+] ls-remote ok via {label}")
                    return True, attempt
                log(f"  [!] ls-remote returned no matching refs via {label}")
        except (GitCommandError, OSError) as exc:
            log(f"  [x] ls-remote failed via {label}: {git_subprocess_error_text(exc)}")

    return False, None


def _path_exists_in_tree_at_ref(
    downloader: GitHubPackageDownloader,
    dep_ref: DependencyReference,
    vpath: str,
    ref: str,
    log: Callable[[str], None],
    winning_attempt: AttemptSpec,
) -> bool:
    """Confirm ``vpath`` is a directory at ``ref`` via shallow fetch + ``ls-tree``.

    Closes the fail-open hole in ``_ref_exists_via_ls_remote``: knowing
    that the ref exists is not the same as knowing the subdirectory
    exists at that ref.  This helper initialises a temporary bare repo,
    fetches a single commit with ``--filter=tree:0`` (no blob bodies,
    cheap), and then runs ``ls-tree`` to assert the path is present in
    the resolved tree.  Cleans up the temp dir regardless of outcome.

    Args:
        winning_attempt: The AttemptSpec returned by
            ``_ref_exists_via_ls_remote`` -- MUST be reused so the same
            credential that proved the ref exists is the one used to
            fetch the tree.  Panel round-3 closed the
            ``attempts[0]``-only bug here.

    Returns:
        True iff the shallow fetch succeeded AND ``ls-tree`` reported
        a directory entry for ``vpath`` at the resolved ref.
    """
    label, url, env = winning_attempt

    base_temp = get_apm_temp_dir()
    tmpdir = Path(tempfile.mkdtemp(prefix="apm-validate-", dir=base_temp))
    try:
        bare = tmpdir / "probe.git"
        bare.mkdir()
        from ..utils.git_env import (
            get_git_executable,
            git_network_env,
            git_no_templates_args,
            git_subprocess_env,
        )

        git_exe = get_git_executable()
        probe_env = git_subprocess_env(env)
        try:
            subprocess.run(
                [git_exe, "init", *git_no_templates_args(), "--bare", str(bare)],
                check=True,
                capture_output=True,
                env=probe_env,
            )
            probe_env = git_network_env(url, probe_env, git_dir=bare)
            subprocess.run(
                [git_exe, "--git-dir", str(bare), "remote", "add", "origin", url],
                check=True,
                capture_output=True,
                env=probe_env,
            )
            remote_env = git_network_env(url, probe_env, git_dir=bare)
            # --filter=tree:0 keeps the fetch payload tiny: we get the
            # commit + a single tree object, no blob contents.
            subprocess.run(
                [
                    git_exe,
                    "--git-dir",
                    str(bare),
                    "fetch",
                    "--depth=1",
                    "--filter=tree:0",
                    "origin",
                    ref,
                ],
                check=True,
                capture_output=True,
                env=remote_env,
            )
        except (subprocess.CalledProcessError, OSError) as exc:
            log(f"  [x] shallow fetch failed via {label}: {git_subprocess_error_text(exc)}")
            return False

        try:
            result = run_git_text(
                [git_exe, "--git-dir", str(bare), "ls-tree", "-d", "FETCH_HEAD", vpath],
                check=True,
                capture_output=True,
                env=remote_env,
            )
            output = result.stdout
        except (subprocess.CalledProcessError, OSError) as exc:
            error = git_subprocess_error_text(exc)
            log(f"  [x] ls-tree failed via {label}: {error}")
            return False

        # ``-d`` also includes gitlinks (160000 commit), which cannot be
        # materialized as plugin content without following another repository.
        if output and output.split(maxsplit=2)[:2] == ["040000", "tree"]:
            log(f"  [+] {vpath}@{ref} present in tree")
            return True
        log(f"  [!] {vpath} not present in tree at {ref}")
        return False
    finally:
        # safe_rmtree wraps robust_rmtree with an ensure_path_within
        # containment assertion -- never call robust_rmtree directly.
        with contextlib.suppress(Exception):
            safe_rmtree(tmpdir, base_temp)


def _ssh_attempt_allowed(downloader: GitHubPackageDownloader) -> bool:
    """Whether the SSH ls-remote attempt should run.

    Mirrors ``_clone_with_fallback``'s gating: SSH is in scope when the
    user explicitly preferred it (``--ssh``) or when cross-protocol
    fallback is allowed.  Default HTTPS-preferring users get no SSH
    attempt -- keeps validation output clean and never invokes ssh on
    machines that don't have it configured.
    """
    try:
        from .transport_selection import ProtocolPreference
    except ImportError:
        return False
    return downloader._protocol_pref == ProtocolPreference.SSH or downloader._allow_fallback
