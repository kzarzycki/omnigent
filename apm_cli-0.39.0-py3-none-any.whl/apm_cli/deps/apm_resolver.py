"""APM dependency resolution engine with recursive resolution and conflict detection."""

import contextlib
import inspect
import logging
import os
import re
import threading
from collections import deque
from collections.abc import Callable, Iterable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import fields, is_dataclass, replace
from pathlib import Path, PureWindowsPath
from typing import TYPE_CHECKING, NoReturn, Optional, Protocol

from apm_cli.core.scope import manifest_file

from ..bundle.local_bundle import route_agent_plugin_package
from ..core.errors import TargetResolutionError
from ..models.apm_package import APMPackage, DependencyReference
from ..models.dependency.materialization import (
    MaterializationSlots,
    nested_materialization_pairs,
)
from ..models.dependency.replacement import build_replacement_index
from ..models.dependency.subsets import EdgeSelection, merge_edge_selections
from ..models.validation import PackageType, detect_package_type, validate_apm_package
from ..utils.path_security import PathTraversalError, ensure_path_within, validate_path_segments
from ._shared import MarketplaceManifestMaterializationError, materialize_marketplace_manifest
from .dependency_graph import (
    CircularRef,
    DependencyGraph,
    DependencyNode,
    DependencyTree,
    FlatDependencyMap,
)
from .immutable_requirements import (
    ImmutableRequirementError,
    ImmutableRequirements,
    ReferenceResolver,
)
from .local_identity import (
    portable_anchor_identity,
    transitive_local_identity,
    with_declaring_edge,
)
from .local_identity import root_local_dirs as collect_root_local_dirs

if TYPE_CHECKING:
    from .lockfile import LockFile

_logger = logging.getLogger(__name__)


# Default worker pool size for the level-batched BFS download phase.
# Parallel resolution is the CENTRAL execution model (uv-inspired);
# the ``APM_RESOLVE_PARALLEL`` env var exists solely as a diagnostic /
# parity-testing knob (e.g. ``APM_RESOLVE_PARALLEL=1 apm install`` to
# reproduce legacy sequential ordering for diff-debugging).  It is NOT
# a user-facing feature toggle.
_DEFAULT_RESOLVE_PARALLEL = 4


def _select_dependency_winners(
    nodes: Iterable[DependencyNode],
) -> tuple[tuple[DependencyNode, ...], dict[str, str]]:
    """Return canonical dependency order and first-wins node IDs."""
    ordered = tuple(sorted(nodes, key=lambda node: (node.depth, node.get_id())))
    winner_ids: dict[str, str] = {}
    for node in ordered:
        winner_ids.setdefault(
            node.dependency_ref.get_unique_key(),
            node.get_id(),
        )
    return ordered, winner_ids


def _alias_divergence_warning(dep_ref: DependencyReference, selection) -> str:
    """Describe divergent aliases for one dependency and the alias that applies."""
    declared = "; ".join(
        f"{edge.declared_by()}: {edge.alias or '(none)'}" for edge in selection.contributors
    )
    return (
        f"Dependency '{dep_ref.get_identity()}' is declared with different aliases "
        f"({declared}). Using '{selection.alias or '(none)'}' from the shallowest "
        "declaration; declare the same alias everywhere to silence this warning."
    )


def _with_node_selection(dep_ref: DependencyReference, selection) -> DependencyReference:
    """Return *dep_ref* carrying the merged selection; keep it when nothing changes."""
    skills = None if selection.skill_subset is None else list(selection.skill_subset)
    targets = None if selection.target_subset is None else list(selection.target_subset)
    if (
        len(selection.contributors) == 1
        and sorted(dep_ref.skill_subset or ()) == (skills or [])
        and sorted(dep_ref.target_subset or ()) == (targets or [])
        and dep_ref.allow_insecure == selection.allow_insecure
    ):
        return dep_ref
    merged = replace(
        dep_ref,
        skill_subset=skills,
        target_subset=targets,
        allow_insecure=selection.allow_insecure,
        selection_contributors=selection.contributors,
        subset_pairings=selection.subset_pairings,
    )
    binding = dep_ref.replacement
    if binding is not None:
        # The lockfile records a replaced node through its original request,
        # so the original carries the node's merged selection too.
        binding.original = replace(binding.original, skill_subset=skills, target_subset=targets)
    # Download callbacks annotate the node reference with non-field state
    # (for example ``resolved_reference``); keep it on the merged reference.
    declared = {item.name for item in fields(dep_ref)}
    for name, value in vars(dep_ref).items():
        if name not in declared:
            setattr(merged, name, value)
    return merged


# Type alias for the download callback.
# Takes (dep_ref, apm_modules_dir, parent_chain, parent_pkg) and returns the
# install path if successful. ``parent_chain`` is a human-readable breadcrumb
# string like "root-pkg > mid-pkg > this-pkg" showing the full dependency
# path including the current node, or just the node's display name for
# direct (depth-1) deps. ``parent_pkg`` is the APMPackage that declared this
# dependency (None for direct deps from the root); callers use its
# ``source_path`` to anchor relative ``local_path`` resolution (#857).
#
# Note: NOT @runtime_checkable -- we use signature inspection
# (``_signature_accepts_parent_pkg``) to detect legacy callbacks, never
# isinstance, so the runtime-checkable overhead would be dead weight.
class DownloadCallback(Protocol):
    def __call__(
        self,
        dep_ref: "DependencyReference",
        apm_modules_dir: Path,
        parent_chain: str = "",
        parent_pkg: Optional["APMPackage"] = None,
    ) -> Path | None: ...


class ActivationCallback(Protocol):
    """Publish a validated download candidate and return its live path."""

    def __call__(self, candidate_path: Path) -> Path: ...


_TRAILING_RETRY = re.compile(r",? then retry\.?$")


class DownloadedPackageError(RuntimeError):
    """A downloaded candidate could not be validated or activated."""


class APMDependencyResolver:
    """Handles recursive APM dependency resolution similar to NPM."""

    def __init__(
        self,
        max_depth: int = 50,
        apm_modules_dir: Path | None = None,
        download_callback: DownloadCallback | None = None,
        max_parallel: int | None = None,
        auth_resolver: object | None = None,
        update_refs: bool = False,
        existing_lockfile: "LockFile | None" = None,
        activation_callback: ActivationCallback | None = None,
        cache_validation_callback: Callable[[Path, str], Path | None] | None = None,
        reference_resolver: ReferenceResolver | None = None,
        frozen: bool = False,
        update_keys: set[str] | None = None,
        read_only: bool = False,
        create_config: bool | None = None,
        preview: bool = False,
    ):
        """Initialize the resolver with maximum recursion depth.

        Args:
            max_depth: Maximum depth for dependency resolution (default: 50)
            apm_modules_dir: Optional explicit apm_modules directory. If not provided,
                             will be determined from project_root during resolution.
            download_callback: Optional callback to download missing packages. If provided,
                               the resolver will attempt to fetch uninstalled transitive deps.
            max_parallel: Max worker threads for the level-batched
                parallel BFS download phase (the default execution
                model). ``None`` resolves from the
                ``APM_RESOLVE_PARALLEL`` env var, falling back to
                ``_DEFAULT_RESOLVE_PARALLEL`` (4). Set to ``1`` ONLY
                for parity-testing against the legacy sequential path
                -- this is a diagnostic knob, not a user toggle.
            auth_resolver: Optional auth resolver for marketplace dependency resolution.
            update_refs: True for ``apm update`` / ``--refresh``. When set,
                ``_should_force_recheck`` gives ``download_callback`` a
                chance to run for a semver-ranged or mutable-ref Git dep
                even when its install path already exists, at any depth -- see that
                method's docstring for why this can't be scoped to direct
                deps only.
            update_keys: Shared selected-package keys for targeted installs and
                scoped updates. Selected descendants are added before download
                callbacks run.
            existing_lockfile: Existing resolved dependency state used by the
                canonical ref-drift owner to decide whether a plain install
                must re-enter the download callback.
            activation_callback: Optional callback that publishes a downloaded
                candidate only after this resolver validates it.
            cache_validation_callback: Optional read-only admission check for reused
                bytes, after the fetch decision and before package normalization.
            read_only: Preview using local sources and unchanged installed packages.
                Never fetch, activate, or materialize metadata; unknown subtrees
                are reported as resolution errors rather than treated as leaves.
            create_config: Whether manifest loads may create a missing user
                config file; defaults to False for read-only and preview runs.
            preview: ``--dry-run`` through the install pipeline: fetch like an
                install, create no user config, and record unavailable subtrees.
        """
        if read_only and any(
            callback is not None
            for callback in (
                download_callback,
                activation_callback,
                cache_validation_callback,
                reference_resolver,
            )
        ):
            raise ValueError(
                "Read-only resolution cannot use fetching or materialization callbacks"
            )
        self._read_only = read_only
        self._create_config = not (read_only or preview) if create_config is None else create_config
        self._preview = preview
        self.max_depth = max_depth
        # Chains cut at ``max_depth``: an org-policy depth limit reports them
        # as a policy refusal (#4826).
        self.depth_limit_chains: list[str] = []
        self._apm_modules_dir: Path | None = apm_modules_dir
        self._project_root: Path | None = None
        self._download_callback = download_callback
        self._activation_callback = activation_callback
        self._cache_validation_callback = cache_validation_callback
        self._update_refs = update_refs
        self._update_keys = update_keys
        self._scoped_rechecked: set[str] = set()
        self._existing_lockfile = existing_lockfile
        self._reference_resolver = reference_resolver
        self._frozen = frozen
        # Whether ``download_callback`` accepts ``parent_pkg`` (added in #857).
        # Detected once via signature inspection so legacy callbacks that
        # predate the field still work without raising a silent TypeError
        # that would mask the dependency.
        self._callback_accepts_parent_pkg: bool = (
            self._signature_accepts_parent_pkg(download_callback)
            if download_callback is not None
            else False
        )
        self._downloaded_packages: set[str] = (
            set()
        )  # Track what we downloaded during this resolution
        # Tracks ``dep_ref.get_unique_key()`` values rejected by the
        # remote-parent local_path guard (#940 / PR #1111 review C2). The
        # resolve phase folds this into ``ctx.callback_failures`` so the
        # integrate phase skips them with the same "already failed during
        # resolution" path used for download failures -- otherwise the
        # rejected dep would still sit in the dependency tree and get
        # copied later via ``_copy_local_package``, defeating the
        # fail-closed posture this guard is meant to enforce.
        self._rejected_remote_local_keys: set[str] = set()
        # Protects mutations of ``_downloaded_packages`` and
        # ``_rejected_remote_local_keys`` when the parallel BFS
        # dispatches ``_try_load_dependency_package`` calls onto a
        # worker pool. The ``max_parallel=1`` parity path still
        # acquires the lock -- the overhead is negligible and the
        # symmetry simplifies reasoning.
        self._download_lock = threading.Lock()
        self._local_materialization_locks: dict[Path, threading.Lock] = {}
        self._auth_resolver = auth_resolver
        self._max_parallel = self._resolve_max_parallel(max_parallel)
        self._marketplace_provenance: dict[str, dict[str, str]] = {}
        self._selected_marketplace_keys: list[str] = []
        # Every declaring edge per node identity (``get_unique_key``), recorded
        # before any dedup so the selection merge sees all of them (#3735).
        self._edge_selections: dict[str, list[EdgeSelection]] = {}
        self._edge_parents: dict[str, list[DependencyNode]] = {}
        self._edge_refs: dict[tuple[str, int], DependencyReference] = {}

    @property
    def marketplace_provenance(self) -> dict[str, dict[str, str]]:
        """Return marketplace provenance captured while resolving the graph."""
        return dict(self._marketplace_provenance)

    @property
    def selected_marketplace_keys(self) -> tuple[str, ...]:
        """Return resolved keys of selected catalog declarations (scoped updates)."""
        return tuple(self._selected_marketplace_keys)

    @staticmethod
    def _resolve_max_parallel(explicit: int | None) -> int:
        """Compute effective worker count for level-batched parallel BFS.

        Parallel is the default and central execution model.  The
        override exists for parity testing (``APM_RESOLVE_PARALLEL=1``)
        and CI diagnostics, not as a user-facing knob.

        Order of precedence:
        1. Explicit ``max_parallel`` ctor arg.
        2. ``APM_RESOLVE_PARALLEL`` env var (diagnostic/parity knob).
        3. ``_DEFAULT_RESOLVE_PARALLEL``.

        Always coerced to ``>= 1`` so the executor never gets a zero
        or negative ``max_workers``.
        """
        if explicit is not None:
            return max(1, int(explicit))
        env = os.environ.get("APM_RESOLVE_PARALLEL", "").strip()
        if env:
            try:
                return max(1, int(env))
            except ValueError:
                _logger.debug("Ignoring invalid APM_RESOLVE_PARALLEL=%r", env)
        return _DEFAULT_RESOLVE_PARALLEL

    @staticmethod
    def _signature_accepts_parent_pkg(callback) -> bool:
        """Return True if ``callback`` declares a ``parent_pkg`` parameter
        (or accepts ``**kwargs``).

        Falls back to False if the signature can't be introspected (e.g. C
        extensions, builtins). The conservative fallback is correct: if we
        don't know the callback's shape, assume the legacy 3-arg form so
        the resolver won't pass an extra positional/keyword that triggers
        TypeError and silently drops the dependency (#940 SR1).
        """
        try:
            sig = inspect.signature(callback)
        except (TypeError, ValueError):
            return False
        for param in sig.parameters.values():
            if param.kind is inspect.Parameter.VAR_KEYWORD:
                return True
            if param.name == "parent_pkg":
                return True
        return False

    def resolve_dependencies(
        self,
        project_root: Path,
        *,
        root_package: APMPackage | None = None,
    ) -> DependencyGraph:
        """
        Resolve all APM dependencies recursively.

        Args:
            project_root: Path to the project root containing apm.yml.
            root_package: Optional parsed root package. A caller can supply
                staged dependency refs without writing the manifest first.

        Returns:
            DependencyGraph: Complete resolved dependency graph
        """
        # Store project root for package loading
        self._project_root = project_root
        if self._apm_modules_dir is None:
            self._apm_modules_dir = project_root / "apm_modules"

        # Load the root package
        apm_yml_path = manifest_file(project_root)
        if not apm_yml_path.exists() and root_package is None:
            # Create empty dependency graph for projects without apm.yml
            empty_package = APMPackage(name="unknown", version="0.0.0", package_path=project_root)
            empty_tree = DependencyTree(root_package=empty_package)
            empty_flat = FlatDependencyMap()
            return DependencyGraph(
                root_package=empty_package,
                dependency_tree=empty_tree,
                flattened_dependencies=empty_flat,
            )

        if root_package is None:
            try:
                root_package = APMPackage.from_apm_yml(
                    apm_yml_path,
                    source_path=project_root.resolve(),
                    create_config=self._create_config,
                )
            except (ValueError, FileNotFoundError) as e:
                # Create error graph
                empty_package = APMPackage(name="error", version="0.0.0", package_path=project_root)
                empty_tree = DependencyTree(root_package=empty_package)
                empty_flat = FlatDependencyMap()
                graph = DependencyGraph(
                    root_package=empty_package,
                    dependency_tree=empty_tree,
                    flattened_dependencies=empty_flat,
                )
                graph.add_error(f"Failed to load root apm.yml: {e}")
                return graph
        elif root_package.source_path is None:
            root_package = replace(root_package, source_path=project_root.resolve())

        # Build the complete dependency tree
        dependency_tree = self.build_dependency_tree(
            apm_yml_path,
            root_package=root_package,
        )

        # Detect circular dependencies
        circular_deps = self.detect_circular_dependencies(dependency_tree)

        # Flatten dependencies for installation
        flattened_deps = self.flatten_dependencies(dependency_tree)

        # Create and return the complete graph
        graph = DependencyGraph(
            root_package=root_package,
            dependency_tree=dependency_tree,
            flattened_dependencies=flattened_deps,
            circular_dependencies=circular_deps,
        )

        for error in dependency_tree.resolution_errors:
            graph.add_error(error)
        graph.declaration_errors.extend(dependency_tree.declaration_errors)

        return graph

    def _remote_parent_eligible(self, parent_dep: DependencyReference) -> bool:
        """Return True if *parent_dep* can serve as the Git repo for ``git: parent`` expansion."""
        if parent_dep.is_azure_devops():
            return bool(parent_dep.ado_repo and parent_dep.repo_url.count("/") >= 2)
        return "/" in parent_dep.repo_url

    def expand_parent_repo_decl(
        self,
        parent_dep: DependencyReference,
        child_dep: DependencyReference,
    ) -> DependencyReference:
        """Expand ``{ git: parent, path: ... }`` using the declaring package's coordinates.

        The child keeps its ``virtual_path`` (monorepo subdirectory), ``alias``, and
        optional ``ref`` override; repository identity (host, ``repo_url``, ADO
        fields, etc.) is inherited from *parent_dep*.
        """
        if not child_dep.is_parent_repo_inheritance:
            raise ValueError(
                "expand_parent_repo_decl requires child_dep.is_parent_repo_inheritance"
            )
        if parent_dep.is_local:
            raise ValueError("git: parent cannot inherit from a local path dependency")
        if parent_dep.repo_url.startswith("_local/"):
            raise ValueError("git: parent cannot inherit from a local path dependency")
        if not self._remote_parent_eligible(parent_dep):
            raise ValueError("git: parent requires a remote Git parent package dependency")

        merged_ref = (
            child_dep.reference if child_dep.reference is not None else parent_dep.reference
        )

        return self._inherit_remote_parent_fields(
            parent_dep,
            child_dep,
            virtual_path=child_dep.virtual_path,
            reference=merged_ref,
            is_virtual=True,
        )

    @staticmethod
    def _inherit_remote_parent_fields(
        parent_dep: DependencyReference,
        child_dep: DependencyReference,
        *,
        virtual_path: str | None,
        reference: str | None,
        is_virtual: bool,
    ) -> DependencyReference:
        """Return *child_dep* with remote identity inherited from *parent_dep*."""
        return replace(
            child_dep,
            repo_url=parent_dep.repo_url,
            host=parent_dep.host,
            host_type=parent_dep.host_type,
            port=parent_dep.port,
            explicit_scheme=parent_dep.explicit_scheme,
            ssh_user=parent_dep.ssh_user,
            ado_organization=parent_dep.ado_organization,
            ado_project=parent_dep.ado_project,
            ado_repo=parent_dep.ado_repo,
            artifactory_prefix=parent_dep.artifactory_prefix,
            is_insecure=parent_dep.is_insecure,
            allow_insecure=parent_dep.allow_insecure,
            source=parent_dep.source,
            registry_name=None,
            reference=reference,
            virtual_path=virtual_path,
            is_virtual=is_virtual,
            is_parent_repo_inheritance=False,
            is_local=False,
            local_path=None,
        )

    @staticmethod
    def _is_absolute_local_path(local_path: str) -> bool:
        """Return True for POSIX, home-expanded, or Windows absolute paths."""
        raw = local_path.strip()
        return Path(raw).expanduser().is_absolute() or PureWindowsPath(raw).is_absolute()

    @staticmethod
    def _portable_anchor_identity(anchored: Path, base: Path | None) -> str:
        """Delegate to :func:`apm_cli.deps.local_identity.portable_anchor_identity`."""
        return portable_anchor_identity(anchored, base)

    def _remote_source_paths_for_parent(
        self,
        parent_dep: DependencyReference,
        parent_pkg: APMPackage,
    ) -> tuple[Path, Path]:
        """Return contained repository and package source-coordinate anchors."""
        if self._apm_modules_dir is None or parent_pkg.source_path is None:
            raise PathTraversalError(
                "remote parent package has no source path to anchor local path"
            )
        source_path = ensure_path_within(parent_pkg.source_path, self._apm_modules_dir)
        if parent_dep.alias:
            # Aliases flatten materialization, not authenticated repository coordinates.
            source_path = ensure_path_within(
                replace(parent_dep, alias=None).get_install_path(self._apm_modules_dir),
                self._apm_modules_dir,
            )
        repo_root = source_path
        if parent_dep.virtual_path:
            validate_path_segments(parent_dep.virtual_path, context="virtual_path")
            for _segment in parent_dep.virtual_path.replace("\\", "/").split("/"):
                if _segment:
                    repo_root = repo_root.parent
        return ensure_path_within(repo_root, self._apm_modules_dir), source_path

    def _expand_remote_parent_local_path(
        self,
        parent_dep: DependencyReference,
        parent_pkg: APMPackage,
        child_dep: DependencyReference,
    ) -> DependencyReference:
        """Expand a remote package's relative ``path:`` dep to a same-repo virtual dep.

        The security boundary is the authenticated parent repository root: a
        relative path must resolve inside that root. The returned dependency keeps
        the parent's host/repo/ref fields so downstream download code reuses the
        same origin and shared clone cache instead of treating the path as a
        consumer-filesystem local dependency.
        """
        if not child_dep.local_path:
            raise PathTraversalError("remote local dependency has no path")
        if child_dep.source == "registry" or parent_dep.source == "registry":
            raise PathTraversalError("registry packages cannot declare same-repo local paths")
        if not self._remote_parent_eligible(parent_dep):
            raise PathTraversalError("remote local dependency has no eligible git parent")
        local_str = str(child_dep.local_path)
        if self._is_absolute_local_path(local_str):
            raise PathTraversalError("absolute paths inside remote packages are not allowed")

        repo_root, parent_source = self._remote_source_paths_for_parent(parent_dep, parent_pkg)
        parent_source = ensure_path_within(parent_source, repo_root)
        local_path = Path(local_str.replace("\\", "/"))
        resolved = ensure_path_within(parent_source / local_path, repo_root)
        virtual_path = resolved.relative_to(repo_root).as_posix()
        if virtual_path in ("", "."):
            return self._inherit_remote_parent_fields(
                parent_dep,
                child_dep,
                virtual_path=None,
                reference=parent_dep.reference,
                is_virtual=False,
            )
        validate_path_segments(virtual_path, context="same-repo path")
        return self._inherit_remote_parent_fields(
            parent_dep,
            child_dep,
            virtual_path=virtual_path,
            reference=parent_dep.reference,
            is_virtual=True,
        )

    def _reject_remote_parent_local_path(
        self,
        dep_ref: DependencyReference,
        parent_pkg: APMPackage | None,
        detail: str,
    ) -> None:
        """Record and report a rejected ``path:`` dep declared by a remote package."""
        local_str = str(dep_ref.local_path or "")
        package_name = parent_pkg.name if parent_pkg else "?"
        try:
            from apm_cli.utils.console import _rich_error

            _rich_error(
                f"Refusing to install local_path dependency '{local_str}' "
                f"declared by remote package '{package_name}': {detail} "
                "Use a relative path that stays inside the same remote repo, "
                "or publish/reference the dependency as a standalone package."
            )
        except Exception:
            _logger.debug("Could not emit remote-parent rejection notice", exc_info=True)
        with self._download_lock:
            self._rejected_remote_local_keys.add(dep_ref.get_unique_key())

    def expand_transitive_declaration(
        self,
        parent_dep: DependencyReference,
        parent_pkg: APMPackage,
        child_dep: DependencyReference,
    ) -> DependencyReference | None:
        """Expand one declaration of *parent_pkg* as breadth-first resolution does.

        Applies ``git: parent`` inheritance and remote same-repository ``path:``
        expansion without reporting. Returns ``None`` where resolution would
        reject the declaration.
        """
        if child_dep.is_parent_repo_inheritance:
            try:
                child_dep = self.expand_parent_repo_decl(parent_dep, child_dep)
            except ValueError:
                return None
        if child_dep.is_local and child_dep.local_path and self._is_remote_parent(parent_pkg):
            try:
                return self._expand_remote_parent_local_path(parent_dep, parent_pkg, child_dep)
            except PathTraversalError:
                return None
        return child_dep

    def _expand_or_reject_remote_parent_local_path(
        self,
        parent_dep: DependencyReference,
        parent_pkg: APMPackage,
        child_dep: DependencyReference,
    ) -> DependencyReference | None:
        """Expand eligible remote ``path:`` deps, otherwise fail closed."""
        if not (child_dep.is_local and child_dep.local_path and self._is_remote_parent(parent_pkg)):
            return child_dep
        try:
            return self._expand_remote_parent_local_path(parent_dep, parent_pkg, child_dep)
        except PathTraversalError as exc:
            self._reject_remote_parent_local_path(child_dep, parent_pkg, str(exc))
            return None

    def _resolve_marketplace_dep(
        self, dep_ref: DependencyReference, *, required_by: str | None = None
    ) -> DependencyReference:
        """Resolve a marketplace dependency to a concrete DependencyReference.

        A declaration that still matches its lock row is replayed from the
        lock before any catalog, alias or registration I/O
        (:func:`~apm_cli.drift.locked_marketplace_replay`); ``--frozen``
        refuses a declaration with no matching lock row instead of asking the
        marketplace, and a local catalog that no longer selects its lock row. Otherwise uses
        :func:`resolve_marketplace_plugin` to look up the plugin in the
        registered marketplace and returns a resolved git-backed reference.
        Prefers the structured ``dependency_reference`` from the resolution
        when available (GitLab-class hosts, in-marketplace subdirectory
        plugins) over parsing the canonical string.

        Args:
            dep_ref: An unresolved marketplace DependencyReference.
            required_by: The declaring package for a transitive declaration,
                which must name a marketplace the root ``marketplaces:`` map
                declares (#2903).

        Returns:
            A concrete (non-marketplace) DependencyReference.

        Raises:
            MarketplaceNotFoundError: Marketplace is not registered.
            PluginNotFoundError: Plugin not found in the marketplace.
            MarketplaceFetchError: Network/auth error fetching marketplace data.
            ValueError: Invalid marketplace or plugin configuration, or a
                frozen or offline run without a matching lock row.
        """
        from apm_cli.drift import (
            MARKETPLACE_CATALOG_METADATA,
            MARKETPLACE_LOCAL_CATALOG,
            catalog_metadata_refusal,
            frozen_marketplace_refusal,
            local_catalog_refusal,
            locked_marketplace_replay,
        )

        if required_by is not None:
            from apm_cli.marketplace.project_marketplaces import (
                require_root_declared_marketplace,
            )

            require_root_declared_marketplace(
                dep_ref.marketplace_name, dep_ref.marketplace_plugin_name, required_by=required_by
            )
        decision = locked_marketplace_replay(
            dep_ref,
            self._existing_lockfile,
            update_refs=self._update_refs,
            modules_dir=self._apm_modules_dir,
        )
        if decision.reference is not None:
            _logger.debug("Replaying %s from apm.lock.yaml", dep_ref.get_display_name())
            return decision.reference
        refusal = frozen_marketplace_refusal(decision) if self._frozen else None
        if refusal is not None:
            raise refusal
        if self._read_only:
            raise ValueError("Marketplace lookup is not available in an offline dependency preview")
        from apm_cli.marketplace.catalog_origin import require_locked_catalog_origin
        from apm_cli.marketplace.dependency_confusion import admit_marketplace_resolution
        from apm_cli.marketplace.resolver import resolve_marketplace_plugin

        require_locked_catalog_origin(
            dep_ref.marketplace_name, dep_ref.marketplace_plugin_name, self._existing_lockfile
        )
        update_selected = self._update_keys is None or dep_ref.get_unique_key() in self._update_keys
        resolution = resolve_marketplace_plugin(
            dep_ref.marketplace_plugin_name,
            dep_ref.marketplace_name,
            version_spec=dep_ref.marketplace_version_spec,
            auth_resolver=self._auth_resolver,
            warning_handler=_logger.warning,
            # An update accepts a changed ref for the plugins it selects; an
            # unselected plugin keeps its locked ref, and a catalog read for
            # locked server metadata does not choose the download, so neither
            # touches the pin.
            enforce_ref_pins=not (self._update_refs and not update_selected)
            and decision.reason != MARKETPLACE_CATALOG_METADATA,
            accept_ref_change=bool(self._update_refs) and update_selected,
        )
        admit_marketplace_resolution(resolution)
        resolved = (
            resolution.dependency_reference
            if resolution.dependency_reference is not None
            else DependencyReference.parse(resolution.canonical)
        )
        # A cold server-owning row reads the catalog for server metadata only;
        # the lock row still pins the download (#3989). A frozen local catalog
        # must still select its lock row (#4639).
        if decision.reason == MARKETPLACE_CATALOG_METADATA:
            refusal = catalog_metadata_refusal(dep_ref, resolved, self._existing_lockfile)
        elif decision.reason == MARKETPLACE_LOCAL_CATALOG and self._frozen:
            refusal = local_catalog_refusal(dep_ref, resolved, self._existing_lockfile)
        if refusal is not None:
            raise refusal
        manifest = getattr(resolution.plugin, "manifest", None)
        if isinstance(manifest, dict) and manifest:
            resolved.marketplace_manifest = dict(manifest)
            resolved.marketplace_name = dep_ref.marketplace_name
            resolved.marketplace_plugin_name = dep_ref.marketplace_plugin_name
        # A selected catalog declaration selects the Git coordinate it
        # resolves to, so scoped updates re-check that package (#3279).
        if self._update_keys is not None and dep_ref.get_unique_key() in self._update_keys:
            resolved_key = resolved.get_unique_key()
            if resolved_key not in self._update_keys:
                self._update_keys.add(resolved_key)
                self._selected_marketplace_keys.append(resolved_key)
        self._marketplace_provenance[resolved.get_unique_key()] = resolution.provenance(
            dep_ref.marketplace_name,
            dep_ref.marketplace_plugin_name,
        )
        return resolved

    def _resolve_marketplace_or_record_error(
        self,
        dep_ref: DependencyReference,
        tree: DependencyTree,
        context: str,
        *,
        required_by: str | None = None,
    ) -> DependencyReference | None:
        """Try to resolve a marketplace dep; record an error on the tree on failure.

        Catches known marketplace exceptions and records them as resolution
        errors.  Unknown exceptions propagate so programmer errors are not
        silently swallowed.

        Args:
            dep_ref: Unresolved marketplace dependency.
            tree: The dependency tree to record errors on.
            context: Human-readable context for error messages
                     (e.g. ``"required by owner/repo"``).
            required_by: Declaring package of a transitive declaration.

        Returns:
            Resolved DependencyReference on success, ``None`` on known failure.
        """
        from apm_cli.marketplace.errors import (
            BuildError,
            DependencyConfusionError,
            MarketplaceFetchError,
            MarketplaceNotFoundError,
            MarketplaceOriginConflictError,
            PluginNotFoundError,
            UndeclaredMarketplaceError,
        )

        try:
            return self._resolve_marketplace_dep(dep_ref, required_by=required_by)
        except (
            DependencyConfusionError,
            MarketplaceNotFoundError,
            MarketplaceOriginConflictError,
            PluginNotFoundError,
            UndeclaredMarketplaceError,
            MarketplaceFetchError,
            BuildError,
            ValueError,
        ) as exc:
            _logger.debug(
                "Marketplace resolution failed for %s@%s: %s",
                dep_ref.marketplace_plugin_name,
                dep_ref.marketplace_name,
                exc,
            )
            tree.resolution_errors.append(
                f"Failed to resolve marketplace dependency "
                f"'{dep_ref.marketplace_plugin_name}' from "
                f"marketplace '{dep_ref.marketplace_name}'"
                f"{f' ({context})' if context else ''}: {exc}"
            )
            return None

    @staticmethod
    def _resolved_no_deeper(tree, dep_ref: DependencyReference, depth: int) -> bool:
        """Whether *dep_ref*'s package, under any ref, already has a node no deeper (#4968)."""
        same_origin = tree.get_node(dep_ref.get_unique_key())
        return same_origin is not None and same_origin.depth <= depth

    @staticmethod
    def _depth_limit_chain(dep_ref: DependencyReference, parent_node: DependencyNode | None) -> str:
        """Name the chain that reached ``max_depth`` (req-rs-006), root first."""
        chain = [dep_ref.to_display_reference()]
        ancestor = parent_node
        while ancestor is not None:
            chain.append(ancestor.dependency_ref.to_display_reference())
            ancestor = ancestor.parent
        return " -> ".join(reversed(chain))

    def build_dependency_tree(
        self,
        root_apm_yml: Path,
        *,
        root_package: APMPackage | None = None,
    ) -> DependencyTree:
        """Build complete tree of all dependencies and sub-dependencies.

        Uses breadth-first traversal to build the dependency tree level by level.
        This allows for early conflict detection and clearer error reporting.

        Args:
            root_apm_yml: Path to the root apm.yml file.
            root_package: Optional parsed root package to use instead of
                reading the file again.

        Returns:
            DependencyTree: Hierarchical dependency tree
        """
        # Load the root unless the caller has staged in-memory refs that must
        # remain unwritten until a consent gate.
        if root_package is None:
            try:
                root_package = APMPackage.from_apm_yml(
                    root_apm_yml,
                    source_path=self._project_root.resolve()
                    if self._project_root is not None
                    else root_apm_yml.parent.resolve(),
                    create_config=self._create_config,
                )
            except (ValueError, FileNotFoundError) as e:
                _logger.warning("Failed to parse root apm.yml: %s", e)
                empty_package = APMPackage(name="error", version="0.0.0")
                tree = DependencyTree(root_package=empty_package)
                return tree

        # Initialize the tree
        tree = DependencyTree(root_package=root_package)
        self._edge_selections = {}
        self._edge_parents = {}
        self._edge_refs = {}
        self.replacement_index = build_replacement_index(root_package.replace_rules or [])
        consumer_root = root_package.source_path or root_apm_yml.parent
        modules_dir = self._apm_modules_dir or root_apm_yml.parent / "apm_modules"
        requirements = ImmutableRequirements(
            root_package.name,
            self._reference_resolver,
            self._existing_lockfile,
            frozen=self._frozen,
            update_refs=self._update_refs,
        )

        # Queue for breadth-first traversal: (dependency_ref, depth, parent_node, is_dev)
        processing_queue: deque[tuple[DependencyReference, int, DependencyNode | None, bool]] = (
            deque()
        )

        # Track full edge constraints, not package identity alone. Different
        # refs for one package must survive until the flattening phase reports
        # the conflict.
        queued_keys: set[str] = set()
        winner_candidates: list[DependencyNode] = []

        # Add root dependencies to queue
        root_deps = root_package.get_apm_dependencies()
        for dep_ref in root_deps:
            if dep_ref.is_parent_repo_inheritance:
                raise ValueError(
                    "git: parent cannot be used in the root apm.yml manifest; "
                    "specify an explicit repository URL. "
                    "The git: parent form is only valid for transitive dependencies."
                )
            if dep_ref.is_marketplace:
                resolved = self._resolve_marketplace_or_record_error(dep_ref, tree, "")
                if resolved is not None:
                    dep_ref = resolved
                else:
                    continue
            dep_ref = self.replacement_index.bind(
                dep_ref,
                consumer_root=consumer_root,
                modules_dir=modules_dir,
                parent=None,
                is_dev=False,
            )
            self._record_edge_selection(dep_ref, None)
            processing_queue.append((dep_ref, 1, None, False))
            queued_keys.add(dep_ref.get_resolution_key())

        # Add root devDependencies to queue (marked is_dev=True)
        root_dev_deps = root_package.get_dev_apm_dependencies()
        for dep_ref in root_dev_deps:
            if dep_ref.is_parent_repo_inheritance:
                raise ValueError(
                    "git: parent cannot be used in the root apm.yml manifest; "
                    "specify an explicit repository URL. "
                    "The git: parent form is only valid for transitive dependencies."
                )
            if dep_ref.is_marketplace:
                resolved = self._resolve_marketplace_or_record_error(dep_ref, tree, "")
                if resolved is not None:
                    dep_ref = resolved
                else:
                    continue
            dep_ref = self.replacement_index.bind(
                dep_ref,
                consumer_root=consumer_root,
                modules_dir=modules_dir,
                parent=None,
                is_dev=True,
            )
            # Record before the prod-wins skip: a dev edge still selects skills.
            self._record_edge_selection(dep_ref, None)
            key = dep_ref.get_resolution_key()
            if key not in queued_keys:
                processing_queue.append((dep_ref, 1, None, True))
                queued_keys.add(key)
            # If already queued as prod, prod wins — skip

        root_local_dirs = collect_root_local_dirs(
            [item[0] for item in processing_queue], consumer_root
        )
        if self._reject_nested_root_declarations(
            tree, [item[0] for item in processing_queue], modules_dir
        ):
            # Structural manifest error: report it before fetching anything, even
            # if other root declarations would also fail during the walk.
            return tree
        # #3696: distinct packages that share one host-blind directory are
        # rejected before their directory is fetched or staged. Each level
        # claims only selected nodes, so a discarded duplicate declaration's
        # alias never claims a directory.
        slots = MaterializationSlots(modules_dir)

        # Process dependencies breadth-first with level-batched parallelism.
        #
        # Parallel BFS is the CENTRAL resolution strategy (uv-inspired).
        # Each level fans out potentially I/O-bound
        # ``_try_load_dependency_package`` calls across a bounded worker
        # pool. All tree mutations -- ``tree.add_node``,
        # ``parent_node.children.append``, ``processing_queue.append``,
        # ``queued_keys`` writes -- still happen on the main thread, in
        # deterministic submission order, so parallelism never affects
        # the resolved tree shape.
        #
        # The ``max_parallel == 1`` branch exists SOLELY as a parity-
        # testing escape hatch (verifies sequential-identical output);
        # it is not a user-facing toggle.
        while processing_queue:
            # --- Drain one level ---
            current_depth = processing_queue[0][1]
            level_items: list[tuple[DependencyReference, int, DependencyNode | None, bool]] = []
            while processing_queue and processing_queue[0][1] == current_depth:
                level_items.append(processing_queue.popleft())

            # --- Phase A (main thread): dedup + node creation ---
            # Each work_item is (node, dep_ref, parent_node, is_dev)
            # and represents a NEW node that needs its package loaded.
            # Items that hit the existing-node fast-path or exceed
            # ``max_depth`` are resolved here and never reach the worker
            # pool.
            work_items: list[
                tuple[DependencyNode, DependencyReference, DependencyNode | None, bool]
            ]
            work_items = []
            scheduled_nodes: set[str] = set()
            for dep_ref, depth, parent_node, is_dev in level_items:
                # Remove from queued set since we're now processing this dependency
                queued_keys.discard(dep_ref.get_resolution_key())

                # Check if we already processed this dependency at this level or higher
                existing_node = tree.nodes.get(dep_ref.get_resolution_key())
                if existing_node and existing_node.depth <= depth:
                    # Prod wins over dev: if existing was dev and this is prod, promote it
                    if existing_node.is_dev and not is_dev:
                        existing_node.is_dev = False
                    # Already processed no deeper: link it under this parent, if any
                    if parent_node and all(
                        child is not existing_node for child in parent_node.children
                    ):
                        parent_node.children.append(existing_node)
                    if (
                        self._update_keys is not None
                        and dep_ref.get_unique_key() in self._update_keys
                        and dep_ref.get_unique_key() not in self._scoped_rechecked
                        and existing_node.get_id() not in scheduled_nodes
                    ):
                        # Recheck the node at its own anchor, not this edge's (#4731).
                        work_items.append(
                            (
                                existing_node,
                                existing_node.dependency_ref,
                                existing_node.parent,
                                is_dev,
                            )
                        )
                        scheduled_nodes.add(existing_node.get_id())
                    continue

                # Past max_depth fails naming the chain (req-rs-006, #4277) unless a node
                # sits no deeper: the same key (reused above) or the same package under
                # another ref (#4968; still walked, so its ref reaches conflict selection).
                if depth > self.max_depth and not self._resolved_no_deeper(tree, dep_ref, depth):
                    chain = self._depth_limit_chain(dep_ref, parent_node)
                    self.depth_limit_chains.append(chain)
                    tree.resolution_errors.append(
                        f"Dependency depth limit ({self.max_depth}) exceeded: {chain}"
                    )
                    continue

                # Create a node for this dependency around a placeholder package
                placeholder_package = APMPackage(
                    name=dep_ref.get_display_name(), version="unknown", source=dep_ref.repo_url
                )

                node = DependencyNode(
                    package=placeholder_package,
                    dependency_ref=dep_ref,
                    depth=depth,
                    parent=parent_node,
                    is_dev=is_dev,
                )

                # Add to tree
                tree.add_node(node)

                # Create parent-child relationship
                if parent_node:
                    parent_node.children.append(node)

                work_items.append((node, dep_ref, parent_node, is_dev))
                scheduled_nodes.add(node.get_id())

            winner_candidates.extend(item[0] for item in work_items)
            for node, _, _, _ in work_items:
                try:
                    requirements.add(node)
                except ImmutableRequirementError as exc:
                    tree.resolution_errors.append(str(exc))
                    return tree
            _, winner_ids = _select_dependency_winners(winner_candidates)
            work_items = [
                item
                for item in work_items
                if winner_ids[item[1].get_unique_key()] == item[0].get_id()
            ]
            if self._reject_shared_slots(tree, slots, ((item[1], item[2]) for item in work_items)):
                return tree

            # --- Phase B (workers): load packages ---
            if not work_items:
                results: list[
                    tuple[
                        tuple[DependencyNode, DependencyReference, DependencyNode | None, bool],
                        APMPackage | None,
                        Exception | None,
                    ]
                ] = []
            elif self._max_parallel == 1 or len(work_items) == 1:
                # Parity-testing path: byte-identical to legacy sequential
                # output so ``APM_RESOLVE_PARALLEL=1`` can be used to
                # diff-debug ordering issues.  NOT a feature flag.
                results = [self._load_work_item(it) for it in work_items]
            else:
                workers = min(self._max_parallel, len(work_items))
                with ThreadPoolExecutor(
                    max_workers=workers, thread_name_prefix="apm-resolve"
                ) as executor:
                    # ``executor.map`` preserves submission order, which
                    # keeps next-level enqueuing deterministic regardless
                    # of which worker finishes first.
                    results = list(executor.map(self._load_work_item, work_items))

            # --- Phase C (main thread): integrate results, enqueue sub-deps ---
            for (node, dep_ref, _parent_node, is_dev), loaded_package, exc in results:
                if dep_ref.replacement is not None and loaded_package is None:
                    detail = str(exc) if exc is not None else "selected source could not be loaded"
                    message = f"Cannot load replacement for {dep_ref.get_unique_key()}: {detail}"
                    tree.resolution_errors.append(message)
                    tree.replacement_load_errors[dep_ref.get_unique_key()] = message
                    continue
                if self._read_only and (exc is not None or loaded_package is None):
                    tree.resolution_errors.append(
                        f"{dep_ref.to_display_reference()}: "
                        f"{exc or 'package metadata is not available locally'}"
                    )
                    continue
                if self._preview and (exc is not None or loaded_package is None):
                    tree.unavailable_subtrees.append(
                        f"{dep_ref.to_display_reference()}: "
                        f"{exc or 'package metadata is not available'}"
                    )
                if exc is not None:
                    if isinstance(exc, MarketplaceManifestMaterializationError):
                        message = f"Marketplace package materialization failed: {exc}"
                        _logger.warning(message)
                        tree.resolution_errors.append(message)
                    elif isinstance(exc, DownloadedPackageError):
                        tree.resolution_errors.append(str(exc))
                    elif isinstance(exc, ValueError):
                        _logger.warning(
                            "Invalid transitive apm.yml for %s: %s",
                            dep_ref.get_display_name(),
                            exc,
                        )
                    else:
                        _logger.debug(
                            "Could not load transitive apm.yml for %s: %s",
                            dep_ref.get_display_name(),
                            exc,
                        )
                    continue
                if loaded_package:
                    # Update the node with the actual loaded package
                    node.package = loaded_package

                    # Get sub-dependencies and add them to the processing queue
                    # Transitive deps inherit is_dev from parent. Iteration
                    # order matches the manifest's declaration order, which
                    # ``loaded_package.get_apm_dependencies()`` preserves.
                    sub_dependencies = loaded_package.get_apm_dependencies()
                    for sub_dep in sub_dependencies:
                        if sub_dep.is_parent_repo_inheritance:
                            sub_dep = self.expand_parent_repo_decl(node.dependency_ref, sub_dep)
                        sub_dep = self._expand_or_reject_remote_parent_local_path(
                            node.dependency_ref,
                            node.package,
                            sub_dep,
                        )
                        if sub_dep is None:
                            if self._read_only:
                                tree.resolution_errors.append(
                                    f"Unverifiable dependency of {node.dependency_ref.to_display_reference()}"
                                )
                            continue
                        if (
                            sub_dep.is_local
                            and sub_dep.local_path
                            and node.package.source_path is not None
                        ):
                            local_path = Path(sub_dep.local_path).expanduser()
                            anchored = (
                                local_path.resolve()
                                if local_path.is_absolute()
                                else (node.package.source_path / local_path).resolve()
                            )
                            sub_dep = transitive_local_identity(
                                sub_dep,
                                declaring_parent=node.get_id(),
                                anchored=anchored,
                                root=root_package.source_path,
                                root_local_dirs=root_local_dirs,
                            )
                            ancestor: DependencyNode | None = node
                            while ancestor is not None:
                                if (
                                    ancestor.dependency_ref.get_cycle_key()
                                    == sub_dep.get_cycle_key()
                                ):
                                    if all(child is not ancestor for child in node.children):
                                        node.children.append(ancestor)
                                    sub_dep = None
                                    break
                                ancestor = ancestor.parent
                            if sub_dep is None:
                                continue
                        if sub_dep.is_marketplace:
                            resolved = self._resolve_marketplace_or_record_error(
                                sub_dep,
                                tree,
                                f"required by {node.dependency_ref.repo_url}",
                                required_by=node.dependency_ref.repo_url,
                            )
                            if resolved is not None:
                                sub_dep = resolved
                            else:
                                continue
                        sub_dep = self.replacement_index.bind(
                            sub_dep,
                            consumer_root=consumer_root,
                            modules_dir=modules_dir,
                            parent=node.dependency_ref.get_unique_key(),
                            is_dev=is_dev,
                        )
                        # Record before the queued_keys dedup drops this edge.
                        self._record_edge_selection(sub_dep, node)
                        # Avoid infinite recursion by checking if we're already processing this dep
                        # Use O(1) set lookup instead of O(n) list comprehension
                        if (
                            self._update_keys is not None
                            and node.dependency_ref.get_unique_key() in self._update_keys
                        ):
                            self._update_keys.add(sub_dep.get_unique_key())
                        queue_key = sub_dep.get_resolution_key()
                        if sub_dep.replacement is not None or queue_key not in queued_keys:
                            processing_queue.append((sub_dep, node.depth + 1, node, is_dev))
                            queued_keys.add(queue_key)

        self._propagate_production(tree)
        self._apply_edge_selections(tree)
        return tree

    def _propagate_production(self, tree: DependencyTree) -> None:
        """Mark every node a production node declares production (prod wins over dev).

        Follows materialized children and every recorded declaring edge, so a
        node first loaded as dev (a root devDependency a production sibling also
        declares) promotes its whole subtree, including children whose edges the
        queue dedup dropped, independent of declaration order (#4731).
        """
        declared: dict[int, list[str]] = {}
        for key, parents in self._edge_parents.items():
            for parent in parents:
                declared.setdefault(id(parent), []).append(key)
        by_key: dict[str, list[DependencyNode]] = {}
        for node in tree.nodes.values():
            by_key.setdefault(node.dependency_ref.get_unique_key(), []).append(node)
        pending = [node for node in tree.nodes.values() if not node.is_dev]
        while pending:
            node = pending.pop()
            declared_children = (
                c for key in declared.get(id(node), ()) for c in by_key.get(key, ())
            )
            for child in [*node.children, *declared_children]:
                if child.is_dev:
                    child.is_dev = False
                    pending.append(child)

    @staticmethod
    def _reject_nested_root_declarations(
        tree: DependencyTree,
        root_refs: list[DependencyReference],
        modules_dir: Path,
    ) -> bool:
        """Record root declarations whose package directories nest (#3699)."""
        nested = nested_materialization_pairs(root_refs, modules_dir)
        for outer, inner in nested:
            tree.add_declaration_error(
                f"{outer.get_identity()} and its subdirectory package {inner.get_identity()} "
                "cannot both be declared in apm.yml: the subdirectory package would be "
                "installed inside the repository package. Keep only one of them."
            )
        return bool(nested)

    @staticmethod
    def _reject_shared_slots(
        tree: DependencyTree,
        slots: MaterializationSlots,
        claims: Iterable[tuple[DependencyReference, DependencyNode | None]],
    ) -> bool:
        """Claim each package directory; record the first shared-directory collision."""
        for dep_ref, parent_node in claims:
            parent = parent_node.dependency_ref if parent_node is not None else None
            collision = slots.claim(dep_ref, parent)
            if collision is not None:
                tree.add_declaration_error(collision)
                return True
        return False

    def _record_edge_selection(
        self, dep_ref: DependencyReference, parent_node: DependencyNode | None
    ) -> None:
        """Record one declaring edge's selection for the selection merge."""
        chain: list[str] = []
        ancestor = parent_node
        while ancestor is not None:
            chain.append(ancestor.get_display_name())
            ancestor = ancestor.parent
        key = dep_ref.get_unique_key()
        self._edge_selections.setdefault(key, []).append(
            EdgeSelection.from_dependency(dep_ref, reversed(chain))
        )
        if parent_node is not None:
            self._edge_parents.setdefault(key, []).append(parent_node)
            self._edge_refs.setdefault((key, id(parent_node)), dep_ref)

    def _select_nearest_parent(
        self, node: DependencyNode, declaring_parents: Iterable[DependencyNode]
    ) -> None:
        """Make the recorded parent the nearest declaring parent, ties by lowest key.

        Equal-depth parents otherwise win by manifest order, which would make
        ``resolved_by`` (and so the lockfile bytes) depend on declaration order.
        A local node takes that parent's own declaration too (#5386).
        """
        if node.parent is None:
            return
        nearest = [parent for parent in declaring_parents if parent.depth == node.depth - 1]
        if not nearest:
            return
        chosen = min(
            nearest,
            key=lambda parent: (parent.dependency_ref.get_unique_key(), parent.get_id()),
        )
        edge = self._edge_refs.get((node.dependency_ref.get_unique_key(), id(chosen)))
        if edge is not None:
            node.dependency_ref = with_declaring_edge(node.dependency_ref, edge)
        if chosen is node.parent:
            return
        node.parent = chosen
        if all(child is not node for child in chosen.children):
            chosen.children.append(node)

    def _apply_edge_selections(self, tree: DependencyTree) -> None:
        """Give every node the merged selection of all edges that declared it.

        Identity, ref, transport hints and the materialized alias stay as the
        first (shallowest, then declared) edge set them; only the per-edge
        selection fields change.
        """
        warned: set[str] = set()
        for node in tree.nodes.values():
            dep_ref = node.dependency_ref
            key = dep_ref.get_unique_key()
            edges = self._edge_selections.get(key)
            if not edges:
                continue
            selection = merge_edge_selections(edges)
            node.dependency_ref = _with_node_selection(dep_ref, selection)
            self._select_nearest_parent(node, self._edge_parents.get(key, ()))
            if selection.divergent_aliases and key not in warned:
                warned.add(key)
                tree.resolution_warnings.append(_alias_divergence_warning(dep_ref, selection))

    def detect_circular_dependencies(self, tree: DependencyTree) -> list[CircularRef]:
        """
        Detect and report circular dependency chains.

        Uses depth-first search to detect cycles in the dependency graph.
        A cycle is detected when we encounter the same repository URL
        in our current traversal path.

        Args:
            tree: The dependency tree to analyze

        Returns:
            List[CircularRef]: List of detected circular dependencies
        """
        circular_deps = []
        visited: set[str] = set()
        current_path: list[str] = []
        current_path_set: set[str] = set()  # O(1) membership test (#171)

        def dfs_detect_cycles(node: DependencyNode) -> None:
            """Recursive DFS function to detect cycles."""
            node_id = node.get_id()
            # Use unique key (includes subdirectory path) to distinguish monorepo packages
            # e.g., vineethsoma/agent-packages/agents/X vs vineethsoma/agent-packages/skills/Y
            unique_key = node.dependency_ref.get_cycle_key()

            # Check if this unique key is already in our current path (cycle detected)
            if unique_key in current_path_set:
                # Found a cycle - create the cycle path
                cycle_start_index = current_path.index(unique_key)
                cycle_path = current_path[cycle_start_index:] + [unique_key]  # noqa: RUF005

                circular_ref = CircularRef(cycle_path=cycle_path, detected_at_depth=node.depth)
                circular_deps.append(circular_ref)
                return

            # Mark current node as visited and add unique key to path
            visited.add(node_id)
            current_path.append(unique_key)
            current_path_set.add(unique_key)

            # Check all children
            for child in node.children:
                child_id = child.get_id()

                # Only recurse if we haven't processed this subtree completely
                if (
                    child_id not in visited
                    or child.dependency_ref.get_cycle_key() in current_path_set
                ):
                    dfs_detect_cycles(child)

            # Remove from path when backtracking (but keep in visited)
            current_path_set.discard(current_path.pop())

        # Start DFS from all root level dependencies (depth 1)
        root_deps = tree.get_nodes_at_depth(1)
        for root_dep in root_deps:
            if root_dep.get_id() not in visited:
                current_path = []  # Reset path for each root
                current_path_set = set()
                dfs_detect_cycles(root_dep)

        return circular_deps

    def flatten_dependencies(self, tree: DependencyTree) -> FlatDependencyMap:
        """
        Flatten tree to avoid duplicate installations (NPM hoisting).

        Implements "first wins" conflict resolution strategy where the first
        declared dependency takes precedence over later conflicting dependencies.

        Args:
            tree: The dependency tree to flatten

        Returns:
            FlatDependencyMap: Flattened dependencies ready for installation
        """
        flat_map = FlatDependencyMap()
        ordered, winner_ids = _select_dependency_winners(
            node for node in tree.nodes.values() if node.depth >= 1
        )
        for node in ordered:
            unique_key = node.dependency_ref.get_unique_key()
            flat_map.add_dependency(
                node.dependency_ref,
                is_conflict=winner_ids[unique_key] != node.get_id(),
            )

        return flat_map

    def _validate_dependency_reference(self, dep_ref: DependencyReference) -> bool:
        """
        Validate that a dependency reference is well-formed.

        Args:
            dep_ref: The dependency reference to validate

        Returns:
            bool: True if valid, False otherwise
        """
        if not dep_ref.repo_url:
            return False

        # Basic validation - in real implementation would be more thorough
        if "/" not in dep_ref.repo_url:  # noqa: SIM103
            return False

        return True

    def _load_work_item(self, item):
        """Worker payload for the level-batched parallel BFS.

        Pure I/O wrapper around ``_try_load_dependency_package`` that
        returns ``(item, loaded_package_or_None, exception_or_None)``
        so the main thread can keep all tree mutations on its side.
        Defined as a method (not a closure inside the BFS while-loop)
        to satisfy ruff B023 -- no risk of accidentally capturing a
        loop-iteration variable.
        """
        node, dep_ref, parent_node, _is_dev = item
        if self._update_keys is not None and dep_ref.get_unique_key() in self._update_keys:
            with self._download_lock:
                self._scoped_rechecked.add(dep_ref.get_unique_key())
        # Compute breadcrumb chain from this node's ancestry so download
        # errors can report "root > mid > failing-dep" context.
        parent_chain = node.get_ancestor_chain()
        try:
            if dep_ref.is_local and self._apm_modules_dir is not None:
                install_path = dep_ref.get_install_path(self._apm_modules_dir)
                with self._download_lock:
                    materialization_lock = self._local_materialization_locks.setdefault(
                        install_path,
                        threading.Lock(),
                    )
                with materialization_lock:
                    loaded = self._try_load_dependency_package(
                        dep_ref,
                        parent_chain=parent_chain,
                        parent_pkg=parent_node.package if parent_node else None,
                    )
            else:
                loaded = self._try_load_dependency_package(
                    dep_ref,
                    parent_chain=parent_chain,
                    parent_pkg=parent_node.package if parent_node else None,
                )
            return (item, loaded, None)
        except (ValueError, FileNotFoundError) as exc:
            return (item, None, exc)
        except OSError as exc:
            if self._read_only:
                return (item, None, exc)
            raise

    def _should_force_recheck(self, dep_ref: DependencyReference) -> bool:
        """Delegate existing-path recheck policy to the canonical drift owner."""
        from apm_cli.drift import should_force_ref_recheck

        locked_dep = (
            self._existing_lockfile.get_dependency(dep_ref.get_unique_key())
            if self._existing_lockfile is not None
            else None
        )
        return should_force_ref_recheck(
            dep_ref,
            locked_dep,
            update_refs=self._update_refs,
            update_keys=self._update_keys,
            package_path=(
                dep_ref.get_install_path(self._apm_modules_dir)
                if self._apm_modules_dir is not None
                else None
            ),
        )

    def _try_load_dependency_package(
        self,
        dep_ref: DependencyReference,
        parent_chain: str = "",
        parent_pkg: APMPackage | None = None,
    ) -> APMPackage | None:
        """
        Try to load a dependency package from apm_modules/.

        This method scans apm_modules/ to find installed packages and loads their
        apm.yml to enable transitive dependency resolution. If a package is not
        installed and a download_callback is available, it will attempt to fetch
        the package first.

        Args:
            dep_ref: Reference to the dependency to load.
            parent_chain: Human-readable breadcrumb of the dependency path
                that led here (e.g. "root-pkg > mid-pkg").  Forwarded to the
                download callback for contextual error messages.
            parent_pkg: APMPackage that declared *dep_ref*, or None if this is
                a direct dep from the root project. Used to anchor relative
                ``local_path`` resolution to the declaring package's source
                directory (#857). Remote same-repo local paths are expanded
                before this loader; any remaining remote local path is rejected
                fail-closed (#940 / #1571).

        Returns:
            APMPackage: Loaded package if found, None otherwise

        Raises:
            ValueError: If package exists but has invalid format
            FileNotFoundError: If package cannot be found
        """
        if self._apm_modules_dir is None:
            return None

        # Fallback fail-closed guard for local_path deps declared by remote
        # packages. Normal BFS expansion converts eligible same-repo relative
        # paths into remote virtual deps before they reach this loader. Anything
        # still local here lacks trusted parent repo coordinates, so refuse it
        # before the download callback can copy from the consumer filesystem.
        if (
            dep_ref.replacement is None
            and dep_ref.is_local
            and dep_ref.local_path
            and self._is_remote_parent(parent_pkg)
        ):
            self._reject_remote_parent_local_path(
                dep_ref,
                parent_pkg,
                "remote package path could not be tied to its authenticated repo root.",
            )
            return None

        # Get the canonical install path for this dependency
        install_path = dep_ref.get_install_path(self._apm_modules_dir)

        if self._read_only:
            if dep_ref.is_local and dep_ref.local_path:
                if self._project_root is None:
                    raise ValueError("Read-only resolution requires a project root")
                if dep_ref.replacement is not None:
                    install_path = self._compute_dep_source_path(dep_ref, parent_pkg, install_path)
                else:
                    base = self._effective_base_dir(parent_pkg, self._project_root)
                    install_path = (base / Path(dep_ref.local_path).expanduser()).resolve()
            elif self._update_refs or self._should_force_recheck(dep_ref):
                raise ValueError("Package metadata requires fetching; preview is offline")
            if not install_path.exists():
                return None

        downloaded_candidate: Path | None = None
        had_existing_install = install_path.exists()

        # If package doesn't exist locally, try to download it. Also fall
        # through for a forced semver re-check (see _should_force_recheck).
        if dep_ref.is_local or not install_path.exists() or self._should_force_recheck(dep_ref):
            if self._download_callback is not None:
                unique_key = self._download_dedup_key(dep_ref, parent_pkg)
                # Avoid re-downloading the same logical (dep_ref, anchor) pair
                # in a single resolution. The anchor is part of the key so that
                # two parents with different ``source_path`` values can each
                # fetch / copy the same dep into their own slot if needed.
                #
                # F7 (#1116): atomically check-and-reserve under
                # ``_download_lock`` so two BFS workers racing on the
                # same logical dep can't both pass the gate and double-
                # fetch. The reserving worker fetches; later workers
                # observe the reservation and skip the callback.
                with self._download_lock:
                    should_fetch = unique_key not in self._downloaded_packages
                    if should_fetch:
                        # Reserve the slot before releasing the lock so a
                        # concurrent worker can't slip past the gate while
                        # we're inside the (potentially slow) callback.
                        self._downloaded_packages.add(unique_key)
                if should_fetch:
                    try:
                        if self._callback_accepts_parent_pkg:
                            downloaded_path = self._download_callback(
                                dep_ref,
                                self._apm_modules_dir,
                                parent_chain,
                                parent_pkg=parent_pkg,
                            )
                        else:
                            downloaded_path = self._download_callback(
                                dep_ref, self._apm_modules_dir, parent_chain
                            )
                        if downloaded_path and downloaded_path.exists():
                            original_install_path = install_path
                            install_path = downloaded_path
                            if downloaded_path != original_install_path:
                                downloaded_candidate = downloaded_path
                        else:
                            # Fetch produced no usable path -- release the
                            # reservation so a subsequent retry (or a
                            # different anchor with the same key) can try
                            # again rather than silently treating either the
                            # old materialization or the dep as downloaded.
                            with self._download_lock:
                                self._downloaded_packages.discard(unique_key)
                            return None
                    except MarketplaceManifestMaterializationError:
                        with self._download_lock:
                            self._downloaded_packages.discard(unique_key)
                        raise
                    except Exception as exc:
                        # Surface the failure at default verbosity AND log a
                        # traceback at debug. Previously this branch silently
                        # swallowed any error, masking transient network /
                        # auth failures behind a generic "package not found"
                        # downstream message (#940 F2 + SR5).
                        with self._download_lock:
                            self._downloaded_packages.discard(unique_key)
                        try:
                            from apm_cli.utils.console import _rich_warning

                            _rich_warning(
                                f"Failed to download dependency "
                                f"'{dep_ref.get_display_name()}': {exc}"
                            )
                        except Exception:
                            _logger.debug("Could not emit download-failure warning", exc_info=True)
                        _logger.debug(
                            "Download callback raised for %s",
                            dep_ref.get_display_name(),
                            exc_info=True,
                        )
                        return None

            # Still doesn't exist after download attempt
            if not install_path.exists():
                return None

        if (
            self._cache_validation_callback is not None
            and self._download_dedup_key(dep_ref, parent_pkg) not in self._downloaded_packages
        ):
            self._cache_validation_callback(install_path, dep_ref.get_unique_key())

        if not self._read_only:
            materialize_marketplace_manifest(dep_ref, install_path)

        # Native Agent Plugins must retain their projected compatibility package
        # so recursive resolution can see APM-only dependencies without requiring
        # or synthesizing an apm.yml compatibility manifest.
        dep_source_path = (
            install_path.resolve()
            if self._read_only and dep_ref.is_local
            else self._compute_dep_source_path(dep_ref, parent_pkg, install_path)
        )
        native_detection = route_agent_plugin_package(install_path)
        if native_detection is not None:
            validation = validate_apm_package(
                install_path,
                source_path=dep_source_path,
                agent_plugin_detection=native_detection,
                read_only=self._read_only,
                create_config=self._create_config,
            )
            if not validation.is_valid:
                self._raise_downloaded_package_error(
                    downloaded_candidate,
                    dep_ref,
                    "; ".join(validation.errors),
                    had_existing_install,
                )
            if validation.package is None:
                self._raise_downloaded_package_error(
                    downloaded_candidate,
                    dep_ref,
                    f"Agent Plugin validation produced no package metadata: {install_path}",
                    had_existing_install,
                )
            if not validation.package.source:
                validation.package.source = dep_ref.repo_url
            return self._activate_validated_package(
                validation.package,
                downloaded_candidate,
                had_existing_install,
            )

        package_type, _ = detect_package_type(install_path)
        if package_type in (
            PackageType.MARKETPLACE_PLUGIN,
            PackageType.SKILL_BUNDLE,
            PackageType.HOOK_PACKAGE,
        ):
            validation = validate_apm_package(
                install_path,
                source_path=dep_source_path,
                read_only=self._read_only,
                create_config=self._create_config,
            )
            if not validation.is_valid:
                self._raise_downloaded_package_error(
                    downloaded_candidate,
                    dep_ref,
                    "; ".join(validation.errors),
                    had_existing_install,
                )
            if validation.package is None:
                self._raise_downloaded_package_error(
                    downloaded_candidate,
                    dep_ref,
                    f"Package validation produced no package metadata: {install_path}",
                    had_existing_install,
                )
            if not validation.package.source:
                validation.package.source = dep_ref.repo_url
            return self._activate_validated_package(
                validation.package,
                downloaded_candidate,
                had_existing_install,
            )

        # Look for apm.yml in the install path
        apm_yml_path = manifest_file(install_path)
        if not apm_yml_path.exists():
            # Package exists but has no apm.yml (e.g., Claude Skill)
            # Check for SKILL.md and create minimal package
            skill_md_path = install_path / "SKILL.md"
            if skill_md_path.exists():
                # Claude Skill without apm.yml - no transitive deps
                package = APMPackage(
                    name=dep_ref.get_display_name(),
                    version="1.0.0",
                    source=dep_ref.repo_url,
                    package_path=install_path,
                    source_path=self._compute_dep_source_path(dep_ref, parent_pkg, install_path),
                )
                return self._activate_validated_package(
                    package,
                    downloaded_candidate,
                    had_existing_install,
                )
            # No manifest found
            self._raise_downloaded_package_error(
                downloaded_candidate,
                dep_ref,
                f"Downloaded package has no apm.yml or SKILL.md: {install_path}",
                had_existing_install,
            )

        # Load and return the package, anchoring relative ``local_path`` deps
        # on the declaring package's source dir (#857). For local deps this
        # is the *original* user source; for remote deps it is the clone in
        # apm_modules.
        try:
            package = APMPackage.from_apm_yml(
                apm_yml_path,
                source_path=dep_source_path,
                create_config=self._create_config,
            )
        except FileNotFoundError:
            self._raise_downloaded_package_error(
                downloaded_candidate,
                dep_ref,
                f"Downloaded package manifest disappeared: {apm_yml_path}",
                had_existing_install,
            )
        except ValueError as exc:
            self._raise_downloaded_package_error(
                downloaded_candidate,
                dep_ref,
                str(exc),
                had_existing_install,
            )
        except TargetResolutionError as exc:
            # The rendered "Fix with one of" commands are for the consumer's own
            # manifest; for a dependency keep only what is wrong with it.
            summary = str(exc).split("\n\nFix with one of:", maxsplit=1)[0]
            parts = [line.strip().rstrip(".") for line in summary.splitlines() if line.strip()]
            self._raise_downloaded_package_error(
                downloaded_candidate,
                dep_ref,
                f"{apm_yml_path}: " + ". ".join(parts),
                had_existing_install,
            )
        # Ensure source is set for tracking. TODO(#940): the cache key
        # already considers source_path; this post-construction mutation
        # of ``source`` (a separate field) is safe today but has the same
        # shape as the bug we just fixed -- review when refactoring.
        if not package.source:
            package.source = dep_ref.repo_url
        return self._activate_validated_package(
            package,
            downloaded_candidate,
            had_existing_install,
        )

    def _activate_validated_package(
        self,
        package: APMPackage,
        downloaded_candidate: Path | None,
        had_existing_install: bool,
    ) -> APMPackage:
        """Publish one validated candidate and remap its package paths."""
        if package.marketplaces is not None:
            # Only the root project's map counts; a package can never add a
            # marketplace (#3006, #2903). Refused before activation.
            from apm_cli.marketplace.user_manifest import dependency_marketplaces_error

            raise DownloadedPackageError(dependency_marketplaces_error(package.name))
        from apm_cli.utils.realpath_win import register_held_root

        if downloaded_candidate is None or self._activation_callback is None:
            # Already at its final placement (existing install or direct download).
            if package.package_path is not None:
                register_held_root(package.package_path, self._apm_modules_dir)
            return package
        try:
            live_path = self._activation_callback(downloaded_candidate)
        except Exception as exc:
            raise DownloadedPackageError(
                f"Failed to activate downloaded dependency "
                f"'{package.name}': {exc}. "
                "The candidate was not activated; inspect the failure and any "
                "reported recovery paths before retrying."
            ) from exc
        if not live_path.exists():
            raise FileNotFoundError(f"Validated package was not published: {live_path}")
        # Placed for good: path resolution may now hold it (Windows) for this command.
        register_held_root(live_path, self._apm_modules_dir)
        package.package_path = self._remap_candidate_path(
            package.package_path,
            downloaded_candidate,
            live_path,
        )
        package.source_path = self._remap_candidate_path(
            package.source_path,
            downloaded_candidate,
            live_path,
        )
        self._remap_dependency_configs(package, downloaded_candidate, live_path)
        return package

    @staticmethod
    def _remap_dependency_configs(
        package: APMPackage,
        candidate: Path,
        live_path: Path,
    ) -> None:
        """Repoint plugin-root paths that were substituted while staged."""
        from apm_cli.deps.plugin_parser import rebase_plugin_root_paths

        for group in (package.dependencies, package.dev_dependencies):
            for entries in (group or {}).values():
                for entry in entries or ():
                    if not is_dataclass(entry) or isinstance(entry, type):
                        continue
                    for spec in fields(entry):
                        current = getattr(entry, spec.name, None)
                        rebased = rebase_plugin_root_paths(current, candidate, live_path)
                        if rebased != current:
                            setattr(entry, spec.name, rebased)

    @staticmethod
    def _raise_downloaded_package_error(
        downloaded_candidate: Path | None,
        dep_ref: DependencyReference,
        detail: str,
        had_existing_install: bool,
    ) -> NoReturn:
        """Raise a specific fail-closed error for newly downloaded candidates.

        Paths inside the staged candidate are shown relative to the package,
        so the error names the dependency and its in-package path rather than
        APM's private staging directory.
        """
        if downloaded_candidate is None:
            raise ValueError(detail)
        detail = APMDependencyResolver._package_relative_detail(detail, downloaded_candidate)
        # The hint below carries the one "retry"; drop the manifest owner's own.
        detail = _TRAILING_RETRY.sub("", detail.rstrip()).rstrip(".")
        label = f"'{dep_ref.get_display_name()}'"
        if dep_ref.replacement is not None:
            label += f" (replacement for '{dep_ref.replacement.original.get_display_name()}')"
        raise DownloadedPackageError(
            f"Downloaded dependency {label} is invalid: "
            f"{detail}. "
            f"{APMDependencyResolver._replacement_failure_hint(had_existing_install)}"
        )

    @staticmethod
    def _package_relative_detail(detail: str, candidate: Path) -> str:
        """Rewrite paths under the staged *candidate* as package-relative paths."""
        roots = {str(candidate)}
        with contextlib.suppress(OSError):
            roots.add(str(candidate.resolve()))
        for root in sorted(roots, key=len, reverse=True):
            for separator in {os.sep, "/"}:
                detail = detail.replace(root + separator, "")
            detail = detail.replace(root, "the package root")
        return detail

    @staticmethod
    def _replacement_failure_hint(had_existing_install: bool) -> str:
        """Return recovery guidance accurate for fresh and replacement installs."""
        if had_existing_install:
            return "The existing installation remains active; fix the cause and retry the install."
        return "The downloaded candidate was not activated; fix the cause and retry the install."

    @staticmethod
    def _remap_candidate_path(
        path: Path | None,
        candidate: Path,
        live_path: Path,
    ) -> Path | None:
        """Map a path inside a staged candidate to the published tree."""
        if path is None:
            return None
        try:
            relative = path.relative_to(candidate)
        except ValueError:
            return path
        return live_path / relative

    @staticmethod
    def _is_remote_parent(parent_pkg: APMPackage | None) -> bool:
        """Return True if *parent_pkg* is a REMOTE package (i.e. fetched via
        git URL or pinned by ref/path).

        Used to gate ``local_path`` deps: only the root project and other
        local packages may legitimately declare them. Remote packages
        declaring a local_path is a path-confusion vector.

        SECURITY NOTE: this is a heuristic on the ``source`` field. A
        sufficiently adversarial remote could spoof a local-looking source.
        The downstream containment check via ``ensure_path_within`` is the
        actual security boundary; this gate just produces the user-facing
        error early.
        """
        if parent_pkg is None or not parent_pkg.source:
            return False
        src = str(parent_pkg.source)
        # Local deps get ``source = "_local/<name>"`` (see DependencyReference
        # construction for is_local=True). Treat that prefix as definitively
        # local even though it contains a slash.
        if src.startswith("_local/"):
            return False
        # Remote sources look like URLs or owner/repo refs. Local sources
        # are filesystem paths the user typed in their apm.yml.
        return (
            src.startswith(("http://", "https://", "git@", "ssh://", "git+"))
            or "://" in src
            or (src.count("/") >= 1 and not src.startswith((".", "/", "~")))
        )

    @staticmethod
    def _compute_dep_source_path(
        dep_ref: DependencyReference,
        parent_pkg: APMPackage | None,
        install_path: Path,
    ) -> Path:
        """Return the source-path anchor for a dependency.

        For LOCAL deps we return the *original* user source directory so that
        transitive ``../sibling`` references inside its apm.yml resolve as a
        developer reading the file expects (#857). For REMOTE deps we return
        the materialized package location; repository-relative expansion derives
        separate source-coordinate anchors.
        """
        from apm_cli.utils.realpath import resolve_path

        if dep_ref.replacement is not None and dep_ref.is_local:
            return dep_ref.replacement.local_source_path()
        if dep_ref.is_local and dep_ref.local_path:
            local = Path(dep_ref.local_path).expanduser()
            if not local.is_absolute() and parent_pkg is not None and parent_pkg.source_path:
                return resolve_path(parent_pkg.source_path / local)
            return resolve_path(local)
        return resolve_path(install_path)

    @staticmethod
    def _download_dedup_key(dep_ref: DependencyReference, parent_pkg: APMPackage | None) -> str:
        """Dedup key for the download cache.

        Includes the parent's source_path so two parents anchoring the same
        local dep at different absolute locations don't collide on the first
        one's resolved path. For non-local deps, the parent anchor doesn't
        affect resolution, so the package identity suffices. Conflicting refs
        are reduced to one winner before worker dispatch.
        """
        base = dep_ref.get_unique_key()
        if (
            dep_ref.replacement is None
            and dep_ref.is_local
            and parent_pkg is not None
            and parent_pkg.source_path
        ):
            return f"{base}@{parent_pkg.source_path}"
        return base

    @staticmethod
    def _effective_base_dir(parent_pkg: APMPackage | None, project_root: Path) -> Path:
        """Return the directory used to anchor relative ``local_path`` deps.

        For direct (root-declared) deps, this is the project root. For
        transitive deps, it is the declaring package's source_path so a
        ``../sibling`` written inside the original package directory means
        what the author meant (#857).
        """
        if parent_pkg is not None and parent_pkg.source_path is not None:
            return parent_pkg.source_path
        return project_root

    def _create_resolution_summary(self, graph: DependencyGraph) -> str:
        """
        Create a human-readable summary of the resolution results.

        Args:
            graph: The resolved dependency graph

        Returns:
            str: Summary string
        """
        summary = graph.get_summary()
        lines = [
            "Dependency Resolution Summary:",
            f"  Root package: {summary['root_package']}",
            f"  Total dependencies: {summary['total_dependencies']}",
            f"  Maximum depth: {summary['max_depth']}",
        ]

        if summary["has_conflicts"]:
            lines.append(f"  Conflicts detected: {summary['conflict_count']}")

        if summary["has_circular_dependencies"]:
            lines.append(f"  Circular dependencies: {summary['circular_count']}")

        if summary["has_errors"]:
            lines.append(f"  Resolution errors: {summary['error_count']}")

        lines.append(f"  Status: {'[+] Valid' if summary['is_valid'] else '[x] Invalid'}")

        return "\n".join(lines)
