"""Transport-plan-driven clone execution.

Drives a :class:`TransportPlan` to completion by executing a sequence
of :class:`TransportAttempt` "commands". Each attempt is a self-contained
recipe (URL scheme, auth scheme, label) that the engine renders into
a concrete URL + git env, hands to the caller-provided ``clone_action``,
and -- on auth/transport failure -- rolls forward to the next attempt
or applies an in-attempt ADO bearer fallback.

Design pattern: **Command** (each TransportAttempt is a command),
chained together with a small **Chain-of-Responsibility** for failure
recovery (per-attempt ADO bearer retry, then plan-level next attempt).

The engine collaborates with the surrounding downloader via a
duck-typed :class:`_DownloaderContext` Protocol so it does not need
to import :class:`GitHubPackageDownloader`. This keeps the engine
unit-testable in isolation and mirrors the existing
``DownloadDelegate`` / ``ArtifactoryOrchestrator`` patterns.
"""

from __future__ import annotations

import os
import re
import subprocess
import time
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Protocol
from urllib.parse import urlsplit

from ..core.auth_chain import AdoAuthChainExhaustedError
from ..core.auth_outcome import (
    RepositoryNotFoundError,
    classify_auth_outcome,
    is_repository_not_found,
)
from ..models.apm_package import DependencyReference
from ..models.dependency.host_virtual import repository_owner
from ..utils.github_host import (
    default_host,
    is_github_hostname,
)
from .bare_cache import build_clone_failure_message
from .git_lazy import git_command_error
from .transport_selection import (
    TransportAttempt,
    TransportPlan,
    fallback_port_warning,
    initial_transport_scheme,
)

if TYPE_CHECKING:
    from git.exc import GitCommandError

    from ..core.auth import AuthResolver


def _retry_sleep(seconds: float) -> None:
    """Wait before retrying a failed Git connection.

    The single retry-wait seam: tests patch this instead of the process-wide
    ``time.sleep``, which would also record sleeps from unrelated threads.
    """
    time.sleep(seconds)


def _is_connect_failure(error: GitCommandError | subprocess.CalledProcessError, url: str) -> bool:
    """Recognize only Git's pre-connection HTTPS failure for this exact remote."""
    remote = urlsplit(url)
    if remote.scheme != "https" or not remote.hostname:
        return False
    stderr = error.stderr
    if isinstance(stderr, bytes):
        stderr = stderr.decode("utf-8", errors="replace")
    if not isinstance(stderr, str):
        return False
    if isinstance(error, git_command_error()):
        if error.status != 128:
            return False
        stderr = stderr.removeprefix("\n  stderr: '").removesuffix("'")
    elif error.returncode != 128:
        return False
    return (
        re.fullmatch(
            r"(?:Cloning into [^\r\n]+\r?\n)?"
            rf"fatal: unable to access '{re.escape(url.rstrip('/'))}/?': "
            rf"Failed to connect to {re.escape(remote.hostname)} port {remote.port or 443}"
            r" after [0-9]+ ms: Couldn't connect to server",
            stderr.strip(),
        )
        is not None
    )


def _debug(msg: str) -> None:
    """Indirect to the downloader's module-level _debug to keep behaviour parity."""
    from .github_downloader import _debug as _gd_debug

    _gd_debug(msg)


def _rich_warning(message: str, *, symbol: str = "warning") -> None:
    """Indirect to ``github_downloader._rich_warning``.

    Routes through the github_downloader module's namespace so that
    existing ``mock.patch('apm_cli.deps.github_downloader._rich_warning')``
    test interception sites still see warning emissions made from this
    extracted module.
    """
    from . import github_downloader as _gd

    _gd._rich_warning(message, symbol=symbol)


class _DownloaderContext(Protocol):
    """The slice of the downloader the clone engine needs."""

    auth_resolver: AuthResolver
    git_env: dict
    has_ado_token: bool

    def _resolve_dep_token(self, dep_ref: DependencyReference | None = ...) -> str | None: ...
    def _resolve_dep_auth_ctx(self, dep_ref: DependencyReference | None = ...): ...
    def _build_noninteractive_git_env(
        self,
        *,
        preserve_config_isolation: bool = ...,
        suppress_credential_helpers: bool = ...,
    ) -> dict: ...
    def _build_repo_url(
        self,
        repo_url_base: str,
        *,
        use_ssh: bool = ...,
        dep_ref: DependencyReference,
    ) -> str: ...
    def _sanitize_git_error(self, error_message: str) -> str: ...


class CloneEngine:
    """Execute a TransportPlan with full fallback semantics.

    Owns:

    * TransportPlan resolution + per-dep transport warnings.
    * Per-attempt URL + env construction.
    * ADO bearer in-attempt retry on PAT 401.
    * Cross-protocol fallback warning on protocol switch.
    * Aggregate error construction on plan exhaustion.
    """

    def __init__(
        self,
        host: _DownloaderContext,
    ) -> None:
        self._host = host

    # The transport selector, protocol pref, allow-fallback flag, and
    # fallback-port-warned dedup set are all read dynamically from the
    # host on each invocation. Snapshotting them at engine-construction
    # time would break tests (and any caller) that mutates these
    # attributes on the downloader after construction.
    @property
    def _transport_selector(self):
        return self._host._transport_selector

    @property
    def _protocol_pref(self):
        return self._host._protocol_pref

    @property
    def _allow_fallback(self) -> bool:
        return self._host._allow_fallback

    @property
    def _fallback_port_warned(self) -> set[tuple]:
        return self._host._fallback_port_warned

    @property
    def _fallback_port_warned_lock(self):
        return self._host._fallback_port_warned_lock

    def execute(
        self,
        repo_url_base: str,
        target_path: Path,
        *,
        dep_ref: DependencyReference | None = None,
        clone_action: Callable[[str, dict[str, str], Path], None],
        verbose_callback=None,
    ) -> None:
        """Run the plan; raise :class:`RuntimeError` if all attempts fail."""
        host = self._host
        last_error: Exception | None = None
        is_ado = bool(dep_ref and dep_ref.is_azure_devops())

        def _clone(url: str, env: dict[str, str], target: Path) -> None:
            """Retry one failed connection without changing transport or credentials."""
            try:
                clone_action(url, env, target)
            except (git_command_error(), subprocess.CalledProcessError) as exc:
                if not _is_connect_failure(exc, url):
                    raise
                _debug("HTTPS connection failed; retrying the same Git action once in 1s")
                # Clone callbacks own partial-target cleanup; fetch callbacks
                # retain the existing bare repository. Never delete here.
                _retry_sleep(1)
                clone_action(url, env, target)

        dep_host = dep_ref.host if dep_ref else None
        is_github = is_github_hostname(dep_host) if dep_host else True
        is_generic = not is_ado and not is_github
        candidate_uses_ssh = initial_transport_scheme(dep_ref, self._protocol_pref) == "ssh"
        rewrite_candidate = (
            host._build_repo_url(
                repo_url_base,
                use_ssh=candidate_uses_ssh,
                dep_ref=dep_ref,
            )
            if dep_ref is not None
            else None
        )

        anonymous_plan = self._transport_selector.select(
            dep_ref=dep_ref,
            cli_pref=self._protocol_pref,
            allow_fallback=self._allow_fallback,
            has_token=False,
            candidate_url=rewrite_candidate,
        )
        public_github_https_first = bool(
            dep_ref is not None
            and not dep_ref.is_insecure
            and anonymous_plan.attempts
            and anonymous_plan.attempts[0].scheme == "https"
            and host.auth_resolver.uses_public_github_anonymous_first(
                dep_host or default_host(),
                port=dep_ref.port,
                host_type=dep_ref.host_type,
            )
            is True
        )

        if public_github_https_first:
            dep_token = None
            has_token = False
            dep_auth_ctx = None
            dep_auth_scheme = "basic"
        else:
            dep_token = host._resolve_dep_token(dep_ref)
            has_token = dep_token is not None
            dep_auth_ctx = host._resolve_dep_auth_ctx(dep_ref)
            dep_auth_scheme = dep_auth_ctx.auth_scheme if dep_auth_ctx else "basic"

        _debug(
            f"_clone_with_fallback: repo={repo_url_base}, is_ado={is_ado}, "
            f"is_generic={is_generic}, has_token={has_token}, "
            f"auth_scheme={dep_auth_scheme}, "
            f"protocol_pref={self._protocol_pref.value}, "
            f"allow_fallback={self._allow_fallback}"
        )

        def _env_for(attempt: TransportAttempt, attempt_url: str) -> dict[str, str]:
            def _without_platform_credentials(env: dict[str, str]) -> dict[str, str]:
                from ..utils.git_env import clear_git_platform_token_env

                clear_git_platform_token_env(env, remove=True)
                return env

            if attempt.use_token:
                if dep_auth_ctx is not None:
                    return host.auth_resolver.git_env_for_remote(
                        dep_auth_ctx,
                        attempt.effective_url or attempt_url,
                    )
                host_kind = host.auth_resolver.classify_host(
                    dep_host or default_host(),
                    port=dep_ref.port if dep_ref is not None else None,
                    host_type=dep_ref.host_type if dep_ref is not None else None,
                ).kind
                return host.auth_resolver._build_git_env(
                    dep_token,
                    host_kind=host_kind,
                    base_env=host.git_env,
                )
            if attempt.scheme == "http":
                return _without_platform_credentials(
                    host._build_noninteractive_git_env(
                        preserve_config_isolation=True,
                        suppress_credential_helpers=True,
                    )
                )
            if is_ado:
                ado_context = dep_auth_ctx or host.auth_resolver.resolve_for_dep(dep_ref)
                return host.auth_resolver.git_env_for_remote(
                    ado_context,
                    attempt.effective_url or attempt_url,
                    base_env=host.git_env,
                )
            if is_generic and dep_ref is not None:
                org = repository_owner(repo_url_base)
                policy_url = attempt.effective_url or attempt_url
                context = host.auth_resolver.resolve_for_remote(
                    dep_host or default_host(),
                    policy_url,
                    org,
                    port=dep_ref.port,
                    host_type=dep_ref.host_type,
                )
                return host.auth_resolver.git_env_for_remote(context, policy_url)
            return _without_platform_credentials(host._build_noninteractive_git_env())

        plan: TransportPlan = (
            anonymous_plan
            if public_github_https_first
            else self._transport_selector.select(
                dep_ref=dep_ref,
                cli_pref=self._protocol_pref,
                allow_fallback=self._allow_fallback,
                has_token=has_token,
                candidate_url=rewrite_candidate,
            )
        )
        _debug(
            "transport plan: "
            f"strict={plan.strict}, "
            f"attempts={[(a.scheme, a.use_token, a.label) for a in plan.attempts]}"
        )

        # Cross-protocol fallback custom-port warning (#786).
        port_warning = fallback_port_warning(dep_ref, plan)
        if port_warning is not None:
            warn_key = (
                dep_host.lower() if dep_host else dep_host,
                repo_url_base,
                dep_ref.port,
            )
            # Guard the check-then-add under the lock so two threads
            # racing on the same warn_key cannot both pass the
            # membership check before either calls add().
            _should_warn = False
            with self._fallback_port_warned_lock:
                if warn_key not in self._fallback_port_warned:
                    self._fallback_port_warned.add(warn_key)
                    _should_warn = True
            if _should_warn:
                _rich_warning(port_warning, symbol="warning")

        def _run_public_github_attempt() -> tuple[str, bool]:
            if dep_ref is None:
                raise RuntimeError("Public GitHub attempt requires a dependency reference")
            winning_url = ""
            winning_token = False

            def _clone_public_github(
                token: str | None,
                git_env: dict[str, str],
            ) -> None:
                nonlocal winning_token, winning_url
                winning_token = token is not None
                winning_url = host._build_repo_url(
                    repo_url_base,
                    use_ssh=False,
                    dep_ref=dep_ref,
                )
                _clone(winning_url, git_env, target_path)

            org = repository_owner(repo_url_base)
            host.auth_resolver.try_with_fallback(
                dep_host or default_host(),
                _clone_public_github,
                org=org,
                port=dep_ref.port,
                path=dep_ref.repo_url,
                host_type=dep_ref.host_type,
                unauth_first=True,
                base_env=host.git_env,
                verbose_callback=verbose_callback,
            )
            return winning_url, winning_token

        prev_label: str | None = None
        prev_scheme: str | None = None
        authenticated_fallback_used = False
        ado_chain_ran = False
        for attempt in plan.attempts:
            if attempt.use_token and not has_token:
                continue

            use_ssh = attempt.scheme == "ssh"
            lazy_public_attempt = (
                public_github_https_first
                and attempt.scheme == "https"
                and not attempt.use_token
                and dep_ref is not None
            )
            url = ""
            if attempt.requested_url is not None:
                url = attempt.requested_url
            elif not lazy_public_attempt:
                try:
                    url = host._build_repo_url(
                        repo_url_base,
                        use_ssh=use_ssh,
                        dep_ref=dep_ref,
                    )
                except Exception as e:
                    last_error = e
                    continue

            if not plan.strict and prev_label and prev_scheme and prev_scheme != attempt.scheme:
                _rich_warning(
                    f"Protocol fallback: {prev_label} clone of {repo_url_base} "
                    f"failed; retrying with {attempt.label}.",
                    symbol="warning",
                )

            try:
                _debug(f"Attempting clone with {attempt.label} (URL sanitized)")
                if lazy_public_attempt:
                    url, authenticated_fallback_used = _run_public_github_attempt()
                elif is_ado and attempt.scheme == "https" and dep_ref is not None:
                    if ado_chain_ran:
                        continue
                    ado_chain_ran = True
                    ado_url = url

                    def _clone_ado(
                        _token: str | None,
                        attempt_env: dict[str, str],
                        attempt_url: str = ado_url,
                    ) -> None:
                        # auth-delegated: try_with_fallback walks PAT -> az bearer
                        # -> path-scoped helper and classifies each failure.
                        _clone(attempt_url, attempt_env, target_path)

                    host.auth_resolver.try_with_fallback(
                        dep_host or "dev.azure.com",
                        _clone_ado,
                        org=dep_ref.ado_organization,
                        port=dep_ref.port,
                        path=dep_ref.repo_url,
                        host_type=dep_ref.host_type,
                        remote_url=attempt.effective_url or ado_url,
                        base_env=host.git_env,
                        verbose_callback=verbose_callback,
                    )
                    authenticated_fallback_used = True
                else:
                    _clone(url, _env_for(attempt, url), target_path)
                if verbose_callback:
                    display = (
                        host._sanitize_git_error(url)
                        if attempt.use_token or authenticated_fallback_used
                        else url
                    )
                    verbose_callback(f"Cloned from: {display}")
                return
            except (
                git_command_error(),
                subprocess.CalledProcessError,
                subprocess.TimeoutExpired,
                AdoAuthChainExhaustedError,
            ) as e:
                last_error = e
                prev_label = attempt.label
                prev_scheme = attempt.scheme
                if plan.strict:
                    break

        repository_not_found = last_error is not None and is_repository_not_found(last_error)
        error_msg = build_clone_failure_message(
            repo_url_base=repo_url_base,
            plan=plan,
            dep_ref=dep_ref,
            dep_host=dep_host,
            is_ado=bool(is_ado),
            is_generic=is_generic,
            has_ado_token=host.has_ado_token,
            has_token=has_token or authenticated_fallback_used,
            auth_resolver=host.auth_resolver,
            configured_github_host=os.environ.get("GITHUB_HOST", ""),
            default_host_fn=default_host,
            last_error=last_error,
            last_attempt_scheme=prev_scheme,
            public_github_non_auth_failure=bool(
                public_github_https_first
                and last_error is not None
                and not classify_auth_outcome(
                    host_kind="github",
                    error=last_error,
                    public_github_anonymous=True,
                ).is_auth_failure
            ),
            repository_not_found=repository_not_found,
        )

        if repository_not_found:
            raise RepositoryNotFoundError(error_msg) from last_error
        raise RuntimeError(error_msg)
