"""Artifactory download orchestration.

This module isolates everything about *Artifactory routing* -- how to
decide whether a dependency should flow through Artifactory, how to
parse the registry-proxy config, and how to materialize a full package
or a subdirectory from an Artifactory VCS archive.

Design pattern: **Adapter** + **Facade**.

- The :class:`ArtifactoryRouter` adapts the heterogeneous ``dep_ref``
  shapes ("explicit Artifactory FQDN", "transparent proxy of GitHub",
  "registry-only mode") into the single decision the caller needs:
  *should this dependency be fetched from Artifactory, and if so,
  with which (host, prefix, scheme)?*

- The :class:`ArtifactoryOrchestrator` is the facade in front of the
  download flow itself: ``download_package`` and
  ``download_subdirectory`` are the two operations the rest of the
  codebase actually invokes. They depend only on a small downloader
  protocol (``_HasArchiveDownloader``) so they remain testable in
  isolation.

Why this lives in its own module: the bulk-cum-fragility ratio. The
flow (parse base URL -> decide routing -> tempdir extraction ->
APM validation -> stamp metadata) is purely internal to Artifactory
and crosscuts none of the other vendor backends. Keeping it inside
``GitHubPackageDownloader`` made the latter monolithic without any
reuse benefit.
"""

from __future__ import annotations

import tempfile
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Protocol

from ..models.apm_package import (
    GitReferenceType,
    PackageInfo,
    ResolvedReference,
    validate_apm_package,
)
from ..models.dependency.host_virtual import repository_owner_and_repo, repository_path_segments
from ..utils.github_host import default_host, is_full_commit_sha, is_github_hostname
from .carried_license import carry_licenses, read_repository_license

if TYPE_CHECKING:
    from ..models.apm_package import DependencyReference


# ---------------------------------------------------------------------------
# Internal collaborators
# ---------------------------------------------------------------------------


class _HasArchiveDownloader(Protocol):
    """Minimal contract the orchestrator needs from its caller.

    Implementations:
      - :class:`apm_cli.deps.download_strategies.DownloadDelegate`
        (production: real HTTP archive download).
      - Test doubles (unit tests).
    """

    def download_artifactory_archive(  # pragma: no cover - protocol only
        self,
        host: str,
        prefix: str,
        owner: str,
        repo: str,
        ref: str,
        target_path: Path,
        *,
        scheme: str = "https",
    ) -> None: ...


# ---------------------------------------------------------------------------
# Routing decisions
# ---------------------------------------------------------------------------


class ArtifactoryRouter:
    """Decide whether (and how) a dependency should flow through Artifactory.

    Stateless aside from environment variable inspection, which is
    delegated to :class:`apm_cli.deps.registry_proxy.RegistryConfig`.
    """

    @staticmethod
    def is_registry_only() -> bool:
        """Return True when registry-only mode is active.

        Honors the canonical ``PROXY_REGISTRY_ONLY`` env var, with
        backward compatibility for the deprecated ``ARTIFACTORY_ONLY``
        alias.
        """
        from .egress_route import EgressSurface, is_proxy_only

        return is_proxy_only(EgressSurface.SOURCE_ARCHIVE)

    @classmethod
    def should_use_proxy(cls, dep_ref: DependencyReference) -> bool:
        """Return True when *dep_ref* should be routed through the
        transparent Artifactory proxy.

        Note: returns False when the dependency is already an explicit
        Artifactory dep (``dep_ref.is_artifactory()``); that path takes
        a different branch in :meth:`ArtifactoryOrchestrator.download_package`.
        """
        if dep_ref.is_artifactory():
            return False
        if cls.is_registry_only():
            return True
        if dep_ref.is_azure_devops():
            return False
        host = dep_ref.host or default_host()
        return is_github_hostname(host)

    @staticmethod
    def parse_proxy_config() -> tuple[str, str, str] | None:
        """Return ``(host, prefix, scheme)`` from registry-proxy env, or None.

        Delegates env-var precedence and deprecation warnings to
        :class:`~apm_cli.deps.registry_proxy.RegistryConfig`.
        """
        from .registry_proxy import RegistryConfig

        cfg = RegistryConfig.from_env()
        if cfg is None:
            return None
        return (cfg.host, cfg.prefix, cfg.scheme)

    @classmethod
    def routing_target(cls, dep_ref: DependencyReference) -> tuple[str, str, str, bool] | None:
        """Return ``(host, prefix, scheme, is_mode_1)`` if *dep_ref* routes through the proxy.

        * Mode 1 (explicit FQDN): host and prefix come from the dependency ref;
          scheme is always ``https`` (Mode 1 deps reject ``http://`` upstream).
        * Mode 2 (shorthand routed by the registry-proxy config): host,
          prefix, and scheme come from that config, so installs that
          intentionally route through an ``http://`` proxy (isolated networks
          on an explicit http opt-in) probe over the same transport.

        Returns ``None`` when no proxy routing applies (regular GitHub/ADO deps)
        or when host/prefix are not real strings (e.g. mocked dependency refs
        in unit tests).
        """
        if dep_ref.is_artifactory():
            host = dep_ref.host
            prefix = dep_ref.artifactory_prefix
            if isinstance(host, str) and isinstance(prefix, str) and host and prefix:
                return (host, prefix, "https", True)
            return None
        if not cls.should_use_proxy(dep_ref):
            return None
        cfg = cls.parse_proxy_config()
        if cfg is None:
            return None
        host, prefix, scheme = cfg
        if isinstance(host, str) and isinstance(prefix, str) and host and prefix:
            return (host, prefix, scheme or "https", False)
        return None

    @classmethod
    def routes_to_locked_proxy(cls, dep_ref: DependencyReference, locked_dep) -> bool:
        """Return True when *dep_ref* routes through the proxy *locked_dep* recorded.

        A proxy-routed lock row records the proxy host and ``registry_prefix``
        instead of the upstream host, so its provider identity differs from
        the manifest shorthand. The row still names the same source when the
        current routing for *dep_ref* lands on that same proxy route.
        """
        locked_prefix = getattr(locked_dep, "registry_prefix", None)
        if not locked_prefix:
            return False
        target = cls.routing_target(dep_ref)
        if target is None:
            return False
        host, prefix, _scheme, _is_mode_1 = target
        locked_host = getattr(locked_dep, "host", None) or ""
        return (host.lower(), prefix.strip("/")) == (locked_host.lower(), locked_prefix.strip("/"))


# ---------------------------------------------------------------------------
# Download orchestration
# ---------------------------------------------------------------------------


class ArtifactoryOrchestrator:
    """Materialize Artifactory packages and subdirectories.

    Holds a reference to a :class:`_HasArchiveDownloader` -- in
    production this is the same ``DownloadDelegate`` instance used by
    the surrounding ``GitHubPackageDownloader``, so HTTP session reuse
    and auth headers stay shared.
    """

    def __init__(self, archive_downloader: _HasArchiveDownloader) -> None:
        self._archive_downloader = archive_downloader

    # -- helpers --------------------------------------------------------

    @staticmethod
    def _resolve_host_prefix(
        dep_ref: DependencyReference,
        proxy_info: tuple[str, str, str] | None,
    ) -> tuple[str, str, str]:
        """Return ``(host, prefix, scheme)`` for the download.

        Explicit Artifactory deps win; otherwise fall back to the
        registry-proxy config.
        """
        if dep_ref.is_artifactory():
            host, prefix = dep_ref.host, dep_ref.artifactory_prefix
            if not host or not prefix:
                raise ValueError(
                    f"Artifactory dependency '{dep_ref.repo_url}' is missing "
                    "host or artifactory prefix"
                )
            return (host, prefix, "https")
        if proxy_info:
            return proxy_info
        raise RuntimeError("Artifactory download requires either FQDN or ARTIFACTORY_BASE_URL")

    @staticmethod
    def _split_owner_repo(dep_ref: DependencyReference) -> tuple[str, str]:
        owner_repo = repository_owner_and_repo(dep_ref.repo_url)
        if owner_repo is None:
            raise ValueError(
                f"Invalid Artifactory repo reference '{dep_ref.repo_url}': "
                "expected 'owner/repo' format"
            )
        owner, repo = owner_repo
        # Owner is the top-level namespace; the remainder of the path is the
        # project slug.  For GitLab projects behind an Artifactory VCS proxy
        # the slug can include subgroups (e.g. ``group/subgroup/project``).
        return owner, repo

    @staticmethod
    def _progress(progress_obj, progress_task_id, *, completed: int, total: int = 100) -> None:
        if progress_obj and progress_task_id is not None:
            progress_obj.update(progress_task_id, completed=completed, total=total)

    @staticmethod
    def _resolved_commit_metadata(ref: str) -> tuple[GitReferenceType, str | None]:
        """Classify an archive ref for lockfile-safe resolution metadata."""
        if is_full_commit_sha(ref):
            return GitReferenceType.COMMIT, ref
        return GitReferenceType.BRANCH, None

    # -- public surface -------------------------------------------------

    def download_package(
        self,
        dep_ref: DependencyReference,
        target_path: Path,
        proxy_info: tuple[str, str, str] | None = None,
        progress_task_id=None,
        progress_obj=None,
    ) -> PackageInfo:
        """Download a full APM package via Artifactory VCS archive."""
        from ..utils.file_ops import robust_rmtree
        from .github_downloader import _debug, _rmtree

        ref = dep_ref.reference or "main"
        owner, repo = self._split_owner_repo(dep_ref)
        host, prefix, scheme = self._resolve_host_prefix(dep_ref, proxy_info)

        _debug(f"Downloading from Artifactory: {host}/{prefix}/{owner}/{repo}#{ref}")
        if target_path.exists() and any(target_path.iterdir()):
            robust_rmtree(target_path)
        target_path.mkdir(parents=True, exist_ok=True)
        self._progress(progress_obj, progress_task_id, completed=10)
        try:
            self._archive_downloader.download_artifactory_archive(
                host, prefix, owner, repo, ref, target_path, scheme=scheme
            )
        except RuntimeError:
            if target_path.exists():
                _rmtree(target_path)
            raise
        self._progress(progress_obj, progress_task_id, completed=70)

        from ._shared import _validate_and_load_package

        validation_result = validate_apm_package(target_path)
        package = _validate_and_load_package(validation_result, target_path, dep_ref)
        ref_type, resolved_commit = self._resolved_commit_metadata(ref)
        package.resolved_commit = resolved_commit
        resolved_ref = ResolvedReference(
            original_ref=f"{dep_ref.repo_url}#{ref}",
            ref_type=ref_type,
            resolved_commit=resolved_commit,
            ref_name=ref,
        )
        self._progress(progress_obj, progress_task_id, completed=100)
        return PackageInfo(
            package=package,
            install_path=target_path,
            resolved_reference=resolved_ref,
            installed_at=datetime.now().isoformat(),
            dependency_ref=dep_ref,
            package_type=validation_result.package_type,
            carried_licenses=carry_licenses(target_path),
        )

    def download_subdirectory(
        self,
        dep_ref: DependencyReference,
        target_path: Path,
        proxy_info: tuple[str, str, str],
        progress_task_id=None,
        progress_obj=None,
    ) -> PackageInfo:
        """Download an archive from Artifactory and extract a subdirectory."""
        from ..config import get_apm_temp_dir
        from ..utils.file_ops import robust_copy2, robust_copytree, robust_rmtree

        ref = dep_ref.reference or "main"
        subdir_path = dep_ref.virtual_path
        repo_parts = repository_path_segments(dep_ref.repo_url)
        owner = repo_parts[0]
        # Preserve subgroup nesting (GitLab via proxy) by folding everything
        # past the owner into the repo slug.
        repo = "/".join(repo_parts[1:]) if len(repo_parts) > 1 else repo_parts[0]
        host, prefix, scheme = proxy_info

        self._progress(progress_obj, progress_task_id, completed=10)

        with tempfile.TemporaryDirectory(dir=get_apm_temp_dir()) as temp_dir:
            temp_path = Path(temp_dir) / "full_pkg"
            self._archive_downloader.download_artifactory_archive(
                host, prefix, owner, repo, ref, temp_path, scheme=scheme
            )
            self._progress(progress_obj, progress_task_id, completed=60)
            source_subdir = temp_path / subdir_path
            if not source_subdir.exists() or not source_subdir.is_dir():
                raise RuntimeError(
                    f"Subdirectory '{subdir_path}' not found in archive from "
                    f"Artifactory ({host}/{prefix}/{owner}/{repo}#{ref})"
                )
            target_path.mkdir(parents=True, exist_ok=True)
            if target_path.exists() and any(target_path.iterdir()):
                robust_rmtree(target_path)
                target_path.mkdir(parents=True, exist_ok=True)
            for item in source_subdir.iterdir():
                src = source_subdir / item.name
                dst = target_path / item.name
                if src.is_dir():
                    robust_copytree(src, dst)
                else:
                    robust_copy2(src, dst)
            repository_license = read_repository_license(temp_path, subdir_path)

        self._progress(progress_obj, progress_task_id, completed=80)
        from ._shared import _validate_and_load_package

        validation_result = validate_apm_package(target_path)
        package = _validate_and_load_package(validation_result, target_path, dep_ref)
        ref_type, resolved_commit = self._resolved_commit_metadata(ref)
        package.resolved_commit = resolved_commit
        resolved_ref = ResolvedReference(
            original_ref=ref,
            ref_name=ref,
            ref_type=ref_type,
            resolved_commit=resolved_commit,
        )
        self._progress(progress_obj, progress_task_id, completed=100)
        return PackageInfo(
            package=package,
            install_path=target_path,
            resolved_reference=resolved_ref,
            installed_at=datetime.now().isoformat(),
            dependency_ref=dep_ref,
            package_type=validation_result.package_type,
            carried_licenses=carry_licenses(
                target_path, repository_license=repository_license, package_subpath=subdir_path
            ),
        )
