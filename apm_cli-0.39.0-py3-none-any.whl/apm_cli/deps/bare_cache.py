"""Bare-repo clone + materialization helpers for the WS2 dedup pipeline.

Extracted from :mod:`github_downloader` to keep that module under the
2400-line CI guardrail (see ``.github/workflows/build-release.yml``).

Public entry points:

* :func:`clone_with_fallback` -- sanitized working-tree clone threaded
  through a caller-supplied transport-plan
  executor.
* :func:`bare_clone_with_fallback` -- 3-tier bare-repo clone for the
  shared cache (the core fix for #1126).
* :func:`materialize_from_bare` -- per-consumer working-tree checkout
  backed by a shared bare's object database.

All three are pure free functions; behavior is unchanged from the
original methods on :class:`GitHubPackageDownloader`. Test contracts
that patch ``downloader._clone_with_fallback`` /
``downloader._bare_clone_with_fallback`` /
``downloader._materialize_from_bare`` are preserved by keeping thin
delegating instance methods on the class.
"""

from __future__ import annotations

import logging
import os
import re
import subprocess
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import urlsplit

from ..models.dependency.host_virtual import dependency_repository_owner
from ..utils.git_env import run_git_text
from ..utils.git_sparse import apply_sparse_cone, materialize_tracked_symlinks
from .git_lazy import bind_git_name

if TYPE_CHECKING:
    from git import Repo

    from ..models.apm_package import DependencyReference

_log = logging.getLogger(__name__)


def _rmtree(path: Path) -> None:
    """Remove a directory tree, handling read-only files and brief Windows locks.

    Delegates to :func:`robust_rmtree` which retries with exponential backoff
    on transient lock errors and chmod-resets read-only ``.git/objects/pack``
    files (Windows portability finding from the #1126 paper audit).
    Duplicated from :mod:`github_downloader` to avoid a circular import
    (``github_downloader`` imports from this module).
    """
    from ..utils.file_ops import robust_rmtree

    robust_rmtree(path, ignore_errors=True)


def _scrub_bare_remote_url(bare_path: Path, git_exe: str, env: dict[str, str]) -> None:
    """Redact ``remote.origin.url`` in a bare repo's ``.git/config``.

    After a successful bare clone, ``remote.origin.url`` retains the
    tokenized URL (e.g. ``https://oauth2:<TOKEN>@github.com/...``). The
    bare is read-only after this point in the WS2 dedup pipeline (no
    further fetches), so the URL is dead weight that just persists the
    token on disk. Replace with ``redacted://`` to eliminate the
    on-disk token footprint.

    Defense-in-depth: tier-1 (init + remote add + fetch) leaves
    ``FETCH_HEAD`` containing the tokenized URL on disk even after the
    config scrub. Truncate it to empty so the token does not survive
    in any on-disk artifact. Best-effort (non-fatal on OSError).

    Best-effort: ``check=False`` so a config-set failure does not abort
    the clone (the bare is still functionally correct without the
    redaction). Convergent panel finding (auth + supply-chain MAJOR).
    On exception, log at WARNING so token-leak-aware operators have an
    audit trail (supply-chain reviewer follow-up: security mechanisms
    must not fail silently).
    """
    try:
        result = subprocess.run(
            [git_exe, "--git-dir", str(bare_path), "remote", "set-url", "origin", "redacted://"],
            env=env,
            check=False,
            capture_output=True,
            timeout=10,
        )
        from ..utils.git_config_memo import invalidate

        invalidate(bare_path)  # its config changed: no earlier probe answers for it
        if result.returncode != 0:
            logging.getLogger(__name__).warning(
                "Failed to redact remote URL from bare repo config at %s "
                "(git exit=%d). Tokenized URL may persist on disk until "
                "shared cache cleanup.",
                bare_path,
                result.returncode,
            )
    except Exception as exc:
        logging.getLogger(__name__).warning(
            "Exception while redacting remote URL from bare repo config "
            "at %s: %s. Tokenized URL may persist on disk until shared "
            "cache cleanup.",
            bare_path,
            exc,
        )

    # Defense-in-depth: truncate FETCH_HEAD which retains the tokenized
    # URL after tier-1 init+fetch (supply-chain panel follow-up).
    fetch_head = bare_path / "FETCH_HEAD"
    try:
        if fetch_head.exists():
            fetch_head.write_text("")
    except OSError as exc:
        logging.getLogger(__name__).warning(
            "Failed to truncate FETCH_HEAD at %s: %s. Tokenized URL "
            "may persist on disk until shared cache cleanup.",
            fetch_head,
            exc,
        )


# Protocol v0 servers refuse a want for an unadvertised commit. Under v2 a
# "not our ref" means the commit is gone on stock git, but some hosts answer
# so for any unadvertised commit; neither may clone the history in full.
_WANT_REFUSED = ("does not allow request for unadvertised object",)
_NOT_OUR_REF = "not our ref"
# git translates its own messages; the fetch runs untranslated so they match.
_UNTRANSLATED = {"LC_ALL": "C", "LANGUAGE": "C"}


def _refuses_want_by_commit(exc: subprocess.CalledProcessError) -> bool:
    """Whether git failed because the server refuses to serve a commit by its id."""
    return any(marker in _stderr_text(exc) for marker in _WANT_REFUSED)


def _stderr_text(exc: subprocess.CalledProcessError) -> str:
    detail = exc.stderr
    if isinstance(detail, bytes):
        detail = detail.decode("utf-8", "replace")
    return (detail or "").lower()


def _fetch_admitted_tip_by_name(
    git_exe: str, path: Path, url: str, ref: str, sha: str, fetch_env: dict[str, str]
) -> bool:
    """Fetch *ref* by name when it still points at *sha*; ``False`` if unknown.

    Both the listing and the fetch use *fetch_env*, the validated clone env of
    *path*, so they reach the destination a clone would (a mirror rewrite).

    Raises:
        AdmittedCommitGoneError: *ref* no longer points at *sha*.
    """
    from ..cache.commit_reachability import admitted_tip_name

    name = admitted_tip_name(url, ref, sha, fetch_env)
    if name is None:
        return False
    subprocess.run(
        [git_exe, "-C", str(path), "fetch", "-q", "--depth=1", "--no-tags", url, name],
        env={**fetch_env, **_UNTRANSLATED},
        check=True,
        capture_output=True,
        timeout=300,
    )
    return True


def fetch_commit_worktree(
    execute_transport_plan: Callable[..., None],
    repo_url_base: str,
    target: Path,
    *,
    dep_ref: DependencyReference,
    sha: str,
    verbose_callback: Callable[[str], None] | None = None,
) -> None:
    """Check out commit *sha* at *target*, fetched by that commit, never by a name (#5138).

    Shallow: ``git init``, ``git fetch --depth=1 --no-tags <url> <sha>`` and a
    detached checkout. A server that refuses a want by commit falls back to a
    full clone and a checkout of *sha*. A server that answers "not our ref"
    gets the ref fetched by name, only while it still points at *sha*; the
    checkout is still of *sha*. Runs over the clone transport plan. The
    caller verifies the checkout against *sha* once links are materialized.
    """
    from ..utils.git_env import (
        checkout_git_worktree,
        clone_git_worktree,
        get_git_executable,
        git_clone_env,
        git_no_templates_args,
        git_subprocess_env,
    )

    git_exe = get_git_executable()

    def _action(url: str, env: dict[str, str], path: Path) -> None:
        env = git_subprocess_env(env)
        if path.exists():
            _rmtree(path)
        # The env a clone would get, with remote-activated config applied.
        fetch_env = git_clone_env(url, env, path)
        try:
            subprocess.run(
                [git_exe, "init", "-q", *git_no_templates_args(), str(path)],
                env=fetch_env,
                check=True,
                capture_output=True,
            )
            subprocess.run(
                [git_exe, "-C", str(path), "fetch", "-q", "--depth=1", "--no-tags", url, sha],
                env={**fetch_env, **_UNTRANSLATED},
                check=True,
                capture_output=True,
                timeout=300,
            )
        except subprocess.CalledProcessError as exc:
            # Only a server that refuses a want by commit gets the full clone; a
            # missing commit or an auth failure fails here, at depth-1 cost.
            ref = getattr(dep_ref, "reference", None)
            if ref and _NOT_OUR_REF in _stderr_text(exc):
                if not _fetch_admitted_tip_by_name(git_exe, path, url, ref, sha, fetch_env):
                    raise
                checkout_git_worktree(path, sha, env=env)
                return
            if not _refuses_want_by_commit(exc):
                raise
            if verbose_callback:
                verbose_callback(
                    f"Fetch by commit refused; cloning in full to check out {sha[:12]}"
                )
            if path.exists():
                _rmtree(path)
            clone_git_worktree(url, path, env=env, no_checkout=True)
        checkout_git_worktree(path, sha, env=env)

    execute_transport_plan(repo_url_base, target, dep_ref=dep_ref, clone_action=_action)


def bare_clone_with_fallback(
    execute_transport_plan: Callable[..., None],
    repo_url_base: str,
    bare_target: Path,
    *,
    dep_ref: DependencyReference,
    ref: str | None,
    is_commit_sha: bool,
) -> None:
    """Clone a repository as a bare repo, with full transport-plan fallback.

    Sibling helper to :meth:`GitHubPackageDownloader._clone_with_fallback`.
    Composes via the caller-supplied ``execute_transport_plan`` callable
    (typically ``self._execute_transport_plan``) so it inherits ADO
    bearer retry and protocol fallback automatically. The bare clone is
    subdir-agnostic (no sparse cone), so a single bare can serve N
    consumers each materializing a different subdir from the same
    repo+ref - this is the core fix for #1126.

    3-tier strategy (per design.md sec 5.2):

      - Tier 1 (SHA refs): ``git init --bare && git remote add
        origin <url> && git fetch --depth=1 origin <sha>``. Requires
        server-side ``uploadpack.allowReachableSHA1InWant=true``
        (default on github.com / GHES; some older GHE / ADO Server /
        Bitbucket Server reject this).
      - Tier 1 (symbolic / default branch): ``git clone --bare
        --depth=1 [--branch <ref>] <url>``.
      - Tier 2 (both): full ``git clone --bare <url>``, verify the
        requested SHA or symbolic ref and point HEAD at that commit.
      - Tier 3: re-raise.

    After every successful tier, ``git update-ref HEAD <ref>`` is
    invoked for SHA refs so consumer ``git rev-parse HEAD`` resolves
    unambiguously (the v3 BLOCKER fix). Then
    :func:`_scrub_bare_remote_url` redacts the tokenized
    ``remote.origin.url`` from ``.git/config`` to eliminate
    on-disk token persistence (panel convergent finding).

    Note: bare-integrity verification (post-clone ``rev-parse HEAD
    == known_sha``) is intentionally deferred. The bare is
    ephemeral, mode-0700, and produced by a trusted (in-tree)
    callable. If ``SharedCloneCache`` is ever opened to
    plugin/user-supplied callables, restore the integrity check at
    the cache boundary. See design.md sec 12 (Bare integrity
    verification).
    """
    from ..utils.git_env import (
        get_git_executable,
        git_clone_env,
        git_network_env,
        git_no_templates_args,
        git_subprocess_env,
    )

    git_exe = get_git_executable()

    def _bare_action(url: str, env: dict[str, str], target: Path) -> None:
        env = git_subprocess_env(env)
        # Pre-attempt cleanup: any prior tier-1 partial state must be
        # wiped before re-attempting (e.g. on ADO bearer retry the
        # template re-invokes _bare_action with a fresh URL/env, and
        # the tier-1 init+fetch leaves a half-built bare on disk).
        # See 6.15.
        if target.exists():
            _rmtree(target)

        if is_commit_sha:
            # Tier 1 (init + fetch by SHA) requires a full 40-char SHA:
            # `git fetch origin <sha>` only works for full SHAs (the
            # smart-HTTP protocol does not resolve abbreviated SHAs),
            # and `git update-ref HEAD <sha>` requires a full 40-char
            # SHA-1. For short SHAs, skip directly to tier 2 where
            # `rev-parse <short>` against the full bare can resolve
            # the abbreviation. Copilot review finding (#1135).
            if len(ref) == 40:
                # Note: `git remote add origin <url>` stores the
                # tokenized URL in `.git/config`. The ADO-bearer env
                # approach relies on http.extraHeader (not stored URL
                # auth), so this is safe today. _scrub_bare_remote_url
                # below redacts the URL after a successful clone so the
                # token does not persist on disk.
                try:
                    env = git_network_env(url, env)
                    subprocess.run(
                        [git_exe, "init", *git_no_templates_args(), "--bare", str(target)],
                        env=env,
                        check=True,
                        capture_output=True,
                    )
                    env = git_network_env(url, env, git_dir=target)
                    subprocess.run(
                        [git_exe, "--git-dir", str(target), "remote", "add", "origin", url],
                        env=env,
                        check=True,
                        capture_output=True,
                    )
                    remote_env = git_network_env(url, env, git_dir=target)
                    subprocess.run(
                        [git_exe, "--git-dir", str(target), "fetch", "--depth=1", "origin", ref],
                        env=remote_env,
                        check=True,
                        capture_output=True,
                        timeout=300,
                    )
                    # CRITICAL (v3 BLOCKER): init+fetch leaves HEAD pointing
                    # at refs/heads/main which doesn't exist locally.
                    # Without update-ref, consumer's `git rev-parse HEAD`
                    # is ambiguous. See 6.18.
                    subprocess.run(
                        [git_exe, "--git-dir", str(target), "update-ref", "HEAD", ref],
                        env=env,
                        check=True,
                        capture_output=True,
                    )
                    _scrub_bare_remote_url(target, git_exe, env)
                    return
                except subprocess.CalledProcessError:
                    pass  # fall through to tier 2

            # Tier 2: full bare clone, validate SHA, set HEAD.
            if target.exists():
                _rmtree(target)
            env = git_clone_env(url, env, target, bare=True)
            subprocess.run(
                [git_exe, "clone", *git_no_templates_args(), "--bare", url, str(target)],
                env=env,
                check=True,
                capture_output=True,
                timeout=600,
            )
            # Resolve abbreviated SHAs (and re-validate full SHAs) against
            # the full clone. `rev-parse <short>^{commit}` returns the
            # 40-char SHA; we feed that into update-ref so HEAD never
            # holds a partial reference. Without this, short-SHA pins
            # would set resolved_commit to the abbreviation and lockfile
            # comparisons against `head.commit.hexsha` (always 40-char)
            # would never match. Copilot review finding (#1135).
            from ..utils.git_env import git_resolve_commit

            # A commit pin: the full commit its (possibly abbreviated) name expands to.
            full_sha = git_resolve_commit(target, ref, bare=True, env=env)
            subprocess.run(
                [git_exe, "--git-dir", str(target), "update-ref", "HEAD", full_sha],
                env=env,
                check=True,
                capture_output=True,
            )
            _scrub_bare_remote_url(target, git_exe, env)
            return

        # Symbolic ref or default branch.
        args = [git_exe, "clone", *git_no_templates_args(), "--bare", "--depth=1"]
        if ref:
            args += ["--branch", ref]
        args += [url, str(target)]
        env = git_clone_env(url, env, target, bare=True)
        try:
            subprocess.run(args, env=env, check=True, capture_output=True, timeout=300)
            _scrub_bare_remote_url(target, git_exe, env)
            return
        except subprocess.CalledProcessError:
            # Tier 2: full bare clone (no shallow, no --branch).
            _rmtree(target)
            env = git_clone_env(url, env, target, bare=True)
            subprocess.run(
                [git_exe, "clone", *git_no_templates_args(), "--bare", url, str(target)],
                env=env,
                check=True,
                capture_output=True,
                timeout=600,
            )
            _scrub_bare_remote_url(target, git_exe, env)
            if ref:
                from ..utils.git_env import git_resolve_commit

                selected_sha = git_resolve_commit(target, ref, env=env, bare=True)
                subprocess.run(
                    [git_exe, "--git-dir", str(target), "update-ref", "HEAD", selected_sha],
                    env=env,
                    check=True,
                    capture_output=True,
                )
            return

    execute_transport_plan(
        repo_url_base,
        bare_target,
        dep_ref=dep_ref,
        clone_action=_bare_action,
    )


def fetch_sha_into_bare(
    execute_transport_plan: Callable[..., None],
    repo_url_base: str,
    bare_path: Path,
    sha: str,
    *,
    dep_ref: DependencyReference,
) -> bool:
    """Attempt to fetch a specific SHA into an existing bare repo.

    Used to hydrate shallow bare clones that are missing a transitive
    SHA-pinned commit.  Three-step strategy:

    1. **Check first** -- ``git rev-parse --verify <sha>^{commit}`` against
       the bare.  If the SHA is already present, returns ``True`` immediately
       without any network I/O.
    2. **Shallow fetch by SHA** (full 40-char SHAs only) -- invokes
       ``execute_transport_plan`` with a fetch action that runs
       ``git fetch <url> <sha>``.  Uses the authenticated URL supplied by
       the transport plan, NOT ``git fetch origin <sha>``, because
       ``remote.origin.url`` has been redacted to ``redacted://`` by
       :func:`_scrub_bare_remote_url`.  After the fetch, verifies with
       ``rev-parse --verify``.  Returns ``True`` on success.
    3. **Broaden shallow** -- invokes ``execute_transport_plan`` with a
       fetch action that runs ``git fetch <url>`` (no ref argument),
       broadening the shallow boundary to include all remote refs.  After
       the fetch, verifies with ``rev-parse --verify``.  Returns ``True``
       on success.

    On any failure in steps 2 or 3, returns ``False`` so the caller can
    fall back to a fresh bare clone.

    Note: this function deliberately does NOT call ``git update-ref HEAD``
    after a successful fetch.  The consumer's :func:`materialize_from_bare`
    handles SHA resolution independently via the ``known_sha`` parameter.

    Args:
        execute_transport_plan: Callable that orchestrates auth and protocol
            fallback (typically ``self._execute_transport_plan``).
        repo_url_base: Base repo URL (unauthenticated) passed to the
            transport plan so it can inject credentials.
        bare_path: Path to the existing bare repo on disk.
        sha: The Git commit SHA to fetch.
        dep_ref: Dependency reference used by the transport plan for
            auth context.

    Returns:
        ``True`` if the SHA is now present in the bare, ``False`` otherwise.
    """
    from ..utils.git_env import get_git_executable, git_network_env, git_subprocess_env

    git_exe = get_git_executable()
    local_env = git_subprocess_env()

    def _rev_parse_present() -> bool:
        """Return True if sha is already reachable in the bare."""
        try:
            # Use the sanitized local environment even for non-network plumbing.
            result = subprocess.run(
                [
                    git_exe,
                    "--git-dir",
                    str(bare_path),
                    "rev-parse",
                    "--verify",
                    f"{sha}^{{commit}}",
                ],
                env=local_env,
                capture_output=True,
                timeout=10,
            )
            return result.returncode == 0
        except Exception:
            return False

    def _pin_sha_as_head_ref() -> None:
        """Add refs/heads/apm-pin-<sha-prefix> so the SHA is reachable via git-clone.

        ``git clone --local --shared`` from a *shallow* bare ignores
        ``--shared`` and falls back to the upload-pack protocol, which
        only transfers objects reachable from advertised refs.  A SHA
        fetched by :func:`fetch_sha_into_bare` is inserted into the
        object store but is *not* referenced by any ref, so the clone
        silently omits it and subsequent ``git checkout <sha>`` fails.

        Creating a synthetic ``refs/heads/apm-pin-*`` ref makes the
        commit reachable via the default ``refs/heads/*`` refspec, so
        upload-pack includes it.  Best-effort: a failure here is logged
        at DEBUG level and does not abort the install (the fallback is
        a fresh bare clone for the pinned package).
        """
        if not re.fullmatch(r"[0-9a-f]{40}", sha):
            _log.debug(
                "fetch_sha_into_bare: sha %r is not a valid 40-char hex SHA, skipping pin ref",
                sha,
            )
            return
        ref_name = f"refs/heads/apm-pin-{sha[:12]}"
        try:
            # no env= needed -- purely local git plumbing, no network access
            result = subprocess.run(
                [git_exe, "--git-dir", str(bare_path), "update-ref", ref_name, sha],
                env=local_env,
                capture_output=True,
                timeout=10,
            )
            if result.returncode == 0:
                _log.debug(
                    "fetch_sha_into_bare: pinned %s as %s in %s",
                    sha[:12],
                    ref_name,
                    bare_path,
                )
            else:
                _log.debug(
                    "fetch_sha_into_bare: update-ref exited %d for %s in %s",
                    result.returncode,
                    sha[:12],
                    bare_path,
                )
        except Exception as exc:
            _log.debug(
                "fetch_sha_into_bare: could not create pin ref for %s in %s: %s",
                sha[:12],
                bare_path,
                exc,
            )

    def _scrub_fetch_head() -> None:
        """Truncate FETCH_HEAD to remove the token-embedded URL written by fetch."""
        fetch_head = bare_path / "FETCH_HEAD"
        try:
            if fetch_head.exists():
                fetch_head.write_text("")
        except OSError as exc:
            _log.warning(
                "Failed to truncate FETCH_HEAD at %s: %s. Tokenized URL "
                "may persist on disk until shared cache cleanup.",
                fetch_head,
                exc,
            )

    # Step 1: check first -- no network if SHA already present.
    _log.debug("fetch_sha_into_bare: checking if %s is present in %s", sha[:12], bare_path)
    if _rev_parse_present():
        _log.debug("fetch_sha_into_bare: SHA %s already present, skipping fetch", sha[:12])
        _pin_sha_as_head_ref()
        return True

    # Step 2: shallow fetch by full SHA (only for full 40-char SHAs).
    if len(sha) == 40:
        _log.debug(
            "fetch_sha_into_bare: attempting shallow fetch of %s into %s", sha[:12], bare_path
        )

        def _fetch_action_sha(url: str, env: dict[str, str], target: Path) -> None:
            network_env = git_network_env(url, env, git_dir=target)
            subprocess.run(
                [git_exe, "--git-dir", str(target), "fetch", "--depth=1", url, sha],
                env=network_env,
                check=True,
                capture_output=True,
                timeout=300,
            )

        try:
            execute_transport_plan(
                repo_url_base,
                bare_path,
                dep_ref=dep_ref,
                clone_action=_fetch_action_sha,
            )
            _scrub_fetch_head()
            if _rev_parse_present():
                _log.debug("fetch_sha_into_bare: shallow fetch of %s succeeded", sha[:12])
                _pin_sha_as_head_ref()
                return True
        except subprocess.CalledProcessError as exc:
            from ..utils.git_env import git_subprocess_error_text

            stderr_text = git_subprocess_error_text(exc)
            _log.debug(
                "fetch_sha_into_bare: shallow fetch of %s failed: %s",
                sha[:12],
                stderr_text,
            )
        except Exception:
            _log.debug(
                "fetch_sha_into_bare: shallow fetch of %s raised unexpected error",
                sha[:12],
            )

    # Step 3: broaden shallow -- fetch all refs without a SHA argument.
    # Depth is capped to avoid unbounded history download on large repos.
    # Override via APM_BROAD_FETCH_DEPTH environment variable.
    broad_depth = os.environ.get("APM_BROAD_FETCH_DEPTH", "50")
    _log.info("Hydrating missing commit %s into shared bare for %s", sha[:12], repo_url_base)
    _log.debug("fetch_sha_into_bare: broadening shallow in %s to find %s", bare_path, sha[:12])

    def _fetch_action_broad(url: str, env: dict[str, str], target: Path) -> None:
        network_env = git_network_env(url, env, git_dir=target)
        subprocess.run(
            [git_exe, "--git-dir", str(target), "fetch", f"--depth={broad_depth}", url],
            env=network_env,
            check=True,
            capture_output=True,
            timeout=300,
        )

    try:
        execute_transport_plan(
            repo_url_base,
            bare_path,
            dep_ref=dep_ref,
            clone_action=_fetch_action_broad,
        )
        _scrub_fetch_head()
        if _rev_parse_present():
            _log.debug("fetch_sha_into_bare: broad fetch succeeded, %s now present", sha[:12])
            _pin_sha_as_head_ref()
            return True
    except subprocess.CalledProcessError as exc:
        from ..utils.git_env import git_subprocess_error_text

        stderr_text = git_subprocess_error_text(exc)
        _log.debug(
            "fetch_sha_into_bare: broad fetch failed for %s in %s: %s",
            sha[:12],
            bare_path,
            stderr_text,
        )
    except Exception:
        _log.debug(
            "fetch_sha_into_bare: broad fetch raised unexpected error for %s",
            sha[:12],
        )

    _log.debug(
        "fetch_sha_into_bare: all fetch attempts exhausted for %s in %s",
        sha[:12],
        bare_path,
    )
    return False


def materialize_from_bare(
    bare_path: Path,
    consumer_dir: Path,
    *,
    ref: str | None,
    env: dict[str, str],
    known_sha: str | None = None,
    sparse_paths: list[str] | None = None,
) -> str:
    """Create a working-tree checkout from a bare repo via local-shared clone.

    Mirrors :class:`GitCache`'s ``_create_checkout`` pattern: each
    consumer gets its own working tree backed by the shared bare's
    object database (via ``objects/info/alternates``). Hardlink-cheap
    and concurrent-safe (consumer dirs are unique per call).

    SHA resolution policy (lifetime invariant 5.2.1):
      - If ``known_sha`` is provided (caller passed a 40-char SHA
        ref), use it directly. Avoids ``rev-parse HEAD`` which is
        ambiguous on init+fetch bares before update-ref runs.
      - Otherwise, resolve from the BARE via ``git --git-dir
        <bare> rev-parse HEAD``. NOT from the consumer - opening
        ``Repo(consumer_dir)`` leaks a Windows file handle that
        blocks downstream rmtree.

    CRLF + LFS pinning before checkout:
      - ``git_line_ending_pin_args`` (``core.autocrlf=false`` and
        ``core.eol`` set to ``lf``) guarantees byte-identical ``text`` /
        ``text=auto`` content across consumers regardless of host Git
        config or platform default (apm#3270).
      - ``git_symlink_pin_args`` writes in-repo links as link text, so
        checkout never needs OS symlink capability; they are then
        replaced with their Git-object content (#3457).
      - ``filter.lfs.smudge=""`` + ``filter.lfs.required=false``
        disables LFS smudge cross-platform (the empty string trick
        works everywhere; ``cat`` is not on Windows PATH).

    Sparse-cone (perf #1433):
      - When ``sparse_paths`` is set, ``git sparse-checkout init --cone``
        followed by ``git sparse-checkout set <paths...>`` runs BEFORE
        ``git checkout``, so only the requested top-level directories
        are materialized in the working tree. The bare's object DB is
        unchanged; only the consumer working tree shrinks.
      - Sparse-checkout failures are RAISED (not silently fallen back)
        because a silent fallback would re-introduce the 78 MB bloat
        this parameter exists to avoid.
      - A link whose target lies outside the requested paths (#2707)
        resolves from Git objects, so the cone never has to widen.

    Returns:
        The resolved commit SHA. Caller threads this into
        ``resolved_commit`` for the lockfile.
    """
    from ..utils.git_env import (
        get_git_executable,
        git_line_ending_pin_args,
        git_line_ending_pin_entries,
        git_no_hooks_args,
        git_no_templates_args,
        git_subprocess_env,
        git_symlink_pin_args,
    )

    git_exe = get_git_executable()
    env = git_subprocess_env(env)
    pin_args = [*git_symlink_pin_args(), *git_line_ending_pin_args()]

    if known_sha:
        resolved_sha = known_sha
    else:
        sha_result = run_git_text(
            [git_exe, "--git-dir", str(bare_path), "rev-parse", "HEAD"],
            capture_output=True,
            timeout=10,
            env=env,
            check=True,
        )
        resolved_sha = sha_result.stdout.strip()

    consumer_dir.parent.mkdir(parents=True, exist_ok=True)
    # --no-checkout because we want to pin line endings and disable
    # LFS smudge BEFORE checkout writes any file content. ``--config``
    # persists the line-ending pins in the clone itself (no extra spawn);
    # the checkout also carries the ``-c`` pins, which outrank env
    # snapshots. The symlink pin travels only as ``-c``: this consumer is
    # not a reusable shard validated by ``_checkout_has_materialization_pins``.
    line_ending_config = [
        arg for key, val in git_line_ending_pin_entries() for arg in ("--config", f"{key}={val}")
    ]
    run_git_text(
        [
            git_exe,
            *git_no_hooks_args(),
            "clone",
            *git_no_templates_args(),
            *line_ending_config,
            "--local",
            "--shared",
            "--no-checkout",
            str(bare_path),
            str(consumer_dir),
        ],
        capture_output=True,
        timeout=60,
        env=env,
        check=True,
    )
    # Disable LFS smudge cross-platform: empty-string smudge is the
    # portable equivalent of `git lfs smudge --skip`. The `cat`
    # alternative is not on Windows PATH.
    for key, val in (
        ("filter.lfs.smudge", ""),
        ("filter.lfs.clean", ""),
        ("filter.lfs.process", ""),
        ("filter.lfs.required", "false"),
    ):
        run_git_text(
            [git_exe, "-C", str(consumer_dir), "config", key, val],
            capture_output=True,
            timeout=10,
            env=env,
            check=False,
        )
    checkout_target = known_sha or "HEAD"
    if sparse_paths:
        apply_sparse_cone(
            git_exe, consumer_dir, list(sparse_paths), env=env, extra_git_args=pin_args
        )
    run_git_text(
        [
            git_exe,
            *git_no_hooks_args(),
            *pin_args,
            "-C",
            str(consumer_dir),
            "checkout",
            checkout_target,
        ],
        capture_output=True,
        timeout=60,
        env=env,
        check=True,
    )
    # Lenient: the package consumer rejects unresolvable links in its path.
    materialize_tracked_symlinks(
        git_exe,
        consumer_dir,
        list(sparse_paths) if sparse_paths else None,
        env=env,
        extra_git_args=[*git_no_hooks_args(), *pin_args],
        strict=False,
    )
    return resolved_sha


def clone_with_fallback(
    execute_transport_plan: Callable[..., None],
    repo_url_base: str,
    target_path: Path,
    *,
    progress_reporter: Any = None,
    dep_ref: DependencyReference | None = None,
    verbose_callback: Callable[[str], None] | None = None,
    repo_cls: Any = None,
    **clone_kwargs: Any,
) -> Repo:
    """Clone a working-tree repository following the TransportSelector plan.

    Thin adapter over the caller-supplied ``execute_transport_plan``
    callable (typically ``self._execute_transport_plan``) that supplies
    a working-tree clone action with a complete sanitized environment.

    Returns:
        The successfully cloned :class:`Repo`.

    Raises:
        RuntimeError: If the planned attempt(s) all fail.
    """
    repo_holder: list[Repo] = []
    git_repo = bind_git_name(globals(), "Repo")
    _repo = repo_cls if repo_cls is not None else git_repo
    supported = {"branch", "depth", "no_checkout", "single_branch"}
    unsupported = sorted(set(clone_kwargs) - supported)
    if unsupported:
        raise TypeError(f"Unsupported clone options: {', '.join(unsupported)}")

    def _wt_action(url: str, env: dict[str, str], target: Path) -> None:
        from ..utils.git_env import clone_git_worktree, git_subprocess_env

        # Retries always start from a clean target, matching the bare path.
        if target.exists():
            _rmtree(target)
        if repo_cls is not None and repo_cls is not git_repo:
            repo_holder.append(
                getattr(_repo, "clone_from")(  # noqa: B009 - injected test double only
                    url,
                    target,
                    env=git_subprocess_env(env),
                    progress=progress_reporter,
                    **clone_kwargs,
                )
            )
            return
        extra_options = ("--single-branch",) if bool(clone_kwargs.get("single_branch")) else ()
        clone_git_worktree(
            url,
            target,
            env=env,
            depth=clone_kwargs.get("depth"),
            branch=clone_kwargs.get("branch"),
            no_checkout=bool(clone_kwargs.get("no_checkout")),
            extra_options=extra_options,
            progress=progress_reporter,
        )
        repo_holder.append(_repo(target))

    execute_transport_plan(
        repo_url_base,
        target_path,
        dep_ref=dep_ref,
        clone_action=_wt_action,
        verbose_callback=verbose_callback,
    )
    return repo_holder[0]


def _git_failure_text(error: Exception) -> str:
    """Return captured command text for internal marker classification only.

    The result may contain credentials, key paths, or remote-controlled text.
    Never surface it to users, logs, or exception messages.
    """
    parts = [str(error)]
    for attr in ("stderr", "stdout"):
        stream = getattr(error, attr, None)
        if not stream:
            continue
        if isinstance(stream, bytes):
            parts.append(stream.decode("utf-8", errors="replace"))
        else:
            parts.append(str(stream))
    return " ".join(part.strip() for part in parts if part and part.strip())


def _is_ssh_key_auth_failure(error_text: str, last_attempt_scheme: str | None) -> bool:
    """Return True for passphrase or public-key errors from an SSH attempt."""
    if (last_attempt_scheme or "").lower() != "ssh":
        return False

    text = error_text.lower()
    markers = (
        "enter passphrase for key",
        "incorrect passphrase supplied",
        "bad passphrase",
        "read_passphrase",
        "permission denied (publickey)",
        # OpenSSH BatchMode=yes output when all keys are skipped (e.g. an
        # encrypted key with no ssh-agent loaded).
        "no supported authentication methods remain",
        "no more authentication methods to try",
    )
    return any(marker in text for marker in markers)


def _ssh_key_auth_diagnostic(
    last_error: Exception | None,
    last_attempt_scheme: str | None,
) -> str:
    """Build an SSH key diagnostic, or an empty string when unrelated."""
    if last_error is None:
        return ""
    if not _is_ssh_key_auth_failure(_git_failure_text(last_error), last_attempt_scheme):
        return ""
    return (
        " SSH key authentication failed while APM ran git non-interactively. "
        "Verify that the key is available to SSH. For a passphrase-protected key, "
        "unlock it before running APM (for example, with 'ssh-add <key-file>'). "
        "In CI, load a dedicated deploy key non-interactively, or switch the "
        "dependency to token-backed HTTPS. APM does not open an interactive "
        "passphrase prompt during clone."
    )


def build_clone_failure_message(
    *,
    repo_url_base: str,
    plan: Any,
    dep_ref: DependencyReference | None,
    dep_host: str | None,
    is_ado: bool,
    is_generic: bool,
    has_ado_token: bool,
    has_token: bool,
    auth_resolver: Any,
    configured_github_host: str,
    default_host_fn: Callable[[], str],
    last_error: Exception | None,
    last_attempt_scheme: str | None,
    public_github_non_auth_failure: bool = False,
    repository_not_found: bool = False,
) -> str:
    """Build the aggregate ``RuntimeError`` message for a failed transport plan.

    Extracted from :meth:`GitHubPackageDownloader._execute_transport_plan`
    to keep that module under the file-length guardrail. Pure formatting:
    no I/O, no clone attempts. A host that answered "not found" gets the
    canonical not-found message alone: protocol fallback and network advice
    cannot help a missing repository.
    """
    if repository_not_found:
        return auth_resolver.build_not_found_message(
            dep_host or default_host_fn(),
            repo_url_base,
            dependency_repository_owner(dep_ref) if dep_ref else None,
            port=dep_ref.port if dep_ref else None,
            host_type=dep_ref.host_type if dep_ref else None,
        )
    if plan.strict and len(plan.attempts) >= 1:
        tried = plan.attempts[0].label
        error_msg = f"Failed to clone repository {repo_url_base} via {tried}. "
        if plan.fallback_hint:
            error_msg += plan.fallback_hint + " "
    else:
        error_msg = f"Failed to clone repository {repo_url_base} using all available methods. "
    effective_scheme = last_attempt_scheme
    for attempt in reversed(plan.attempts):
        if attempt.scheme != last_attempt_scheme:
            continue
        effective_url = getattr(attempt, "effective_url", None)
        if isinstance(effective_url, str) and effective_url:
            effective_scheme = urlsplit(effective_url).scheme.lower()
            break
    if effective_scheme == "file":
        error_msg += (
            "The configured local Git mirror failed. Verify that its path exists "
            "and is readable, then inspect the matching rule with "
            "'git config --show-origin --get-regexp ^url\\..*\\.insteadOf$'."
        )
    elif is_ado and getattr(last_error, "attempts", None) is not None:
        # The exhausted ADO chain names every credential step in order; it
        # leads the message and replaces the generic "Last error" suffix.
        error_msg += f"{last_error} " + auth_resolver.build_error_context(
            dep_host or "dev.azure.com",
            "clone",
            org=dep_ref.ado_organization if dep_ref else None,
            port=dep_ref.port if dep_ref else None,
            dep_url=dep_ref.repo_url if dep_ref else None,
            attempts=last_error.attempts,
        )
        return error_msg
    elif is_ado and not has_ado_token:
        host = dep_host or "dev.azure.com"
        error_msg += auth_resolver.build_error_context(
            host,
            "clone",
            org=dep_ref.ado_organization if dep_ref else None,
            port=dep_ref.port if dep_ref else None,
            dep_url=dep_ref.repo_url if dep_ref else None,
        )
    elif is_generic:
        if dep_host:
            host_info = auth_resolver.classify_host(
                dep_host,
                port=dep_ref.port if dep_ref else None,
            )
            host_name = host_info.display_name
        else:
            host_name = "the target host"
        error_msg += (
            f"For private repositories on {host_name}, configure SSH keys or a git "
            "credential helper. APM delegates authentication to git for "
            "non-GitHub/ADO hosts."
        )
    elif (
        configured_github_host
        and dep_host
        and dep_host == configured_github_host
        and configured_github_host != "github.com"
    ):
        suggested = f"github.com/{repo_url_base}"
        if dep_ref and dep_ref.virtual_path:
            suggested += f"/{dep_ref.virtual_path}"
        error_msg += (
            f"GITHUB_HOST is set to '{configured_github_host}', so shorthand dependencies "
            f"(without a hostname) resolve against that host. "
            f"If this package lives on a different server (e.g., github.com), "
            f"use the full hostname in apm.yml: {suggested}"
        )
    elif public_github_non_auth_failure:
        error_msg += (
            f"Could not connect to {dep_host or default_host_fn()} "
            "(network error, not an auth failure). "
            "Check your internet connection and proxy settings. "
            "Run with --verbose for details."
        )
    elif not has_token:
        host = dep_host or default_host_fn()
        org = dependency_repository_owner(dep_ref) if dep_ref else None
        error_msg += auth_resolver.build_error_context(
            host,
            "clone",
            org=org,
            port=dep_ref.port if dep_ref else None,
            dep_url=dep_ref.repo_url if dep_ref else None,
        )
    else:
        error_msg += "Please check repository access permissions and authentication setup."

    error_msg += _ssh_key_auth_diagnostic(last_error, last_attempt_scheme)

    if last_error:
        from ..utils.git_env import git_subprocess_error_text

        error_msg += f" Last error: {git_subprocess_error_text(last_error)}"

    return error_msg


def __getattr__(name: str) -> Any:
    # ``Repo`` stays a module attribute (a patch target) without importing
    # GitPython until a clone needs it.
    if name == "Repo":
        return bind_git_name(globals(), name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
