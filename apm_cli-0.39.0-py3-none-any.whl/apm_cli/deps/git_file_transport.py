"""Git-transport-first single-file fetcher for path:-specifier deps (issue #1014).

When a dependency's source is already a git/SSH repo, this module
extracts path:-specified files through a sparse/partial git checkout
(blob:none + sparse paths) rather than calling the host REST API. This
fixes self-hosted GitLab instances where the API returns 410 (disabled).

Design constraints
------------------
* git-transport-first: git is tried before the REST API for GitLab and
  generic git sources.
* No new credentials: SSH keys and system git credential fill are used;
  the function inherits the same auth environment as regular clones.
* ensure_path_within() is applied to the materialized path before
  reading it, preventing traversal and symlink-escape attacks.
* Same-run batching: callers can reuse one sparse/partial checkout for
  multiple files from the same repo/ref. The temp directory is cleaned
  up when the transport closes.
* File-level sparse-checkout uses non-cone sparse paths (git 2.25+) so
  root-level files do not trigger whole-tree materialization.
"""

from __future__ import annotations

import contextlib
import os
import re
import subprocess
import sys
import tempfile
import threading
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from ..utils.git_env import (
    get_git_executable,
    git_no_hooks_args,
    git_no_templates_args,
    redact_git_diagnostic,
    run_git_text,
)
from ..utils.path_security import PathTraversalError, ensure_path_within, validate_path_segments

if TYPE_CHECKING:
    from ..models.apm_package import DependencyReference

_GIT_TIMEOUT = 120  # seconds per git subprocess


class GitFileTransportError(RuntimeError):
    """Transport-level git failure during path-scoped file fetch."""


class GitFileTransportSecurityError(ValueError):
    """Security validation failure before invoking git transport."""


@dataclass(frozen=True)
class GitFileFetchResult:
    """A sparse-file payload and the exact commit Git fetched for it."""

    content: bytes
    resolved_commit: str


def _debug(message: str) -> None:
    """Print debug message if APM_DEBUG environment variable is set."""
    if os.environ.get("APM_DEBUG"):
        print(f"[DEBUG] {redact_git_diagnostic(message)}", file=sys.stderr)


class GitSparseFileTransport:
    """Reusable sparse/partial checkout for path-scoped git file fetches."""

    def __init__(
        self,
        dep_ref: DependencyReference,
        ref: str,
        *,
        build_repo_url_fn: Callable[..., str],
        git_env: dict[str, str],
        timeout: int = _GIT_TIMEOUT,
    ) -> None:
        """Create a reusable sparse checkout for one repository and ref."""
        if ref.startswith("-"):
            raise GitFileTransportSecurityError("Invalid git ref: refs must not start with '-'")
        self._dep_ref = dep_ref
        self._ref = ref
        self._build_repo_url_fn = build_repo_url_fn
        self._git_env = {**git_env, "GIT_TERMINAL_PROMPT": "0", "GIT_ASKPASS": "echo"}
        self._timeout = timeout
        self._temp_dir = tempfile.TemporaryDirectory(prefix="apm_gitfetch_")
        with contextlib.suppress(OSError):
            Path(self._temp_dir.name).chmod(0o700)
        self._work_dir = Path(self._temp_dir.name) / "work"
        self._auth_url: str | None = None
        self._sparse_paths: set[str] = set()
        self._requested_paths: set[str] = set()
        self._initialized = False
        self._lock = threading.Lock()
        self._state = threading.Condition()
        self._active_fetches = 0
        self._closed = False

    def __enter__(self) -> GitSparseFileTransport:
        """Return this transport as a context manager value."""
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        """Clean up the temporary checkout when the context exits."""
        self.close()

    def close(self) -> None:
        """Remove the temporary checkout backing this transport."""
        with self._state:
            if self._closed:
                return
            self._closed = True
            while self._active_fetches:
                self._state.wait()
        with self._lock:
            self._temp_dir.cleanup()
            self._auth_url = None

    def fetch_file(self, file_path: str) -> bytes:
        """Fetch one file from the transport's repository/ref."""
        result = self._fetch_file(file_path, include_commit=False)
        if not isinstance(result, bytes):
            raise GitFileTransportError(
                "git file fetch returned commit metadata for a bytes request"
            )
        return result

    def fetch_file_with_commit(self, file_path: str) -> GitFileFetchResult:
        """Fetch one file and return the exact commit selected by ``FETCH_HEAD``."""
        result = self._fetch_file(file_path, include_commit=True)
        if not isinstance(result, GitFileFetchResult):
            raise GitFileTransportError("git file fetch omitted commit metadata")
        return result

    def _fetch_file(self, file_path: str, *, include_commit: bool) -> bytes | GitFileFetchResult:
        """Materialize and read one containment-checked sparse file."""
        validate_path_segments(file_path, context="path")
        with self._state:
            if self._closed:
                raise GitFileTransportError("git file transport is closed")
            self._requested_paths.add(file_path)
            self._active_fetches += 1
        try:
            with self._lock:
                self._ensure_checkout(file_path)
                self._materialize_links(file_path)
                target = self._work_dir / file_path
                ensure_path_within(target, self._work_dir)
                if not target.exists():
                    raise GitFileTransportError(
                        f"File '{file_path}' not found after git sparse checkout of "
                        f"{self._dep_ref.host}/{self._dep_ref.repo_url}@{self._ref}. "
                        "Verify the path exists at that ref "
                        f"(try `git ls-tree -r --name-only {self._ref} -- {file_path}`)."
                    )

                # The lock serializes sparse-checkout expansion and the
                # containment/read pair so another checkout cannot race the
                # target between ensure_path_within() and read_bytes().
                content = target.read_bytes()
                if not include_commit:
                    return content
                result = self._run(
                    [get_git_executable(), "rev-parse", "--verify", "FETCH_HEAD^{commit}"]
                )
                resolved_commit = result.stdout.strip()
                if not re.fullmatch(r"[0-9a-f]{40}", resolved_commit, flags=re.IGNORECASE):
                    raise GitFileTransportError(
                        "git file fetch did not resolve FETCH_HEAD to a full commit SHA"
                    )
                return GitFileFetchResult(content=content, resolved_commit=resolved_commit.lower())
        finally:
            with self._state:
                self._active_fetches -= 1
                if self._active_fetches == 0:
                    self._state.notify_all()

    def _ensure_checkout(self, file_path: str) -> None:
        """Initialize or expand the sparse checkout for file_path."""
        self._work_dir.mkdir(exist_ok=True)
        if not self._initialized:
            self._auth_url = self._build_repo_url_fn(
                self._dep_ref.repo_url,
                dep_ref=self._dep_ref,
            )
            self._run([get_git_executable(), "init", *git_no_templates_args()])
            from ..utils.git_env import git_network_env

            self._git_env = git_network_env(
                self._auth_url,
                self._git_env,
                worktree=self._work_dir,
            )
            self._run([get_git_executable(), "remote", "add", "origin", self._auth_url])
            self._git_env = git_network_env(
                self._auth_url,
                self._git_env,
                worktree=self._work_dir,
            )
            self._run([get_git_executable(), "sparse-checkout", "init", "--no-cone"])
            with self._state:
                requested_paths = tuple(self._requested_paths)
            self._set_sparse_paths(*requested_paths)
            _debug(
                "git sparse fetch: "
                f"host={self._dep_ref.host} repo={self._dep_ref.repo_url} "
                f"ref={self._ref} paths={len(self._sparse_paths)}"
            )
            self._run(
                [
                    get_git_executable(),
                    "fetch",
                    "--filter=blob:none",
                    "--depth=1",
                    "origin",
                    self._ref,
                ]
            )
            self._run([get_git_executable(), *git_no_hooks_args(), "checkout", "FETCH_HEAD"])
            self._initialized = True
            return

        if file_path not in self._sparse_paths:
            self._set_sparse_paths(file_path)
            self._run([get_git_executable(), *git_no_hooks_args(), "checkout", "FETCH_HEAD"])

    def _materialize_links(self, file_path: str) -> None:
        """Replace a tracked link at *file_path* with its Git-object content (#3457)."""
        from ..utils.git_env import git_subprocess_env
        from ..utils.git_sparse import materialize_tracked_symlinks

        try:
            materialize_tracked_symlinks(
                get_git_executable(),
                self._work_dir,
                [file_path],
                env=git_subprocess_env(self._git_env),
                timeout=self._timeout,
                extra_git_args=list(git_no_hooks_args()),
            )
        except (PathTraversalError, RuntimeError, subprocess.SubprocessError) as exc:
            raise GitFileTransportError(
                f"git file fetch could not resolve '{file_path}': {exc}"
            ) from exc

    def _set_sparse_paths(self, *file_paths: str) -> None:
        """Apply the accumulated file-level sparse paths."""
        self._sparse_paths.update(file_paths)
        self._run(
            [
                get_git_executable(),
                "sparse-checkout",
                "set",
                "--no-cone",
                "--",
                *sorted(self._sparse_paths),
            ]
        )

    def _run(self, cmd: list[str]) -> subprocess.CompletedProcess[str]:
        """Run one git command and raise a sanitized error on failure."""
        from ..utils.git_env import git_subprocess_env, redact_git_diagnostic

        try:
            result = run_git_text(
                cmd,
                cwd=str(self._work_dir),
                env=git_subprocess_env(self._git_env),
                capture_output=True,
                timeout=self._timeout,
            )
        except subprocess.TimeoutExpired as exc:
            raise GitFileTransportError(f"git file fetch timed out: {' '.join(cmd[:3])}") from exc
        if result.returncode != 0:
            safe_stderr = redact_git_diagnostic(result.stderr.strip())
            raise GitFileTransportError(
                f"git file fetch failed: {' '.join(cmd[:3])}: {safe_stderr}"
            )
        return result


def fetch_file_via_git_sparse(
    dep_ref: DependencyReference,
    file_path: str,
    ref: str,
    *,
    build_repo_url_fn: Callable[..., str],
    git_env: dict[str, str],
    timeout: int = _GIT_TIMEOUT,
) -> bytes:
    """Fetch a single file from a git repo via sparse/partial checkout.

    Performs a depth-1, blob:none sparse checkout to extract only the
    requested file without downloading the full repository. Applies
    ensure_path_within() containment on the materialized path to reject
    symlink/traversal escapes from a cloned repository.

    Args:
        dep_ref: Parsed dependency reference (host, repo_url, etc.).
        file_path: Path to the file within the repository (e.g.
            ``"agents/api-specialist.agent.md"``).
        ref: Git ref (branch, tag, or commit SHA).
        build_repo_url_fn: Callable that returns a credential-free clone
            URL for dep_ref. Injected to avoid circular imports with the
            owning downloader.
        git_env: Subprocess environment dict (inherits git auth, e.g.
            GIT_ASKPASS, GH_TOKEN, SSH agent forwarding).
        timeout: Per-subprocess timeout in seconds.

    Returns:
        bytes: Raw file content.

    Raises:
        PathTraversalError: If file_path contains traversal segments
            (``..``) or the checked-out file is a symlink that escapes
            the temporary work tree.
        RuntimeError: If any git command fails or the file is absent
            after checkout.
    """
    with GitSparseFileTransport(
        dep_ref,
        ref,
        build_repo_url_fn=build_repo_url_fn,
        git_env=git_env,
        timeout=timeout,
    ) as transport:
        return transport.fetch_file(file_path)
