"""Backend-specific download delegates for APM packages.

Encapsulates HTTP resilient-get, GitHub API file download, Azure DevOps
file download, and Artifactory archive download logic.  The owning
:class:`~apm_cli.deps.github_downloader.GitHubPackageDownloader` creates
a single :class:`DownloadDelegate` instance and delegates download
operations to it (Facade/Delegate pattern).
"""

import base64
import json
import os
import random
import sys
import tempfile
import threading
import time
import weakref
import zipfile
from functools import partial
from pathlib import Path
from urllib.parse import quote, urlsplit

import requests

from ..cache.url_normalize import normalize_repo_url
from ..core.auth import AuthResolver, HostInfo
from ..core.auth_chain import AdoAuthChainExhaustedError
from ..core.auth_outcome import AuthAttemptFailed
from ..models.apm_package import DependencyReference
from ..models.dependency.host_virtual import dependency_repository_owner, repository_owner_and_repo
from ..utils.archive import ArchiveError, read_zip_member, safe_extract_zip
from ..utils.console import _rich_warning
from ..utils.git_env import redact_git_diagnostic, validate_git_url_rewrite_safety
from ..utils.github_host import (
    build_ado_api_url,
    build_artifactory_archive_url,
    build_raw_content_url,
    default_host,
    is_github_hostname,
)
from ..utils.http_credentials import unfollowed_redirect_request
from .artifactory_entry import _NoNetrcSession
from .git_file_transport import (
    GitFileFetchResult,
    GitFileTransportError,
    GitSparseFileTransport,
)
from .github_rate_limit import GitHubThrottleError, github_throttle_error
from .host_backends import backend_for
from .transport_selection import fallback_port_warning, initial_transport_scheme

# ---------------------------------------------------------------------------
# Module-level debug helper (mirrors the one in github_downloader so that
# this module has no import dependency on the orchestrator).
# ---------------------------------------------------------------------------


def _debug(message: str) -> None:
    """Print debug message if APM_DEBUG environment variable is set."""
    if os.environ.get("APM_DEBUG"):
        print(f"[DEBUG] {redact_git_diagnostic(message)}", file=sys.stderr)


def _close_response(response: requests.Response, context: str) -> None:
    """Close an HTTP response and preserve failures in debug diagnostics."""
    try:
        response.close()
    except Exception as exc:
        _debug(f"{context} response close failed: {exc}")


def _backoff_sleep(seconds: float) -> None:
    """Wait between resilient_get retries.

    The single retry-wait seam: tests patch this instead of the process-wide
    ``time.sleep``, which would also record sleeps from unrelated threads.
    """
    time.sleep(seconds)


_ARTIFACTORY_DOWNLOAD_CHUNK_BYTES = 1024 * 1024


def _close_git_file_transports(transports: dict[object, object]) -> None:
    """Close cached git file transports owned by a DownloadDelegate."""
    for transport in list(transports.values()):
        close = getattr(transport, "close", None)
        if close is not None:
            try:
                close()
            except Exception as exc:
                _debug(f"git file transport cleanup failed: {exc}")
    transports.clear()


# ---------------------------------------------------------------------------
# DownloadDelegate
# ---------------------------------------------------------------------------


class DownloadDelegate:
    """Facade/Delegate that encapsulates backend-specific download logic.

    Holds the real implementations of HTTP resilient-get, URL building,
    and file download methods for GitHub, Azure DevOps, and Artifactory
    backends.

    A back-reference to the owning ``GitHubPackageDownloader`` (*host*)
    is kept as a known trade-off: it creates a circular reference
    between the delegate and its owner, but avoids duplicating shared
    state (``auth_resolver``, tokens, ``registry_config``) and
    preserves existing test ``patch.object`` points on the orchestrator.
    """

    def __init__(self, host, git_file_transport_factory=None):
        """Initialize with a reference to the owning downloader.

        Args:
            host: The :class:`GitHubPackageDownloader` instance that owns
                this delegate.
        """
        self._host = host
        self._git_file_transports: dict[tuple[str, str, str, str, str], GitSparseFileTransport] = {}
        self._git_file_transports_lock = threading.Lock()
        self._git_file_transport_factory = git_file_transport_factory
        self._git_file_transport_finalizer = weakref.finalize(
            self,
            _close_git_file_transports,
            self._git_file_transports,
        )

    # ------------------------------------------------------------------
    # HTTP resilient GET
    # ------------------------------------------------------------------

    def resilient_get(
        self,
        url: str,
        headers: dict[str, str],
        timeout: int = 30,
        max_retries: int = 3,
        *,
        stream: bool = False,
        retry_throttles: bool = True,
        allow_netrc: bool = True,
        redirect_base: str | None = None,
    ) -> requests.Response:
        """HTTP GET with selectable retries for transient HTTP failures.

        Args:
            url: Request URL
            headers: HTTP headers
            timeout: Request timeout in seconds
            max_retries: Maximum total attempts, including the initial request
            stream: Whether to stream the response body instead of buffering it
            retry_throttles: Whether general callers retry a classified
                throttle. Virtual-file download callers disable this so they
                can select sparse Git without a retry or sleep.
            allow_netrc: Whether Requests may use ambient netrc credentials.
            redirect_base: When set, every attempt goes through the redirect
                owner (``unfollowed_redirect_request``) with *url* bounded to
                this base. No redirect is followed: a 3xx is returned so the
                auth-outcome classifier sees it.

        Returns:
            requests.Response (caller should call .raise_for_status() as needed)

        Raises:
            requests.exceptions.RequestException: After all retries exhausted
        """
        last_exc = None
        last_response = None
        for attempt in range(max_retries):
            try:
                if redirect_base is not None:
                    response = unfollowed_redirect_request(
                        "GET",
                        url,
                        base_url=redirect_base,
                        headers=headers,
                        timeout=timeout,
                        stream=stream,
                        ambient_credentials=allow_netrc,
                    )
                elif allow_netrc:
                    response = requests.get(
                        url,
                        headers=headers,
                        timeout=timeout,
                        stream=stream,
                    )
                else:
                    with _NoNetrcSession() as session:
                        response = session.get(
                            url,
                            headers=headers,
                            timeout=timeout,
                            stream=stream,
                        )

                throttle = github_throttle_error(response, "GitHub API")
                if throttle is not None:
                    if not retry_throttles:
                        return response
                    last_response = response
                    if attempt < max_retries - 1:
                        wait = throttle.throttle.retry_after_seconds
                        if wait is None:
                            wait = min(2**attempt, 30) * (0.5 + random.random())  # noqa: S311
                        else:
                            wait = min(wait, 60)
                        _debug(
                            f"Rate limited ({response.status_code}), retry in "
                            f"{wait:.1f}s (attempt {attempt + 1}/{max_retries})"
                        )
                        _close_response(response, "rate-limit retry")
                        _backoff_sleep(wait)
                    continue

                if response.status_code == 503:
                    last_response = response
                    if attempt < max_retries - 1:
                        wait = min(2**attempt, 30) * (0.5 + random.random())  # noqa: S311
                        _debug(
                            f"Service unavailable, retry in {wait:.1f}s "
                            f"(attempt {attempt + 1}/{max_retries})"
                        )
                        _close_response(response, "service-unavailable retry")
                        _backoff_sleep(wait)
                    continue

                return response
            except requests.exceptions.ConnectionError as e:
                last_exc = e
                if attempt < max_retries - 1:
                    wait = min(2**attempt, 30) * (0.5 + random.random())  # noqa: S311
                    _debug(
                        f"Connection error, retry in {wait:.1f}s "
                        f"(attempt {attempt + 1}/{max_retries})"
                    )
                    _backoff_sleep(wait)
            except requests.exceptions.Timeout as e:
                last_exc = e
                if attempt < max_retries - 1:
                    _debug(f"Timeout, retrying (attempt {attempt + 1}/{max_retries})")

        # A retryable service failure returns its final response for the caller
        # to inspect and render.
        if last_response is not None:
            return last_response

        if last_exc:
            raise last_exc
        raise requests.exceptions.RequestException(f"All {max_retries} attempts failed for {url}")

    # ------------------------------------------------------------------
    # Repository URL building
    # ------------------------------------------------------------------

    def build_repo_url(
        self,
        repo_ref: str,
        use_ssh: bool = False,
        *,
        dep_ref: DependencyReference,
    ) -> str:
        """Build the credential-free repository URL for cloning.

        Supports both GitHub and Azure DevOps URL formats:
        - GitHub: https://github.com/owner/repo.git
        - ADO: https://dev.azure.com/org/project/_git/repo

        Credentials are never embedded in the URL; they are injected via
        git env (``http.extraheader`` / credential helpers) by
        :class:`AuthResolver`.

        Args:
            repo_ref: Repository reference in format "owner/repo" or
                "org/project/repo" for ADO (kept for call-site symmetry;
                the URL is derived from ``dep_ref``)
            use_ssh: Whether to use SSH URL for git operations
            dep_ref: DependencyReference describing host, port, and repo

        Returns:
            str: Repository URL suitable for git clone operations
        """
        # Fall back to the configured default host when the dep_ref
        # carries none (e.g. shorthand ``owner/repo`` references).
        host = dep_ref.host or getattr(self._host, "github_host", None) or default_host()

        # Pick the vendor-specific backend via ``classify_host`` -- this
        # replaces the in-line ``if is_ado / elif is_github / else`` ladder
        # with a single dispatch.
        backend = backend_for(
            dep_ref,
            self._host.auth_resolver,
            fallback_host=host,
        )

        is_ado = backend.kind == "ado"
        is_insecure = bool(getattr(dep_ref, "is_insecure", False))

        _debug(
            f"build_repo_url: host={host}, kind={backend.kind}, ado_org={dep_ref.ado_organization}"
        )

        # ADO without a parsed ``ado_organization`` cannot use the ADO
        # builders (they need org/project/repo). Fall through to the
        # generic GitHub-style URL the way the previous ladder did.
        if is_ado and not dep_ref.ado_organization:
            backend = backend_for(
                None,
                self._host.auth_resolver,
                fallback_host=host,
            )

        if use_ssh:
            return backend.build_clone_ssh_url(dep_ref)
        if is_insecure:
            return backend.build_clone_http_url(dep_ref)
        return backend.build_clone_https_url(dep_ref)

    # ------------------------------------------------------------------
    # Artifactory helpers
    # ------------------------------------------------------------------

    def get_artifactory_headers(self, *, scheme: str, host: str) -> dict[str, str]:
        """Build registry auth headers for a request to ``scheme://host``.

        The registry token is scoped to the configured ``PROXY_REGISTRY_URL``
        origin (see :meth:`RegistryConfig.headers_for`); requests to any
        other origin carry no registry credential.
        """
        cfg = self._host.registry_config
        if cfg is None:
            return {}
        return cfg.headers_for(scheme, host)

    def _stream_artifactory_archive(
        self,
        response: requests.Response,
        output_path: Path,
        url: str,
        max_archive_bytes: int,
    ) -> None:
        """Stream an Artifactory archive response to disk with a byte cap."""
        content_length = response.headers.get("Content-Length", "")
        if content_length:
            try:
                declared_size = int(content_length)
            except (TypeError, ValueError):
                declared_size = None
            else:
                if declared_size > max_archive_bytes:
                    raise ArchiveError(f"Archive too large ({declared_size} bytes) from {url}")

        total_bytes = 0
        with open(output_path, "wb") as archive_file:
            for chunk in response.iter_content(chunk_size=_ARTIFACTORY_DOWNLOAD_CHUNK_BYTES):
                if not chunk:
                    continue
                total_bytes += len(chunk)
                if total_bytes > max_archive_bytes:
                    raise ArchiveError(f"Archive too large ({total_bytes} bytes) from {url}")
                archive_file.write(chunk)

    def _extract_artifactory_zip(self, zf: zipfile.ZipFile, target_path: Path, url: str) -> None:
        """Extract an Artifactory VCS archive with shared ZIP safety guards."""
        names = zf.namelist()
        if not names:
            raise RuntimeError(f"Empty archive from {url}")

        root_prefix = names[0]
        if root_prefix.endswith("/"):

            def _strip_root(member_name: str) -> str | None:
                if member_name == root_prefix:
                    return None
                if not member_name.startswith(root_prefix):
                    raise ArchiveError(
                        f"Archive member is outside root prefix {root_prefix!r}: {member_name!r}"
                    )
                rel_path = member_name[len(root_prefix) :]
                return rel_path or None

            safe_extract_zip(
                zf,
                target_path,
                error_type=ArchiveError,
                member_name_transform=_strip_root,
            )
            return

        safe_extract_zip(zf, target_path, error_type=ArchiveError)

    def download_artifactory_archive(
        self,
        host: str,
        prefix: str,
        owner: str,
        repo: str,
        ref: str,
        target_path: Path,
        scheme: str = "https",
    ) -> None:
        """Download and extract a zip archive from Artifactory VCS proxy.

        Tries multiple URL patterns (GitHub-style and GitLab-style).
        GitHub archives contain a single root directory named {repo}-{ref}/;
        this method strips that prefix on extraction so files land directly
        in *target_path*.

        Raises RuntimeError on failure.
        """
        import zipfile

        from ..config import get_apm_temp_dir

        archive_urls = build_artifactory_archive_url(host, prefix, owner, repo, ref, scheme=scheme)
        headers = self.get_artifactory_headers(scheme=scheme, host=host)

        # Guard: reject unreasonably large archives (default 500 MB)
        max_archive_bytes = int(os.environ.get("ARTIFACTORY_MAX_ARCHIVE_MB", "500")) * 1024 * 1024

        last_error = None
        # A 200 archive that fails validation is a more useful cause than a
        # later 404 from a fallback URL, so report it unless a later URL succeeds.
        archive_error = None
        for url in archive_urls:
            _debug(f"Trying Artifactory archive: {url}")
            resp = None
            try:
                resp = self._host._resilient_get(
                    url,
                    headers=headers,
                    timeout=60,
                    stream=True,
                    allow_netrc=False,
                )
                if resp.status_code == 200:
                    target_path.mkdir(parents=True, exist_ok=True)
                    with tempfile.TemporaryDirectory(dir=get_apm_temp_dir()) as temp_dir:
                        archive_path = Path(temp_dir) / "artifactory-download.zip"
                        self._stream_artifactory_archive(
                            resp,
                            archive_path,
                            url,
                            max_archive_bytes,
                        )
                        with zipfile.ZipFile(archive_path) as zf:
                            self._extract_artifactory_zip(zf, target_path, url)
                    _debug(f"Extracted Artifactory archive to {target_path}")
                    return
                else:
                    last_error = f"HTTP {resp.status_code} from {url}"
                    _debug(last_error)
            except ArchiveError as e:
                last_error = f"Unsafe zip archive from {url}: {e}"
                archive_error = archive_error or last_error
                _debug(last_error)
            except zipfile.BadZipFile:
                last_error = f"Invalid zip archive from {url}"
                archive_error = archive_error or last_error
                _debug(last_error)
            except requests.RequestException as e:
                last_error = str(e)
                _debug(f"Request failed: {last_error}")
            finally:
                if resp is not None:
                    _close_response(resp, "artifactory archive")

        detail = f"Archive error: {archive_error}" if archive_error else f"Last error: {last_error}"
        raise RuntimeError(
            f"Failed to download package {owner}/{repo}#{ref} from Artifactory "
            f"({host}/{prefix}). {detail}"
        )

    def download_file_from_artifactory(
        self,
        host: str,
        prefix: str,
        owner: str,
        repo: str,
        file_path: str,
        ref: str,
        scheme: str = "https",
    ) -> bytes:
        """Download a single file from Artifactory.

        Tries the Archive Entry Download API first (fetches one file
        without downloading the full archive).  Falls back to the full
        archive approach when the entry API is unavailable or returns an
        error.
        """
        # Fast path: use the RegistryClient interface for entry download
        artifactory_get = partial(self._host._resilient_get, allow_netrc=False)
        cfg = self._host.registry_config
        if cfg is not None and cfg.host == host:
            client = cfg.get_client()
            content = client.fetch_file(
                owner,
                repo,
                file_path,
                ref,
                resilient_get=artifactory_get,
            )
        else:
            # No RegistryConfig or host mismatch (explicit FQDN mode) --
            # fall back to the standalone helper.
            from .artifactory_entry import fetch_entry_from_archive

            content = fetch_entry_from_archive(
                host,
                prefix,
                owner,
                repo,
                file_path,
                ref,
                scheme=scheme,
                headers=self.get_artifactory_headers(scheme=scheme, host=host),
                resilient_get=artifactory_get,
            )
        if content is not None:
            return content

        # Fallback: download full archive and extract the file
        import io
        import zipfile

        archive_urls = build_artifactory_archive_url(host, prefix, owner, repo, ref, scheme=scheme)
        headers = self.get_artifactory_headers(scheme=scheme, host=host)

        for url in archive_urls:
            try:
                resp = self._host._resilient_get(
                    url,
                    headers=headers,
                    timeout=60,
                    allow_netrc=False,
                )
                if resp.status_code != 200:
                    continue
                with zipfile.ZipFile(io.BytesIO(resp.content)) as zf:
                    entries = zf.infolist()
                    root_prefix = entries[0].filename if entries else ""
                    for name in (root_prefix + file_path, file_path):
                        try:
                            entry = zf.getinfo(name)
                        except KeyError:
                            continue
                        return read_zip_member(zf, entry, error_type=ArchiveError)
            except (zipfile.BadZipFile, requests.RequestException):
                continue

        raise RuntimeError(
            f"Failed to download file '{file_path}' from Artifactory "
            f"({host}/{prefix}/{owner}/{repo}#{ref})"
        )

    # ------------------------------------------------------------------
    # Raw / CDN download helper
    # ------------------------------------------------------------------

    def try_raw_download(self, owner: str, repo: str, ref: str, file_path: str) -> bytes | None:
        """Attempt to fetch a file via raw.githubusercontent.com (CDN).

        This pre-auth helper must remain token-free: it runs before
        ``AuthResolver`` has established that credentials may be required.

        Returns the raw bytes on success, or ``None`` if the file was not found
        (HTTP 404) or the request failed for any reason.  This is intentionally
        best-effort: callers fall back to the Contents API when ``None`` is
        returned.
        """
        raw_url = build_raw_content_url(owner, repo, ref, file_path)
        try:
            response = requests.get(raw_url, timeout=30)
            if response.status_code == 200:
                return response.content
        except requests.exceptions.RequestException:
            pass
        return None

    # ------------------------------------------------------------------
    # Azure DevOps file download
    # ------------------------------------------------------------------

    def download_ado_file(
        self,
        dep_ref: DependencyReference,
        file_path: str,
        ref: str = "main",
    ) -> bytes:
        """Download a file from Azure DevOps repository.

        Args:
            dep_ref: Parsed dependency reference with ADO-specific fields
            file_path: Path to file within the repository
            ref: Git reference (branch, tag, or commit SHA)

        Returns:
            bytes: File content
        """
        # Validate required ADO fields before proceeding
        if not all([dep_ref.ado_organization, dep_ref.ado_project, dep_ref.ado_repo]):
            raise ValueError(
                "Invalid Azure DevOps dependency reference: missing "
                "organization, project, or repo. "
                f"Got: org={dep_ref.ado_organization}, "
                f"project={dep_ref.ado_project}, repo={dep_ref.ado_repo}"
            )

        host = dep_ref.host or "dev.azure.com"
        api_url = build_ado_api_url(
            dep_ref.ado_organization,
            dep_ref.ado_project,
            dep_ref.ado_repo,
            file_path,
            ref,
            host,
            dep_ref.port,
        )

        resolver = self._host.auth_resolver

        def _fetch(url: str) -> bytes:
            def _request(_token: str | None, git_env: dict[str, str]):
                # The auth chain picks the credential (PAT, az bearer, or the
                # path-scoped helper) and classifies every response, including
                # an HTML sign-in page; ambient netrc never overrides it.
                response = self._host._resilient_get(
                    url,
                    headers=resolver.http_authorization_headers(git_env),
                    timeout=30,
                    allow_netrc=False,
                    # No redirect is followed; a sign-in 3xx returns to the
                    # auth-outcome classifier.
                    redirect_base=url,
                )
                if response.status_code != 200:
                    raise AuthAttemptFailed(response=response)
                return response

            response = resolver.try_with_fallback(
                host,
                _request,
                org=dep_ref.ado_organization,
                port=dep_ref.port,
                path=dep_ref.repo_url,
            )
            return response.content

        try:
            try:
                return _fetch(api_url)
            except AuthAttemptFailed as failed:
                status = getattr(failed.response, "status_code", None)
                if isinstance(status, int) and 200 <= status < 300:
                    raise RuntimeError(
                        f"Unexpected HTTP {status} downloading {file_path} from Azure DevOps"
                    ) from failed
                if status != 404:
                    raise RuntimeError(f"Failed to download {file_path}: HTTP {status}") from failed
                if ref not in ["main", "master"]:
                    raise RuntimeError(
                        f"File not found: {file_path} at ref '{ref}' in {dep_ref.repo_url}"
                    ) from failed
                fallback_ref = "master" if ref == "main" else "main"
                fallback_url = build_ado_api_url(
                    dep_ref.ado_organization,
                    dep_ref.ado_project,
                    dep_ref.ado_repo,
                    file_path,
                    fallback_ref,
                    host,
                    dep_ref.port,
                )
                try:
                    return _fetch(fallback_url)
                except AuthAttemptFailed as fallback_failed:
                    raise RuntimeError(
                        f"File not found: {file_path} in {dep_ref.repo_url} "
                        f"(tried refs: {ref}, {fallback_ref})"
                    ) from fallback_failed
        except AdoAuthChainExhaustedError as exhausted:
            error_msg = f"Authentication failed for Azure DevOps {dep_ref.repo_url}. {exhausted}"
            error_msg += resolver.build_error_context(
                host,
                "download",
                org=dep_ref.ado_organization,
                port=dep_ref.port,
                dep_url=dep_ref.repo_url,
                attempts=exhausted.attempts,
            )
            raise RuntimeError(error_msg) from exhausted
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"Network error downloading {file_path}: {e}") from e

    def _git_file_transport_key(
        self,
        dep_ref: DependencyReference,
        ref: str,
        requested_url: str,
        effective_url: str,
        auth_mode: str,
    ) -> tuple[str, str, str, str, str]:
        """Return the cache key for one path-scoped Git file checkout."""
        provider = self._host.auth_resolver.classify_host(
            dep_ref.host or default_host(), port=dep_ref.port, host_type=dep_ref.host_type
        )
        return (
            provider.kind,
            ref,
            normalize_repo_url(requested_url),
            normalize_repo_url(effective_url),
            auth_mode,
        )

    def _discard_git_file_transport(
        self, key: tuple[str, str, str, str, str], failed_transport: GitSparseFileTransport
    ) -> None:
        """Close and remove a failed cached git-file checkout."""
        with self._git_file_transports_lock:
            if self._git_file_transports.get(key) is failed_transport:
                del self._git_file_transports[key]
        failed_transport.close()

    def _download_gitlab_file_via_git(
        self,
        dep_ref: DependencyReference,
        file_path: str,
        ref: str,
        *,
        requested_url: str,
        effective_url: str,
        git_env: dict[str, str],
        auth_mode: str,
    ) -> bytes:
        """Execute one prepared GitLab attempt through a reusable sparse checkout."""
        key = self._git_file_transport_key(dep_ref, ref, requested_url, effective_url, auth_mode)

        def _prepared_repo_url(repo_ref: str, *, dep_ref: DependencyReference) -> str:
            return requested_url

        with self._git_file_transports_lock:
            transport = self._git_file_transports.get(key)
            if transport is None:
                transport_factory = self._git_file_transport_factory or GitSparseFileTransport
                transport = transport_factory(
                    dep_ref,
                    ref,
                    build_repo_url_fn=_prepared_repo_url,
                    git_env=git_env,
                )
                self._git_file_transports[key] = transport
        try:
            return transport.fetch_file(file_path)
        except GitFileTransportError:
            self._discard_git_file_transport(key, transport)
            raise

    def _download_github_file_via_git(
        self,
        dep_ref: DependencyReference,
        file_path: str,
        ref: str,
    ) -> GitFileFetchResult:
        """Fetch a throttled GitHub virtual file through one sparse Git transport."""
        host = dep_ref.host or default_host()
        if (
            self._host.auth_resolver.uses_public_github_anonymous_first(
                host,
                port=dep_ref.port,
                host_type=dep_ref.host_type,
            )
            is True
        ):

            def _fetch(
                _token: str | None,
                git_env: dict[str, str],
            ) -> GitFileFetchResult:
                attempt_env = dict(git_env)

                def _tokenless_repo_url(
                    repo_ref: str,
                    *,
                    dep_ref: DependencyReference,
                ) -> str:
                    return self.build_repo_url(repo_ref, dep_ref=dep_ref)

                transport_factory = self._git_file_transport_factory or GitSparseFileTransport
                transport = transport_factory(
                    dep_ref,
                    ref,
                    build_repo_url_fn=_tokenless_repo_url,
                    git_env=attempt_env,
                )
                try:
                    return transport.fetch_file_with_commit(file_path)
                finally:
                    transport.close()

            return self._host.auth_resolver.try_with_fallback(
                host,
                _fetch,
                org=dependency_repository_owner(dep_ref),
                port=dep_ref.port,
                path=dep_ref.repo_url,
                host_type=dep_ref.host_type,
                unauth_first=True,
                base_env=self._host.git_env,
            )

        auth_ctx = self._host.auth_resolver.resolve_for_dep(dep_ref)
        remote_url = self.build_repo_url(dep_ref.repo_url, dep_ref=dep_ref)
        if auth_ctx.token:
            git_env = self._host.auth_resolver.git_env_for_remote(auth_ctx, remote_url)
        else:
            # Public repositories use normal non-interactive Git. Do not
            # inherit an unrelated downloader token into this fallback.
            git_env = self._host._build_noninteractive_git_env()

        effective_url = validate_git_url_rewrite_safety(remote_url, git_env) or remote_url
        key = self._git_file_transport_key(
            dep_ref, ref, remote_url, effective_url, "managed" if auth_ctx.token else "native"
        )

        def _tokenless_repo_url(repo_ref: str, *, dep_ref: DependencyReference) -> str:
            return remote_url

        with self._git_file_transports_lock:
            transport = self._git_file_transports.get(key)
            if transport is None:
                transport_factory = self._git_file_transport_factory or GitSparseFileTransport
                transport = transport_factory(
                    dep_ref,
                    ref,
                    build_repo_url_fn=_tokenless_repo_url,
                    git_env=git_env,
                )
                self._git_file_transports[key] = transport
        try:
            return transport.fetch_file_with_commit(file_path)
        except GitFileTransportError:
            self._discard_git_file_transport(key, transport)
            raise

    def download_github_file_via_throttle_fallback(
        self,
        dep_ref: DependencyReference,
        file_path: str,
        ref: str,
        throttle: GitHubThrottleError,
    ) -> GitFileFetchResult:
        """Select the sole sparse-Git fallback for a confirmed GitHub throttle."""
        if dep_ref.is_insecure:
            raise RuntimeError(
                f"{throttle}; sparse Git fallback is unavailable for insecure HTTP dependencies"
            )
        try:
            return self._download_github_file_via_git(dep_ref, file_path, ref)
        except GitFileTransportError as exc:
            raise RuntimeError(
                f"{throttle}; sparse Git transport failed: {exc}. "
                "Retry after GitHub quota recovery; for private repositories, "
                "verify GITHUB_APM_PAT can read the repository."
            ) from exc

    # ------------------------------------------------------------------
    # GitLab file download
    # ------------------------------------------------------------------

    @staticmethod
    def _gitlab_rest_eligible(effective_url: str, api_base: str) -> bool:
        """Authorize REST only for an executed same-origin HTTPS Git attempt."""
        remote = urlsplit(effective_url)
        api = urlsplit(api_base)
        return (
            remote.scheme.lower() == api.scheme.lower() == "https"
            and remote.hostname == api.hostname
            and (remote.port or 443) == (api.port or 443)
        )

    def download_gitlab_file(
        self,
        dep_ref: DependencyReference,
        file_path: str,
        ref: str = "main",
        verbose_callback=None,
    ) -> bytes:
        """Execute the selected Git plan before an authorized HTTPS REST fallback."""
        host = dep_ref.host or default_host()
        host_info = self._host.auth_resolver.classify_host(
            host,
            port=dep_ref.port,
            host_type=dep_ref.host_type,
        )
        project_path = dep_ref.repo_url
        if not project_path:
            raise RuntimeError("Missing repository path for GitLab file download")

        resolver = self._host.auth_resolver
        candidate_url = self.build_repo_url(
            project_path,
            dep_ref=dep_ref,
            use_ssh=initial_transport_scheme(dep_ref, self._host._protocol_pref) == "ssh",
        )
        anonymous_plan = self._host._transport_selector.select(
            dep_ref=dep_ref,
            cli_pref=self._host._protocol_pref,
            allow_fallback=self._host._allow_fallback,
            has_token=False,
            candidate_url=candidate_url,
        )
        initial = anonymous_plan.attempts[0]
        initial_ctx = resolver.resolve_for_remote(
            host,
            initial.effective_url or initial.requested_url or candidate_url,
            dependency_repository_owner(dep_ref),
            port=dep_ref.port,
            host_type=dep_ref.host_type,
        )
        plan = self._host._transport_selector.select(
            dep_ref=dep_ref,
            cli_pref=self._host._protocol_pref,
            allow_fallback=self._host._allow_fallback,
            has_token=bool(initial_ctx.token),
            candidate_url=candidate_url,
        )
        notice = fallback_port_warning(dep_ref, plan)
        if notice:
            warn_key = (host.lower(), project_path, dep_ref.port)
            with self._host._fallback_port_warned_lock:
                should_warn = warn_key not in self._host._fallback_port_warned
                self._host._fallback_port_warned.add(warn_key)
            if should_warn:
                _rich_warning(notice, symbol="warning")

        rest_eligible = False
        failures: list[str] = []
        last_error: GitFileTransportError | None = None
        previous_attempt = None
        for attempt in plan.attempts:
            requested_url = attempt.requested_url or self.build_repo_url(
                project_path,
                dep_ref=dep_ref,
                use_ssh=attempt.scheme == "ssh",
            )
            effective_url = attempt.effective_url or requested_url
            attempt_ctx = resolver.resolve_for_remote(
                host,
                effective_url,
                dependency_repository_owner(dep_ref),
                port=dep_ref.port,
                host_type=dep_ref.host_type,
            )
            git_env = (
                resolver.git_env_for_remote(attempt_ctx, effective_url)
                if attempt.use_token
                else resolver.build_native_git_credential_env(host_info, effective_url)
            )
            # Revalidate before reuse: a cached checkout must not bypass changed policy.
            effective_url = validate_git_url_rewrite_safety(requested_url, git_env) or effective_url
            if (
                not plan.strict
                and previous_attempt is not None
                and previous_attempt.scheme != attempt.scheme
            ):
                _rich_warning(
                    redact_git_diagnostic(
                        f"Protocol fallback: {previous_attempt.label} GitLab sparse fetch of "
                        f"{project_path} failed; retrying with {attempt.label}."
                    ),
                    symbol="warning",
                )
            try:
                content = self._download_gitlab_file_via_git(
                    dep_ref,
                    file_path,
                    ref,
                    requested_url=requested_url,
                    effective_url=effective_url,
                    git_env=git_env,
                    auth_mode="managed" if attempt.use_token else "native",
                )
            except GitFileTransportError as exc:
                last_error = exc
                previous_attempt = attempt
                failures.append(redact_git_diagnostic(f"{attempt.label}: {exc}"))
                rest_eligible = rest_eligible or self._gitlab_rest_eligible(
                    effective_url, host_info.api_base
                )
            else:
                if verbose_callback:
                    verbose_callback(
                        f"Fetched file via git transport: {host}/{project_path}/{file_path}"
                    )
                return content

        if rest_eligible:
            return self._download_gitlab_file_via_rest(dep_ref, file_path, ref, verbose_callback)
        failure_detail = "; ".join(failures)
        raise RuntimeError(
            redact_git_diagnostic(
                f"Failed to download {file_path} at ref '{ref}' from {host}/{project_path}. "
                f"Git transport failed ({failure_detail}); GitLab REST is not authorized "
                "by the selected transport plan. Verify access using the selected Git "
                "transport (including SSH keys for SSH), or explicitly configure an HTTPS "
                "dependency using the web endpoint."
            )
        ) from last_error

    def _download_gitlab_file_via_rest(
        self,
        dep_ref: DependencyReference,
        file_path: str,
        ref: str,
        verbose_callback=None,
    ) -> bytes:
        """Read the existing GitLab REST endpoint after transport authorization."""
        host = dep_ref.host or default_host()
        host_info = self._host.auth_resolver.classify_host(
            host, port=dep_ref.port, host_type=dep_ref.host_type
        )
        project_path = dep_ref.repo_url
        org = project_path.split("/")[0]
        file_ctx = self._host.auth_resolver.resolve(
            host,
            org,
            port=dep_ref.port,
            host_type=dep_ref.host_type,
        )
        token = file_ctx.token
        headers = AuthResolver.gitlab_rest_headers(token)

        api_base = host_info.api_base.rstrip("/")
        enc_proj = quote(project_path, safe="")
        enc_file = quote(file_path, safe="")

        def _raw_url(r: str) -> str:
            return (
                f"{api_base}/projects/{enc_proj}/repository/files/{enc_file}/raw"
                f"?ref={quote(r, safe='')}"
            )

        api_url = _raw_url(ref)

        # A token-bearing request uses the credential-scoped session so the
        # PRIVATE-TOKEN header never follows a redirect to another origin.
        gitlab_get = partial(self._host._resilient_get, allow_netrc=not token)

        try:
            response = gitlab_get(api_url, headers=headers, timeout=30)
            response.raise_for_status()
            if verbose_callback:
                verbose_callback(f"Downloaded file: {host}/{dep_ref.repo_url}/{file_path}")
            return response.content
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                if ref not in ("main", "master"):
                    raise RuntimeError(
                        f"File not found: {file_path} at ref '{ref}' in {dep_ref.repo_url}"
                    ) from e
                fallback_ref = "master" if ref == "main" else "main"
                fallback_url = _raw_url(fallback_ref)
                try:
                    response = gitlab_get(fallback_url, headers=headers, timeout=30)
                    response.raise_for_status()
                    if verbose_callback:
                        verbose_callback(f"Downloaded file: {host}/{dep_ref.repo_url}/{file_path}")
                    return response.content
                except requests.exceptions.HTTPError as fallback_err:
                    raise RuntimeError(
                        f"File not found: {file_path} in {dep_ref.repo_url} "
                        f"(tried refs: {ref}, {fallback_ref})"
                    ) from fallback_err
            if e.response is not None and e.response.status_code in (401, 403):
                error_msg = (
                    f"Authentication failed for GitLab {dep_ref.repo_url} "
                    f"(file: {file_path}, ref: {ref}). "
                )
                if not token:
                    error_msg += self._host.auth_resolver.build_error_context(
                        host, "download", org=org, port=dep_ref.port
                    )
                else:
                    error_msg += (
                        "Please verify your token can read this project (required API scope)."
                    )
                raise RuntimeError(error_msg) from e
            if e.response is not None:
                raise RuntimeError(
                    f"Failed to download {file_path}: HTTP {e.response.status_code}"
                ) from e
            raise
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"Network error downloading {file_path}: {e}") from e

    # ------------------------------------------------------------------
    # GitHub file download
    # ------------------------------------------------------------------

    def _download_public_github_file_anonymous_first(
        self,
        dep_ref: DependencyReference,
        file_path: str,
        ref: str,
        verbose_callback=None,
        raw_only: bool = False,
    ) -> bytes:
        """Fetch one github.com file anonymously, resolving auth only on 4xx.

        With ``raw_only=True`` the Contents API fallback is skipped: the
        helper reports a miss (``RuntimeError``) when the raw CDN does not
        have the file under any candidate ref.  This is the request-budget
        seam used by virtual-package validation (microsoft/apm#3283) so a
        CDN-only marker sweep never spends the shared anonymous REST quota.
        """
        host = dep_ref.host or default_host()
        owner_repo = repository_owner_and_repo(dep_ref.repo_url)
        if owner_repo is None:
            raise RuntimeError(f"Invalid repository path for {dep_ref.repo_url}")
        owner, repo = owner_repo
        refs = [ref]
        if ref in ("main", "master"):
            refs.append("master" if ref == "main" else "main")

        for candidate_ref in refs:
            content = self.try_raw_download(owner, repo, candidate_ref, file_path)
            if content is not None:
                if verbose_callback:
                    verbose_callback(f"Downloaded file: {host}/{dep_ref.repo_url}/{file_path}")
                return content

        if raw_only:
            # Raw-CDN-only callers (virtual-package marker sweep) must not
            # escalate a miss to the Contents API: that is the exact
            # per-marker anonymous-quota waste this seam exists to avoid.
            raise RuntimeError(
                f"File {file_path} not found via raw CDN at ref {ref}"
                f" (refs tried: {', '.join(refs)})"
            )

        def _contents_request(
            token: str | None,
            _git_env: dict[str, str],
        ) -> bytes:
            headers: dict[str, str] = {
                "Accept": "application/vnd.github.v3.raw",
            }
            headers.update(AuthResolver.github_rest_headers(token))
            last_response = None
            for candidate_ref in refs:
                api_url = self._build_contents_api_urls(
                    host,
                    owner,
                    repo,
                    file_path,
                    candidate_ref,
                    is_github_host=True,
                )[0]
                response = self._host._resilient_get(
                    api_url,
                    headers=headers,
                    timeout=30,
                    retry_throttles=False,
                )
                if response.status_code == 200:
                    if verbose_callback:
                        verbose_callback(f"Downloaded file: {host}/{dep_ref.repo_url}/{file_path}")
                    return self._extract_contents_api_payload(
                        response,
                        is_github_host=True,
                    )
                throttle = github_throttle_error(response, host)
                if throttle is not None:
                    raise throttle
                last_response = response
                if response.status_code != 404:
                    response.raise_for_status()
            if last_response is not None:
                last_response.raise_for_status()
            raise RuntimeError(f"No GitHub Contents API response for {file_path}")

        try:
            return self._host.auth_resolver.try_with_fallback(
                host,
                _contents_request,
                org=owner,
                port=dep_ref.port,
                path=dep_ref.repo_url,
                host_type=dep_ref.host_type,
                unauth_first=True,
                verbose_callback=verbose_callback,
            )
        except GitHubThrottleError:
            raise
        except requests.exceptions.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else "unknown"
            if status in (401, 403):
                context = self._host.auth_resolver.build_error_context(
                    host,
                    "download",
                    org=owner,
                    port=dep_ref.port,
                    dep_url=dep_ref.repo_url,
                )
                raise RuntimeError(
                    f"Authentication failed for {dep_ref.repo_url} "
                    f"(file: {file_path}, ref: {ref}). "
                    f"{context}"
                ) from exc
            if status == 404:
                raise RuntimeError(
                    self._build_unsupported_or_missing_error(
                        host,
                        dep_ref.repo_url,
                        file_path,
                        ref,
                        self._build_contents_api_urls(
                            host,
                            owner,
                            repo,
                            file_path,
                            ref,
                            is_github_host=True,
                        ),
                        is_github_host=True,
                        fallback_ref=refs[-1] if len(refs) > 1 else None,
                    )
                ) from exc
            raise RuntimeError(
                self._build_download_http_error(
                    host,
                    file_path,
                    status,
                    "Contents API",
                )
            ) from exc
        except requests.exceptions.RequestException as exc:
            raise RuntimeError(
                self._build_download_network_error(
                    host,
                    file_path,
                    "Contents API",
                    exc,
                )
            ) from exc

    def download_github_file(
        self,
        dep_ref: DependencyReference,
        file_path: str,
        ref: str = "main",
        verbose_callback=None,
        raw_only: bool = False,
    ) -> bytes:
        """Download a file from GitHub repository.

        For github.com without a token, tries raw.githubusercontent.com first
        (CDN, no rate limit) before falling back to the Contents API.
        Authenticated requests and non-github.com hosts always use the
        Contents API directly.

        Args:
            dep_ref: Parsed dependency reference
            file_path: Path to file within the repository
            ref: Git reference (branch, tag, or commit SHA)
            verbose_callback: Optional callable for verbose logging
            raw_only: Skip the Contents API fallback and report a miss via
                ``RuntimeError`` when the raw CDN does not have the file.
                Only honored on the public-github anonymous-first path (the
                sole caller is virtual-package validation, microsoft/apm#3283);
                all other paths keep their existing behavior.

        Returns:
            bytes: File content
        """
        host = dep_ref.host or default_host()

        if (
            self._host.auth_resolver.uses_public_github_anonymous_first(
                host,
                port=dep_ref.port,
                host_type=dep_ref.host_type,
            )
            is True
        ):
            return self._download_public_github_file_anonymous_first(
                dep_ref,
                file_path,
                ref,
                verbose_callback,
                raw_only=raw_only,
            )

        # Parse owner/repo from repo_url
        owner_repo = repository_owner_and_repo(dep_ref.repo_url)
        if owner_repo is None:
            raise RuntimeError(f"Invalid repository path for {dep_ref.repo_url}")
        owner, repo = owner_repo

        # Resolve auth once through the same per-dependency boundary used by
        # clone URLs. Generic hosts intentionally return None here so APM
        # does not attach managed PATs to ad-hoc HTTP requests.
        file_ctx = self._host._resolve_dep_auth_ctx(dep_ref)
        token = file_ctx.token if file_ctx else None

        # --- CDN fast-path for github.com without a token ---
        # raw.githubusercontent.com is served from GitHub's CDN and is not
        # subject to the REST API rate limit (60 req/h unauthenticated).
        # Only available for github.com -- GHES/GHE-DR have no equivalent.
        if host.lower() == "github.com" and not token:
            content = self.try_raw_download(owner, repo, ref, file_path)
            if content is not None:
                if verbose_callback:
                    verbose_callback(f"Downloaded file: {host}/{dep_ref.repo_url}/{file_path}")
                return content
            # raw download returned 404 -- could be wrong default branch.
            # Try the other default branch before falling through to the API.
            if ref in ("main", "master"):
                fallback_ref = "master" if ref == "main" else "main"
                content = self.try_raw_download(owner, repo, fallback_ref, file_path)
                if content is not None:
                    if verbose_callback:
                        verbose_callback(f"Downloaded file: {host}/{dep_ref.repo_url}/{file_path}")
                    return content
            # All raw attempts failed -- fall through to API path which
            # handles private repos, rate-limit messaging, and SAML errors.

        # --- Generic host: raw URL first, then API version negotiation ---
        # For non-GitHub non-GHE hosts (Gitea, Gogs, self-hosted git), try the
        # raw URL path first, then negotiate API versions v1 -> v3.
        is_github_host = is_github_hostname(host) or self._is_configured_ghes(host)
        if not is_github_host:
            raw_url = f"https://{host}/{owner}/{repo}/raw/{ref}/{file_path}"
            raw_headers = self._build_generic_host_auth_headers(host, file_ctx, accept=None)
            if verbose_callback:
                verbose_callback(f"Trying raw URL on generic host {host}: {raw_url}")
            try:
                response = self._host._resilient_get(raw_url, headers=raw_headers, timeout=30)
            except (requests.RequestException, OSError) as raw_err:
                raise RuntimeError(
                    self._build_download_network_error(host, file_path, "raw URL", raw_err)
                ) from raw_err
            if response.status_code == 200:
                if verbose_callback:
                    verbose_callback(f"Downloaded file: {host}/{dep_ref.repo_url}/{file_path}")
                return response.content
            if response.status_code != 404:
                raise RuntimeError(
                    self._build_download_http_error(
                        host, file_path, response.status_code, "raw URL"
                    )
                )

        # --- Contents API path (authenticated, enterprise, or raw fallback) ---
        # Build API URL candidates - format differs by host type
        api_url_candidates = self._build_contents_api_urls(
            host, owner, repo, file_path, ref, is_github_host=is_github_host
        )
        api_url = api_url_candidates[0]

        # Set up authentication headers
        # GitHub family: use GitHub raw-media accept header. Generic hosts
        # ignore it and may return JSON envelopes -- handle that on read.
        accept = "application/vnd.github.v3.raw" if is_github_host else "application/json"
        if is_github_host:
            headers: dict[str, str] = {"Accept": accept}
            headers.update(AuthResolver.github_rest_headers(token))
        else:
            headers = self._build_generic_host_auth_headers(host, file_ctx, accept=accept)

        # Try to download with the specified ref
        try:
            if verbose_callback and host.lower() != "github.com":
                verbose_callback(f"Trying Contents API on {host}: {api_url}")
            response = self._host._resilient_get(
                api_url,
                headers=headers,
                timeout=30,
                retry_throttles=not is_github_host,
            )
            response.raise_for_status()
            if verbose_callback:
                verbose_callback(f"Downloaded file: {host}/{dep_ref.repo_url}/{file_path}")
            return self._extract_contents_api_payload(response, is_github_host)
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response is not None else "unknown"
            if is_github_host and e.response is not None:
                throttle = github_throttle_error(e.response, host)
                if throttle is not None:
                    raise throttle from e
            if status == 404:
                # For generic hosts, try remaining API version candidates before ref fallback
                for candidate_url in api_url_candidates[1:]:
                    try:
                        if verbose_callback:
                            verbose_callback(
                                f"Contents API 404; trying next candidate: {candidate_url}"
                            )
                        candidate_resp = self._host._resilient_get(
                            candidate_url, headers=headers, timeout=30
                        )
                        candidate_resp.raise_for_status()
                        if verbose_callback:
                            verbose_callback(
                                f"Downloaded file: {host}/{dep_ref.repo_url}/{file_path}"
                            )
                        return self._extract_contents_api_payload(candidate_resp, is_github_host)
                    except requests.exceptions.HTTPError as ce:
                        status = ce.response.status_code if ce.response is not None else "unknown"
                        if status != 404:
                            raise RuntimeError(  # noqa: B904
                                self._build_download_http_error(
                                    host, file_path, status, "Contents API"
                                )
                            )
                    except requests.exceptions.RequestException as ce:
                        raise RuntimeError(  # noqa: B904
                            self._build_download_network_error(host, file_path, "Contents API", ce)
                        )

                # Try fallback branches if the specified ref fails
                if ref not in ["main", "master"]:
                    raise RuntimeError(  # noqa: B904
                        self._build_unsupported_or_missing_error(
                            host,
                            dep_ref.repo_url,
                            file_path,
                            ref,
                            api_url_candidates,
                            is_github_host=is_github_host,
                        )
                    )

                # Try the other default branch
                fallback_ref = "master" if ref == "main" else "main"
                fallback_url_candidates = self._build_contents_api_urls(
                    host,
                    owner,
                    repo,
                    file_path,
                    fallback_ref,
                    is_github_host=is_github_host,
                )

                for fallback_url in fallback_url_candidates:
                    try:
                        if verbose_callback:
                            verbose_callback(f"Trying Contents API on {host}: {fallback_url}")
                        response = self._host._resilient_get(
                            fallback_url,
                            headers=headers,
                            timeout=30,
                            retry_throttles=not is_github_host,
                        )
                        response.raise_for_status()
                        if verbose_callback:
                            verbose_callback(
                                f"Downloaded file: {host}/{dep_ref.repo_url}/{file_path}"
                            )
                        return self._extract_contents_api_payload(response, is_github_host)
                    except requests.exceptions.HTTPError as fe:
                        if is_github_host and fe.response is not None:
                            throttle = github_throttle_error(fe.response, host)
                            if throttle is not None:
                                raise throttle from fe
                        status = fe.response.status_code if fe.response is not None else "unknown"
                        if status != 404:
                            raise RuntimeError(  # noqa: B904
                                self._build_download_http_error(
                                    host, file_path, status, "Contents API"
                                )
                            )
                    except requests.exceptions.RequestException as fe:
                        raise RuntimeError(  # noqa: B904
                            self._build_download_network_error(host, file_path, "Contents API", fe)
                        )

                raise RuntimeError(  # noqa: B904
                    self._build_unsupported_or_missing_error(
                        host,
                        dep_ref.repo_url,
                        file_path,
                        ref,
                        api_url_candidates,
                        is_github_host=is_github_host,
                        fallback_ref=fallback_ref,
                    )
                )
            elif status in (401, 403):
                # Retry without auth -- the repo might be public.
                # GHES/GHE-DR don't support unauthenticated org-scoped retries.
                if token and is_github_host and not host.lower().endswith(".ghe.com"):
                    try:
                        unauth_headers: dict[str, str] = {"Accept": "application/vnd.github.v3.raw"}
                        response = self._host._resilient_get(
                            api_url,
                            headers=unauth_headers,
                            timeout=30,
                            retry_throttles=False,
                        )
                        response.raise_for_status()
                        if verbose_callback:
                            verbose_callback(
                                f"Downloaded file: {host}/{dep_ref.repo_url}/{file_path}"
                            )
                        return self._extract_contents_api_payload(response, is_github_host)
                    except requests.exceptions.HTTPError:
                        pass  # Fall through to the original error

                error_msg = (
                    f"Authentication failed for {dep_ref.repo_url} "
                    f"(file: {file_path}, ref: {ref}). "
                )
                if not token:
                    if is_github_host:
                        error_msg += self._host.auth_resolver.build_error_context(
                            host,
                            "download",
                            org=owner,
                            port=dep_ref.port if dep_ref else None,
                            dep_url=dep_ref.repo_url if dep_ref else None,
                        )
                    else:
                        error_msg += (
                            "No APM-managed token was sent for generic host file download. "
                            "Use a whole-repo git dependency for full clone auth support. "
                            "For platform-specific HTTP file reads, use object-form type: gitlab "
                            f"for GitLab-compatible hosts or set GITHUB_HOST={host} for GitHub "
                            "Enterprise Server. Re-run with --verbose to see attempted URLs."
                        )
                elif is_github_host and not host.lower().endswith(".ghe.com"):
                    error_msg += (
                        "Both authenticated and unauthenticated access "
                        "were attempted. The repository may be private, "
                        "or your token may lack SSO/SAML authorization "
                        "for this organization."
                    )
                elif is_github_host:
                    error_msg += "Please check your GitHub token permissions."
                else:
                    # Generic host: don't claim SSO/SAML or "GitHub token".
                    error_msg += (
                        f"Host {host} rejected the request. "
                        "Verify the repository exists and that the token has "
                        "access. Tokens are sourced from your git credential "
                        "helper, a per-org GITHUB_APM_PAT_<ORG> env var, or "
                        f"GITHUB_HOST={host} when this host is your GitHub "
                        "Enterprise Server."
                    )
                if is_github_host:
                    error_msg += " Re-run with --verbose to see attempted URLs."
                raise RuntimeError(error_msg)  # noqa: B904
            else:
                raise RuntimeError(
                    self._build_download_http_error(host, file_path, status, "Contents API")
                ) from e
        except requests.exceptions.RequestException as e:
            raise RuntimeError(
                self._build_download_network_error(host, file_path, "Contents API", e)
            ) from e

    # ------------------------------------------------------------------
    # Helpers for download_github_file
    # ------------------------------------------------------------------

    @staticmethod
    def _is_configured_ghes(host: str) -> bool:
        """Return True when *host* matches the user's declared GHES via GITHUB_HOST.

        ``GITHUB_HOST=<custom-domain>`` is the documented opt-in for treating
        a non-``*.ghe.com`` FQDN as GitHub-family. Centralised so the routing
        check, header builder, and Contents-API URL builder cannot drift.
        """
        configured = os.environ.get("GITHUB_HOST", "").strip().lower()
        if not configured:
            return False
        return (host or "").lower() == configured

    @staticmethod
    def _build_contents_api_urls(
        host: str,
        owner: str,
        repo: str,
        file_path: str,
        ref: str,
        *,
        is_github_host: bool | None = None,
    ) -> list[str]:
        """Return the ordered list of Contents-API URL candidates for *host*.

        Thin wrapper around the per-host backends -- the actual URL shape
        lives on the backend. Kept as a static method on
        :class:`DownloadDelegate` for back-compat with existing callers
        and tests that monkey-patch it.
        """
        from .host_backends import GenericGitBackend, GHECloudBackend, GHESBackend, GitHubBackend

        if is_github_host is None:
            is_github_host = is_github_hostname(host) or DownloadDelegate._is_configured_ghes(host)

        host_lower = (host or "").lower()
        if not is_github_host:
            backend = GenericGitBackend(
                host_info=HostInfo(
                    host=host,
                    kind="generic",
                    has_public_repos=False,
                    api_base=f"https://{host}",
                )
            )
        elif host_lower == "github.com":
            backend = GitHubBackend(
                host_info=HostInfo(
                    host=host,
                    kind="github",
                    has_public_repos=True,
                    api_base="https://api.github.com",
                )
            )
        elif host_lower.endswith(".ghe.com"):
            backend = GHECloudBackend(
                host_info=HostInfo(
                    host=host,
                    kind="ghe_cloud",
                    has_public_repos=False,
                    api_base=f"https://{host}/api/v3",
                )
            )
        else:
            # Configured GHES (GITHUB_HOST=<custom-host>): api_base is
            # ``https://{host}/api/v3``, not ``https://api.{host}``.
            backend = GHESBackend(
                host_info=HostInfo(
                    host=host,
                    kind="ghes",
                    has_public_repos=False,
                    api_base=f"https://{host}/api/v3",
                )
            )
        return backend.build_contents_api_urls(owner, repo, file_path, ref)

    @staticmethod
    def _build_generic_host_auth_headers(
        host: str, auth_ctx, *, accept: str | None = None
    ) -> dict[str, str]:
        """Build HTTP headers for a generic-host (non-GitHub) request.

        SECURITY GUARD: HTTP single-file downloads use the same token
        boundary as clone URLs. Generic hosts receive no APM-managed
        Authorization header; they must succeed unauthenticated or use a
        host-specific backend such as ``type: gitlab``.

        Forwarding is allowed only when the caller passes a non-generic
        auth context whose token is unambiguously intended for this host.
        """
        headers: dict[str, str] = {}
        if accept:
            headers["Accept"] = accept
        if auth_ctx is None or not getattr(auth_ctx, "token", None):
            return headers
        source = getattr(auth_ctx, "source", None) or ""
        host_scoped = source == "git-credential-fill"
        org_scoped = source.startswith("GITHUB_APM_PAT_")
        configured_ghes = DownloadDelegate._is_configured_ghes(host)
        if host_scoped or org_scoped or configured_ghes:
            headers.update(AuthResolver.github_rest_headers(auth_ctx.token))
        return headers

    @staticmethod
    def _extract_contents_api_payload(response, is_github_host: bool) -> bytes:
        """Decode a Contents-API response into raw file bytes.

        - GitHub family: ``Accept: application/vnd.github.v3.raw`` returns
          the file bytes directly; pass through ``response.content``.
        - Generic hosts (Gitea, Gogs): the raw-media accept header is
          ignored and the server returns a JSON envelope of the form::

              {"content": "<base64>", "encoding": "base64", ...}

          Decode ``content`` as base64 and return the resulting bytes.
          Some Gitea installations also emit ``encoding: ""`` with raw
          content -- pass that through unchanged. If the response is not
          a JSON envelope at all (custom proxy, raw bytes), fall back to
          ``response.content``.
        """
        if is_github_host:
            return response.content

        body = response.content
        try:
            ctype = str((response.headers or {}).get("Content-Type") or "").lower()
        except (AttributeError, TypeError):
            ctype = ""
        if "json" not in ctype and not (
            isinstance(body, (bytes, bytearray)) and body.lstrip().startswith(b"{")
        ):
            return body
        try:
            payload = json.loads(body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError, AttributeError, RecursionError):
            return body
        if not isinstance(payload, dict) or "content" not in payload:
            return body
        encoding = (payload.get("encoding") or "").lower()
        content_field = payload.get("content") or ""
        if encoding == "base64":
            try:
                return base64.b64decode(content_field, validate=False)
            except (ValueError, TypeError):
                return body
        # Non-base64 envelope (rare): return literal content if it's a string,
        # otherwise fall back to the raw body.
        if isinstance(content_field, str):
            return content_field.encode("utf-8")
        return body

    @staticmethod
    def _build_download_http_error(
        host: str,
        file_path: str,
        status: int | str,
        endpoint: str,
    ) -> str:
        """Build a host- and endpoint-specific HTTP download error."""
        return (
            f"Failed to download {file_path} from {host}: HTTP {status} "
            f"from {endpoint} endpoint. Re-run with --verbose to see attempted URLs."
        )

    @staticmethod
    def _build_download_network_error(
        host: str,
        file_path: str,
        endpoint: str,
        error: BaseException,
    ) -> str:
        """Build a host- and endpoint-specific network download error."""
        detail = str(error).strip().splitlines()[0] if str(error).strip() else type(error).__name__
        return (
            f"Network error downloading {file_path} from {host} via {endpoint} endpoint: "
            f"{detail}. Re-run with --verbose to see attempted URLs."
        )

    @staticmethod
    def _build_unsupported_or_missing_error(
        host: str,
        repo_url: str,
        file_path: str,
        ref: str,
        api_url_candidates: list[str],
        *,
        is_github_host: bool,
        fallback_ref: str | None = None,
    ) -> str:
        """Build a discoverable error when no Contents-API candidate hits 200."""
        ref_part = f"(tried refs: {ref}, {fallback_ref})" if fallback_ref else f"at ref '{ref}'"
        if is_github_host:
            return f"File not found: {file_path} in {repo_url} {ref_part}"
        # Non-GitHub host: name what was tried so users can diagnose
        # GitLab / unsupported-host cases without re-reading source.
        tried = ", ".join(["raw"] + [u.split("/api/")[1].split("/")[0] for u in api_url_candidates])
        canonical_url = f"https://{host}/{repo_url}/raw/{ref}/{file_path}"
        return (
            f"File not found on generic host {host}: {canonical_url} {ref_part}. "
            f"Tried URL families: {tried}. "
            "If this is GitLab, virtual subdirectory packages are not "
            "supported (use the dict-form full repo URL instead)."
        )
