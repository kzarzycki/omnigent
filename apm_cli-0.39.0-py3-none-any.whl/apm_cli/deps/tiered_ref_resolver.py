"""Tiered git reference resolver -- collapses redundant clones (#1369).

Issue #1369: ``apm update -y -v`` ran the integrate loop serially, calling
``ctx.downloader.resolve_git_reference(dep_ref)`` per-dep. Each call did
``mkdtemp`` + a shallow ``git clone --depth=1`` with ZERO memoization.
A 9-dep manifest pointing at 3 unique (repo, ref) tuples produced 9
clones. On Windows + Defender + a slow ADO endpoint that scaled to 1583s.

This module collapses that work via a four-tier waterfall executed by
:class:`TieredRefResolver`:

* **L0 PerRunCache** -- in-memory ``{(url, ref): sha}``. Zero I/O.
  Catches the duplicate-within-run case (9 deps -> 3 underlying resolves).
* **L1 CommitsAPI** -- cheap ``GET /repos/.../commits/{ref}`` against the
  GitHub-family host_backend, with ``Accept: application/vnd.github.sha``
  + optional ``HttpCache`` ETag. ~1 RTT.
* **L2 BareRevParse** -- read a recorded current-remote observation first;
  if absent, use ``git rev-parse`` against an existing cached bare clone.
  Zero network. Catches the second-run case without reviving superseded refs.
* **L3 LegacyClone** -- delegates to the legacy
  :meth:`GitReferenceResolver.resolve` (shallow clone + introspect).
  Behaviourally identical to the pre-#1369 path; always succeeds or
  raises.

The resolver reuses every existing performance primitive APM already
ships -- ``HttpCache`` (ETag), ``GitCache`` (bare rev-parse),
``host_backends`` (commits API URL), ``_resilient_get`` (HTTP + retries),
``AuthResolver`` (token resolution) -- and adds only the orchestrator
plus the per-run cache. No new infrastructure.

Concurrency: a coalesce lock around ``(url, ref)`` ensures that
concurrent ``resolve()`` calls for the same key block on a single
in-flight resolution rather than racing. Makes the resolver safe for
``apm outdated``'s ThreadPoolExecutor and for any future parallel
integrate phase.

Feature flag: setting ``APM_TIERED_RESOLVER=0`` (or any value other than
``1``/``true``/``yes``) disables the tiered stack entirely; callers fall
through to the legacy clone path. Default ON.
"""

from __future__ import annotations

import logging
import os
import re
import threading
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from ..models.apm_package import (
    DependencyReference,
    GitReferenceType,
    ResolvedReference,
)
from ..utils.github_host import default_host

if TYPE_CHECKING:
    from ..cache.git_cache import GitCache
    from ..deps.git_reference_resolver import GitReferenceResolver
    from ..deps.github_downloader import GitHubPackageDownloader
    from ..deps.lockfile import LockFile

_log = logging.getLogger(__name__)

_SHA_RE = re.compile(r"^[a-f0-9]{40}$", re.IGNORECASE)


class RefFreshnessPolicy(Enum):
    """Canonical authority for which resolver caches may establish a ref."""

    REPRODUCIBLE = "reproducible"
    LOCKED_OR_CURRENT = "locked-or-current"
    CURRENT_REMOTE = "current-remote"

    @classmethod
    def for_install_intent(
        cls,
        *,
        update_refs: bool,
        refresh: bool,
    ) -> RefFreshnessPolicy:
        """Map install command intent to one resolver freshness policy."""
        if update_refs or refresh:
            return cls.CURRENT_REMOTE
        return cls.LOCKED_OR_CURRENT

    @property
    def allows_lock_seed(self) -> bool:
        """Return whether a matching dependency may replay a lockfile SHA."""
        return self is not self.CURRENT_REMOTE

    @property
    def allows_bare_cache(self) -> bool:
        """Return whether a persistent bare ref may answer resolution."""
        return self is self.REPRODUCIBLE

    @property
    def requires_remote(self) -> bool:
        """Return whether even locked refs must be refreshed from upstream."""
        return self is self.CURRENT_REMOTE


class RefFreshnessContext(Protocol):
    """Structural input needed to derive install ref freshness."""

    ref_freshness_policy: RefFreshnessPolicy | None
    update_refs: bool
    refresh: bool
    existing_lockfile: LockFile | None


def ref_freshness_policy_for_install(
    context: RefFreshnessContext,
) -> RefFreshnessPolicy:
    """Return the configured policy or derive it from install intent once."""
    configured = context.ref_freshness_policy
    if configured is not None:
        if not isinstance(configured, RefFreshnessPolicy):
            raise TypeError("ref_freshness_policy must be a RefFreshnessPolicy")
        return configured
    if context.existing_lockfile is None:
        return RefFreshnessPolicy.CURRENT_REMOTE
    return RefFreshnessPolicy.for_install_intent(
        update_refs=context.update_refs,
        refresh=context.refresh,
    )


def _repository_cache_identity(dep_ref: DependencyReference) -> str:
    """Return the full normalized repository identity shared by all cache tiers."""
    from ..cache.url_normalize import normalize_repo_url

    return normalize_repo_url(dep_ref.to_github_url())


def is_tiered_resolver_enabled() -> bool:
    """Read the ``APM_TIERED_RESOLVER`` env flag. Default ON.

    Set to ``0``/``false``/``no`` to disable the tiered stack and force
    every resolution through the legacy clone path. Useful as an
    emergency rollback without redeploying.
    """
    val = os.environ.get("APM_TIERED_RESOLVER", "1").strip().lower()
    return val not in ("0", "false", "no", "off", "")


# ---------------------------------------------------------------------------
# Per-run cache
# ---------------------------------------------------------------------------


class PerRunRefCache:
    """Thread-safe in-memory ``{(url, ref): sha}`` cache.

    Lives for the duration of one install/update/outdated run. Cleared
    by simply dropping the surrounding :class:`TieredRefResolver`.
    """

    def __init__(self) -> None:
        self._store: dict[tuple[str, str], str] = {}
        self._lock = threading.Lock()

    def get(self, url: str, ref: str) -> str | None:
        with self._lock:
            return self._store.get((url, ref))

    def put(self, url: str, ref: str, sha: str) -> None:
        with self._lock:
            self._store[(url, ref)] = sha

    def size(self) -> int:
        with self._lock:
            return len(self._store)


# ---------------------------------------------------------------------------
# Tier Protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class RefResolutionTier(Protocol):
    """Single resolution strategy. Returns the SHA or ``None`` to fall through."""

    name: str

    def try_resolve(self, dep_ref: DependencyReference, ref: str) -> str | None: ...


# ---------------------------------------------------------------------------
# L0: in-memory cache lookup
# ---------------------------------------------------------------------------


@dataclass
class L0PerRunCache:
    """Read-only view over :class:`PerRunRefCache` for tier dispatch."""

    cache: PerRunRefCache
    name: str = "per_run_cache"

    def try_resolve(self, dep_ref: DependencyReference, ref: str) -> str | None:
        return self.cache.get(_repository_cache_identity(dep_ref), ref)


# ---------------------------------------------------------------------------
# L1: cheap commits API
# ---------------------------------------------------------------------------


_ABBREVIATED_COMMIT_RE = re.compile(r"^[0-9a-fA-F]{7,39}$")


_UNSAFE_REF_RE = re.compile(r"\.\.|@\{|[\x00-\x20\x7f%~^:?*\[\\]")


_VERSION_LIKE_RE = re.compile(r"^v?\d")


def _exact_ref_queries(ref: str) -> tuple[str, ...]:
    """Commits-API names that match only an origin branch or tag named *ref*.

    A name the API could read as a revision expression or an encoded path
    (``..``, ``@{``, ``^``, ``~``, ``%``) gets no query at all.
    """
    if _UNSAFE_REF_RE.search(ref):
        return ()
    for namespace in ("heads", "tags"):
        if ref.startswith(f"refs/{namespace}/"):
            return (ref.removeprefix("refs/"),)
    if ref.startswith("refs/"):
        return ()
    if _ABBREVIATED_COMMIT_RE.match(ref):
        return (ref,)
    if _VERSION_LIKE_RE.match(ref):
        # A version-like name is usually a tag: ask that namespace first.
        return (f"tags/{ref}", f"heads/{ref}")
    return (f"heads/{ref}", f"tags/{ref}")


def _listed_exactly(
    resolver: object, dep_ref: DependencyReference, ref: str
) -> tuple[bool, str | None]:
    """``(named, commit)`` for the origin branch or tag named *ref*, from its ref listing.

    The commits API resolves a name like ``git rev-parse``, so ``heads/<x>``
    could answer with a tag named ``heads/<x>``; the listing matches the
    namespace exactly, with no fallback to another ref. *named* is true when
    a branch or tag of that name exists, even if it is ambiguous (no commit).
    """
    if not _exact_ref_queries(ref):
        return False, None
    from .git_remote_ops import exact_branch_or_tag_sha

    records = [
        (
            remote.commit_sha,
            f"refs/{'heads' if remote.ref_type == GitReferenceType.BRANCH else 'tags'}/{remote.name}",
        )
        for remote in resolver.list_remote_refs(dep_ref)
    ]
    wanted = {ref} if ref.startswith("refs/") else {f"refs/heads/{ref}", f"refs/tags/{ref}"}
    if not wanted & {name for _sha, name in records}:
        return False, None
    try:
        sha = exact_branch_or_tag_sha(records, ref, str(dep_ref.repo_url))
    except RuntimeError:
        return True, None
    return True, sha.lower() if _SHA_RE.match(sha or "") else None


def _resolve_exactly(resolver: object, dep_ref: DependencyReference, ref: str) -> str | None:
    """The commit *ref* names at the origin: an exact branch or tag, else an abbreviation.

    The commits API resolves a name like rev-parse, so a branch or tag name
    resolves from the exact ref listing. A hex name is a branch or tag first,
    as Git prefers a ref; only with none does the API expand it as an
    abbreviated commit, which admission then checks like any pin.
    """
    available = getattr(resolver, "commits_api_available", None)
    if available is not None and not available(dep_ref):
        return None
    named, sha = _listed_exactly(resolver, dep_ref, ref)
    if named or not _ABBREVIATED_COMMIT_RE.match(ref):
        return sha
    for query in _exact_ref_queries(ref):
        sha = resolver.resolve_commit_sha_for_ref(dep_ref, query)
        if sha and _SHA_RE.match(sha):
            return sha.lower()
    return None


class L1CommitsAPI:
    """Resolve via the GitHub-family commits API.

    Delegates to :meth:`GitReferenceResolver.resolve_commit_sha_for_ref` --
    the cheap-path helper that already dispatches through
    ``host_backends.build_commits_api_url`` and ``host._resilient_get``,
    inheriting that helper's auth behavior. The optional metadata lookup
    makes one HTTP attempt so rate limiting cannot delay L2/L3 fallback.
    Returns ``None`` for hosts whose backend has no cheap commits endpoint
    (e.g. ADO today); the caller then falls through to L2/L3.

    Future: an explicit :class:`HttpCache` ETag pass could be added here
    for unauthenticated requests (the underlying helper does not yet
    integrate with the on-disk HTTP cache). Out of scope for #1369.
    """

    name = "commits_api"

    def __init__(self, host: object) -> None:
        self._host = host

    def try_resolve(self, dep_ref: DependencyReference, ref: str) -> str | None:
        if _SHA_RE.match(ref or ""):
            return ref.lower()

        try:
            if dep_ref.is_artifactory() or dep_ref.is_azure_devops():
                return None
        except Exception:
            return None

        # Fast path: delegate to the existing cheap-API helper. It
        # already handles host backend dispatch, token resolution,
        # _resilient_get, and the GitHub sha-accept Content-Type. We do
        # NOT duplicate that code here; tier-1's value-add over the
        # raw helper is the orchestrator-level caching + coalescing.
        try:
            resolver = getattr(self._host, "_refs", None)
            if resolver is None:
                return None
            return _resolve_exactly(resolver, dep_ref, ref)
        except Exception as exc:
            _log.debug(
                "L1 commits API failed for %s@%s (%s)",
                dep_ref.repo_url,
                ref,
                type(exc).__name__,
            )
            return None


# ---------------------------------------------------------------------------
# L2: bare-repo rev-parse (zero network)
# ---------------------------------------------------------------------------


class L2BareRevParse:
    """Resolve from a remote-observation receipt, then a cached bare clone.

    No network. A corrupt receipt misses rather than reviving an older bare
    ref. Without a receipt, a cached bare clone supplies the legacy fallback.
    Cheap follow-up tier after L0/L1 miss --
    catches repeat reproducible installs where the bare exists but the cheap
    API is unavailable (e.g. ADO). Current-state commands exclude this tier.
    """

    name = "bare_rev_parse"

    def __init__(self, git_cache: GitCache | None) -> None:
        self._git_cache = git_cache

    def try_resolve(self, dep_ref: DependencyReference, ref: str) -> str | None:
        if self._git_cache is None or not ref:
            return None
        if _SHA_RE.match(ref):
            return ref.lower()

        recorded, sha = self._git_cache.read_resolved_ref(dep_ref.to_github_url(), ref)
        if recorded:
            return sha

        # Only the git cache opens its bares (trust-checked, run inertly).
        try:
            return self._git_cache.bare_ref_sha(dep_ref.to_github_url(), ref)
        except Exception:
            return None


# ---------------------------------------------------------------------------
# L3: legacy clone path (always-correct fallback)
# ---------------------------------------------------------------------------


class L3LegacyClone:
    """Delegate to the pre-#1369 :meth:`GitReferenceResolver.resolve`.

    Behaviourally identical to today's path. Always returns a SHA on
    success or raises. The whole point of L0-L2 is to AVOID calling
    this tier -- it does the shallow-clone-into-tempdir that #1369 was
    about.
    """

    name = "legacy_clone"

    def __init__(self, legacy_resolver: GitReferenceResolver) -> None:
        self._legacy = legacy_resolver

    def try_resolve(self, dep_ref: DependencyReference, ref: str) -> str | None:
        try:
            resolved = self._legacy.resolve(dep_ref)
        except Exception as exc:
            _log.debug(
                "L3 legacy resolve failed for %s (%s)",
                dep_ref.repo_url,
                type(exc).__name__,
            )
            return None
        sha = getattr(resolved, "resolved_commit", None)
        if sha and _SHA_RE.match(sha):
            return sha.lower()
        return None

    def resolve_full(self, dep_ref: DependencyReference) -> ResolvedReference:
        """Return the full :class:`ResolvedReference` from the legacy path.

        Used as the final escape hatch when no tier produced a SHA but
        the caller still needs a structured result (e.g. artifactory
        deps which have ``resolved_commit=None`` by design).
        """
        return self._legacy.resolve(dep_ref)


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------


class TieredRefResolver:
    """Run the four-tier waterfall with per-run dedup + coalescing.

    Lifetime: per install/update/outdated run. The factory
    :func:`build_tiered_ref_resolver` constructs an instance during the
    resolve phase; it is assigned to both ``ctx.ref_resolver`` and
    ``downloader._tiered_resolver`` so any subsequent code path that
    calls ``downloader.resolve_git_reference()`` automatically benefits.
    """

    def __init__(
        self,
        tiers: list[RefResolutionTier],
        cache: PerRunRefCache,
        legacy: L3LegacyClone,
        freshness_policy: RefFreshnessPolicy = RefFreshnessPolicy.REPRODUCIBLE,
    ) -> None:
        self._tiers = tiers
        self._cache = cache
        self._legacy = legacy
        self.freshness_policy = freshness_policy
        self._lock_seeds: dict[tuple[str, str, tuple[str, str], str], str] = {}
        self._coalesce: dict[tuple[str, str], threading.Event] = {}
        self._coalesce_lock = threading.Lock()
        self._remote_resolutions: dict[tuple[str, str], str] = {}
        # Diagnostics: counts per tier across the run. Read by tests.
        self.stats: dict[str, int] = {tier.name: 0 for tier in tiers}
        self.stats["coalesced"] = 0
        # Zero-I/O resolves of an already-concrete SHA. Tracked separately
        # so verbose tier stats do not inflate the commits-API count.
        self.stats["sha_passthrough"] = 0

    def remotely_resolved(self, dep_ref: DependencyReference, sha: str) -> bool:
        """Authorize persistence only for a current-remote tier's exact observation."""
        key = (_repository_cache_identity(dep_ref), dep_ref.reference or "")
        with self._coalesce_lock:
            return self._remote_resolutions.get(key) == sha

    def seed(self, repo_ref: str | DependencyReference, ref: str, sha: str) -> bool:
        """Record a dependency-scoped lockfile ``ref -> sha``.

        Used by the resolve phase to inject a lockfile-recorded commit
        (``resolved_commit``) for a named ``resolved_ref`` -- a branch OR a
        tag name, whichever the lockfile recorded -- BEFORE any download
        runs, so the subsequent ``resolve()`` for that same ref gets an L0
        hit and the commits-API tier (L1) never fires. ``ref`` must be the
        exact ref string ``resolve()`` will look up. Idempotent; a no-op
        unless ``sha`` is a full 40-char hex commit and ``ref`` is
        non-empty. Returns ``True`` when a value was stored.

        Lock seeds must not enter the repository-wide fresh-result cache:
        a sibling virtual package without a matching lock entry must still
        establish the current upstream ref. Historical provider metadata
        that can no longer be classified is rejected, not replayed.
        """
        if (
            not self.freshness_policy.allows_lock_seed
            or not ref
            or not sha
            or not _SHA_RE.match(sha)
        ):
            return False
        dep_ref = self._normalize(repo_ref)
        # Only historical admission is recoverable; current declarations
        # still use strict classification during parsing and resolution.
        try:
            key = self._lock_seed_key(dep_ref, ref)
        except (ValueError, RuntimeError) as exc:
            _log.debug(
                "Skipping lock seed: historical provider identity is unclassifiable (%s)",
                type(exc).__name__,
            )
            return False
        with self._coalesce_lock:
            self._lock_seeds[key] = sha.lower()
        return True

    @staticmethod
    def _lock_seed_key(
        dep_ref: DependencyReference, ref: str
    ) -> tuple[str, str, tuple[str, str], str]:
        from ..core.host_providers import effective_host_provider_identity

        return (
            dep_ref.get_unique_key(),
            _repository_cache_identity(dep_ref),
            effective_host_provider_identity(
                dep_ref.host or default_host(), host_type=dep_ref.host_type
            ),
            ref,
        )

    def resolve(self, repo_ref: str | DependencyReference) -> ResolvedReference:
        """Resolve a git reference, dispatching through the tier waterfall.

        Mirrors :meth:`GitReferenceResolver.resolve` in signature and
        return type so callers swap in without code changes elsewhere.
        """
        dep_ref = self._normalize(repo_ref)
        ref = dep_ref.reference or None

        # No ref or artifactory: fall straight through to legacy so we
        # preserve the existing default-branch + artifactory paths
        # without re-implementing them per-tier.
        if not ref or dep_ref.is_artifactory():
            return self._legacy.resolve_full(dep_ref)

        # Ref is already a concrete commit SHA (e.g. the download ref was
        # rewritten from the lockfile): resolution is a no-op with zero I/O.
        # Count it distinctly so verbose tier stats reflect *real* network
        # round-trips -- previously this fell into the commits-API tier and
        # inflated ``commits_api`` even though no HTTP call was made.
        if _SHA_RE.match(ref):
            self.stats["sha_passthrough"] = self.stats.get("sha_passthrough", 0) + 1
            return self._build_result(dep_ref, ref, ref.lower(), tier_name="sha_passthrough")

        if self._lock_seeds:
            lock_key = self._lock_seed_key(dep_ref, ref)
            with self._coalesce_lock:
                locked = self._lock_seeds.get(lock_key)
            if locked is not None:
                self.stats["per_run_cache"] += 1
                return self._build_result(dep_ref, ref, locked, tier_name="lock_seed")

        key = (_repository_cache_identity(dep_ref), ref)

        # Fast path: cache hit avoids both tier dispatch and the
        # coalesce lock entirely.
        cached = self._cache.get(*key)
        if cached:
            self.stats["per_run_cache"] += 1
            return self._build_result(dep_ref, ref, cached, tier_name="per_run_cache")

        # Coalesce concurrent resolves of the same key.
        with self._coalesce_lock:
            existing = self._coalesce.get(key)
            if existing is None:
                self._coalesce[key] = threading.Event()
                leader = True
            else:
                leader = False

        if not leader:
            existing.wait()
            self.stats["coalesced"] += 1
            cached = self._cache.get(*key)
            if cached:
                return self._build_result(dep_ref, ref, cached, tier_name="coalesced")
            # Leader failed -- fall through and try ourselves.

        try:
            sha = self._dispatch(dep_ref, ref)
            if sha:
                self._cache.put(*key, sha)
                return self._build_result(dep_ref, ref, sha, tier_name=self._last_tier)
            # All tiers returned None and L3 included -- this is
            # genuine failure (e.g. ref not found). Re-raise from
            # legacy so callers get the original error message.
            return self._legacy.resolve_full(dep_ref)
        finally:
            if leader:
                with self._coalesce_lock:
                    event = self._coalesce.pop(key, None)
                if event is not None:
                    event.set()

    def _dispatch(self, dep_ref: DependencyReference, ref: str) -> str | None:
        self._last_tier = "none"
        for tier in self._tiers:
            try:
                sha = tier.try_resolve(dep_ref, ref)
            except Exception as exc:
                _log.debug("Tier %s raised (%s)", tier.name, type(exc).__name__)
                continue
            if sha and _SHA_RE.match(sha):
                self.stats[tier.name] = self.stats.get(tier.name, 0) + 1
                self._last_tier = tier.name
                if self.freshness_policy.requires_remote and tier.name in (
                    "commits_api",
                    "legacy_clone",
                ):
                    key = (_repository_cache_identity(dep_ref), ref)
                    with self._coalesce_lock:
                        self._remote_resolutions[key] = sha.lower()
                return sha.lower()
        return None

    @staticmethod
    def _normalize(repo_ref: str | DependencyReference) -> DependencyReference:
        if isinstance(repo_ref, DependencyReference):
            return repo_ref
        try:
            return DependencyReference.parse(repo_ref)
        except ValueError as exc:
            raise ValueError(f"Invalid repository reference '{repo_ref}': {exc}") from exc

    @staticmethod
    def _build_result(
        dep_ref: DependencyReference,
        ref: str,
        sha: str,
        *,
        tier_name: str,
    ) -> ResolvedReference:
        # Choose ref_type heuristically. The cheap tiers do not
        # distinguish branch vs tag (a single SHA-returning API call
        # cannot tell you which container the ref lives in without a
        # second call). We pick COMMIT when the input *was* a SHA-like
        # string and BRANCH otherwise. Callers that need precise
        # distinction (today: cache eligibility in integrate.py:77)
        # already treat BRANCH and TAG identically when the SHA
        # matches the lockfile, so the heuristic is behaviour-safe.
        ref_type = GitReferenceType.COMMIT if _SHA_RE.match(ref) else GitReferenceType.BRANCH
        _log.debug(
            "TieredRefResolver: %s @ %s -> %s (via %s)",
            dep_ref.repo_url,
            ref,
            sha[:12],
            tier_name,
        )
        return ResolvedReference(
            original_ref=str(dep_ref),
            ref_type=ref_type,
            resolved_commit=sha,
            ref_name=ref,
        )


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def build_tiered_ref_resolver(
    *,
    downloader: GitHubPackageDownloader,
    git_cache: GitCache | None = None,
    freshness_policy: RefFreshnessPolicy = RefFreshnessPolicy.REPRODUCIBLE,
) -> TieredRefResolver | None:
    """Construct the production tier stack, or ``None`` if disabled.

    The compatibility default permits bare-cache answers. Install callers use
    ``LOCKED_OR_CURRENT`` to replay matching lock seeds while resolving every
    unseeded ref upstream. Commands changing current state use ``CURRENT_REMOTE``.

    Returns ``None`` when ``APM_TIERED_RESOLVER`` is disabled so callers
    can opt out by simply leaving ``downloader._tiered_resolver = None``;
    the downloader facade falls through to the legacy resolver in that
    case.

    Args:
        downloader: The package downloader providing auth and legacy resolve.
        git_cache: Optional persistent git cache for the L2 bare-rev-parse tier.
        freshness_policy: Canonical cache/remote policy for this command.
            ``CURRENT_REMOTE`` excludes lock-seeded and persistent bare-cache
            answers while retaining per-run coalescing of fresh results.
    """
    _ = default_host  # keep import side-effect for compat with monkeypatched tests
    if not is_tiered_resolver_enabled():
        _log.debug("TieredRefResolver disabled via APM_TIERED_RESOLVER env var")
        return None

    cache = PerRunRefCache()
    legacy_inner = getattr(downloader, "_refs", None)
    if legacy_inner is None:
        # Pathological: downloader without a legacy resolver. Bail out
        # so callers fall through to whatever path they had before.
        return None
    legacy = L3LegacyClone(legacy_inner)

    tiers: list[RefResolutionTier] = [
        L0PerRunCache(cache=cache),
        L1CommitsAPI(host=downloader),
    ]
    if freshness_policy.allows_bare_cache:
        tiers.append(L2BareRevParse(git_cache=git_cache))
    else:
        _log.debug(
            "TieredRefResolver: L2BareRevParse excluded by %s policy",
            freshness_policy.value,
        )
    tiers.append(legacy)

    return TieredRefResolver(
        tiers=tiers,
        cache=cache,
        legacy=legacy,
        freshness_policy=freshness_policy,
    )
