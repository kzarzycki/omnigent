"""Git reference resolution.

Resolves user-supplied refs (branch / tag / commit SHA / unspecified)
to a concrete :class:`ResolvedReference` and enumerates remote refs
without cloning. Splits three concerns out of the
:class:`GitHubPackageDownloader` monolith:

1. **Cheap SHA resolution** for GitHub-family hosts via the commits API
   (``GET /repos/.../commits/{ref}`` with ``Accept: application/vnd.github.sha``).
2. **List remote refs** via ``git ls-remote --tags --heads`` with the
   ADO bearer-fallback dance handled by ``AuthResolver``.
3. **Resolve a ref to a SHA** via clone-and-introspect (shallow first,
   then full clone fallback) when the cheap path does not apply.

Design pattern: **Strategy**, exposed through a single :class:`Facade`
(:class:`GitReferenceResolver`).

The resolver holds a reference to the surrounding downloader (a
``DownloaderContext`` Protocol) so it can reuse shared infrastructure
(auth env, transport-aware clone, ls-remote parsing helpers) without
duplicating that code. This mirrors the existing ``DownloadDelegate``
pattern.
"""

from __future__ import annotations

import re
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Protocol

from ..core.auth_chain import AdoAuthChainExhaustedError
from ..core.auth_outcome import (
    RepositoryNotFoundError,
    classify_auth_outcome,
    is_repository_not_found,
)
from ..models.apm_package import (
    DependencyReference,
    GitReferenceType,
    RemoteRef,
    ResolvedReference,
)
from ..models.dependency.host_virtual import (
    dependency_repository_owner,
    repository_owner,
    repository_path_segments,
)
from ..utils.git_env import get_git_executable, git_subprocess_error_text
from ..utils.github_host import (
    default_host,
    is_github_hostname,
)
from .git_lazy import git_command_error, loaded_git_module, new_git_command_error
from .git_remote_ops import validate_ls_remote_tag_output
from .github_rate_limit import raise_for_github_throttle
from .transport_selection import ProtocolPreference, initial_transport_scheme

if TYPE_CHECKING:
    import requests

    from ..core.auth import AuthResolver
    from .transport_selection import TransportSelector


# ---------------------------------------------------------------------------
# Downloader collaboration contract
# ---------------------------------------------------------------------------


class _DownloaderContext(Protocol):
    """The slice of :class:`GitHubPackageDownloader` the resolver needs.

    Kept duck-typed (``Protocol``) so tests can inject a minimal stub
    without instantiating the full downloader.
    """

    auth_resolver: AuthResolver
    git_env: dict
    shared_clone_cache: object | None
    _protocol_pref: ProtocolPreference
    _transport_selector: TransportSelector

    def _resolve_dep_token(self, dep_ref: DependencyReference | None = ...) -> str | None: ...
    def _resolve_dep_auth_ctx(self, dep_ref: DependencyReference | None = ...): ...
    def _build_noninteractive_git_env(
        self,
        *,
        preserve_config_isolation: bool = ...,
        suppress_credential_helpers: bool = ...,
    ) -> dict: ...
    def _build_repo_url(
        self,
        repo_url_base: str,
        *,
        use_ssh: bool = ...,
        dep_ref: DependencyReference,
    ) -> str: ...
    def _clone_with_fallback(self, *args, **kwargs): ...
    def _sanitize_git_error(self, error_message: str) -> str: ...
    def _resilient_get(
        self,
        url: str,
        headers: dict[str, str],
        timeout: int = ...,
        max_retries: int = ...,
    ) -> requests.Response: ...
    def _parse_ls_remote_output(self, output: str) -> list[RemoteRef]: ...
    def _sort_remote_refs(self, refs: list[RemoteRef]) -> list[RemoteRef]: ...
    def _parse_artifactory_base_url(self) -> tuple | None: ...
    def _should_use_artifactory_proxy(self, dep_ref: DependencyReference) -> bool: ...


# ---------------------------------------------------------------------------
# Resolver
# ---------------------------------------------------------------------------


class GitReferenceResolver:
    """Resolve and enumerate Git references for an APM dependency."""

    def __init__(self, host: _DownloaderContext) -> None:
        self._host = host

    # -- list_remote_refs ----------------------------------------------

    def list_remote_refs(self, dep_ref: DependencyReference) -> list[RemoteRef]:
        """Enumerate remote tags and branches without cloning.

        Uses ``git ls-remote --tags --heads`` for all git hosts (GitHub,
        Azure DevOps, GitLab, generic). Artifactory dependencies return
        an empty list (no git repo), as do all dependencies when
        registry-only mode (``PROXY_REGISTRY_ONLY``) is active.
        """
        return self._list_remote_refs(dep_ref, include_heads=True)

    def list_remote_tag_refs(self, dep_ref: DependencyReference) -> list[RemoteRef]:
        """Enumerate remote tags only, preserving annotated-tag metadata."""
        return self._list_remote_refs(dep_ref, include_heads=False)

    def _list_remote_refs(
        self,
        dep_ref: DependencyReference,
        *,
        include_heads: bool,
    ) -> list[RemoteRef]:
        """Enumerate remote tags, optionally including branch heads."""
        host = self._host

        if dep_ref.is_artifactory():
            return []

        from .egress_route import EgressSurface, is_refused

        if is_refused(EgressSurface.SOURCE_ENUMERATION):
            # PROXY_REGISTRY_ONLY=1: the proxy is the only sanctioned source,
            # so skip the direct ls-remote against the upstream host. Mirrors
            # the is_artifactory() short-circuit above: a registry-only
            # dependency has no git remote we are permitted to enumerate.
            return []

        is_ado = dep_ref.is_azure_devops()
        repo_url_base = dep_ref.repo_url
        candidate_uses_ssh = initial_transport_scheme(dep_ref, host._protocol_pref) == "ssh"
        rewrite_candidate = host._build_repo_url(
            repo_url_base,
            use_ssh=candidate_uses_ssh,
            dep_ref=dep_ref,
        )
        anonymous_plan = host._transport_selector.select(
            dep_ref=dep_ref,
            cli_pref=host._protocol_pref,
            allow_fallback=False,
            has_token=False,
            candidate_url=rewrite_candidate,
        )
        dep_host = dep_ref.host or default_host()
        public_github_https_first = bool(
            not dep_ref.is_insecure
            and anonymous_plan.attempts
            and anonymous_plan.attempts[0].scheme == "https"
            and host.auth_resolver.uses_public_github_anonymous_first(
                dep_host,
                port=dep_ref.port,
                host_type=dep_ref.host_type,
            )
            is True
        )
        if public_github_https_first:
            dep_token = None
            dep_auth_ctx = None
            transport_plan = anonymous_plan
        else:
            dep_token = host._resolve_dep_token(dep_ref)
            dep_auth_ctx = host._resolve_dep_auth_ctx(dep_ref)
            transport_plan = host._transport_selector.select(
                dep_ref=dep_ref,
                cli_pref=host._protocol_pref,
                allow_fallback=False,
                has_token=bool(dep_token),
                candidate_url=rewrite_candidate,
            )
        transport_attempt = transport_plan.attempts[0]
        use_ssh = transport_attempt.scheme == "ssh"

        if public_github_https_first:
            ls_env: dict[str, str] = {}
            remote_url = ""
        elif use_ssh:
            ls_env = host._build_noninteractive_git_env()
            from ..utils.git_env import clear_git_auth_env

            clear_git_auth_env(ls_env)
            ls_env.pop("GIT_ASKPASS", None)
        elif dep_token and transport_attempt.use_token:
            if dep_auth_ctx is not None:
                ls_env = host.auth_resolver.git_env_for_context(
                    dep_auth_ctx,
                    base_env=host.git_env,
                )
            else:
                classified = host.auth_resolver.classify_host(
                    dep_host or default_host(),
                    port=dep_ref.port,
                    host_type=dep_ref.host_type,
                )
                fallback_kind = "github" if is_github_hostname(dep_host or "") else "generic"
                ls_env = host.auth_resolver._build_git_env(
                    dep_token,
                    host_kind=getattr(classified, "kind", fallback_kind),
                    base_env=host.git_env,
                )
        elif is_ado:
            ado_context = dep_auth_ctx or host.auth_resolver.resolve_for_dep(dep_ref)
            ls_env = host.auth_resolver.git_env_for_remote(
                ado_context,
                transport_attempt.effective_url or rewrite_candidate,
                base_env=host.git_env,
            )
        else:
            ls_env = host._build_noninteractive_git_env(
                preserve_config_isolation=bool(getattr(dep_ref, "is_insecure", False)),
                suppress_credential_helpers=bool(getattr(dep_ref, "is_insecure", False)),
            )

        if transport_attempt.requested_url is not None:
            remote_url = transport_attempt.requested_url
        elif not public_github_https_first:
            remote_url = host._build_repo_url(
                repo_url_base,
                use_ssh=use_ssh,
                dep_ref=dep_ref,
            )

        # Keep the GitPython object as a test seam. The network call itself
        # routes through the direct-subprocess owner unless a test replaces
        # this method.
        from . import github_downloader as _gd

        # Read ``git`` from the module dict: a test double or an already
        # loaded GitPython is honoured, but this probe never imports GitPython.
        _git_cls = getattr(getattr(loaded_git_module(vars(_gd)), "cmd", None), "Git", None)
        g = _git_cls() if _git_cls is not None else None
        ls_args = ("--tags", "--heads") if include_heads else ("--tags",)

        def _run_remote(url: str, env: dict[str, str]) -> str:
            if g is not None and type(g).__module__.startswith("unittest.mock"):
                return g.ls_remote(*ls_args, url, env=env)
            from ..utils.git_env import git_remote_refs

            result = git_remote_refs(url, env=env, options=ls_args)
            if result.returncode != 0:
                # auth-delegated: try_with_fallback (or the caller's resolved
                # context) selects this environment.
                raise new_git_command_error(
                    [get_git_executable(), "ls-remote", *ls_args, url],
                    result.returncode,
                    stderr=result.stderr,
                )
            return result.stdout

        def _primary_op():
            try:
                if g is None or not type(g).__module__.startswith("unittest.mock"):
                    from .anonymous_ref_listing import list_refs_authenticated

                    listed = list_refs_authenticated(
                        remote_url, include_heads=include_heads, env=ls_env
                    )
                    if listed is not None:
                        return ("ok", listed)
                output = _run_remote(remote_url, ls_env)
                return ("ok", output)
            except git_command_error() as exc:
                return ("err", exc)

        ado_chain = is_ado and not use_ssh
        ado_attempts = None
        if public_github_https_first:

            def _public_github_op(
                token: str | None,
                git_env: dict[str, str],
            ) -> tuple[str, str]:
                public_url = host._build_repo_url(
                    repo_url_base,
                    use_ssh=False,
                    dep_ref=dep_ref,
                )
                if token is None and not (
                    g is not None and type(g).__module__.startswith("unittest.mock")
                ):
                    # The anonymous attempt only: answered in process when git's
                    # request is provably identical; otherwise git runs as before.
                    from .anonymous_ref_listing import list_refs_anonymously

                    listed = list_refs_anonymously(
                        public_url, include_heads=include_heads, env=git_env
                    )
                    if listed is not None:
                        return ("ok", listed)
                return ("ok", _run_remote(public_url, git_env))

            org = repository_owner(repo_url_base)
            try:
                outcome = host.auth_resolver.try_with_fallback(
                    dep_host,
                    _public_github_op,
                    org=org,
                    port=dep_ref.port,
                    path=dep_ref.repo_url,
                    host_type=dep_ref.host_type,
                    unauth_first=True,
                    base_env=host.git_env,
                )
            except (git_command_error(), OSError) as exc:
                outcome = ("err", exc)
        elif ado_chain:

            def _ado_op(_token: str | None, git_env: dict[str, str]) -> tuple[str, str]:
                # auth-delegated: try_with_fallback walks PAT -> az bearer ->
                # path-scoped helper and classifies each failure.
                return ("ok", _run_remote(remote_url, git_env))

            try:
                outcome = host.auth_resolver.try_with_fallback(
                    dep_host,
                    _ado_op,
                    org=dependency_repository_owner(dep_ref),
                    port=dep_ref.port,
                    path=dep_ref.repo_url,
                    host_type=dep_ref.host_type,
                    remote_url=transport_attempt.effective_url or remote_url,
                    base_env=host.git_env,
                )
            except (git_command_error(), OSError, AdoAuthChainExhaustedError) as exc:
                outcome = ("err", exc)
            ado_attempts = getattr(outcome[1], "attempts", None) if outcome[0] == "err" else None
        else:
            outcome = _primary_op()

        if outcome[0] == "ok":
            if not include_heads:
                validate_ls_remote_tag_output(outcome[1])
            refs = host._parse_ls_remote_output(outcome[1])
            return host._sort_remote_refs(refs)

        e = outcome[1]
        dep_host = dep_ref.host
        is_github = is_github_hostname(dep_host) if dep_host else True
        is_generic = not is_ado and not is_github

        ref_kind = "remote refs" if include_heads else "remote tags"
        if is_repository_not_found(e):
            raise RepositoryNotFoundError(
                host.auth_resolver.build_not_found_message(
                    dep_host or default_host(),
                    repo_url_base,
                    dependency_repository_owner(dep_ref),
                    port=dep_ref.port,
                    host_type=dep_ref.host_type,
                )
            ) from e
        error_msg = f"Failed to list {ref_kind} for {repo_url_base}. "
        if (
            public_github_https_first
            and not classify_auth_outcome(
                host_kind="github",
                error=e,
                public_github_anonymous=True,
            ).is_auth_failure
        ):
            error_msg += (
                f"Could not connect to {dep_host or default_host()} "
                "(network error, not an auth failure). "
                "Check your internet connection and proxy settings. "
                "Run with --verbose for details."
            )
        elif is_generic:
            if dep_host:
                host_info = host.auth_resolver.classify_host(dep_host, port=dep_ref.port)
                host_name = host_info.display_name
            else:
                host_name = "the target host"
            error_msg += (
                f"For private repositories on {host_name}, configure SSH keys "
                f"or a git credential helper. "
                f"APM delegates authentication to git for non-GitHub/ADO hosts."
            )
        else:
            target_host = dep_host or default_host()
            org = (
                dependency_repository_owner(dep_ref) if dep_ref else repository_owner(repo_url_base)
            )
            error_msg += host.auth_resolver.build_error_context(
                target_host,
                "list refs",
                org=org,
                port=dep_ref.port if dep_ref else None,
                dep_url=dep_ref.repo_url if dep_ref else None,
                attempts=ado_attempts,
            )

        sanitized = host._sanitize_git_error(git_subprocess_error_text(e))
        error_msg += f" Last error: {sanitized}"
        raise RuntimeError(error_msg) from e

    # -- resolve_commit_sha_for_ref ------------------------------------

    def commits_api_available(self, dep_ref: DependencyReference) -> bool:
        """Whether the cheap tier serves *dep_ref*: a commits API host over HTTPS.

        Makes no request. The resolver tier reads branch and tag names from the
        origin's ref listing only where it would otherwise ask the commits API,
        so other hosts and SSH keep the clone-based resolution. Registry-only
        mode is enforced by the listing and the commits API themselves.
        """
        from .host_backends import backend_for

        host = self._host
        try:
            if dep_ref.is_artifactory() or dep_ref.is_azure_devops():
                return False
            if initial_transport_scheme(dep_ref, host._protocol_pref) != "https":
                return False
            if len(repository_path_segments(dep_ref.repo_url)) < 2:
                return False
            fallback = dep_ref.host or default_host()
            backend = backend_for(dep_ref, host.auth_resolver, fallback_host=fallback)
            return backend.build_commits_api_url(dep_ref, "HEAD") is not None
        except Exception:
            return False

    def resolve_commit_sha_for_ref(self, dep_ref: DependencyReference, ref: str) -> str | None:
        """Resolve a Git ref to a 40-char SHA via the cheap GitHub commits API.

        Returns the SHA on success, or ``None`` on any failure (404,
        network, non-GitHub host, unexpected body shape, etc.).
        Failures are swallowed so callers can still record the ref name.
        Registry-only mode (``PROXY_REGISTRY_ONLY``) returns ``None``
        without a request; an already-full SHA is still passed through.
        """
        host = self._host

        try:
            if dep_ref.is_artifactory() or dep_ref.is_azure_devops():
                return None
        except Exception:
            return None

        target_host = dep_ref.host or default_host()

        if re.match(r"^[a-f0-9]{40}$", ref.lower() or ""):
            return ref.lower()

        from .egress_route import EgressSurface, is_refused

        if is_refused(EgressSurface.SOURCE_ENUMERATION):
            # PROXY_REGISTRY_ONLY=1: the commits API is on the upstream host,
            # which the mode forbids contacting. Callers already treat None
            # as "keep the ref name" and fall through to proxy resolution.
            return None

        if initial_transport_scheme(dep_ref, host._protocol_pref) == "ssh":
            return None

        try:
            if len(repository_path_segments(dep_ref.repo_url)) < 2:
                return None
        except AttributeError:
            return None

        from .host_backends import backend_for

        backend = backend_for(dep_ref, host.auth_resolver, fallback_host=target_host)
        api_url = backend.build_commits_api_url(dep_ref, ref)
        if api_url is None:
            return None

        org = dependency_repository_owner(dep_ref)

        def _request(token: str | None, _git_env: dict[str, str]) -> str | None:
            headers: dict[str, str] = {"Accept": "application/vnd.github.sha"}
            from ..core.auth import AuthResolver

            headers.update(AuthResolver.github_rest_headers(token))
            response = host._resilient_get(
                api_url,
                headers=headers,
                timeout=10,
                max_retries=1,
            )
            if response.status_code != 200:
                raise_for_github_throttle(response, target_host)
                error = RuntimeError(f"GitHub commits API returned HTTP {response.status_code}")
                error.status_code = response.status_code
                raise error
            body = (response.text or "").strip()
            return body.lower() if re.match(r"^[a-f0-9]{40}$", body.lower()) else None

        try:
            if (
                host.auth_resolver.uses_public_github_anonymous_first(
                    target_host,
                    port=dep_ref.port,
                    host_type=dep_ref.host_type,
                )
                is True
            ):
                return host.auth_resolver.try_with_fallback(
                    target_host,
                    _request,
                    org=org,
                    port=dep_ref.port,
                    path=dep_ref.repo_url,
                    host_type=dep_ref.host_type,
                    unauth_first=True,
                )
            file_ctx = host.auth_resolver.resolve(
                target_host,
                org,
                port=dep_ref.port,
                host_type=dep_ref.host_type,
            )
            return _request(file_ctx.token, file_ctx.git_env)
        except Exception:
            return None

    # -- resolve (clone-and-introspect) --------------------------------

    def resolve(self, repo_ref: str | DependencyReference) -> ResolvedReference:
        """Resolve a Git reference (branch/tag/commit) to a specific commit SHA."""
        from ..config import get_apm_temp_dir
        from .github_downloader import _rmtree

        host = self._host

        if isinstance(repo_ref, DependencyReference):
            dep_ref = repo_ref
        else:
            try:
                dep_ref = DependencyReference.parse(repo_ref)
            except ValueError as e:
                raise ValueError(f"Invalid repository reference '{repo_ref}': {e}")  # noqa: B904

        ref = dep_ref.reference or None
        original_ref_str = str(dep_ref)

        # Artifactory: no git repo to query, return ref-based resolution
        if dep_ref.is_artifactory() or (
            host._parse_artifactory_base_url() and host._should_use_artifactory_proxy(dep_ref)
        ):
            effective_ref = ref or "main"
            is_commit = re.match(r"^[a-f0-9]{7,40}$", effective_ref.lower()) is not None
            return ResolvedReference(
                original_ref=original_ref_str,
                ref_type=GitReferenceType.COMMIT if is_commit else GitReferenceType.BRANCH,
                resolved_commit=None,
                ref_name=effective_ref,
            )

        # Semver range resolution: enumerate remote tags, pick the highest match.
        # Non-semver refs fall through to the existing branch/commit/clone path.
        if ref:
            from ..deps.registry.semver import is_semver_range, pick_best

            if is_semver_range(ref):
                remote_refs = self.list_remote_refs(dep_ref)
                # Build version-string -> (tag_name, sha) map.
                # Strip the common 'v' prefix (e.g. 'v1.2.3' -> '1.2.3').
                candidates: dict[str, tuple[str, str]] = {}
                for rr in remote_refs:
                    if rr.ref_type != GitReferenceType.TAG:
                        continue
                    raw_tag = rr.name
                    version_str = raw_tag[1:] if raw_tag.startswith("v") else raw_tag
                    from ..marketplace.semver import parse_semver

                    if parse_semver(version_str) is not None:
                        candidates[version_str] = (raw_tag, rr.commit_sha)
                best_version = pick_best(ref, list(candidates.keys()))
                if best_version is None:
                    available = sorted(candidates.keys())[:10]
                    raise ValueError(
                        f"No git tag in {dep_ref.repo_url!r} satisfies semver range {ref!r}. "
                        f"Available semver tags: {available}"
                    )
                best_tag, best_sha = candidates[best_version]
                return ResolvedReference(
                    original_ref=ref,
                    ref_type=GitReferenceType.TAG,
                    ref_name=best_tag,
                    resolved_commit=best_sha,
                )

        is_likely_commit = bool(ref) and re.match(r"^[a-f0-9]{7,40}$", ref.lower()) is not None

        temp_dir = None
        try:
            temp_dir = Path(tempfile.mkdtemp(dir=get_apm_temp_dir()))

            if is_likely_commit:
                try:
                    host._clone_with_fallback(
                        dep_ref.repo_url, temp_dir, progress_reporter=None, dep_ref=dep_ref
                    )
                    from ..utils.git_env import git_resolve_commit

                    ref_type = GitReferenceType.COMMIT
                    resolved_commit = git_resolve_commit(temp_dir, ref, env=host.git_env)
                    ref_name = ref
                except Exception as e:
                    sanitized_error = host._sanitize_git_error(git_subprocess_error_text(e))
                    raise ValueError(  # noqa: B904
                        f"Could not resolve commit '{ref}' in repository "
                        f"{dep_ref.repo_url}: {sanitized_error}"
                    )
            else:
                shallow = None
                if not (ref or "").startswith("refs/"):
                    try:
                        shallow = self._resolve_shallow(dep_ref, ref, temp_dir)
                    except (git_command_error(), RuntimeError):
                        # The clone engine reports a failed plan as RuntimeError.
                        shallow = None
                if shallow is not None:
                    ref_type, resolved_commit, ref_name = shallow
                else:
                    try:
                        host._clone_with_fallback(
                            dep_ref.repo_url, temp_dir, progress_reporter=None, dep_ref=dep_ref
                        )
                        try:
                            ref_type, resolved_commit = self._resolve_in_clone(
                                temp_dir, ref, dep_ref
                            )
                            ref_name = ref
                        except Exception as e:
                            sanitized_error = host._sanitize_git_error(git_subprocess_error_text(e))
                            raise ValueError(  # noqa: B904
                                f"Could not resolve reference '{ref}' in repository "
                                f"{dep_ref.repo_url}: {sanitized_error}"
                            )

                    except git_command_error() as e:
                        if "Authentication failed" in str(
                            e
                        ) or "remote: Repository not found" in str(e):
                            error_msg = f"Failed to clone repository {dep_ref.repo_url}. "
                            target_host = dep_ref.host or default_host()
                            org = dependency_repository_owner(dep_ref)
                            error_msg += host.auth_resolver.build_error_context(
                                target_host,
                                "resolve reference",
                                org=org,
                                port=dep_ref.port,
                                dep_url=dep_ref.repo_url,
                            )
                            raise RuntimeError(error_msg)  # noqa: B904
                        else:
                            sanitized_error = host._sanitize_git_error(git_subprocess_error_text(e))
                            raise RuntimeError(  # noqa: B904
                                f"Failed to clone repository {dep_ref.repo_url}: {sanitized_error}"
                            )

        finally:
            if temp_dir and temp_dir.exists():
                _rmtree(temp_dir)

        return ResolvedReference(
            original_ref=original_ref_str,
            ref_type=ref_type,
            resolved_commit=resolved_commit,
            ref_name=ref_name,
        )

    def _resolve_shallow(self, dep_ref, ref, temp_dir):
        """Resolve a short name (or the default branch) with a shallow ``clone --branch``."""
        from ..utils.git_env import git_current_branch, git_worktree_head

        host = self._host
        clone_kwargs = {"depth": 1}
        if ref:
            clone_kwargs["branch"] = ref
        host._clone_with_fallback(
            dep_ref.repo_url, temp_dir, progress_reporter=None, dep_ref=dep_ref, **clone_kwargs
        )
        resolved_commit = git_worktree_head(temp_dir, env=host.git_env)
        ref_name = ref if ref else git_current_branch(temp_dir, env=host.git_env)
        return GitReferenceType.BRANCH, resolved_commit, ref_name

    def _resolve_in_clone(self, temp_dir, ref, dep_ref):
        """Resolve *ref* in a full clone; a fully qualified name only in its own namespace."""
        from ..utils.git_env import git_exact_ref_commit

        if ref.startswith("refs/heads/"):
            candidates = ((GitReferenceType.BRANCH, f"refs/remotes/origin/{ref[11:]}"),)
        elif ref.startswith("refs/tags/"):
            candidates = ((GitReferenceType.TAG, ref),)
        else:
            candidates = (
                (GitReferenceType.BRANCH, f"refs/remotes/origin/{ref}"),
                (GitReferenceType.TAG, f"refs/tags/{ref}"),
            )
        for ref_type, name in candidates:
            commit = git_exact_ref_commit(temp_dir, name, env=self._host.git_env)
            if commit:
                return ref_type, commit
        raise ValueError(f"Reference '{ref}' not found in repository {dep_ref.repo_url}")
