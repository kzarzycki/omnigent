"""Standalone MCP lifecycle orchestrator.

Owns all MCP dependency resolution, installation, stale cleanup, and lockfile
persistence logic.  This is NOT a BaseIntegrator subclass  -- MCP integration is
config-level orchestration (registry APIs, runtime configs, lockfile tracking),
not file-level deployment (copy/collision/sync).

The existing adapters (client/, package_manager/) and registry operations
(registry/operations.py) are *used* by this class, not modified.
"""

from __future__ import annotations

import builtins
import copy
import json
import logging
import re
import warnings
from collections.abc import Callable, MutableMapping
from pathlib import Path
from typing import TYPE_CHECKING

import tomlkit
import yaml
from tomlkit.exceptions import TOMLKitError

from apm_cli.adapters.client._remote_shapes import harness_label
from apm_cli.core.null_logger import NullCommandLogger
from apm_cli.core.remediation import MCP_LOCKFILE_UNWRITABLE
from apm_cli.deps.lockfile import (
    LockFile,
    LockfileRefusal,
    get_lockfile_path,
    installed_apm_version,
)
from apm_cli.deps.lockfile_write_authority import lockfile_exists
from apm_cli.integration.mcp_config_view import (
    _collect_transitive_compat,
    _deduplicate,
    _get_server_configs,
    _get_server_provenance,
)
from apm_cli.integration.write_seam import atomic_write_text, write_json_config
from apm_cli.mcp_transport import canonical_remote_transport
from apm_cli.models.dependency.mcp import ManifestHeaderValue
from apm_cli.runtime.utils import find_runtime_binary
from apm_cli.utils.console import (
    _get_console,  # noqa: F401 -- re-exported; mcp_integrator_install imports this via lazy import
    _rich_error,
    _rich_info,
    _rich_success,
    _rich_warning,
)
from apm_cli.utils.staging_guard import assert_no_staging_paths
from apm_cli.utils.yaml_io import load_yaml, yaml_to_str

if TYPE_CHECKING:
    from apm_cli.core.command_logger import CommandLogger
    from apm_cli.core.target_detection import EffectiveTargetDecision
    from apm_cli.integration.mcp_integrator_install import ResolvedMcpTargets

_log = logging.getLogger(__name__)


def _reject_symlink_config(
    config_path: Path,
    label: str,
    logger: CommandLogger | None,
    *,
    fail_on_write_error: bool,
) -> bool:
    """Reject MCP cleanup through a symlink without reading its target."""
    protected_markers = {".claude", ".config", ".cursor", ".vscode"}
    symlink_candidates = {config_path, config_path.parent}
    parts = config_path.parts
    for index, part in enumerate(parts):
        if part in protected_markers:
            current = Path(*parts[: index + 1])
            symlink_candidates.add(current)
            for child in parts[index + 1 :]:
                current = current / child
                symlink_candidates.add(current)
            break
    try:
        has_symlink = any(path.is_symlink() for path in symlink_candidates)
    except OSError:
        has_symlink = True
    if not has_symlink:
        return False
    message = (
        f"Refusing to clean symlinked MCP config: {label} ({config_path}). "
        "Replace the symlink with a regular file or directory, then retry."
    )
    if fail_on_write_error:
        from apm_cli.install.errors import RequiredIntegrationError

        raise RequiredIntegrationError(message)
    if logger is not None:
        logger.warning(message)
    else:
        _rich_warning(message, symbol="warning")
    return True


def _cleanup_failure_message(label: str, exc: Exception) -> str:
    """Return an ASCII-safe cleanup failure with the underlying cause."""
    cause = str(exc) or exc.__class__.__name__
    ascii_cause = cause.encode("ascii", "backslashreplace").decode("ascii")
    return (
        f"MCP cleanup failed for {label}: {ascii_cause}. "
        "Check the config path and permissions, then retry."
    )


def _is_vscode_available(project_root: Path | str | None = None) -> bool:
    """Return True when VS Code can be targeted for MCP configuration.

    VS Code is considered available when either:
    - the ``code`` CLI command is on PATH (the standard case), or
    - a ``.vscode/`` directory exists in the resolved project root
      (common on macOS where the user hasn't run "Install 'code' command
      in PATH" from the VS Code command palette).

    Args:
        project_root: Project root to inspect for a `.vscode/` directory when
            explicit project context is provided. Falls back to CWD when unset.
    """
    root = Path(project_root) if project_root is not None else Path.cwd()
    from apm_cli.utils.git_env import trusted_executable

    return trusted_executable("code") is not None or (root / ".vscode").is_dir()


def _write_cleaned_json_config(
    config_path: Path,
    config: dict,
    servers_key: str,
    *,
    trailing_newline: bool,
    delete_emptied: bool,
) -> None:
    """Write a cleaned MCP JSON config, or delete it once APM's last entry left.

    With *delete_emptied*, a file whose servers were all removed by this
    cleanup and that holds no other key is offered to the provenance owner,
    which deletes it only when APM created it (#4852, #4867). A file with any
    other key, even an empty one, stays.
    """
    from apm_cli.integration.config_file_provenance import (
        delete_emptied_config,
        recorded_config_write,
    )

    empty = not config.get(servers_key) and set(config) <= {servers_key}
    if delete_emptied and delete_emptied_config(config_path, root=config_path.parent, empty=empty):
        return
    with recorded_config_write(config_path):
        write_json_config(
            config_path,
            config,
            default_trailing_newline=trailing_newline,
            new_file_mode=0o600,
        )


def _clean_json_mcp_config(
    config_path: Path,
    stale_names: builtins.set,
    logger,
    label: str,
    servers_key: str = "mcpServers",
    trailing_newline: bool = False,
    use_rich: bool = False,
    fail_on_write_error: bool = False,
    nested_servers: Callable[[dict], dict | None] | None = None,
    nested_settings: frozenset[str] = frozenset(),
    delete_emptied: bool = False,
) -> int:
    """Remove stale entries from a JSON-based MCP config file.

    Args:
        config_path: Path to the JSON config file.
        stale_names: Set of server names to remove (expanded form).
        logger: Command logger for progress messages.
        label: Human-readable config label used in log messages.
        servers_key: Key under which MCP servers are stored (default: ``"mcpServers"``).
        trailing_newline: When True, append a trailing newline after JSON serialisation.
        use_rich: When True, emit removal notices via ``_rich_success``; otherwise use
            ``logger.progress``.
        nested_servers: Returns a second server map inside the parsed config,
            or ``None``.  Stale names are removed from it as well, for layouts
            such as OpenCode v2 that keep servers below the top-level key.
            A top-level entry is then removed only when the nested map does
            not declare the same name, since that entry is not APM's.
        nested_settings: Top-level keys that hold settings rather than
            servers whenever ``nested_servers`` returns a map.
        delete_emptied: Delete the file once this cleanup removed every server
            it held and no other key remains (project ``.mcp.json``, #4852).

    Returns:
        Number of entries removed.
    """
    if (
        _reject_symlink_config(
            config_path,
            label,
            logger,
            fail_on_write_error=fail_on_write_error,
        )
        or not config_path.exists()
    ):
        return 0
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
        if not isinstance(config, dict):
            raise ValueError(f"{label} root must be a mapping")
        servers = config.get(servers_key, {})
        if not isinstance(servers, dict):
            raise ValueError(f"{label} {servers_key} must be a mapping")
        nested = nested_servers(config) if nested_servers else None
        if nested is None:
            removed = [n for n in stale_names if n in servers]
        else:
            removed = [
                n
                for n in stale_names
                if n in servers and n not in nested and n not in nested_settings
            ]
        for name in removed:
            del servers[name]
        if nested:
            nested_removed = [n for n in stale_names if n in nested]
            for name in nested_removed:
                del nested[name]
            removed = sorted(builtins.set(removed) | builtins.set(nested_removed))
        if removed:
            _write_cleaned_json_config(
                config_path,
                config,
                servers_key,
                trailing_newline=trailing_newline,
                delete_emptied=delete_emptied and nested is None,
            )
            for name in removed:
                msg = f"Removed stale MCP server '{name}' from {label}"
                if use_rich:
                    _rich_success(msg, symbol="check")
                else:
                    logger.progress(msg)
        return len(removed)
    except Exception as exc:
        _log.debug("Failed to clean stale MCP servers from %s", label, exc_info=True)
        if fail_on_write_error:
            from apm_cli.install.errors import RequiredIntegrationError

            raise RequiredIntegrationError(_cleanup_failure_message(label, exc)) from exc
        return 0


def _clean_hermes_mcp_config(
    config_path: Path,
    stale_names: builtins.set,
    logger,
    fail_on_write_error: bool = False,
) -> int:
    """Atomically remove stale servers from Hermes' YAML config."""
    label = "Hermes config.yaml"
    if (
        _reject_symlink_config(
            config_path,
            label,
            logger,
            fail_on_write_error=fail_on_write_error,
        )
        or not config_path.exists()
    ):
        return 0
    try:
        config = load_yaml(config_path)
        if config is None:
            config = {}
        if not isinstance(config, dict):
            raise ValueError("Hermes config root must be a mapping")
        servers = config.get("mcp_servers", {})
        if not isinstance(servers, dict):
            raise ValueError("Hermes mcp_servers must be a mapping")
        removed = [name for name in stale_names if name in servers]
        for name in removed:
            del servers[name]
        if removed:
            config["mcp_servers"] = servers
            atomic_write_text(config_path, yaml_to_str(config), new_file_mode=0o600)
            for name in removed:
                logger.progress(f"Removed stale MCP server '{name}' from {label}")
        return len(removed)
    except (OSError, UnicodeDecodeError, ValueError, yaml.YAMLError) as exc:
        _log.debug("Failed to clean stale MCP servers from %s", label, exc_info=True)
        if fail_on_write_error:
            from apm_cli.install.errors import RequiredIntegrationError

            raise RequiredIntegrationError(_cleanup_failure_message(label, exc)) from exc
        return 0


def _clean_toml_mcp_config(
    config_path: Path,
    stale_names: builtins.set,
    label: str,
    logger: CommandLogger | None = None,
    use_rich: bool = True,
    fail_on_write_error: bool = False,
) -> int:
    """Remove stale entries from a TOML-based MCP config file.

    Args:
        config_path: Path to the TOML config file.
        stale_names: Set of server names to remove (expanded form).
        label: Human-readable config label used in log messages.
        logger: Optional command logger for progress messages. When provided
            and *use_rich* is False, removal notices use ``logger.progress``.
        use_rich: When True (default), emit removal notices via ``_rich_success``;
            otherwise use ``logger.progress``.

    Returns:
        Number of entries removed.
    """
    if (
        _reject_symlink_config(
            config_path,
            label,
            logger,
            fail_on_write_error=fail_on_write_error,
        )
        or not config_path.exists()
    ):
        return 0
    try:
        config = tomlkit.parse(config_path.read_text(encoding="utf-8"))
        servers = config.get("mcp_servers", {})
        if not isinstance(servers, MutableMapping):
            raise ValueError("mcp_servers must be a table")
        removed = [n for n in stale_names if n in servers]
        for name in removed:
            del servers[name]
        if removed:
            atomic_write_text(config_path, tomlkit.dumps(config), new_file_mode=0o600)
            for name in removed:
                msg = f"Removed stale MCP server '{name}' from {label}"
                if use_rich:
                    _rich_success(msg, symbol="check")
                elif logger is not None:
                    logger.progress(msg)
        return len(removed)
    except (OSError, TOMLKitError, UnicodeDecodeError, ValueError) as exc:
        _log.debug("Failed to clean stale MCP servers from %s", label, exc_info=True)
        if fail_on_write_error:
            from apm_cli.install.errors import RequiredIntegrationError

            raise RequiredIntegrationError(_cleanup_failure_message(label, exc)) from exc
        return 0


def _clean_claude_config(
    config_path: Path,
    stale_names: builtins.set,
    logger,
    is_user_scope: bool = False,
    fail_on_write_error: bool = False,
    label: str | None = None,
) -> int:
    """Remove stale entries from a Claude Code JSON config file.

    Handles both the project-level ``.mcp.json`` and the user-level
    ``~/.claude.json``, which share the same JSON structure but differ in
    scope-validation requirements and log labels.

    Args:
        config_path: Path to the Claude JSON config file.
        stale_names: Set of server names to remove (expanded form).
        logger: Command logger for progress messages.
        is_user_scope: When True, validates that the top-level config is a dict
            (``~/.claude.json`` guard) and uses the user-scope log label.
        fail_on_write_error: When True, raise RequiredIntegrationError on write failure.
        label: Optional human-readable config label used in log messages.

    Returns:
        Number of entries removed.
    """
    if label is None:
        label = str(config_path) if is_user_scope else ".mcp.json"
    if (
        _reject_symlink_config(
            config_path,
            label,
            logger,
            fail_on_write_error=fail_on_write_error,
        )
        or not config_path.exists()
    ):
        return 0
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
        if not isinstance(config, dict):
            raise ValueError(f"{label} root must be a mapping")
        servers = config.get("mcpServers", {})
        if not isinstance(servers, dict):
            raise ValueError(f"{label} mcpServers must be a mapping")
        removed = [n for n in stale_names if n in servers]
        for name in removed:
            del servers[name]
        if removed:
            _write_cleaned_json_config(
                config_path,
                config,
                "mcpServers",
                trailing_newline=True,
                delete_emptied=not is_user_scope,
            )
            for name in removed:
                logger.progress(f"Removed stale MCP server '{name}' from {label}")
        return len(removed)
    except Exception as exc:
        _log.debug("Failed to clean stale MCP servers from %s", label, exc_info=True)
        if fail_on_write_error:
            from apm_cli.install.errors import RequiredIntegrationError

            raise RequiredIntegrationError(_cleanup_failure_message(label, exc)) from exc
        return 0


# MCPDependency fields that may carry an authored ``${CLAUDE_PLUGIN_ROOT}``.
_PLUGIN_ROOT_FIELDS = ("command", "args", "env", "url", "headers", "cwd", "extra")


class MCPIntegrator:
    """MCP lifecycle orchestrator  -- dependency resolution, installation, and cleanup.

    All methods are static: the class is a logical namespace, not a stateful
    object.  This keeps the extraction minimal and preserves the original
    call-site semantics exactly.
    """

    # ------------------------------------------------------------------
    # Dependency resolution
    # ------------------------------------------------------------------

    @staticmethod
    def prevalidate_registry_dependencies(
        mcp_deps: list,
        *,
        registry_url: str | None,
        verbose: bool,
        logger,
        registry_source: str | None = None,
        retry_args: tuple[str, ...] = (),
    ) -> builtins.dict[str, builtins.dict]:
        """Validate direct-install registry identities before any write."""
        from apm_cli.integration.mcp_integrator_install import (
            prevalidate_registry_dependencies,
        )

        return prevalidate_registry_dependencies(
            mcp_deps,
            registry_url=registry_url,
            verbose=verbose,
            logger=logger,
            registry_source=registry_source,
            retry_args=retry_args,
        )

    @staticmethod
    def collect_transitive(
        apm_modules_dir: Path,
        lock_path: Path | None = None,
        trust_private: bool = False,
        logger=None,
        diagnostics=None,
    ) -> list:
        """Compatibility delegate for canonical MCP source traversal."""
        return _collect_transitive_compat(
            apm_modules_dir,
            lock_path,
            trust_private,
            logger=logger,
            diagnostics=diagnostics,
        )

    # ------------------------------------------------------------------
    # Deduplication
    # ------------------------------------------------------------------

    @staticmethod
    def deduplicate(deps: list) -> list:
        """Deduplicate MCP dependencies by name; first occurrence wins.

        Root deps are listed before transitive, so root overlays take
        precedence.
        """
        return _deduplicate(deps)

    # ------------------------------------------------------------------
    # Server info helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_self_defined_info(dep, *, plugin_root: str | None = None) -> dict:
        """Build a synthetic server_info dict from a self-defined MCPDependency.

        Mimics the structure returned by the MCP registry so that existing
        adapter code can consume self-defined deps without changes.

        An authored ``${CLAUDE_PLUGIN_ROOT}`` stays in ``_raw_stdio`` with the
        package root under ``PLUGIN_ROOT_INFO_KEY``, so each adapter renders its
        own portable form. *plugin_root* binds a stored declaration that carries
        no materialized root to the current one.
        """
        import dataclasses

        from apm_cli.deps.plugin_root_render import (
            PLUGIN_ROOT_INFO_KEY,
            RECORDED_RENDER_INFO_KEY,
            plugin_root_of,
            render_plugin_root,
            with_absolute_plugin_root,
        )

        root = plugin_root or plugin_root_of(dep)

        def absolute(value):
            return render_plugin_root(
                value, plugin_root=root, project_root=None, project_relative=False
            )

        info: dict = {
            "name": dep.name,
            "is_self_defined": True,
        }
        if root:
            info[PLUGIN_ROOT_INFO_KEY] = root

        # For stdio self-defined deps, store raw command/args so adapters
        # can bypass registry-specific formatting (npm, docker, etc.).
        if dep.transport == "stdio" or (
            dep.transport not in ("http", "sse", "streamable-http") and dep.command
        ):
            info["_raw_stdio"] = {
                "command": dep.command or dep.name,
                "args": list(dep.args) if dep.args else [],
                "env": dict(dep.env) if dep.env else {},
            }
            if dep.cwd is not None:
                info["_raw_stdio"]["cwd"] = dep.cwd

        if dep.transport in ("http", "sse", "streamable-http"):
            # Build as a remote endpoint
            remote = {
                "transport": canonical_remote_transport({"transport": dep.transport}),
                "url": absolute(dep.url or ""),
            }
            if dep.headers:
                remote["headers"] = [
                    {"name": k, "value": ManifestHeaderValue(v) if isinstance(v, str) else v}
                    for k, v in absolute(dep.headers).items()
                ]
            info["remotes"] = [remote]
        else:
            # Build as a stdio package
            env_vars = []
            if dep.env:
                env_vars = [{"name": k, "description": "", "required": True} for k in dep.env]

            runtime_args = []
            if dep.args:
                if isinstance(dep.args, builtins.list):
                    runtime_args = [{"is_required": True, "value_hint": a} for a in dep.args]
                elif isinstance(dep.args, builtins.dict):
                    runtime_args = [
                        {"is_required": True, "value_hint": v} for v in dep.args.values()
                    ]

            info["packages"] = [
                {
                    "runtime_hint": dep.command or dep.name,
                    "name": dep.name,
                    "registry_name": "self-defined",
                    "runtime_arguments": runtime_args,
                    "package_arguments": [],
                    "environment_variables": env_vars,
                }
            ]

        # Embed tools override for adapters to pick up
        if dep.tools:
            info["_apm_tools_override"] = dep.tools

        dep.apply_opencode_enabled(info)

        # Pass through harness-specific extra keys for adapters to merge
        if dep.extra:
            info["_extra"] = absolute(dict(dep.extra))

        assert_no_staging_paths(info, f"MCP client configuration for '{dep.name}'")
        recorded_root = getattr(dep, "recorded_plugin_root", None)
        if isinstance(recorded_root, str) and recorded_root:
            recorded = with_absolute_plugin_root(dep, _PLUGIN_ROOT_FIELDS, root=recorded_root)
            info[RECORDED_RENDER_INFO_KEY] = MCPIntegrator._build_self_defined_info(
                dataclasses.replace(recorded, plugin_root=None, recorded_plugin_root=None)
            )
        return info

    @staticmethod
    def _canonicalize_remote_transports(info: dict) -> None:
        """Record each remote's canonical transport under ``transport`` (in place).

        Registry payloads are normalized at ingestion; this keeps server info
        that reached the overlay another way on the same canonical key.
        """
        for remote in info.get("remotes") or []:
            if not isinstance(remote, dict):
                continue
            try:
                remote["transport"] = canonical_remote_transport(remote)
            except ValueError:
                continue  # the rendering adapter reports it with its own label

    @staticmethod
    def _apply_overlay(server_info_cache: dict, dep) -> None:
        """Apply MCPDependency overlay fields onto cached server_info (in-place).

        Modifies the server_info dict in *server_info_cache[dep.name]* to
        reflect overlay preferences (transport selection, env, headers, tools).
        """
        info = server_info_cache.get(dep.name)
        if not info:
            return

        from apm_cli.deps.plugin_root_render import with_absolute_plugin_root

        dep = with_absolute_plugin_root(dep, ("headers", "args", "env", "extra"))
        dep.apply_opencode_enabled(info)

        MCPIntegrator._canonicalize_remote_transports(info)

        # Transport overlay: select matching transport from available options
        if dep.transport:
            if dep.transport in ("http", "sse", "streamable-http"):
                # User prefers remote transport  -- remove packages to force remote path
                if info.get("remotes"):
                    info.pop("packages", None)
                    declared = canonical_remote_transport({"transport": dep.transport})
                    matching = [
                        remote
                        for remote in info["remotes"]
                        if isinstance(remote, dict) and remote.get("transport") == declared
                    ]
                    if matching:
                        info["remotes"] = matching
            elif dep.transport == "stdio":
                # User prefers stdio  -- remove remotes to force package path
                if info.get("packages"):
                    info.pop("remotes", None)

        # Package type overlay: select specific package registry (npm, pypi, oci)
        if dep.package and "packages" in info:
            filtered = [
                p
                for p in info["packages"]
                if p.get("registry_name", "").lower() == dep.package.lower()
            ]
            if filtered:
                info["packages"] = filtered

        # Headers overlay: merge into remote headers
        if dep.headers and "remotes" in info:
            for remote in info["remotes"]:
                existing_headers = remote.get("headers", [])
                if isinstance(existing_headers, builtins.list):
                    for k, v in dep.headers.items():
                        existing_headers.append(
                            {
                                "name": k,
                                "value": ManifestHeaderValue(v) if isinstance(v, str) else v,
                            }
                        )
                    remote["headers"] = existing_headers
                elif isinstance(existing_headers, builtins.dict):
                    existing_headers.update(
                        {
                            k: ManifestHeaderValue(v) if isinstance(v, str) else v
                            for k, v in dep.headers.items()
                        }
                    )

        # Args overlay: merge into package runtime arguments
        if dep.args and "packages" in info:
            for pkg in info["packages"]:
                existing_args = pkg.get("runtime_arguments", [])
                if isinstance(dep.args, builtins.list):
                    for arg in dep.args:
                        existing_args.append({"value_hint": str(arg)})
                elif isinstance(dep.args, builtins.dict):
                    for k, v in dep.args.items():
                        existing_args.append({"value_hint": f"--{k}={v}"})
                pkg["runtime_arguments"] = existing_args

        # Registry data cannot supply authored overlay metadata.
        info.pop("_apm_env_overlay", None)
        # Keep authored values separate from collected install-time values.
        if dep.env:
            info["_apm_env_overlay"] = dict(dep.env)

        # Tools overlay: embed for adapters to pick up
        if dep.tools:
            info["_apm_tools_override"] = dep.tools

        # Pass through harness-specific extra keys for adapters to merge
        if dep.extra:
            info["_extra"] = dict(dep.extra)

        # Warn about overlay fields not yet applied at install time
        if dep.version:
            warnings.warn(
                f"MCP overlay field 'version' on '{dep.name}' is not yet applied "
                f"at install time and will be ignored.",
                stacklevel=2,
            )

    # ------------------------------------------------------------------
    # Name extraction
    # ------------------------------------------------------------------

    @staticmethod
    def get_server_names(mcp_deps: list) -> builtins.set:
        """Extract unique server names from a list of MCP dependencies."""
        names: builtins.set = builtins.set()
        for dep in mcp_deps:
            if hasattr(dep, "name"):
                names.add(dep.name)
            elif isinstance(dep, str):
                names.add(dep)
        return names

    @staticmethod
    def get_server_configs(mcp_deps: list) -> builtins.dict:
        """Extract server configs as {name: config_dict} from MCP dependencies."""
        return _get_server_configs(mcp_deps)

    @staticmethod
    def get_server_provenance(mcp_deps: list) -> builtins.dict:
        """Extract transitive provenance as {name: declaring_package} from MCP deps.

        Only servers carrying a ``resolved_by`` (set by
        :meth:`collect_transitive` for servers declared by a sub-package)
        are included. Servers declared directly in the root manifest have
        ``resolved_by is None`` and are omitted -- absence means "direct",
        mirroring the dependency-side convention. Because ``mcp_deps`` is the
        final deduplicated list (root entries listed first, first-wins), a
        server declared both in the root and transitively resolves to the
        root entry and is correctly treated as direct here (#2081).
        """
        return _get_server_provenance(mcp_deps)

    @staticmethod
    def _append_drifted_to_install_list(
        install_list: builtins.list,
        drifted: builtins.set,
    ) -> None:
        """Append drifted server names to *install_list* without duplicates.

        Appends in sorted order to guarantee deterministic CLI output.
        Names already present in *install_list* are skipped.
        """
        existing = builtins.set(install_list)
        for name in builtins.sorted(drifted):
            if name not in existing:
                install_list.append(name)

    @staticmethod
    def _detect_mcp_config_drift(
        mcp_deps: list,
        stored_configs: builtins.dict,
    ) -> builtins.set:
        """Return names of MCP deps whose manifest config differs from stored.

        Compares each dependency's current serialized config against the
        previously stored config in the lockfile.  Only dependencies that
        have a stored baseline *and* whose config has changed are returned.
        """
        from apm_cli.models.dependency.mcp import opencode_enabled_matches

        drifted: builtins.set = builtins.set()
        for dep in mcp_deps:
            if not hasattr(dep, "to_dict") or not hasattr(dep, "name"):
                continue
            current_config = dep.to_dict()
            stored = stored_configs.get(dep.name)
            if stored is not None and (
                stored != current_config or not opencode_enabled_matches(current_config, stored)
            ):
                drifted.add(dep.name)
        return drifted

    @staticmethod
    def _check_self_defined_servers_needing_installation(
        dep_names: list,
        target_runtimes: list,
        project_root=None,
        user_scope: bool = False,
    ) -> list:
        """Return self-defined MCP servers missing from at least one runtime.

        Self-defined servers have no registry UUID, so installation checks use
        the runtime config keys directly. Runtime config reads are cached per
        runtime to avoid repeating the same client setup for every dependency.
        """
        try:
            from apm_cli.core.conflict_detector import MCPConflictDetector
            from apm_cli.factory import ClientFactory
        except ImportError:
            return list(dep_names)

        runtime_existing = {}
        runtime_failures = []
        for runtime in target_runtimes:
            try:
                client = ClientFactory.create_client(
                    runtime,
                    project_root=project_root,
                    user_scope=user_scope,
                )
                detector = MCPConflictDetector(client)
                runtime_existing[runtime] = detector.get_existing_server_configs()
            except Exception:
                runtime_failures.append(runtime)

        servers_needing_installation = []
        for dep_name in dep_names:
            if runtime_failures:
                servers_needing_installation.append(dep_name)
                continue
            for runtime in target_runtimes:
                if dep_name not in runtime_existing.get(runtime, {}):
                    servers_needing_installation.append(dep_name)
                    break

        return servers_needing_installation

    # ------------------------------------------------------------------
    # Stale server cleanup
    # ------------------------------------------------------------------

    @staticmethod
    def remove_stale(
        stale_names: builtins.set,
        runtime: str = None,  # noqa: RUF013
        exclude: str = None,  # noqa: RUF013
        project_root=None,
        user_scope: bool = False,
        logger=None,
        scope=None,
        fail_on_write_error: bool = False,
        stored_configs: builtins.dict | None = None,
        native_hashes: builtins.dict[str, builtins.dict[str, str]] | None = None,
    ) -> None:
        """Remove MCP server entries that are no longer required by any dependency.

        Cleans up runtime configuration files only for the runtimes that were
        actually targeted during installation.  *stale_names* contains MCP
        dependency references (e.g. ``"io.github.github/github-mcp-server"``).
        For Copilot CLI and Codex, config keys are derived from the last path
        segment, so we match against both the full reference and the short name.

        Args:
            scope: InstallScope (PROJECT or USER).  When USER, only
                global-capable runtimes are cleaned.
        """
        if logger is None:
            logger = NullCommandLogger()
        if not stale_names:
            return

        # Determine which runtimes to clean, mirroring install-time logic.
        # Derived from ClientFactory so adding a new MCP-capable target
        # extends cleanup automatically (no parallel list to maintain).
        from apm_cli.factory import ClientFactory

        all_runtimes = ClientFactory.supported_clients()
        if runtime:  # noqa: SIM108
            target_runtimes = {runtime}
        else:
            target_runtimes = builtins.set(all_runtimes)
        if exclude:
            target_runtimes.discard(exclude)

        from apm_cli.core.scope import InstallScope
        from apm_cli.install.mcp.ownership import (
            project_mcp_cleanup_reachable,
            require_removable_mcp_connections,
        )

        # Scope filtering: at USER scope, only clean global-capable runtimes.
        if scope is InstallScope.USER:
            from apm_cli.factory import ClientFactory as _CF

            supported = builtins.set()
            for rt in target_runtimes:
                try:
                    if _CF.create_client(rt).supports_user_scope:
                        supported.add(rt)
                except ValueError:
                    pass
            target_runtimes = supported

        # Claude Code: when scope is unspecified, fail safely toward the project
        # config only -- never touch user config on the user's behalf without
        # an explicit USER scope, since that file is shared across all Claude
        # Code projects on the host.
        clean_claude_user = "claude" in target_runtimes and (
            scope is InstallScope.USER or user_scope
        )
        clean_claude_project = "claude" in target_runtimes and not clean_claude_user
        if "claude" in target_runtimes and scope is None and not user_scope:
            logger.progress(
                "Claude Code stale cleanup: scope unspecified -- defaulting to "
                "project .mcp.json only; pass -g/--global to also clean ~/.claude.json"
            )

        # Build an expanded set that includes both the full reference and the
        # native key the adapters write (registry ``owner/name`` -> ``name``).
        # Self-defined servers keep their declared key (#3493); their older
        # truncated keys are reconciled only under ownership proof at install
        # time, so a short-name entry here may belong to the user.
        from apm_cli.adapters.client.base import MCPClientAdapter

        expanded_stale: builtins.set = builtins.set()
        for n in stale_names:
            expanded_stale.add(n)
            stored = (stored_configs or {}).get(n)
            self_defined = isinstance(stored, dict) and stored.get("registry") is False
            info = {"name": n, "is_self_defined": True} if self_defined else None
            expanded_stale.add(MCPClientAdapter.determine_config_key(n, None, info))

        project_root_path = Path(project_root) if project_root is not None else Path.cwd()

        # Per-runtime cleanup -- each helper reads, diffs, writes, and logs.
        if "vscode" in target_runtimes:
            _clean_json_mcp_config(
                project_root_path / ".vscode" / "mcp.json",
                expanded_stale,
                logger,
                ".vscode/mcp.json",
                servers_key="servers",
                fail_on_write_error=fail_on_write_error,
            )

        if "copilot" in target_runtimes:
            from apm_cli.factory import ClientFactory

            copilot_user = scope is not InstallScope.PROJECT
            copilot_client = ClientFactory.create_client(
                "copilot",
                project_root=project_root_path,
                user_scope=copilot_user,
            )
            copilot_cfg = Path(copilot_client.get_config_path())
            if copilot_user:
                _clean_json_mcp_config(
                    copilot_cfg,
                    expanded_stale,
                    logger,
                    "Copilot CLI config",
                    use_rich=True,
                    fail_on_write_error=fail_on_write_error,
                )
            elif runtime is not None or stored_configs:
                # The project .mcp.json is shared with Claude Code and the user:
                # remove only entries proven to be APM's, as the Claude cleanup does.
                if _reject_symlink_config(
                    copilot_cfg, ".mcp.json", logger, fail_on_write_error=fail_on_write_error
                ):
                    return
                verified_keys = require_removable_mcp_connections(
                    copilot_client,
                    stale_names,
                    stored_configs or {},
                    (native_hashes or {}).get("copilot"),
                )
                _clean_json_mcp_config(
                    copilot_cfg,
                    verified_keys,
                    logger,
                    ".mcp.json",
                    trailing_newline=True,
                    use_rich=True,
                    fail_on_write_error=fail_on_write_error,
                    delete_emptied=True,
                )

        # Clean the scope-resolved Codex config.toml (mcp_servers section)
        if "codex" in target_runtimes:
            from apm_cli.factory import ClientFactory

            codex_client = ClientFactory.create_client(
                "codex",
                project_root=project_root,
                user_scope=user_scope,
            )
            codex_cfg = Path(codex_client.get_config_path())
            if _reject_symlink_config(
                codex_cfg, "Codex CLI config", logger, fail_on_write_error=fail_on_write_error
            ):
                return
            verified_keys = require_removable_mcp_connections(
                codex_client, stale_names, stored_configs or {}, (native_hashes or {}).get("codex")
            )
            _clean_toml_mcp_config(
                codex_cfg,
                verified_keys,
                "Codex CLI config",
                fail_on_write_error=fail_on_write_error,
            )

        clean_user_scope = user_scope or scope is InstallScope.USER
        if "cursor" in target_runtimes:
            from apm_cli.adapters.client.cursor import CursorClientAdapter

            _clean_json_mcp_config(
                CursorClientAdapter.config_path_for(project_root_path, clean_user_scope),
                expanded_stale,
                logger,
                "Cursor MCP config",
                use_rich=True,
                fail_on_write_error=fail_on_write_error,
            )

        # Project scope is opt-in; user scope uses ~/.config/opencode/.
        if "opencode" in target_runtimes:
            if clean_user_scope or project_mcp_cleanup_reachable(
                project_root_path, ".opencode", runtime_scoped=runtime is not None
            ):
                from apm_cli.adapters.client.opencode import (
                    V2_MCP_SETTINGS,
                    OpenCodeClientAdapter,
                )

                _clean_json_mcp_config(
                    OpenCodeClientAdapter.config_path_for(project_root_path, clean_user_scope),
                    expanded_stale,
                    logger,
                    "OpenCode MCP config",
                    servers_key="mcp",
                    fail_on_write_error=fail_on_write_error,
                    nested_servers=OpenCodeClientAdapter.native_v2_servers,
                    nested_settings=V2_MCP_SETTINGS,
                )

        if "windsurf" in target_runtimes:
            from apm_cli.adapters.client.windsurf import WindsurfClientAdapter

            _clean_json_mcp_config(
                Path.home() / ".codeium" / "windsurf" / "mcp_config.json",
                expanded_stale,
                logger,
                f"{WindsurfClientAdapter.user_wide_config_display} "
                "(user-wide: all Windsurf workspaces)",
                use_rich=True,
                fail_on_write_error=fail_on_write_error,
            )

        if "kiro" in target_runtimes:
            from apm_cli.factory import ClientFactory

            kiro_cfg = Path(
                ClientFactory.create_client(
                    "kiro",
                    project_root=project_root_path,
                    user_scope=user_scope or scope is InstallScope.USER,
                ).get_config_path()
            )
            _clean_json_mcp_config(
                kiro_cfg,
                expanded_stale,
                logger,
                "Kiro MCP config",
                use_rich=True,
                fail_on_write_error=fail_on_write_error,
            )

        # Clean JetBrains Copilot user-scope mcp.json
        if "intellij" in target_runtimes:
            from apm_cli.factory import ClientFactory

            intellij_client = ClientFactory.create_client(
                "intellij",
                project_root=project_root_path,
                user_scope=True,
            )
            removed = intellij_client.remove_managed_servers(expanded_stale)
            config_path = intellij_client.get_config_path()
            for name in sorted(removed):
                _rich_success(
                    f"Removed stale MCP server '{name}' from {config_path}",
                    symbol="check",
                )

        # Clean .gemini/settings.json (only if .gemini/ directory exists)
        if "gemini" in target_runtimes:
            _clean_json_mcp_config(
                project_root_path / ".gemini" / "settings.json",
                expanded_stale,
                logger,
                ".gemini/settings.json",
                fail_on_write_error=fail_on_write_error,
            )

        # Clean the scope-resolved Antigravity mcp_config.json.
        if "antigravity" in target_runtimes:
            from apm_cli.factory import ClientFactory

            antigravity_cfg = Path(
                ClientFactory.create_client(
                    "antigravity",
                    project_root=project_root_path,
                    user_scope=user_scope or scope is InstallScope.USER,
                ).get_config_path()
            )
            _clean_json_mcp_config(
                antigravity_cfg,
                expanded_stale,
                logger,
                "Antigravity MCP config",
                fail_on_write_error=fail_on_write_error,
            )

        if "hermes" in target_runtimes:
            from apm_cli.factory import ClientFactory
            from apm_cli.integration.targets import resolve_user_root

            unresolved_cfg = resolve_user_root("hermes") / "config.yaml"
            if _reject_symlink_config(
                unresolved_cfg,
                "Hermes config.yaml",
                logger,
                fail_on_write_error=fail_on_write_error,
            ):
                return
            hermes_cfg = Path(
                ClientFactory.create_client(
                    "hermes",
                    project_root=project_root_path,
                    user_scope=user_scope or scope is InstallScope.USER,
                ).get_config_path()
            )
            _clean_hermes_mcp_config(
                hermes_cfg,
                expanded_stale,
                logger,
                fail_on_write_error=fail_on_write_error,
            )

        # Clean Claude Code project .mcp.json when it is reachable for cleanup.
        if clean_claude_project:
            claude_project_enabled = project_mcp_cleanup_reachable(
                project_root_path, ".claude", runtime_scoped=runtime is not None
            )
            if claude_project_enabled or stored_configs:
                if _reject_symlink_config(
                    project_root_path / ".mcp.json",
                    ".mcp.json",
                    logger,
                    fail_on_write_error=fail_on_write_error,
                ):
                    return
                project_client = ClientFactory.create_client(
                    "claude", project_root=project_root_path, user_scope=False
                )
                verified_keys = require_removable_mcp_connections(
                    project_client,
                    stale_names,
                    stored_configs or {},
                    (native_hashes or {}).get("claude"),
                )
            if claude_project_enabled:
                _clean_claude_config(
                    project_root_path / ".mcp.json",
                    verified_keys,
                    logger,
                    fail_on_write_error=fail_on_write_error,
                )

        # Clean Claude Code user ~/.claude.json or $CLAUDE_CONFIG_DIR/.claude.json (USER scope only)
        if clean_claude_user:
            from apm_cli.adapters.client.claude import ClaudeClientAdapter

            claude_label = "Claude user config"
            try:
                unresolved_cfg = ClaudeClientAdapter.resolve_user_claude_unresolved_path()
                claude_label = str(unresolved_cfg)
                if _reject_symlink_config(
                    unresolved_cfg,
                    claude_label,
                    logger,
                    fail_on_write_error=fail_on_write_error,
                ):
                    return
                claude_cfg = ClaudeClientAdapter.resolve_user_claude_json_path(unresolved_cfg)
            except Exception as exc:
                _log.debug("Failed to resolve Claude user-scope config path", exc_info=True)
                if fail_on_write_error:
                    from apm_cli.install.errors import RequiredIntegrationError

                    raise RequiredIntegrationError(
                        _cleanup_failure_message(claude_label, exc)
                    ) from exc
                return

            user_client = ClientFactory.create_client(
                "claude", project_root=project_root_path, user_scope=True
            )
            verified_keys = require_removable_mcp_connections(
                user_client, stale_names, stored_configs or {}, (native_hashes or {}).get("claude")
            )
            _clean_claude_config(
                claude_cfg,
                verified_keys,
                logger,
                is_user_scope=True,
                fail_on_write_error=fail_on_write_error,
                label=claude_label,
            )

        from apm_cli.install.mcp.write_receipts import forget_removed_mcp_writes

        forget_removed_mcp_writes(project_root_path, user_scope=clean_user_scope)

    # ------------------------------------------------------------------
    # Lockfile persistence
    # ------------------------------------------------------------------

    @staticmethod
    def update_lockfile(
        mcp_server_names: builtins.set,
        lock_path: Path | None = None,
        *,
        mcp_configs: builtins.dict | None = None,
        mcp_target_servers: builtins.dict | None = None,
        mcp_config_provenance: builtins.dict | None = None,
        native_hashes: builtins.dict[str, builtins.dict[str, str]] | None = None,
        logger: CommandLogger | None = None,
        fail_on_write_error: bool = False,
        stamp_version: bool = False,
    ) -> None:
        """Update the lockfile with the current set of APM-managed MCP server names.

        Accepts the lock path directly to avoid a redundant disk read when the
        caller already has it.

        Args:
            mcp_server_names: Set of MCP server names to persist.
            lock_path: Path to the lockfile.  Defaults to ``apm.lock.yaml`` in CWD.
            mcp_configs: Keyword-only.  When provided, overwrites ``mcp_configs``
                         in the lockfile (used for drift-detection baseline).
            mcp_target_servers: Keyword-only. Per-target APM-owned server names.
            mcp_config_provenance: Keyword-only.  When provided, overwrites
                         ``mcp_config_provenance`` (name -> declaring package for
                         transitively-contributed servers). Passed in lockstep
                         with ``mcp_configs`` so the two never diverge (#2081).
                         ``None`` leaves the existing value untouched.
            logger: Optional command logger for actionable creation failures.
            stamp_version: Record the running APM version, once this install
                         translated the lock's pre-0.37 MCP claims (see
                         ``lock_holds_untranslated_mcp_claims``).
            fail_on_write_error: Raise a required-integration error on any
                         persistence failure.

        Raises:
            LockfileFormatError: If the existing lockfile is malformed.
            OSError: If a non-strict atomic lockfile write fails.
            RequiredIntegrationError: If a strict persistence attempt fails.
        """
        if lock_path is None:
            lock_path = get_lockfile_path(Path.cwd())
        # A project whose apm.yml declares only MCP dependencies never enters
        # the APM install pipeline, so nothing else creates apm.lock.yaml --
        # yet `apm audit` counts MCP dependencies when deciding a lockfile is
        # required, and failed with "run 'apm install'" right after a
        # successful install (#2373). Establish the lockfile here when there
        # is MCP state to record. Calls that clear the last server keep the
        # early return: they must not conjure a lockfile for a project that
        # never had one.
        creating = not lockfile_exists(lock_path)
        if creating and not (mcp_server_names or mcp_configs):
            return
        try:
            existing_lockfile = None if creating else LockFile.read(lock_path)
            if existing_lockfile is None and not creating:
                return
            lockfile = (
                LockFile(apm_version=installed_apm_version())
                if existing_lockfile is None
                else copy.deepcopy(existing_lockfile)
            )
            lockfile.mcp_servers = sorted(mcp_server_names)
            if mcp_configs is not None:
                lockfile.mcp_configs = mcp_configs
            if mcp_target_servers is not None:
                from apm_cli.core.deployment_ledger import DeploymentLedgerCodec

                DeploymentLedgerCodec.replace_mcp_target_servers(
                    lockfile,
                    {
                        target: sorted(servers)
                        for target, servers in sorted(mcp_target_servers.items())
                        if servers
                    },
                    native_hashes=native_hashes,
                )
            if mcp_config_provenance is not None:
                lockfile.mcp_config_provenance = mcp_config_provenance
            # Invariant: provenance only carries entries that still have a live
            # config. Prune dangling keys unconditionally so a caller that
            # rewrites mcp_configs without an explicit provenance argument (e.g.
            # the single-server ``apm install mcp`` path) can never leave a
            # stale entry that would exempt a genuinely orphaned server (#2081).
            if lockfile.mcp_config_provenance:
                lockfile.mcp_config_provenance = {
                    name: pkg
                    for name, pkg in lockfile.mcp_config_provenance.items()
                    if name in lockfile.mcp_configs
                }
            if stamp_version:
                lockfile.apm_version = installed_apm_version()
            if (
                existing_lockfile is not None
                and lockfile.apm_version == existing_lockfile.apm_version
                and lockfile.is_semantically_equivalent(existing_lockfile)
            ):
                _log.debug("MCP lockfile unchanged -- skipping write")
                return
            lockfile.save(lock_path, existing_lockfile=existing_lockfile)
        except Exception as exc:
            _log.debug(
                "MCP lockfile persistence failed at %s",
                lock_path,
                exc_info=True,
            )
            if creating and not isinstance(exc, LockfileRefusal):
                # Failing to UPDATE leaves a usable lockfile behind, but failing
                # to CREATE one reproduces #2373 exactly -- install reports
                # success and the next audit says "run 'apm install'". Debug
                # level would hide the fix silently not applying.
                message = (
                    f"Could not write {lock_path.name}; 'apm audit' will report it as "
                    "missing. "
                    f"{MCP_LOCKFILE_UNWRITABLE.bind(lockfile=lock_path.name).sentence()}"
                )
                if logger is not None:
                    logger.warning(message)
                else:
                    _rich_warning(message, symbol="warning")
            if fail_on_write_error:
                from apm_cli.install.errors import RequiredIntegrationError

                if isinstance(exc, LockfileRefusal):
                    raise RequiredIntegrationError(str(exc)) from exc
                raise RequiredIntegrationError(
                    "MCP lockfile update failed. Check apm.lock.yaml permissions, then retry."
                ) from exc
            raise

    # ------------------------------------------------------------------
    # Runtime detection
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_runtimes(scripts: dict) -> list[str]:
        """Extract runtime commands from apm.yml scripts."""
        # CRITICAL: Use builtins.set explicitly to avoid Click command collision!
        detected = builtins.set()

        for script_name, command in scripts.items():  # noqa: B007
            if re.search(r"\bcopilot\b", command):
                detected.add("copilot")
            if re.search(r"\bcodex\b", command):
                detected.add("codex")
            if re.search(r"\bgemini\b", command):
                detected.add("gemini")
            if re.search(r"\bclaude\b", command):
                detected.add("claude")
            if re.search(r"\bllm\b", command):
                detected.add("llm")
            if re.search(r"\bwindsurf\b", command):
                detected.add("windsurf")
            if re.search(r"\bkiro\b", command):
                detected.add("kiro")
            if re.search(r"\bantigravity\b|\bagy\b", command):
                detected.add("antigravity")

        return builtins.list(detected)

    @staticmethod
    def _filter_runtimes(detected_runtimes: list[str]) -> list[str]:
        """Filter to only runtimes that are actually installed and support MCP."""
        from apm_cli.factory import ClientFactory

        # First filter to only MCP-compatible runtimes
        try:
            mcp_compatible = []
            for rt in detected_runtimes:
                try:
                    ClientFactory.create_client(rt)
                    mcp_compatible.append(rt)
                except ValueError:
                    continue

            # Then filter to only installed runtimes
            try:
                from apm_cli.runtime.manager import RuntimeManager

                manager = RuntimeManager()
                return [rt for rt in mcp_compatible if manager.is_runtime_available(rt)]
            except ImportError:
                available = []
                for rt in mcp_compatible:
                    if find_runtime_binary(rt):
                        available.append(rt)
                return available

        except ImportError:
            # Derived from ClientFactory; see _MCP_CLIENT_REGISTRY.
            from apm_cli.factory import ClientFactory

            mcp_compatible = [
                rt for rt in detected_runtimes if rt in ClientFactory.supported_clients()
            ]
            return [rt for rt in mcp_compatible if find_runtime_binary(rt)]

    # ------------------------------------------------------------------
    # Per-runtime installation
    # ------------------------------------------------------------------

    @staticmethod
    def _install_for_runtime(
        runtime: str,
        mcp_deps: list[str],
        shared_env_vars: dict = None,  # noqa: RUF013
        server_info_cache: dict = None,  # noqa: RUF013
        shared_runtime_vars: dict = None,  # noqa: RUF013
        project_root=None,
        user_scope: bool = False,
        logger=None,
        replace_existing: bool = False,
        installed_servers: builtins.set[str] | None = None,
        managed_fields: builtins.set[str] | None = None,
        written_native_hashes: builtins.dict[str, str] | None = None,
    ) -> bool:
        """Install MCP dependencies for a specific runtime.

        Returns True if all deps were configured successfully, False otherwise.
        """
        if logger is None:
            logger = NullCommandLogger()
        try:
            from apm_cli.core.operations import install_package

            all_ok = True
            for dep in mcp_deps:
                logger.verbose_detail(f"  Installing {dep}...")
                try:
                    result = install_package(
                        runtime,
                        dep,
                        shared_env_vars=shared_env_vars,
                        server_info_cache=server_info_cache,
                        shared_runtime_vars=shared_runtime_vars,
                        project_root=project_root,
                        user_scope=user_scope,
                        replace_existing=replace_existing,
                        managed_fields=managed_fields,
                    )
                    if result["failed"]:
                        # Name the runtime: one dependency fails once per runtime (#4288).
                        logger.error(f"  Failed to install {dep} for {harness_label(runtime)}")
                        all_ok = False
                    elif result.get("installed") and installed_servers is not None:
                        installed_servers.add(dep)
                        if written_native_hashes is not None:
                            written_native_hashes.update(result.get("native_hashes", {}))
                    if not result["failed"] and logger and runtime == "codex":
                        from apm_cli.factory import ClientFactory

                        config_path = ClientFactory.create_client(
                            runtime,
                            project_root=project_root,
                            user_scope=user_scope,
                        ).get_config_path()
                        _log.debug("Codex config written to %s", config_path)
                        logger.verbose_detail(f"  Codex config: {config_path}")
                except Exception as install_error:
                    _log.debug(
                        "Failed to install MCP dep %s for runtime %s",
                        dep,
                        runtime,
                        exc_info=True,
                    )
                    logger.error(
                        f"  Failed to install {dep} for {harness_label(runtime)}: {install_error}"
                    )
                    all_ok = False

            # Emit aggregated post-install diagnostics for runtimes that
            # support runtime env-var substitution (currently Copilot CLI;
            # Claude Code's are emitted once per run by run_mcp_install).
            # Safe no-op for runtimes whose adapter doesn't aggregate state.
            try:
                if runtime == "copilot":
                    from apm_cli.adapters.client.copilot import CopilotClientAdapter
                    from apm_cli.adapters.client.copilot_project import (
                        CopilotProjectClientAdapter,
                    )

                    CopilotClientAdapter.emit_install_run_summary()
                    CopilotProjectClientAdapter.emit_install_run_summary()
            except Exception:
                _log.debug("Failed to emit install-run summary", exc_info=True)

            return all_ok

        except ImportError as e:
            logger.warning(f"Core operations not available for runtime {runtime}: {e}")
            logger.progress(f"Dependencies for {runtime}: {', '.join(mcp_deps)}")
            return False
        except ValueError as e:
            from apm_cli.factory import ClientFactory

            supported_runtimes = ", ".join(sorted(ClientFactory.supported_clients()))
            logger.warning(f"Runtime {runtime} not supported: {e}")
            logger.progress(f"Supported runtimes: {supported_runtimes}")
            return False
        except Exception as e:
            _log.debug("Unexpected error installing for runtime %s", runtime, exc_info=True)
            logger.error(f"Error installing for runtime {runtime}: {e}")
            return False

    # ------------------------------------------------------------------
    # Main orchestrator
    # ------------------------------------------------------------------

    @staticmethod
    def _gate_project_scoped_runtimes(
        target_runtimes: list[str],
        *,
        user_scope: bool,
        project_root,
        apm_config: dict | None,
        explicit_target: str | list[str] | None,
        target_decision: EffectiveTargetDecision | None = None,
    ) -> list[str]:
        """Filter *target_runtimes* against the project's active targets.

        UX parity with ``apm install`` for apm dependencies: the active
        target set (explicit ``--target`` > ``targets:`` field >
        directory-signal detection) is the whitelist for MCP writes. Any
        runtime outside that set is skipped with an info line naming both
        what was dropped and the active set, so users can audit the
        decision input without re-reading apm.yml (#1335).

        Strict resolution model -- mirrors :func:`resolve_targets`,
        the same call ``apm install`` uses
        (``install/phases/targets.py:233``):

          - flag > yaml-targets > directory signals (no permissive
            "fallback to copilot" greenfield default);
          - no flag, no ``targets:``, and no harness-signal directory ->
            :class:`NoHarnessError` (red ``[x]``, write nothing);
          - multiple ambiguous signals with no disambiguation ->
            :class:`AmbiguousHarnessError` (same fail-closed shape).

        ``explicit_target`` accepts ``str``, ``list[str]``, or a CSV
        string (``"claude,copilot"``) -- the latter is produced by
        legacy callers; it is normalized to a list before the resolver
        is invoked so the canonical-name validator does not reject it as
        one unknown token.

        A malformed ``targets:`` field (conflicting ``target:`` +
        ``targets:``, ``targets: []``, or unknown canonical name) likewise
        fails closed: nothing is written.

        Exit semantics differ deliberately from ``install/phases/targets.py``:
        the canonical install phase calls ``raise SystemExit(2)`` when
        resolution fails; this gate may be invoked mid-bundle (see
        ``install/local_bundle_handler``) where a hard exit would corrupt
        partial state, so we render the same red ``[x]`` voice and return
        an empty list (fail-closed-continue).

        At user scope the package's declared ``targets:`` field and the
        ``--target`` flag are still respected: a package that declares
        ``targets: copilot`` is only installed for Copilot, even when
        Kiro (or another runtime) is detected on the host.  When neither
        the package nor the CLI restricts targets, all detected runtimes
        pass through (backward-compatible).
        """
        from apm_cli.core.apm_yml import (
            ConflictingTargetsError,
            EmptyTargetsListError,
            UnknownTargetError,
        )
        from apm_cli.integration.targets import RUNTIME_TO_CANONICAL_TARGET
        from apm_cli.models.manifest_targets import manifest_target_restriction

        if target_decision is not None and target_decision.canonical_targets is not None:
            active = set(target_decision.canonical_targets)
            out = [
                runtime
                for runtime in target_runtimes
                if RUNTIME_TO_CANONICAL_TARGET.get(runtime, runtime) in active
            ]
            dropped = sorted(set(target_runtimes) - set(out))
            if dropped:
                active_csv = ", ".join(sorted(active)) or "<none>"
                scope_label = ", scope: global" if user_scope else ""
                _rich_info(
                    f"Skipped MCP config for {', '.join(dropped)} "
                    f"(active targets: {active_csv}{scope_label})",
                    symbol="info",
                )
            return out

        # --- step 1: parse declared targets (fail-closed on any invalid form)
        yaml_targets: list[str] | None = None
        if apm_config:
            try:
                parsed = manifest_target_restriction(apm_config)
                yaml_targets = parsed if parsed else None
            except (
                ConflictingTargetsError,
                EmptyTargetsListError,
                UnknownTargetError,
            ) as exc:
                _rich_error(
                    "Skipping all MCP config writes -- apm.yml 'targets' field is invalid.",
                    symbol="error",
                )
                _rich_error(str(exc), symbol="error")
                _log.debug(
                    "manifest target declaration invalid; failing closed (no MCP writes)",
                    exc_info=True,
                )
                return []

        # --- step 2: normalize CSV explicit_target sugar to a list -----
        flag: str | list[str] | None
        if isinstance(explicit_target, str) and "," in explicit_target:
            flag = [t.strip() for t in explicit_target.split(",") if t.strip()]
        else:
            flag = explicit_target

        if flag is not None:
            tokens = [flag] if isinstance(flag, str) else list(flag)
            flag = [RUNTIME_TO_CANONICAL_TARGET.get(t, t) for t in tokens]

        # --- step 2b: user-scope short path ----------------------------
        # At user scope directory-signal detection is meaningless (there
        # is no "project root" to probe).  If the package or the CLI
        # restricts targets we filter here; otherwise every detected
        # runtime passes through unchanged (backward-compatible default).
        if user_scope:
            # Collect the canonical target names from flag / yaml.
            active: set[str] | None = None
            if flag is not None:
                tokens_list = flag if isinstance(flag, list) else [flag]
                # "all" is a special passthrough -- mirror resolve_targets.
                if "all" in tokens_list:
                    return target_runtimes
                active = set(tokens_list)
            elif yaml_targets is not None:
                active = set(yaml_targets)

            if active is None:
                return target_runtimes

            out = [
                rt for rt in target_runtimes if RUNTIME_TO_CANONICAL_TARGET.get(rt, rt) in active
            ]
            dropped = sorted(set(target_runtimes) - set(out))
            if dropped:
                active_csv = ", ".join(sorted(active)) or "<none>"
                _rich_info(
                    f"Skipped MCP config for {', '.join(dropped)} (active targets: {active_csv}, scope: global)",
                    symbol="info",
                )
                _log.debug(
                    "Active-targets gate dropped (user scope): %s (active=%s)",
                    dropped,
                    sorted(active),
                )
            return out

        # --- step 3 (project scope): delegate to the v2 resolver -------
        if flag is not None:
            project_tokens = flag if isinstance(flag, list) else [flag]
            if "all" in project_tokens:
                from apm_cli.core.target_catalog import expand_all

                flag = [
                    RUNTIME_TO_CANONICAL_TARGET.get(target, target)
                    for target in expand_all("install")
                ]
        from apm_cli.core.errors import (
            AmbiguousHarnessError,
            NoHarnessError,
        )
        from apm_cli.core.target_detection import resolve_targets

        root = project_root or Path.cwd()
        try:
            resolved = resolve_targets(root, flag=flag, yaml_targets=yaml_targets)
        except (NoHarnessError, AmbiguousHarnessError) as exc:
            _rich_error(
                "Skipping all MCP config writes -- could not resolve active targets.",
                symbol="error",
            )
            _rich_error(str(exc), symbol="error")
            _log.debug(
                "resolve_targets failed; failing closed (no MCP writes)",
                exc_info=True,
            )
            return []

        active = set(resolved.targets)

        out = [rt for rt in target_runtimes if RUNTIME_TO_CANONICAL_TARGET.get(rt, rt) in active]
        dropped = sorted(set(target_runtimes) - set(out))
        if dropped:
            # Mirror the canonical `Targets: X  (source: Y)` provenance shape
            # (install/phases/targets.py:265, core/target_detection.py:777):
            # double-space before the parenthetical. The "or '<none>'" guard is
            # defensive -- an empty active set is unreachable when
            # _resolve_targets_v2 succeeded, but if a future contract change
            # widens that contract we surface "<none>" rather than render
            # "(active targets: )" which reads as a renderer bug.
            active_csv = ", ".join(sorted(active)) or "<none>"
            _rich_info(
                f"Skipped MCP config for {', '.join(dropped)}  (active targets: {active_csv})",
                symbol="info",
            )
            _log.debug(
                "Active-targets gate dropped: %s (active=%s)",
                dropped,
                sorted(active),
            )
        return out

    @staticmethod
    def install(  # noqa: PLR0913
        mcp_deps: list,
        runtime: str = None,  # noqa: RUF013
        exclude: str = None,  # noqa: RUF013
        verbose: bool = False,
        apm_config: dict = None,  # noqa: RUF013
        stored_mcp_configs: dict = None,  # noqa: RUF013
        project_root=None,
        user_scope: bool = False,
        explicit_target: str | list[str] | None = None,
        target_decision: EffectiveTargetDecision | None = None,
        logger=None,
        diagnostics=None,
        scope=None,
        managed_target_servers: builtins.dict | None = None,
        prevalidated_registry_servers: builtins.dict[str, builtins.dict] | None = None,
        fail_on_write_error: bool = False,
        native_hashes: builtins.dict[str, builtins.dict[str, str]] | None = None,
        resolved_targets: ResolvedMcpTargets | None = None,
    ) -> int:
        """Install MCP dependencies.

        Args:
            mcp_deps: List of MCP dependency entries (registry strings or
                MCPDependency objects).
            runtime: Target specific runtime only.
            exclude: Exclude specific runtime from installation.
            verbose: Show detailed installation information.
            apm_config: The parsed apm.yml configuration dict (optional).
                When not provided, the method loads it from disk.
            stored_mcp_configs: Previously stored MCP configs from lockfile
                for diff-aware installation.  When provided, servers whose
                manifest config has changed are re-applied automatically.
            project_root: Project root for repo-local runtime configs.
            user_scope: Whether runtime configuration is being resolved at user scope.
            explicit_target: Explicit target selected by CLI or manifest.
            scope: InstallScope (PROJECT or USER). When USER, only
                runtimes whose adapter declares ``supports_user_scope``
                are targeted; workspace-only runtimes are skipped.
            managed_target_servers: Mutable per-target ownership state. Existing
                entries are reconciled to active targets and successful writes
                are recorded in place.

        Returns:
            Number of MCP servers newly configured or updated.
        """
        from apm_cli.core.command_logger import library_output
        from apm_cli.integration.mcp_integrator_install import run_mcp_install

        # Client adapters emit through the command's logger (#4089).
        with library_output(logger):
            return run_mcp_install(
                mcp_deps,
                runtime=runtime,
                exclude=exclude,
                verbose=verbose,
                apm_config=apm_config,
                stored_mcp_configs=stored_mcp_configs,
                project_root=project_root,
                user_scope=user_scope,
                explicit_target=explicit_target,
                target_decision=target_decision,
                logger=logger,
                diagnostics=diagnostics,
                scope=scope,
                managed_target_servers=managed_target_servers,
                prevalidated_registry_servers=prevalidated_registry_servers,
                fail_on_write_error=fail_on_write_error,
                native_hashes=native_hashes,
                resolved_targets=resolved_targets,
            )
