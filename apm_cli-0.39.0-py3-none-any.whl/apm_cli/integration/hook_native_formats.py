"""Native hook schema adapters around the vendor-neutral hook IR."""

from __future__ import annotations

import math
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from apm_cli.hook_contract import (
    HOOK_COMMAND_KEYS,
    HookContractError,
    HookDocument,
    HookHandler,
    _entries_to_ir,
    _handler_to_ir,
    _thaw,
    hook_handlers,
)
from apm_cli.utils.diagnostics import printable_ascii_text

_ANTIGRAVITY_NESTED_EVENTS: frozenset[str] = frozenset({"PreToolUse", "PostToolUse"})

# https://cursor.com/docs/hooks (native events, not case-derived aliases).
CURSOR_NATIVE_EVENTS = frozenset(
    {
        "sessionStart",
        "sessionEnd",
        "preToolUse",
        "postToolUse",
        "postToolUseFailure",
        "subagentStart",
        "subagentStop",
        "beforeShellExecution",
        "afterShellExecution",
        "beforeMCPExecution",
        "afterMCPExecution",
        "beforeReadFile",
        "afterFileEdit",
        "beforeSubmitPrompt",
        "preCompact",
        "stop",
        "afterAgentResponse",
        "afterAgentThought",
        "beforeTabFileRead",
        "afterTabFileEdit",
        "workspaceOpen",
    }
)

# https://cursor.com/docs/hooks - the only keys Cursor's loader recognizes.
CURSOR_CONFIG_TOP_LEVEL_KEYS = frozenset({"version", "hooks"})

# Node.js module types a hook bundle's package.json may declare.
NODE_MODULE_TYPES: tuple[str, ...] = ("commonjs", "module")


def node_module_type(value: object) -> str:
    """Return the Node module type *value* declares, defaulting to CommonJS."""
    return value if isinstance(value, str) and value in NODE_MODULE_TYPES else NODE_MODULE_TYPES[0]


def hook_module_type_metadata(module_type: str) -> dict[str, str]:
    """Return the package.json document that sets a hook bundle's Node module type."""
    return {"type": node_module_type(module_type)}


def is_hook_module_type_metadata(document: object) -> bool:
    """Return True when *document* holds only a Node module type, so defines no hooks."""
    return any(
        document == hook_module_type_metadata(module_type) for module_type in NODE_MODULE_TYPES
    )


def _cursor_matcher(matcher: str | None, event: str, *, foreign: bool) -> str | None:
    """Translate only explicitly representable Claude tool-name alternatives."""
    if matcher is not None and not isinstance(matcher, str):
        raise HookContractError("Cursor matcher must be a string")
    if not foreign or matcher in (None, "", "*", ".*"):
        return matcher
    if event not in {"preToolUse", "postToolUse"}:
        raise HookContractError("Claude event matcher has no verified Cursor equivalent")
    names = matcher.split("|")
    mapping = {
        "Bash": "Shell",
        "Read": "Read",
        "Edit": "Write",
        "Write": "Write",
        "Grep": "Grep",
        "Task": "Task",
        "WebFetch": "WebFetch",
        "WebSearch": "WebSearch",
    }
    if any(name not in mapping for name in names):
        if all(name.strip() in mapping for name in names):
            raise HookContractError(
                "Claude matcher alternatives contain whitespace; use literal alternatives "
                "such as 'Bash|Read' instead of 'Bash | Read'"
            )
        raise HookContractError(
            "Cursor cannot preserve this Claude matcher; regex, Glob and server-qualified "
            "MCP translations are not supported"
        )
    # Cursor combines file creation and editing under Write. Mapping either
    # Claude tool alone would broaden the original restriction.
    if set(names) & {"Edit", "Write"} and not {"Edit", "Write"} <= set(names):
        raise HookContractError("Cursor Write requires both Claude Edit and Write alternatives")
    return "|".join(dict.fromkeys(mapping[name] for name in names))


def _check_cursor_field_types(entry: dict[str, Any]) -> None:
    """Keep source and rendered field predicates identical across IR conversion."""
    if "matcher" in entry and not isinstance(entry["matcher"], str):
        raise HookContractError("Cursor matcher must be a string")
    for key in ("timeout", "timeoutSec"):
        if key in entry and (
            type(entry[key]) not in (int, float) or not math.isfinite(entry[key]) or entry[key] <= 0
        ):
            raise HookContractError("Cursor timeout must be a finite positive number of seconds")
    if "failClosed" in entry and type(entry["failClosed"]) is not bool:
        raise HookContractError("Cursor failClosed must be a boolean")


def _validate_cursor_handler(entry: dict[str, Any], event: str) -> None:
    """Validate native output; source-only checks live in _to_cursor_hook_entries."""
    allowed = {
        "type",
        "command",
        "prompt",
        "model",
        "timeout",
        "matcher",
        "loop_limit",
        "failClosed",
        "_apm_source",
    }
    if entry.keys() - allowed:
        raise HookContractError(
            f"unsupported Cursor handler fields {sorted(entry.keys() - allowed)!r}; "
            "no fields were discarded"
        )
    _check_cursor_field_types(entry)
    if "_apm_source" in entry and not isinstance(entry["_apm_source"], str):
        raise HookContractError("invalid Cursor hook ownership metadata")
    kind = entry.get("type", "command")
    if not isinstance(kind, str) or kind not in {"command", "prompt"}:
        raise HookContractError("Cursor supports only command and prompt handlers")
    content_key = "prompt" if kind == "prompt" else "command"
    incompatible = {"command"} if kind == "prompt" else {"prompt", "model"}
    if incompatible & entry.keys() or not isinstance(entry.get(content_key), str):
        raise HookContractError(f"Cursor {kind} handler requires a string {content_key}")
    if "model" in entry and not isinstance(entry["model"], str):
        raise HookContractError("Cursor prompt model must be a string")
    if "loop_limit" in entry:
        limit = entry["loop_limit"]
        if event not in {"stop", "subagentStop"} or (
            limit is not None and (type(limit) is not int or limit < 0)
        ):
            raise HookContractError(
                "Cursor loop_limit requires stop/subagentStop and integer or null"
            )


def _to_cursor_hook_entries(
    entries: list, event_name: str, *, foreign: bool = False
) -> list[dict[str, Any]]:
    """Render the neutral IR as strict native Cursor flat handlers.

    Claude import mappings are documented at
    https://cursor.com/docs/reference/third-party-hooks. The bounded adapter
    rejects mappings that lose restrictions instead of imitating lossy import.
    Check source-only restrictions before IR normalization loses them, then
    validate rendered output through _validate_cursor_handler.
    """
    if event_name not in CURSOR_NATIVE_EVENTS:
        raise HookContractError(f"unsupported Cursor event {event_name!r}")
    for declaration in hook_handlers({"hooks": {event_name: entries}}):
        raw = declaration.value
        _check_cursor_field_types(raw)
        if "timeout" in raw and "timeoutSec" in raw:
            raise HookContractError("Cursor handler must declare only one timeout")
        if (
            foreign
            and "/hooks/" in declaration.json_pointer.removeprefix("/hooks/")
            and "matcher" in raw
        ):
            raise HookContractError(
                "Claude handler-level matcher has no verified Cursor equivalent"
            )
    result: list[dict[str, Any]] = []
    for binding in _entries_to_ir(entries, event_name).bindings:
        if binding.metadata:
            raise HookContractError(
                f"unsupported Cursor matcher-group fields {sorted(binding.metadata)!r}"
            )
        matcher = _cursor_matcher(binding.matcher, event_name, foreign=foreign)
        for handler in binding.handlers:
            if handler.platform != "all":
                raise HookContractError(
                    "Cursor cannot preserve platform-specific command restrictions"
                )
            rendered = _handler_from_ir(handler, timeout_milliseconds=False)
            if matcher is not None:
                if "matcher" in rendered:
                    raise HookContractError("Cursor cannot combine nested and outer matchers")
                rendered["matcher"] = matcher
            if foreign and event_name in {"stop", "subagentStop"}:
                rendered.setdefault("loop_limit", None)
            _validate_cursor_handler(rendered, event_name)
            result.append(rendered)
    return result


def validate_cursor_config(document: object) -> None:
    """Reject a native file that Cursor would not load, without repairing user data."""
    if not isinstance(document, dict) or not isinstance(document.get("hooks"), dict):
        raise HookContractError("Cursor config requires a hooks object")
    unknown_keys = document.keys() - CURSOR_CONFIG_TOP_LEVEL_KEYS
    if unknown_keys:
        raise HookContractError(
            f"Cursor config has unsupported top-level keys {sorted(unknown_keys)!r}"
        )
    if type(document.get("version")) is not int or document["version"] != 1:
        raise HookContractError("Cursor config requires version 1")
    for event, entries in document["hooks"].items():
        if event not in CURSOR_NATIVE_EVENTS or not isinstance(entries, list):
            raise HookContractError(f"unsupported Cursor event {event!r} or non-array entries")
        for entry in entries:
            if not isinstance(entry, dict):
                raise HookContractError("Cursor native handlers must be objects")
            _validate_cursor_handler(entry, event)


# Copilot documents prompt handlers only on sessionStart; other events fail closed.
# Ref: https://docs.github.com/en/copilot/reference/hooks-reference#prompt-hooks
_EVENT_PROMPT_TYPES: dict[str, dict[str, tuple[str, ...]]] = {
    "github_hooks": {"sessionStart": ("prompt",)},
}


@dataclass(frozen=True)
class HookContentEntry:
    """Discovered native hook content, independent of ownership and safety."""

    pointer: str
    prompt: str | None = None
    error: str | None = None


def _inspect_handler(
    value: dict[str, Any],
    pointer: str,
    prompt_types: tuple[str, ...],
    command_keys: tuple[str, ...] = ("command",),
) -> HookContentEntry:
    """Classify one documented handler without inspecting command text."""
    kind = value.get("type", "command")
    if kind in prompt_types:
        prompt = value.get("prompt")
        if isinstance(prompt, str):
            return HookContentEntry(f"{pointer}/prompt", prompt=prompt)
        return HookContentEntry(pointer, error="prompt handler requires a string prompt")
    if kind == "command":
        commands = [value[key] for key in command_keys if key in value]
        if commands and all(isinstance(command, str) for command in commands):
            return HookContentEntry(pointer)
        return HookContentEntry(pointer, error="command handler requires string command fields")
    return HookContentEntry(pointer, error="unsupported native hook handler type")


def inspect_native_hooks(
    document: object,
    format_id: str,
    *,
    container: str = "hooks",
    prompt_types: tuple[str, ...] = (),
    named_containers: bool = False,
    shared: bool = False,
    nested_handlers: bool | None = None,
) -> tuple[HookContentEntry, ...]:
    """Read only documented native hook containers and prompt-bearing fields."""
    if not isinstance(document, dict):
        return (HookContentEntry("", error="hook document must be an object"),)
    if format_id == "kiro_hooks":
        if document.get("version") != "v1" or not isinstance(document.get("hooks"), list):
            return (HookContentEntry("", error="unsupported Kiro hook document"),)
        result = []
        for index, hook in enumerate(document["hooks"]):
            pointer = f"/hooks/{index}"
            if (
                not isinstance(hook, dict)
                or not isinstance(hook.get("trigger"), str)
                or not isinstance(hook.get("action"), dict)
            ):
                result.append(HookContentEntry(pointer, error="invalid Kiro hook action"))
            else:
                result.append(_inspect_handler(hook["action"], f"{pointer}/action", ("agent",)))
        return tuple(result)
    if format_id not in {
        "github_hooks",
        "claude_hooks",
        "cursor_hooks",
        "codex_hooks",
        "gemini_hooks",
        "antigravity_hooks",
        "windsurf_hooks",
    }:
        return (HookContentEntry("", error="unsupported native hook format"),)
    if format_id in {"github_hooks", "cursor_hooks"}:
        version = document.get("version", 1)
        if type(version) is not int or version != 1:
            return (HookContentEntry("", error="unsupported native hook version"),)
    if named_containers:
        containers = [
            (f"/{name.replace('~', '~0').replace('/', '~1')}", value)
            for name, value in document.items()
            if name != "version"
        ]
    elif container in document:
        containers = [(f"/{container}", document[container])]
    elif shared:
        return ()
    else:
        return (HookContentEntry("", error="missing native hook container"),)
    event_prompt_types = _EVENT_PROMPT_TYPES.get(format_id, {})
    result: list[HookContentEntry] = []
    for prefix, events in containers:
        try:
            handlers = hook_handlers({"hooks": events})
        except HookContractError as exc:
            # Shape errors can include user-controlled event names. The diagnostic
            # identifies the container instead of echoing its contents.
            result.append(
                HookContentEntry(prefix, error=f"invalid hook container ({type(exc).__name__})")
            )
            continue
        for handler in handlers:
            nested = (
                handler.event in _ANTIGRAVITY_NESTED_EVENTS if named_containers else nested_handlers
            )
            is_child = "/hooks/" in handler.json_pointer.removeprefix("/hooks/")
            if not is_child and nested is True and not isinstance(handler.value.get("hooks"), list):
                result.append(
                    HookContentEntry(
                        prefix + handler.json_pointer.removeprefix("/hooks"),
                        error="native hook event requires nested handlers",
                    )
                )
                continue
            if not is_child and nested is False and "hooks" in handler.value:
                result.append(
                    HookContentEntry(
                        prefix + handler.json_pointer.removeprefix("/hooks"),
                        error="native hook event requires flat handlers",
                    )
                )
                continue
            if is_child and nested is False:
                continue
            if is_child and "hooks" in handler.value:
                result.append(
                    HookContentEntry(
                        prefix + handler.json_pointer.removeprefix("/hooks"),
                        error="unsupported additional hook nesting",
                    )
                )
                continue
            if isinstance(handler.value.get("hooks"), list):
                continue
            pointer = prefix + handler.json_pointer.removeprefix("/hooks")
            event_types = () if is_child else event_prompt_types.get(handler.event, ())
            result.append(
                _inspect_handler(
                    dict(handler.value),
                    pointer,
                    prompt_types + event_types,
                    HOOK_COMMAND_KEYS if format_id == "github_hooks" else ("command",),
                )
            )
    return tuple(result)


def _handler_from_ir(handler: HookHandler, *, timeout_milliseconds: bool) -> dict[str, Any]:
    """Render a portable handler into one native command object."""
    result = _thaw(handler.metadata)
    if handler.command is not None:
        result["command"] = handler.command
    if handler.timeout_seconds is not None:
        result["timeout"] = (
            handler.timeout_seconds * 1000 if timeout_milliseconds else handler.timeout_seconds
        )
    if handler.provenance:
        result["_apm_source"] = handler.provenance
    return result


def _render_nested_document(
    document: HookDocument,
    *,
    timeout_milliseconds: bool,
    default_matcher: str | None = None,
) -> list:
    """Render neutral bindings into a matcher plus nested-handlers schema."""
    result: list = []
    for binding in document.bindings:
        if "raw_entry" in binding.metadata:
            result.append(_thaw(binding.metadata["raw_entry"]))
            continue
        outer = _thaw(binding.metadata)
        if binding.matcher is not None or default_matcher is not None:
            outer["matcher"] = binding.matcher or default_matcher
        outer["hooks"] = [
            _handler_from_ir(handler, timeout_milliseconds=timeout_milliseconds)
            for handler in binding.handlers
        ]
        provenance = binding.provenance or next(
            (handler.provenance for handler in binding.handlers if handler.provenance is not None),
            None,
        )
        if provenance:
            outer["_apm_source"] = provenance
            for handler in outer["hooks"]:
                handler.pop("_apm_source", None)
        result.append(outer)
    return result


def _copilot_keys_to_gemini(hook: dict) -> None:
    """Compatibility edge helper backed by the neutral handler model."""
    rendered = _handler_from_ir(
        _handler_to_ir(hook, None),
        timeout_milliseconds=True,
    )
    hook.clear()
    hook.update(rendered)


def _to_gemini_hook_entries(entries: list) -> list:
    """Render portable bindings in Gemini's nested millisecond schema."""
    return _render_nested_document(
        _entries_to_ir(entries),
        timeout_milliseconds=True,
    )


def _legacy_hook_entries(entries: list, target: str) -> list:
    """Render old native shapes for ownership matching, never for deployment."""
    if target == "claude":
        return _to_claude_hook_entries(entries, default_handler_type=False)
    if target == "codex":
        # Codex installs wrote the original flat entries before native nesting,
        # then nested them without typing untyped flat command entries.
        return [*entries, *_to_codex_hook_entries(entries, default_handler_type=False)]
    return []


def _with_default_command_type(entry: object) -> object:
    """Supply the required ``type`` for an untyped flat command entry.

    Only flat entries that the neutral grammar reads as a command handler are
    defaulted; explicit types, nested groups, and non-command entries pass
    through unchanged.
    """
    if not isinstance(entry, dict) or "type" in entry or isinstance(entry.get("hooks"), list):
        return entry
    if not isinstance(_handler_to_ir(entry, None).command, str):
        return entry
    return {"type": "command", **entry}


def _to_claude_hook_entries(entries: list, *, default_handler_type: bool = True) -> list:
    """Render portable bindings in Claude's nested matcher schema.

    ``default_handler_type=False`` reproduces the output of installs before
    untyped flat command entries were typed, so owned entries they wrote can
    still be matched on reinstall.
    """
    if default_handler_type:
        entries = [_with_default_command_type(entry) for entry in entries]
    return _render_nested_document(
        _entries_to_ir(entries),
        timeout_milliseconds=False,
        default_matcher="*",
    )


def require_claude_native_events(
    hook_files: list[Path],
    parse_hook_json: Callable[[Path], dict | None],
    event_maps: dict[str, dict[str, str]],
    package_label: str = "",
) -> None:
    """Refuse Claude output whose events Claude Code rejects (#3226).

    Every documented Claude Code event is PascalCase, and Claude Code rejects
    unknown events. Copilot names with a documented Claude pair are renamed by
    the event map; any other lower-case name has no faithful Claude rendering,
    so fail before settings are replaced instead of writing an invalid event
    or silently dropping a protective hook.
    """
    claude_map = event_maps.get("claude", {})
    invalid: dict[str, set[str]] = {}
    for hook_file in hook_files:
        data = parse_hook_json(hook_file)
        hooks = data.get("hooks") if isinstance(data, dict) else None
        if not isinstance(hooks, dict):
            continue
        for event in hooks:
            native = claude_map.get(event, event)
            if not isinstance(native, str) or not native[:1].isupper():
                invalid.setdefault(hook_file.name, set()).add(str(event))
    if not invalid:
        return
    details = "; ".join(
        f"{printable_ascii_text(name)}: {', '.join(sorted(printable_ascii_text(e) for e in events))}"
        for name, events in sorted(invalid.items())
    )
    prefix = f"{printable_ascii_text(package_label)}: " if package_label else ""
    raise HookContractError(
        f"{prefix}hook events have no documented Claude Code name ({details}). "
        "Claude settings were not changed. Rename them to Claude events such as "
        "PreToolUse, or limit this package to targets that support them with "
        "'target:' in its apm.yml or dependency 'targets:' in yours"
    )


def _to_codex_hook_entries(entries: list, *, default_handler_type: bool = True) -> list:
    """Render portable bindings in Codex's nested hook schema.

    ``default_handler_type=False`` reproduces the output of installs before
    untyped flat command entries were typed, so owned entries they wrote can
    still be matched on reinstall.
    """
    if default_handler_type:
        entries = [_with_default_command_type(entry) for entry in entries]
    return _render_nested_document(
        _entries_to_ir(entries),
        timeout_milliseconds=False,
    )


def _to_antigravity_hook_entries(entries: list, event_name: str) -> list:
    """Render portable bindings in Antigravity's event-dependent schema."""
    document = _entries_to_ir(entries, event_name)
    if event_name in _ANTIGRAVITY_NESTED_EVENTS:
        return _render_nested_document(
            document,
            timeout_milliseconds=False,
            default_matcher="*",
        )

    flat: list[dict[str, Any]] = []
    for binding in document.bindings:
        if "raw_entry" in binding.metadata:
            flat.append(_thaw(binding.metadata["raw_entry"]))
            continue
        for handler in binding.handlers:
            rendered = _handler_from_ir(handler, timeout_milliseconds=False)
            if binding.provenance and "_apm_source" not in rendered:
                rendered["_apm_source"] = binding.provenance
            flat.append(rendered)
    return flat
