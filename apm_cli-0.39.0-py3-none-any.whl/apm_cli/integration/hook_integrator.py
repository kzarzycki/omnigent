"""Hook integration functionality for APM packages.
Integrates hook JSON files and referenced scripts during package installation.
Supports VSCode Copilot (.github/hooks/), Claude Code
(.claude/settings.json), and Cursor (.cursor/hooks.json) targets.

Native handler layouts are declared in the merge-target registry below and
converted through ``hook_native_formats``: Claude uses nested matcher groups,
GitHub Copilot accepts bash/powershell commands, and Cursor uses flat commands.

Script path handling:
    - Supported plugin-root aliases -> package-relative path rewritten for target
    - ./path -> relative path, resolved from the hook file context, rewritten for target
    - System commands (no path separators) -> passed through unchanged
"""

import json
import logging
import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, TypedDict

import yaml

from apm_cli.core.deployment_ledger import DeploymentLedgerCodec
from apm_cli.core.deployment_state import (
    MaterializationResult,
    MaterializationStatus,
    NativePayloadValidation,
)
from apm_cli.core.remediation import HOOK_PATH_ESCAPES_PACKAGE
from apm_cli.core.scope import InstallScope, manifest_file
from apm_cli.hook_contract import HOOK_COMMAND_KEYS as _HOOK_COMMAND_KEYS
from apm_cli.hook_contract import summarize_hook_command, walk_hook_commands
from apm_cli.integration import config_file_provenance as provenance
from apm_cli.integration import write_seam
from apm_cli.integration.base_integrator import BaseIntegrator, IntegrationResult
from apm_cli.integration.copilot_hook_paths import copilot_hook_target
from apm_cli.integration.hook_bundle import (
    copy_deployed_hook_bundle,
    hook_cleanup_root,
    iter_deployable_hook_bundle_files,
)
from apm_cli.integration.hook_command_paths import (
    SCRIPTS_SUBDIR_HOOK_TARGETS,
    hook_scripts_parent,
    iter_plugin_root_paths,
    iter_relative_script_paths,
    normalize_quoted_plugin_root,
    plugin_root_relative_path,
    splice_references,
    unresolved_plugin_root_references,
    wrapping_quote,
)
from apm_cli.integration.hook_command_warnings import warn_unresolved_plugin_root
from apm_cli.integration.hook_cursor_preflight import preflight_cursor_hooks
from apm_cli.integration.hook_file_routing import hook_package_label
from apm_cli.integration.hook_native_formats import (
    _legacy_hook_entries,
    _to_antigravity_hook_entries,
    _to_claude_hook_entries,
    _to_codex_hook_entries,
    _to_cursor_hook_entries,
    _to_gemini_hook_entries,
    require_claude_native_events,
)
from apm_cli.integration.hook_ownership import (
    LocalBundleMarkers,
    canonical_hook_order,
    dependency_hook_source_marker,
    dependency_hook_sources,
    drop_dependency_owned_entries,
    drop_source_entries,
    legacy_source_marker_is_unambiguous,
    local_bundle_hook_source_marker,
    read_hook_object,
    read_merged_hook_config,
    remove_emptied_hook_file,
    remove_hook_sidecar,
    write_hook_sidecar,
)
from apm_cli.integration.hook_ownership import (
    extract_apm_source_sidecar as _extract_apm_source_sidecar,
)
from apm_cli.integration.hook_ownership import (
    reinject_apm_source_from_sidecar as _reinject_apm_source_from_sidecar,
)
from apm_cli.integration.hook_ownership import require_hook_event_lists as _hook_lists
from apm_cli.integration.hook_source_selection import (
    HookSourceSelection,
    _parse_hook_json,
    _referenced_hook_source_files,
    resolve_plugin_root_hook_script,
    resolve_relative_hook_script,
    select_hook_sources,
)
from apm_cli.utils.console import _rich_warning
from apm_cli.utils.diagnostics import printable_ascii_text
from apm_cli.utils.path_security import (
    PathTraversalError,
)
from apm_cli.utils.paths import portable_relpath

if TYPE_CHECKING:
    from apm_cli.deps.lockfile import LockFile
    from apm_cli.integration.cleanup import DeploymentEvidence
    from apm_cli.integration.targets import UserHookHomeReference

_log = logging.getLogger(__name__)

_DOT_NAMED_HOOK_ROOTS = frozenset({"cursor", "codex", "windsurf", "kiro"})


# DEPRECATED -- use IntegrationResult directly for new code.
# Backward-compatible shim: accepts hooks_integrated= kwarg and
# exposes a hooks_integrated property for consumers of the old API.
class HookIntegrationResult(IntegrationResult):
    """Backward-compatible wrapper around IntegrationResult."""

    def __init__(self, *args, hooks_integrated=None, **kwargs):
        if hooks_integrated is not None:
            kwargs.setdefault("files_integrated", hooks_integrated)
            kwargs.setdefault("files_updated", 0)
            kwargs.setdefault("files_skipped", 0)
            kwargs.setdefault("target_paths", [])
        super().__init__(*args, **kwargs)

    @property
    def hooks_integrated(self):
        """Alias for files_integrated (backward compat)."""
        return self.files_integrated


class HookTargetReconcileStats(TypedDict):
    """Counts and locations produced by package-target hook contraction."""

    files_removed: int
    errors: int
    failed_targets: list[str]
    failed_paths: list[str]
    deleted_paths: list[str]  # emptied hook files deleted (#4852)


@dataclass(frozen=True)
class _MergeHookConfig:
    """Configuration for targets that merge hooks into a single JSON file."""

    config_filename: str  # e.g. "settings.json" or "hooks.json"
    target_key: str  # target name passed to _rewrite_hooks_data
    require_dir: bool  # True = skip if target dir doesn't exist
    schema_strict: bool = True  # Ownership always lives outside native files.
    # Antigravity reserves "apm" instead of "hooks"; sibling names belong to users.
    event_container_key: str = "hooks"
    # Native defaults are injected only when absent, never over user values.
    top_level_defaults: dict[str, Any] = field(default_factory=dict)
    prompt_handler_types: tuple[str, ...] = ()
    named_containers: bool = False
    nested_handlers: bool | None = None


# Per-target hook event name mapping.  Packages are authored with
# Copilot (camelCase) or Claude (PascalCase) names; targets that use
# different conventions get their events renamed during merge.
_HOOK_EVENT_MAP: dict[str, dict[str, str]] = {
    "copilot": {
        # Claude PascalCase -> Copilot camelCase
        "PreToolUse": "preToolUse",
        "preToolUse": "preToolUse",
        "PostToolUse": "postToolUse",
        "postToolUse": "postToolUse",
        **dict.fromkeys(("UserPromptSubmit", "userPromptSubmit"), "userPromptSubmitted"),
        "userPromptSubmitted": "userPromptSubmitted",
        **dict.fromkeys(("SessionStart", "sessionStart"), "sessionStart"),
        **dict.fromkeys(("Stop", "AgentStop", "agentStop"), "agentStop"),
        "PreTaskExecution": "preTaskExecution",
        "preTaskExecution": "preTaskExecution",
        "PostTaskExecution": "postTaskExecution",
        "postTaskExecution": "postTaskExecution",
    },
    "claude": {
        # Copilot hooks-reference alias pairs -> documented Claude events.
        "preToolUse": "PreToolUse",
        "postToolUse": "PostToolUse",
        "postToolUseFailure": "PostToolUseFailure",
        **dict.fromkeys(("SessionStart", "sessionStart"), "SessionStart"),
        "sessionEnd": "SessionEnd",
        **dict.fromkeys(("userPromptSubmitted", "userPromptSubmit"), "UserPromptSubmit"),
        **dict.fromkeys(("Stop", "AgentStop", "agentStop"), "Stop"),
        "subagentStop": "SubagentStop",
        "preCompact": "PreCompact",
    },
    "cursor": {  # Values must stay within CURSOR_NATIVE_EVENTS.
        "PreToolUse": "preToolUse",
        "PostToolUse": "postToolUse",
        "UserPromptSubmit": "beforeSubmitPrompt",
        "Stop": "stop",
        "SubagentStop": "subagentStop",
        "SessionStart": "sessionStart",
        "SessionEnd": "sessionEnd",
        "PreCompact": "preCompact",
    },
    "gemini": {
        # Copilot / Claude -> Gemini
        "PreToolUse": "BeforeTool",
        "preToolUse": "BeforeTool",
        "PostToolUse": "AfterTool",
        "postToolUse": "AfterTool",
        "Stop": "SessionEnd",
    },
    "kiro": {
        # Portable and legacy spellings -> Kiro v1 PascalCase triggers.
        "PreToolUse": "PreToolUse",
        "preToolUse": "PreToolUse",
        "PostToolUse": "PostToolUse",
        "postToolUse": "PostToolUse",
        "UserPromptSubmit": "UserPromptSubmit",
        "userPromptSubmit": "UserPromptSubmit",
        "promptSubmit": "UserPromptSubmit",
        "Stop": "Stop",
        "stop": "Stop",
        "AgentStop": "Stop",
        "agentStop": "Stop",
        "SessionStart": "SessionStart",
        "sessionStart": "SessionStart",
        "PreTaskExecution": "PreTaskExec",
        "preTaskExecution": "PreTaskExec",
        "PreTaskExec": "PreTaskExec",
        "PostTaskExecution": "PostTaskExec",
        "postTaskExecution": "PostTaskExec",
        "PostTaskExec": "PostTaskExec",
        "PostFileCreate": "PostFileCreate",
        "PostFileSave": "PostFileSave",
        "PostFileDelete": "PostFileDelete",
    },
}

# Expected hook event naming convention per target.
# Used to warn when a package author deploys events whose casing does not
# match the target's convention AND no explicit rename mapping exists.
_HOOK_EVENT_EXPECTED_CASING: dict[str, str] = {
    "copilot": "camelCase",
    "vscode": "PascalCase",
    "claude": "PascalCase",
    "cursor": "camelCase",
    "codex": "PascalCase",
    "gemini": "PascalCase",
    "antigravity": "PascalCase",
    "windsurf": "PascalCase",
    "kiro": "PascalCase",
}


def _detect_event_casing(name: str) -> str | None:
    """Return 'camelCase', 'PascalCase', or None for an event name string."""
    if not name or not name[0].isalpha():
        return None
    if name[0].islower() and any(c.isupper() for c in name[1:]):
        return "camelCase"
    if name[0].isupper():
        return "PascalCase"
    return None


def _sanitize_event_name(name: str) -> str:
    """Return event name with non-printable-ASCII characters stripped, for safe logging."""
    return "".join(c for c in name if 0x20 <= ord(c) <= 0x7E)


def _emit_hook_event_diagnostics(
    event_names: list[str],
    target_key: str,
    event_map: dict[str, str],
) -> None:
    """Log hook events per-target and warn on unmapped casing mismatches.

    This is informational only -- it never blocks deployment.
    """
    if not event_names:
        return
    event_label = "hook event" if len(event_names) == 1 else "hook events"
    _log.info(
        "target %s: detected %s: %s",
        target_key,
        event_label,
        ", ".join(sorted(_sanitize_event_name(n) for n in event_names)),
    )
    expected_casing = _HOOK_EVENT_EXPECTED_CASING.get(target_key)
    if not expected_casing:
        return
    # Warn for events whose detected casing does not match the target convention
    # and that are not covered by an explicit rename in event_map.
    mismatched = [
        n
        for n in event_names
        if _detect_event_casing(n) not in (None, expected_casing) and n not in event_map
    ]
    if mismatched:
        example = "preToolUse" if expected_casing == "camelCase" else "PreToolUse"
        safe_mismatched = sorted(_sanitize_event_name(n) for n in mismatched)
        _rich_warning(
            f"Hook events for target '{target_key}' may not be recognized: "
            f"{', '.join(safe_mismatched)}. "
            f"Target expects {expected_casing} (e.g. {example}). "
            f"Rename events to match the {expected_casing} convention, then reinstall."
        )
        _log.warning(
            "target %s: hook event casing mismatch (no mapping): %s",
            target_key,
            ", ".join(safe_mismatched),
        )


def _validate_copilot_payload(payload: dict) -> list[str]:
    """Return native payload shape errors before any filesystem mutation."""
    errors: list[str] = []
    if payload.get("version") != 1:
        errors.append("top-level version must equal 1")
    hooks = payload.get("hooks")
    if not isinstance(hooks, dict):
        return [*errors, "top-level hooks must be an object"]
    for event, entries in hooks.items():
        if not isinstance(entries, list):
            errors.append(f"hook event {event!r} must contain a list")
            continue
        for index, entry in enumerate(entries):
            if not isinstance(entry, dict):
                errors.append(f"hook event {event!r} entry {index} must be an object")
                continue
            handlers = entry.get("hooks")
            if handlers is not None and (
                not isinstance(handlers, list)
                or not all(isinstance(handler, dict) for handler in handlers)
            ):
                errors.append(f"hook event {event!r} entry {index} handlers must be objects")
    return errors


_MERGE_HOOK_TARGETS: dict[str, _MergeHookConfig] = {
    "claude": _MergeHookConfig(
        config_filename="settings.json",
        target_key="claude",
        require_dir=False,
        schema_strict=True,
        prompt_handler_types=("prompt", "agent"),
        nested_handlers=True,
    ),
    "cursor": _MergeHookConfig(
        config_filename="hooks.json",
        target_key="cursor",
        require_dir=True,
        top_level_defaults={"version": 1},
        prompt_handler_types=("prompt",),
        nested_handlers=False,
    ),
    "codex": _MergeHookConfig(
        config_filename="hooks.json",
        target_key="codex",
        require_dir=True,
        nested_handlers=True,
    ),
    "gemini": _MergeHookConfig(
        config_filename="settings.json",
        target_key="gemini",
        require_dir=True,
        nested_handlers=True,
    ),
    "antigravity": _MergeHookConfig(
        config_filename="hooks.json",
        target_key="antigravity",
        require_dir=True,
        event_container_key="apm",
        named_containers=True,
    ),
    "windsurf": _MergeHookConfig(
        config_filename="hooks.json",
        target_key="windsurf",
        require_dir=True,
    ),
}


_APM_HOOKS_SIDECAR = "apm-hooks.json"


def native_hook_config(target_name: str) -> _MergeHookConfig | None:
    """Return the canonical native container and content contract for a target."""
    return _MERGE_HOOK_TARGETS.get(target_name)


class HookIntegrator(BaseIntegrator):
    """Handles integration of APM package hooks into target locations.

    Discovers hook JSON files and their referenced scripts from packages,
    then installs them to the appropriate target location:
    - VSCode: .github/hooks/<pkg>-<name>.json + .github/hooks/scripts/<pkg>/
    - Claude: Merged into .claude/settings.json hooks key + .claude/hooks/<pkg>/
    - Cursor: Merged into .cursor/hooks.json hooks key + .cursor/hooks/<pkg>/
    """

    # Superset of all known script-path keys across supported hook specs.
    # Every call site in _rewrite_hooks_data() iterates over this tuple,
    # so a single addition here propagates everywhere.
    #
    #   "command":    Claude Code (primary), VS Code (default/cross-platform), Cursor
    #   "bash":       GitHub Copilot Agent cloud/CLI
    #   "powershell": GitHub Copilot Agent cloud/CLI
    #   "windows":    VS Code (OS-specific override)
    #   "linux":      VS Code (OS-specific override)
    #   "osx":        VS Code (OS-specific override)
    #
    # Refs:
    #   GH Copilot Agent: https://docs.github.com/en/copilot/concepts/agents/coding-agent/about-hooks
    #   VS Code:          https://code.visualstudio.com/docs/copilot/customization/hooks
    #   Claude Code:      https://code.claude.com/docs/en/hooks
    HOOK_COMMAND_KEYS: tuple[str, ...] = _HOOK_COMMAND_KEYS
    replay_command_root: Path | None = None  # live user root, set only by audit replay

    @staticmethod
    def _iter_hook_entries(payload: dict) -> list[tuple[str, dict]]:
        """Flatten hook payloads into (event_name, entry_dict) pairs."""
        return [
            (declaration.event, {declaration.key: declaration.command})
            for declaration in walk_hook_commands(payload)
        ]

    _summarize_command = staticmethod(summarize_hook_command)

    def _build_display_payload(
        self,
        target_label: str,
        output_path: str,
        source_hook_file: Any,
        rewritten: dict,
    ) -> dict:
        """Build CLI display metadata for an integrated hook file.

        Uses post-path-rewrite data (the 'rewritten' dict) so the summary
        faithfully reflects what is actually written to disk and executed.
        """
        actions = []
        for event_name, entry in self._iter_hook_entries(rewritten):
            actions.append(
                {
                    "event": event_name,
                    "summary": self._summarize_command(entry),
                }
            )
        return {
            "target_label": target_label,
            "output_path": output_path,
            "source_hook_file": source_hook_file.name
            if hasattr(source_hook_file, "name")
            else str(source_hook_file),
            "actions": actions,
            "rendered_json": json.dumps(rewritten, indent=2, sort_keys=True),
        }

    def find_hook_files(self, package_path: Path, source_plan=None) -> list[Path]:
        """Find all hook JSON files in a package.

        Searches in:
        - .apm/hooks/ subdirectory (APM convention)
        - hooks/ subdirectory (Claude-native convention)

        Args:
            package_path: Path to the package directory

        Returns:
            List[Path]: List of absolute paths to hook JSON files
        """
        hook_files: list[Path] = []
        seen_stems: set[str] = set()

        # Search in .apm/hooks/ (APM convention)
        apm_hooks = package_path / ".apm" / "hooks"
        if apm_hooks.exists():
            for f in sorted(apm_hooks.glob("*.json")):
                if f.is_symlink():
                    continue
                stem_key = f.stem.lower()
                if stem_key not in seen_stems:
                    seen_stems.add(stem_key)
                    hook_files.append(f)

        # Search in hooks/ (Claude-native convention)
        hooks_dir = package_path / "hooks"
        if hooks_dir.exists():
            for f in sorted(hooks_dir.glob("*.json")):
                if f.is_symlink():
                    continue
                stem_key = f.stem.lower()
                if stem_key not in seen_stems:
                    seen_stems.add(stem_key)
                    hook_files.append(f)

        return self.filter_authorized_files(hook_files, source_plan)

    @classmethod
    def find_deployable_hook_bundle_files(
        cls,
        package_path: Path,
        hook_files: list[Path],
    ) -> list[Path]:
        """Return the legacy Claude-compatible projection of the shared selector."""
        selection = cls.select_deployable_hook_sources(
            package_path,
            ("claude",),
            hook_files=hook_files,
        )
        return sorted(selection.files)

    @classmethod
    def select_deployable_hook_sources(
        cls,
        package_path: Path,
        target_names: Iterable[str],
        *,
        hook_files: list[Path] | None = None,
    ) -> HookSourceSelection:
        """Select hook inputs that each resolved target will materialize.

        This is the sole hook source-selection algorithm.  Filenames never
        route (#3226); it records retired-routing widening, excludes Copilot's
        recursively-scanned JSON assets, and enumerates each source root once
        per target.
        """
        integrator = cls()
        known = integrator.find_hook_files(package_path)
        discovered_files = hook_files if hook_files is not None else known
        return select_hook_sources(
            package_path,
            target_names,
            hook_files=discovered_files,
            parse_hook_json=integrator._parse_hook_json,
            iter_bundle_files=iter_deployable_hook_bundle_files,
            merge_target_names=_MERGE_HOOK_TARGETS,
            known_descriptors=known,
        )

    def select_hook_sources_for_target(
        self,
        package_info,
        target_name: str,
        *,
        source_plan=None,
    ) -> HookSourceSelection:
        """Read the plan's selection (empty when unauthorized) or build one; refuse widening."""
        if source_plan is not None:
            selection = getattr(source_plan, "hook_source_selection", None)
            if selection is None:
                selection = HookSourceSelection({}, {})
        else:
            selection = self.select_deployable_hook_sources(
                package_info.install_path, (target_name,)
            )
        # Routing only; Claude events are checked at preflight and the Claude write.
        selection.require_configured_routing(hook_package_label(package_info))
        return selection

    @staticmethod
    def _referenced_hook_source_files(
        data: dict, package_path: Path, hook_file_dir: Path
    ) -> set[Path]:
        """Resolve existing package files referenced by a parsed hook document."""
        return _referenced_hook_source_files(data, package_path, hook_file_dir)

    def _parse_hook_json(self, hook_file: Path) -> dict | None:
        """Parse a hook document and normalize a supported naked hook slice."""
        return _parse_hook_json(hook_file, logger=_log)

    @staticmethod
    def _project_scoped_command_path(
        command: str,
        target: str,
        target_rel: str,
        deploy_root: Path | None,
        source_key: str | None = None,
        path_quote: str = "",
        home_reference: "UserHookHomeReference | None" = None,
    ) -> str:
        """Return a target-native script reference without sacrificing portability."""
        if deploy_root is not None:
            path = (deploy_root / target_rel).resolve()
            if home_reference is None:
                return str(path)
            return home_reference.anchor(path, source_key, quote=path_quote)
        if target != "claude":
            return target_rel

        if "$" in target_rel or "`" in target_rel:
            raise ValueError("Claude project hook paths cannot contain shell expansion characters")

        project_dir = "CLAUDE_PROJECT_DIR"
        if source_key == "powershell" or re.match(
            r"\s*(?:powershell|pwsh)(?:\.exe)?(?:\s|$)", command, re.IGNORECASE
        ):
            return f"$env:{project_dir}/{target_rel}"
        path = f"${{{project_dir}}}/{target_rel}"
        return path if path_quote else f'"{path}"'

    def _rewrite_command_for_target(
        self,
        command: str,
        package_path: Path,
        package_name: str,
        target: str,
        hook_file_dir: Path | None = None,
        root_dir: str | None = None,
        deploy_root: Path | None = None,
        source_key: str | None = None,
        home_reference: "UserHookHomeReference | None" = None,
    ) -> tuple[str, list[tuple[Path, str]]]:
        """Rewrite plugin-root and relative script references for a target."""
        scripts_to_copy = []
        command = normalize_quoted_plugin_root(command)
        edits: list[tuple[int, int, str]] = []

        if target in SCRIPTS_SUBDIR_HOOK_TARGETS:
            default_root = ".github"
        else:
            default_root = f".{target}" if target in _DOT_NAMED_HOOK_ROOTS else ".claude"
        scripts_base = hook_scripts_parent(target, root_dir or default_root) + package_name

        def scoped(target_rel: str, quote: str) -> str:
            return self._project_scoped_command_path(
                command, target, target_rel, deploy_root, source_key, quote, home_reference
            )

        handled_plugin_root_refs: set[str] = set()
        traversal_plugin_root_refs: set[str] = set()
        for match in iter_plugin_root_paths(command):
            full_var = match.group(0)
            rel_path = plugin_root_relative_path(match.group(1))

            try:
                source_file = resolve_plugin_root_hook_script(package_path, rel_path)
            except PathTraversalError:
                traversal_plugin_root_refs.add(full_var)
                continue
            handled_plugin_root_refs.add(full_var)
            if source_file.exists() and source_file.is_file():
                target_rel = f"{scripts_base}/{rel_path}"
                scripts_to_copy.append((source_file, target_rel))
                resolved_cmd = scoped(target_rel, wrapping_quote(command, match))
                edits.append((match.start(), match.end(), resolved_cmd))
            else:
                # File absent: always warn so a misconfigured hook is never
                # silently deployed.  For user-scope (deploy_root set) also
                # rewrite the unexpanded variable to an absolute source path
                # so the target surfaces a clear "file not found".  For
                # project-scope (deploy_root is None) leave the variable in
                # place -- rewriting to an absolute path would re-introduce
                # the #1394 portability regression in committed configs.
                _rich_warning(
                    "Hook script not found for package "
                    f"'{printable_ascii_text(package_name)}': "
                    f"{printable_ascii_text(str(source_file))}"
                )
                if deploy_root is not None:
                    edits.append((match.start(), match.end(), str(source_file)))

        new_command = splice_references(command, edits)
        # Keep matcher misses visible instead of silently deploying them.
        for residual in unresolved_plugin_root_references(new_command):
            if residual in handled_plugin_root_refs:
                continue
            package_label = printable_ascii_text(package_name)
            if residual in traversal_plugin_root_refs:
                _rich_warning(
                    f"Hook path escapes package '{package_label}': "
                    f"{printable_ascii_text(residual)}. "
                    f"{HOOK_PATH_ESCAPES_PACKAGE.sentence()}"
                )
                continue
            warn_unresolved_plugin_root(new_command, residual, package_label)

        edits = []
        for match in iter_relative_script_paths(new_command):
            rel_ref = match.group(1)
            # Normalize to forward slashes for path resolution
            rel_path = rel_ref[2:].replace("\\", "/")

            source_file = resolve_relative_hook_script(package_path, hook_file_dir, rel_path)
            if source_file is None:
                continue
            if source_file.exists() and source_file.is_file():
                target_rel = f"{scripts_base}/{rel_path}"
                scripts_to_copy.append((source_file, target_rel))
                resolved_cmd = scoped(target_rel, wrapping_quote(new_command, match))
                edits.append((*match.span(1), resolved_cmd))
            else:
                # File absent: always warn (see ${PLUGIN_ROOT} branch above
                # for the project-scope vs user-scope rationale).
                _rich_warning(
                    "Hook script not found for package "
                    f"'{printable_ascii_text(package_name)}': "
                    f"{printable_ascii_text(str(source_file))}"
                )
                if deploy_root is not None:
                    edits.append((*match.span(1), str(source_file)))

        return splice_references(new_command, edits), scripts_to_copy

    def _rewrite_hooks_data(
        self,
        data: dict,
        package_path: Path,
        package_name: str,
        target: str,
        hook_file_dir: Path | None = None,
        root_dir: str | None = None,
        deploy_root: Path | None = None,
        home_reference: "UserHookHomeReference | None" = None,
    ) -> tuple[dict, list[tuple[Path, str]]]:
        """Rewrite all command paths in a hooks JSON structure.

        Creates a deep copy and rewrites command paths for the target platform.

        Args:
            data: Parsed hook JSON data
            package_path: Root path of the source package
            package_name: Name for scripts subdirectory
            target: "vscode" or "claude"
            hook_file_dir: Directory containing the hook JSON file (for ./path resolution)
            root_dir: Override root directory (e.g. ".copilot" for user scope)
            deploy_root: Absolute root of the deployment directory.  When provided,
                all rewritten script paths are pinned to the deploy root so the
                target can locate scripts regardless of the working directory.
                When *None*, paths remain relative (backward-compatible behaviour).

        Returns:
            Tuple of (rewritten_data_copy, list of (source_file, target_rel_path))
        """
        import copy

        rewritten = copy.deepcopy(data)
        all_scripts: list[tuple[Path, str]] = []

        hooks = rewritten.get("hooks", {})
        for event_name, matchers in hooks.items():
            if not isinstance(matchers, list):
                continue
            for matcher in matchers:
                if not isinstance(matcher, dict):
                    continue
                # Rewrite script paths in the matcher dict itself
                # (GitHub Copilot flat format: bash/powershell/windows keys at this level)
                for key in self.HOOK_COMMAND_KEYS:
                    if key in matcher:
                        new_cmd, scripts = self._rewrite_command_for_target(
                            matcher[key],
                            package_path,
                            package_name,
                            target,
                            hook_file_dir=hook_file_dir,
                            root_dir=root_dir,
                            deploy_root=deploy_root,
                            source_key=key,
                            home_reference=home_reference and home_reference.for_handler(matcher),
                        )
                        if scripts:
                            _log.debug(
                                "Hook %s/%s: rewrote '%s' key (%d script(s))",
                                package_name,
                                event_name,
                                key,
                                len(scripts),
                            )
                        matcher[key] = new_cmd
                        all_scripts.extend(scripts)

                # Rewrite script paths in nested hooks array
                # (Claude format: matcher groups with inner hooks array)
                for hook in matcher.get("hooks", []):
                    if not isinstance(hook, dict):
                        continue
                    for key in self.HOOK_COMMAND_KEYS:
                        if key in hook:
                            new_cmd, scripts = self._rewrite_command_for_target(
                                hook[key],
                                package_path,
                                package_name,
                                target,
                                hook_file_dir=hook_file_dir,
                                root_dir=root_dir,
                                deploy_root=deploy_root,
                                source_key=key if key != "command" else hook.get("shell"),
                                home_reference=home_reference and home_reference.for_handler(hook),
                            )
                            if scripts:
                                _log.debug(
                                    "Hook %s/%s: rewrote '%s' key (%d script(s))",
                                    package_name,
                                    event_name,
                                    key,
                                    len(scripts),
                                )
                            hook[key] = new_cmd
                            all_scripts.extend(scripts)

        # De-duplicate by target path to avoid redundant copies when
        # multiple keys (e.g. command + bash) reference the same script.
        seen_targets: dict[str, Path] = {}
        for source, target_rel in all_scripts:
            if target_rel not in seen_targets:
                seen_targets[target_rel] = source
        unique_scripts = [(src, tgt) for tgt, src in seen_targets.items()]

        return rewritten, unique_scripts

    @staticmethod
    def _root_local_identity_root(package_info, project_root: Path | None) -> Path | None:
        """Return the project root used to identify root-local packages."""
        return getattr(package_info, "root_local_project_root", None) or project_root

    @staticmethod
    def _is_root_local_package(package_info, project_root: Path | None) -> bool:
        """Return True when *package_info* represents the project's own .apm content."""
        identity_root = HookIntegrator._root_local_identity_root(package_info, project_root)
        if identity_root is None:
            return False
        try:
            return Path(package_info.install_path).resolve() == Path(identity_root).resolve()
        except (OSError, RuntimeError):
            return False

    @staticmethod
    def _safe_source_name(value: str | None, fallback: str = "_local") -> str:
        """Return a stable source marker that is also safe for hook script paths."""
        if not isinstance(value, str) or not value:
            return fallback
        safe = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip())
        # Collapse any run of 2+ dots to a single dot before stripping edges.
        # Embedded sequences like "foo..bar" would otherwise pass through the
        # earlier guard and reach downstream Path joins as a parent-dir hop.
        safe = re.sub(r"\.{2,}", ".", safe).strip(".-_")
        if not safe or safe in {".", ".."}:
            return fallback
        return safe

    @staticmethod
    def _get_root_local_package_name(package_info, project_root: Path) -> str:
        """Get the stable source marker for root .apm content."""
        apm_yml = manifest_file(Path(project_root))
        if apm_yml.exists():
            try:
                from apm_cli.utils.yaml_io import load_yaml

                data = load_yaml(apm_yml)
                if isinstance(data, dict):
                    manifest_name = HookIntegrator._safe_source_name(data.get("name"))
                    if manifest_name != "_local":
                        return manifest_name
            except (OSError, ValueError, yaml.YAMLError) as exc:
                _log.debug(
                    "Hook integrator: apm.yml manifest unreadable for %s (%s: %s), "
                    "falling back to install_path basename",
                    project_root,
                    exc.__class__.__name__,
                    exc,
                )

        package = getattr(package_info, "package", None)
        package_name = HookIntegrator._safe_source_name(getattr(package, "name", None))
        if package_name != "_local":
            return package_name
        return "_local"

    def _get_package_name(self, package_info, project_root: Path | None = None) -> str:
        """Get a short package name for use in file/directory naming.

        Args:
            package_info: PackageInfo object
            project_root: When provided and the package is the project root,
                reads ``apm.yml`` ``name`` for a stable source marker instead
                of falling back to ``install_path.name`` (which drifts on
                directory renames and worktrees). See #1329.

        Returns:
            str: Package name used as hook source marker and script namespace
        """
        if self._is_root_local_package(package_info, project_root):
            identity_root = HookIntegrator._root_local_identity_root(package_info, project_root)
            return HookIntegrator._get_root_local_package_name(package_info, Path(identity_root))
        return package_info.install_path.name

    @staticmethod
    def _get_hook_source_marker(
        package_info,
        project_root: Path,
        package_name: str,
    ) -> str:
        """Get the marker stored in merged hook JSON for ownership cleanup."""
        if HookIntegrator._is_root_local_package(package_info, project_root):
            if package_name == "_local":
                return "_local"
            return f"_local/{package_name}"
        if isinstance(bundle_id := getattr(package_info, "local_bundle_id", None), str):
            return local_bundle_hook_source_marker(bundle_id, package_info.local_bundle_approval)
        try:
            dependency_ref = vars(package_info).get("dependency_ref")
        except TypeError:
            dependency_ref = None
        if dependency_ref is not None:
            marker = dependency_hook_source_marker(dependency_ref)
            if isinstance(marker, str) and marker and marker != "unknown":
                return marker
        return package_name

    @staticmethod
    def _get_hook_source_markers(
        package_info,
        project_root: Path,
        package_name: str,
        dependency_sources: set[str] | None = None,
    ) -> tuple[str, frozenset[str]]:
        """Return the canonical marker and any safe legacy marker aliases."""
        primary = HookIntegrator._get_hook_source_marker(
            package_info,
            project_root,
            package_name,
        )
        legacy: set[str] = set()
        root_local = HookIntegrator._is_root_local_package(package_info, project_root)
        root_legacy_is_unambiguous = False
        if root_local:
            known_dependency_sources = (
                dependency_sources
                if dependency_sources is not None
                else dependency_hook_sources(project_root)
            )
            root_legacy_is_unambiguous = package_name not in known_dependency_sources
        if primary != package_name and (
            root_legacy_is_unambiguous
            or legacy_source_marker_is_unambiguous(
                package_info,
                project_root,
                package_name,
            )
        ):
            legacy.add(package_name)
        return primary, frozenset(legacy)

    @staticmethod
    def _hook_entry_content_key(entry: dict) -> str:
        """Build a stable comparison key excluding APM ownership metadata."""
        comparable = {k: v for k, v in sorted(entry.items()) if k != "_apm_source"}
        return json.dumps(comparable, sort_keys=True, separators=(",", ":"))

    @staticmethod
    def _should_remove_prior_merged_entry(
        entry,
        *,
        source_marker: str,
        legacy_source_markers: frozenset[str],
        fresh_content_keys: set[str],
        heal_stale_root_source: bool,
        dependency_sources: set[str],
        remove_current_source: bool,
    ) -> bool:
        """Return True when an existing merged-hook entry should be replaced."""
        if not isinstance(entry, dict):
            return False
        source = entry.get("_apm_source")
        if remove_current_source and source == source_marker:
            return True
        if remove_current_source and source in legacy_source_markers:
            return True
        if not heal_stale_root_source or not source or source in dependency_sources:
            return False
        return HookIntegrator._hook_entry_content_key(entry) in fresh_content_keys

    def _deploy_root_for_hook_rewrite(self, project_root: Path, user_scope: bool) -> Path | None:
        # User scope needs cwd-independent paths; audit replay renders the live root's.
        return (self.replay_command_root or project_root) if user_scope else None

    @staticmethod
    def _home_reference_for_hook_rewrite(target, user_scope: bool):
        """Return the target's verified home reference for user-scope hook rewrites."""
        from apm_cli.integration.targets import UserHookHomeReference

        reference = getattr(target, "user_hook_home_reference", None) if user_scope else None
        return reference if isinstance(reference, UserHookHomeReference) else None

    def integrate_package_hooks(
        self,
        package_info,
        project_root: Path,
        force: bool = False,
        managed_files: set = None,  # noqa: RUF013
        diagnostics=None,
        target=None,
        user_scope: bool = False,
        source_plan=None,
    ) -> HookIntegrationResult:
        """Integrate hooks from a package into hooks dir (Copilot target).

        Deploys hook JSON files with clean filenames and copies referenced
        script files. Keeps user-authored and edited files unless force=True.

        Args:
            package_info: PackageInfo with package metadata and install path
            project_root: Root directory of the project
            force: If True, overwrite user-authored files on collision
            managed_files: Set of relative paths known to be APM-managed
            target: Optional TargetProfile for scope-resolved root_dir
            user_scope: If True, rewrite hook script commands so global hooks
                resolve from any working directory

        Returns:
            HookIntegrationResult: Results of the integration operation
        """
        package_name = self._get_package_name(package_info, project_root)
        hook_sources = self.select_hook_sources_for_target(
            package_info,
            "copilot",
            source_plan=source_plan,
        )
        hook_files = hook_sources.descriptors_for("copilot")

        if not hook_files:
            return HookIntegrationResult(
                files_integrated=0, files_updated=0, files_skipped=0, target_paths=[]
            )

        root_dir = target.root_dir if target else ".github"
        hooks_dir = project_root / root_dir / "hooks"
        write_seam.mkdir(hooks_dir, parents=True, exist_ok=True)
        deploy_root_for_rewrite = self._deploy_root_for_hook_rewrite(project_root, user_scope)
        home_reference = self._home_reference_for_hook_rewrite(target, user_scope)

        hooks_integrated = 0
        scripts_copied = 0
        scripts_adopted = 0
        target_paths: list[Path] = []
        display_payloads: list = []
        materializations: list[MaterializationResult] = []
        from apm_cli.integration.targets import KNOWN_TARGETS
        from apm_cli.utils.content_hash import compute_file_hash

        for hook_file in hook_files:
            data = self._parse_hook_json(hook_file)
            if data is None:
                continue

            # Rewrite script paths for Copilot target
            rewritten, scripts = self._rewrite_hooks_data(
                data,
                package_info.install_path,
                package_name,
                "vscode",
                hook_file_dir=hook_file.parent,
                root_dir=root_dir,
                deploy_root=deploy_root_for_rewrite,
                home_reference=home_reference,
            )

            target_path = copilot_hook_target(hooks_dir, package_name, hook_file)
            rel_path = portable_relpath(target_path, project_root)

            if self.check_collision(
                target_path, rel_path, managed_files, force, diagnostics=diagnostics
            ):
                continue

            hooks = rewritten.get("hooks", {})
            event_map = _HOOK_EVENT_MAP.get("copilot", {})
            _emit_hook_event_diagnostics(list(hooks.keys()), "copilot", event_map)
            if isinstance(hooks, dict):
                renamed_hooks = {}
                for raw_event_name, entries in hooks.items():
                    event_name = event_map.get(raw_event_name, raw_event_name)
                    if event_name in renamed_hooks and isinstance(renamed_hooks[event_name], list):
                        if isinstance(entries, list):
                            renamed_hooks[event_name].extend(entries)
                            continue
                    renamed_hooks[event_name] = entries
                rewritten["hooks"] = renamed_hooks

            rewritten.setdefault("version", 1)
            errors = _validate_copilot_payload(rewritten)
            validation = NativePayloadValidation(
                valid=not errors,
                contract="copilot-hooks-v1",
                errors=tuple(errors),
            )
            locator = DeploymentLedgerCodec.locator_for_path(
                target_path,
                project_root=project_root,
                target=target or KNOWN_TARGETS["copilot"],
                scope=InstallScope.PROJECT,
            )
            if not validation.valid:
                if diagnostics is not None:
                    diagnostics.error(
                        f"Invalid Copilot hook payload for {rel_path}",
                        package=package_name,
                        detail="; ".join(validation.errors),
                    )
                materializations.append(
                    MaterializationResult(
                        locator=locator,
                        owners=frozenset({package_info.get_canonical_dependency_string()}),
                        status=MaterializationStatus.FAILED,
                        content_hash=None,
                        validation=validation,
                    )
                )
                continue

            # An edited hook file is kept (#4626); its scripts are gated one by one below.
            if not self.keeps_edited_output(
                target_path,
                hook_file,
                rel_path,
                force,
                diagnostics,
                target_paths,
                expected_content=json.dumps(rewritten, indent=2) + "\n",
            ):
                # Write rewritten JSON; byte-identical output is unchanged (#4184).
                if self.write_text_if_changed(target_path, json.dumps(rewritten, indent=2) + "\n"):
                    self.note_rendered_write(target_path)
                    hooks_integrated += 1
                elif not self.receipted_unchanged(target_path):
                    # A managed file already holding the render is APM's bytes (#3701).
                    if managed_files and rel_path in managed_files:
                        self.note_rendered_write(target_path)
                    scripts_adopted += 1
                target_paths.append(target_path)
                materializations.append(
                    MaterializationResult(
                        locator=locator,
                        owners=frozenset({package_info.get_canonical_dependency_string()}),
                        status=MaterializationStatus.WRITTEN,
                        content_hash=compute_file_hash(target_path),
                        validation=validation,
                    )
                )
                display_payloads.append(
                    self._build_display_payload(
                        f"{root_dir}/hooks/", target_path.name, hook_file, rewritten
                    )
                )

            copy_result = copy_deployed_hook_bundle(
                self,
                package_path=package_info.install_path,
                hook_file_dir=hook_file.parent,
                project_root=project_root,
                scripts=scripts,
                managed_files=managed_files,
                force=force,
                diagnostics=diagnostics,
                target_paths=target_paths,
                hook_descriptor_files=set(hook_files),
                exclude_json_files=True,
                source_plan=source_plan,
                selected_bundle_files=hook_sources.bundle_for("copilot"),
            )
            scripts_copied += copy_result.scripts_copied
            scripts_adopted += copy_result.files_adopted

        return HookIntegrationResult(
            files_integrated=hooks_integrated,
            files_updated=0,
            files_skipped=0,
            target_paths=target_paths,
            scripts_copied=scripts_copied,
            files_adopted=scripts_adopted,
            display_payloads=display_payloads,
            hooks_registered=sum(
                m.status is MaterializationStatus.WRITTEN for m in materializations
            ),
            materializations=tuple(materializations),
        )

    # ------------------------------------------------------------------
    # Shared JSON-merge implementation for Claude / Cursor / Codex
    # ------------------------------------------------------------------

    def _integrate_merged_hooks(
        self,
        config: "_MergeHookConfig",
        package_info,
        project_root: Path,
        *,
        force: bool = False,
        managed_files: set = None,  # noqa: RUF013
        diagnostics=None,
        target=None,
        user_scope: bool = False,
        source_plan=None,
        retiring_targets: frozenset[str] = frozenset(),
    ) -> HookIntegrationResult:
        """Merge native hook entries into a shared target-specific JSON config."""
        _empty = HookIntegrationResult(
            files_integrated=0, files_updated=0, files_skipped=0, target_paths=[]
        )

        root_dir = target.root_dir if target else f".{config.target_key}"
        target_dir = project_root / root_dir
        container = config.event_container_key

        # Opt-in check: some targets only deploy when their dir exists
        if config.require_dir and not target_dir.exists():
            return _empty

        _deploy_root_for_rewrite = self._deploy_root_for_hook_rewrite(project_root, user_scope)
        _home_reference = self._home_reference_for_hook_rewrite(target, user_scope)

        package_name = self._get_package_name(package_info, project_root)
        hook_sources = self.select_hook_sources_for_target(
            package_info,
            config.target_key,
            source_plan=source_plan,
        )
        hook_files = hook_sources.descriptors_for(config.target_key)
        if not hook_files:
            return _empty
        if config.target_key == "claude":  # write-boundary re-check, as for Cursor
            require_claude_native_events(
                hook_files, self._parse_hook_json, _HOOK_EVENT_MAP, hook_package_label(package_info)
            )

        heal_stale_root_source = self._is_root_local_package(package_info, project_root)
        dependency_sources = (
            dependency_hook_sources(project_root) if heal_stale_root_source else set()
        )
        source_marker, legacy_source_markers = self._get_hook_source_markers(
            package_info,
            project_root,
            package_name,
            dependency_sources,
        )
        # Always re-check authorized Cursor/import sources at this write
        # boundary, even if preflight_hooks_for_targets already ran for this
        # plan. A plan object can be reused across projects or after a
        # Claude import file is added mid-install; a cached "already
        # preflighted" flag would silently bypass the check in exactly that
        # case (#3129). Forward retiring_targets: this fallback also needs it.
        if config.target_key in {"cursor", "claude"}:
            preflight_cursor_hooks(
                self,
                package_info,
                project_root,
                hook_sources,
                _HOOK_EVENT_MAP,
                user_scope=user_scope,
                retiring_targets=retiring_targets,
            )
        hooks_integrated = 0
        scripts_copied = 0
        scripts_adopted = 0
        target_paths: list[Path] = []
        display_payloads: list = []
        # Finalize display JSON after native conversion and ownership extraction.
        pending_display: list = []
        # Clear once so later files do not erase earlier contributions.
        cleared_events: set = set()

        # Read existing JSON config
        json_path = target_dir / config.config_filename
        json_config = read_merged_hook_config(json_path, project_root, user_scope=user_scope)

        # Load external ownership metadata before reconciling native entries.
        sidecar_path = target_dir / _APM_HOOKS_SIDECAR
        sidecar_data: dict = {}
        if config.schema_strict and sidecar_path.exists():
            try:
                with open(sidecar_path, encoding="utf-8") as f:
                    _raw = json.load(f)
                if isinstance(_raw, dict):
                    sidecar_data = _raw
                else:
                    _log.warning(
                        "Sidecar file %s contains non-dict JSON; treating as empty.",
                        sidecar_path,
                    )
                    sidecar_data = {}
            except (json.JSONDecodeError, OSError) as exc:
                _log.warning("Failed to read sidecar %s: %s; treating as empty.", sidecar_path, exc)
                sidecar_data = {}

            # Re-inject _apm_source from sidecar into matching in-memory entries
            if sidecar_data and container in json_config:
                _reinject_apm_source_from_sidecar(json_config[container], sidecar_data)

        # Antigravity reserves "apm"; leave sibling user containers untouched.
        if container not in json_config:
            json_config[container] = {}
            _log.debug("Seeded hook container '%s' in %s", container, config.config_filename)

        # Safe legacy leaf aliases retire with the canonical marker (#3665).
        owned_markers = frozenset({source_marker, *legacy_source_markers})
        if config.target_key == "cursor":
            drop_source_entries(json_config[container], owned_markers)

        # Defaults never overwrite existing user fields.
        injected_keys: list[str] = []
        for key, value in config.top_level_defaults.items():
            if key not in json_config:
                json_config[key] = value
                injected_keys.append(key)
        if injected_keys:
            _log.debug(
                "Injected top_level_defaults into %s: %s",
                config.config_filename,
                injected_keys,
            )

        for hook_file in hook_files:
            data = self._parse_hook_json(hook_file)
            if data is None:
                continue

            # Rewrite script paths for the target
            rewritten, scripts = self._rewrite_hooks_data(
                data,
                package_info.install_path,
                package_name,
                config.target_key,
                hook_file_dir=hook_file.parent,
                root_dir=root_dir,
                deploy_root=_deploy_root_for_rewrite,
                home_reference=_home_reference,
            )

            # Merge hooks into config (additive)
            hooks = rewritten.get("hooks", {})
            event_map = _HOOK_EVENT_MAP.get(config.target_key, {})

            _emit_hook_event_diagnostics(list(hooks.keys()), config.target_key, event_map)

            # Build reverse map: normalised name -> set of source aliases
            reverse_map: dict[str, set[str]] = {}
            for source_name, norm_name in event_map.items():
                reverse_map.setdefault(norm_name, set()).add(source_name)
            entries_appended_for_file = False
            file_event_entries: dict = {}
            for raw_event_name, entries in hooks.items():
                if not isinstance(entries, list) or not entries:
                    continue
                event_name = event_map.get(raw_event_name, raw_event_name)
                events = (event_name, *sorted(reverse_map.get(event_name, ())))
                _hook_lists(json_config[container], events, json_path, project_root, user_scope)
                legacy_content_keys = {
                    self._hook_entry_content_key(entry)
                    for entry in _legacy_hook_entries(entries, config.target_key)
                    if isinstance(entry, dict)
                }
                if config.target_key == "claude":
                    entries = _to_claude_hook_entries(entries)
                elif config.target_key == "cursor":
                    entries = _to_cursor_hook_entries(
                        entries, event_name, foreign=raw_event_name in event_map
                    )
                elif config.target_key == "codex":
                    entries = _to_codex_hook_entries(entries)
                elif config.target_key == "gemini":
                    entries = _to_gemini_hook_entries(entries)
                elif config.target_key == "antigravity":
                    entries = _to_antigravity_hook_entries(entries, event_name)

                # Mark each entry with APM source for sync/cleanup
                for entry in entries:
                    if isinstance(entry, dict):
                        entry["_apm_source"] = source_marker
                fresh_content_keys = legacy_content_keys | {
                    self._hook_entry_content_key(entry)
                    for entry in entries
                    if isinstance(entry, dict)
                }

                # Replace owned entries once per event to prevent reinstall duplicates
                # without erasing earlier hook files' contributions (#708).
                remove_current_source = event_name not in cleared_events
                if remove_current_source or heal_stale_root_source:
                    # Clear from the normalised event
                    prior_entries = json_config[container][event_name]
                    kept_entries = [
                        e
                        for e in prior_entries
                        if not self._should_remove_prior_merged_entry(
                            e,
                            source_marker=source_marker,
                            legacy_source_markers=legacy_source_markers,
                            fresh_content_keys=fresh_content_keys,
                            heal_stale_root_source=heal_stale_root_source,
                            dependency_sources=dependency_sources,
                            remove_current_source=remove_current_source,
                        )
                    ]
                    if heal_stale_root_source:
                        kept_ids = {id(e) for e in kept_entries}
                        healed = sum(
                            1
                            for e in prior_entries
                            if isinstance(e, dict)
                            and e.get("_apm_source")
                            and e.get("_apm_source") != source_marker
                            and e.get("_apm_source") not in dependency_sources
                            and id(e) not in kept_ids
                        )
                        if healed:
                            _log.debug(
                                "Hook integrator: healed %d stale same-content "
                                "merged hook entries for source %s in event %s",
                                healed,
                                source_marker,
                                event_name,
                            )
                    json_config[container][event_name] = kept_entries
                    # Also clear from any alias events that map to
                    # this normalised name (handles migration from
                    # corrupted installs with mixed-case event keys).
                    for alias in reverse_map.get(event_name, set()):
                        if alias != event_name and alias in json_config[container]:
                            json_config[container][alias] = [
                                e
                                for e in json_config[container][alias]
                                if not self._should_remove_prior_merged_entry(
                                    e,
                                    source_marker=source_marker,
                                    legacy_source_markers=legacy_source_markers,
                                    fresh_content_keys=fresh_content_keys,
                                    heal_stale_root_source=heal_stale_root_source,
                                    dependency_sources=dependency_sources,
                                    remove_current_source=remove_current_source,
                                )
                            ]
                            # Remove the alias key entirely if now empty
                            if not json_config[container][alias]:
                                del json_config[container][alias]
                    cleared_events.add(event_name)
                json_config[container][event_name].extend(entries)

                # Deduplicate same-package entries by content.
                # Safety net for edge cases where multiple source files
                # produce semantically identical entries.
                seen_keys: set[str] = set()
                deduped: list = []
                for entry in json_config[container][event_name]:
                    if not isinstance(entry, dict):
                        deduped.append(entry)
                        continue
                    cmp = {k: v for k, v in sorted(entry.items()) if k != "_apm_source"}
                    source = entry.get("_apm_source")
                    dedup_key = json.dumps({"s": source, "c": cmp}, sort_keys=True)
                    if dedup_key not in seen_keys:
                        seen_keys.add(dedup_key)
                        deduped.append(entry)
                json_config[container][event_name] = deduped
                entries_appended_for_file = True
                # Retain references so ownership stripping also cleans display JSON.
                file_event_entries.setdefault(event_name, []).extend(
                    e for e in entries if isinstance(e, dict)
                )

            if entries_appended_for_file:
                hooks_integrated += 1
                pending_display.append(
                    (
                        config.config_filename,
                        config.config_filename,
                        hook_file,
                        file_event_entries,
                    )
                )
            else:
                # Empty sources must not produce misleading success (#1499).
                rel_hook = hook_file.name
                _rich_warning(
                    f"Hook file {rel_hook} contributed no entries to "
                    f"{config.target_key} settings; skipped."
                )
                _log.warning(
                    "Hook file %s contributed no entries to %s settings "
                    "(all events empty or non-list); skipping.",
                    hook_file,
                    config.target_key,
                )

            copy_result = copy_deployed_hook_bundle(
                self,
                package_path=package_info.install_path,
                hook_file_dir=hook_file.parent,
                project_root=project_root,
                scripts=scripts,
                managed_files=managed_files,
                force=force,
                diagnostics=diagnostics,
                target_paths=target_paths,
                hook_descriptor_files=set(hook_files),
                source_plan=source_plan,
                selected_bundle_files=hook_sources.bundle_for(config.target_key),
                target=target,
            )
            scripts_copied += copy_result.scripts_copied
            scripts_adopted += copy_result.files_adopted

        drop_source_entries(json_config[container], owned_markers, keep_events=cleared_events)
        canonical_hook_order(json_config[container])
        # Shared configs are cleaned by ownership, never file-level deletion.
        write_seam.mkdir(json_path.parent, parents=True, exist_ok=True)

        if config.schema_strict:
            sidecar_out = _extract_apm_source_sidecar(json_config.get(container, {}))

            # Write sidecar
            sidecar_path = target_dir / _APM_HOOKS_SIDECAR
            if sidecar_out:
                write_hook_sidecar(sidecar_path, sidecar_out, project_root, user_scope)
            elif sidecar_path.exists():
                remove_hook_sidecar(sidecar_path)

        # Display only finalized, schema-clean native entries.
        for _label, _path, _hook_file, _file_event_entries in pending_display:
            display_payloads.append(
                self._build_display_payload(
                    _label,
                    _path,
                    _hook_file,
                    {"hooks": _file_event_entries},
                )
            )

        # Cursor's strict config must not be observable half-written by its watcher.
        rendered = json.dumps(json_config, indent=2) + "\n"
        with provenance.recorded_install_write(json_path, project_root, user_scope):
            changed = self.write_text_if_changed(json_path, rendered, write_seam.atomic_write_text)

        return HookIntegrationResult(
            files_integrated=hooks_integrated if changed else 0,
            files_updated=0,
            files_skipped=0,
            target_paths=target_paths,
            scripts_copied=scripts_copied,
            files_adopted=scripts_adopted,  # an unchanged config is no adoption (RA-007)
            hooks_registered=hooks_integrated,
            display_payloads=display_payloads,
        )

    def integrate_package_hooks_claude(
        self,
        package_info,
        project_root: Path,
        force: bool = False,
        managed_files: set = None,  # noqa: RUF013
        diagnostics=None,
        *,
        user_scope: bool = False,
    ) -> HookIntegrationResult:
        """Integrate hooks into .claude/settings.json.

        .. deprecated:: Use :meth:`integrate_hooks_for_target` instead.
        """
        return self._integrate_merged_hooks(
            _MERGE_HOOK_TARGETS["claude"],
            package_info,
            project_root,
            force=force,
            managed_files=managed_files,
            diagnostics=diagnostics,
            user_scope=user_scope,
        )

    def integrate_package_hooks_cursor(
        self,
        package_info,
        project_root: Path,
        force: bool = False,
        managed_files: set = None,  # noqa: RUF013
        diagnostics=None,
        *,
        user_scope: bool = False,
    ) -> HookIntegrationResult:
        """Integrate hooks into .cursor/hooks.json.

        .. deprecated:: Use :meth:`integrate_hooks_for_target` instead.
        """
        return self._integrate_merged_hooks(
            _MERGE_HOOK_TARGETS["cursor"],
            package_info,
            project_root,
            force=force,
            managed_files=managed_files,
            diagnostics=diagnostics,
            user_scope=user_scope,
        )

    def integrate_package_hooks_codex(
        self,
        package_info,
        project_root: Path,
        force: bool = False,
        managed_files: set = None,  # noqa: RUF013
        diagnostics=None,
        *,
        user_scope: bool = False,
    ) -> HookIntegrationResult:
        """Integrate hooks into .codex/hooks.json.

        .. deprecated:: Use :meth:`integrate_hooks_for_target` instead.
        """
        return self._integrate_merged_hooks(
            _MERGE_HOOK_TARGETS["codex"],
            package_info,
            project_root,
            force=force,
            managed_files=managed_files,
            diagnostics=diagnostics,
            user_scope=user_scope,
        )

    def preflight_hooks_for_targets(
        self,
        package_info: Any,
        project_root: Path,
        source_plan: Any,
        *,
        user_scope: bool = False,
        retiring_targets: frozenset[str] = frozenset(),
    ) -> None:
        """Check routing, Claude events and Cursor imports before any primitive write."""
        selection = source_plan.hook_source_selection
        if selection is not None:
            selection.require_deployable(package_info, _HOOK_EVENT_MAP)
            preflight_cursor_hooks(
                self,
                package_info,
                project_root,
                selection,
                _HOOK_EVENT_MAP,
                user_scope=user_scope,
                retiring_targets=retiring_targets,
            )

    def integrate_hooks_for_target(
        self,
        target,
        package_info,
        project_root: Path,
        *,
        force: bool = False,
        managed_files: set = None,  # noqa: RUF013
        diagnostics=None,
        scope=None,
        user_scope: bool = False,
        dep_targets_active: bool = False,
        allowed_targets: set[str] | None = None,
        source_plan=None,
        retiring_targets: frozenset[str] = frozenset(),
    ) -> "HookIntegrationResult":
        """Integrate hooks for a single *target*.

        Copilot uses individual JSON files (genuinely different pattern).
        All other merge-based targets are dispatched via the
        ``_MERGE_HOOK_TARGETS`` registry.

        ``user_scope`` requires cwd-independent paths (#1310 / #1354);
        project configs retain portable repo-relative paths (#1394).
        """
        if dep_targets_active and (not allowed_targets or target.name not in allowed_targets):
            raise AssertionError(f"BUG: target {target.name} bypassed chokepoint filter")
        if target.name == "copilot":
            return self.integrate_package_hooks(
                package_info,
                project_root,
                force=force,
                managed_files=managed_files,
                diagnostics=diagnostics,
                target=target,
                user_scope=user_scope,
                source_plan=source_plan,
            )

        if target.name == "kiro":
            from apm_cli.integration.kiro_hook_integrator import integrate_kiro_hooks

            return integrate_kiro_hooks(
                self,
                package_info,
                project_root,
                force=force,
                managed_files=managed_files,
                diagnostics=diagnostics,
                target=target,
                user_scope=user_scope,
                source_plan=source_plan,
            )

        config = _MERGE_HOOK_TARGETS.get(target.name)
        if config is not None:
            return self._integrate_merged_hooks(
                config,
                package_info,
                project_root,
                force=force,
                managed_files=managed_files,
                diagnostics=diagnostics,
                target=target,
                user_scope=user_scope,
                source_plan=source_plan,
                retiring_targets=retiring_targets,
            )

        return HookIntegrationResult(
            files_integrated=0,
            files_updated=0,
            files_skipped=0,
            target_paths=[],
        )

    def reconcile_package_target_restriction(
        self,
        package_info,
        project_root: Path,
        excluded_targets,
        *,
        dry_run: bool = False,
    ) -> HookTargetReconcileStats:
        """Remove hooks from targets the package no longer deploys to, or count them (#3924)."""
        package_name = self._get_package_name(package_info, project_root)
        source_marker, legacy_source_markers = self._get_hook_source_markers(
            package_info,
            project_root,
            package_name,
        )
        markers = frozenset({source_marker, *legacy_source_markers})
        return self._retire_source_markers(project_root, excluded_targets, markers, dry_run)

    def retire_local_bundle_hooks(self, bundle_id: str, project_root: Path, targets):
        """Remove one local bundle's merged hooks; its next install ships none (#3700)."""
        return self._retire_source_markers(project_root, targets, LocalBundleMarkers(bundle_id))

    def _retire_source_markers(
        self, project_root: Path, excluded_targets, source_markers: frozenset[str], dry_run=False
    ) -> HookTargetReconcileStats:
        stats: HookTargetReconcileStats = {
            "files_removed": 0,
            "errors": 0,
            "failed_targets": [],
            "failed_paths": [],
            "deleted_paths": [],
        }
        for target in excluded_targets:
            config = _MERGE_HOOK_TARGETS.get(target.name)
            if config is None:
                continue
            target_dir = project_root / target.root_dir
            json_path = target_dir / config.config_filename
            errors_before, existed = stats["errors"], json_path.exists()
            self._clean_apm_source_from_json(
                json_path,
                source_markers,
                stats,
                container=config.event_container_key,
                sidecar_path=json_path.parent / _APM_HOOKS_SIDECAR,
                dry_run=dry_run,
                defaults=config.top_level_defaults,
                root=hook_cleanup_root(target, project_root),
            )
            if existed and not dry_run and not json_path.exists():
                stats["deleted_paths"].append(portable_relpath(json_path, project_root))
            if stats["errors"] != errors_before:
                stats["failed_targets"].append(target.name)
                for path in (json_path, json_path.parent / _APM_HOOKS_SIDECAR):
                    stats["failed_paths"].append(portable_relpath(path, project_root))
        return stats

    @staticmethod
    def _clean_apm_source_from_json(
        json_path: Path,
        source_markers: frozenset[str],
        stats: HookTargetReconcileStats,
        *,
        container: str,
        sidecar_path: Path,
        dry_run: bool = False,
        defaults: dict[str, Any] | None = None,
        root: Path | None = None,
    ) -> None:
        """Remove one package owner while preserving user and sibling entries."""
        if not json_path.exists() and not sidecar_path.exists():
            return
        try:
            data = read_hook_object(json_path)
            sidecar_data = read_hook_object(sidecar_path)

            hooks = data.get(container)
            native_modified = False
            if isinstance(hooks, dict):
                if sidecar_data:
                    _reinject_apm_source_from_sidecar(hooks, sidecar_data)
                for event_name in list(hooks):
                    entries = hooks[event_name]
                    if not isinstance(entries, list):
                        continue
                    filtered = [
                        entry
                        for entry in entries
                        if not (
                            isinstance(entry, dict) and entry.get("_apm_source") in source_markers
                        )
                    ]
                    if len(filtered) == len(entries):
                        continue
                    native_modified = True
                    if filtered:
                        hooks[event_name] = filtered
                    else:
                        del hooks[event_name]
                if not hooks:
                    data.pop(container, None)

            sidecar_had_source = any(
                isinstance(entry, dict) and entry.get("_apm_source") in source_markers
                for entries in sidecar_data.values()
                if isinstance(entries, list)
                for entry in entries
            )
            if isinstance(hooks, dict):
                sidecar_out = _extract_apm_source_sidecar(hooks)
            else:
                sidecar_out = {
                    event_name: [
                        entry
                        for entry in entries
                        if not (
                            isinstance(entry, dict) and entry.get("_apm_source") in source_markers
                        )
                    ]
                    for event_name, entries in sidecar_data.items()
                    if isinstance(entries, list)
                }
                sidecar_out = {
                    event_name: entries for event_name, entries in sidecar_out.items() if entries
                }

            if dry_run:
                # Match the config and sidecar writes that a real cleanup would make.
                stats["files_removed"] += int(native_modified) + int(
                    native_modified or sidecar_had_source
                )
                return
            if native_modified:
                if not remove_emptied_hook_file(json_path, data, defaults or {}, root, stats):
                    with provenance.recorded_config_write(json_path, skeleton=defaults or {}):
                        write_seam.atomic_write_text(json_path, json.dumps(data, indent=2) + "\n")
                stats["files_removed"] += 1
            if native_modified or sidecar_had_source:
                if sidecar_out:
                    write_hook_sidecar(sidecar_path, sidecar_out)
                elif sidecar_path.exists():
                    remove_hook_sidecar(sidecar_path)
                stats["files_removed"] += 1
        except (json.JSONDecodeError, OSError, TypeError):
            stats["errors"] += 1

    def sync_integration(
        self,
        apm_package,
        project_root: Path,
        managed_files: set = None,  # noqa: RUF013
        managed_file_hashes: dict[str, str] | None = None,
        targets=None,
        evidence: "DeploymentEvidence | None" = None,
    ) -> dict:
        """Remove APM-managed hook files.

        Uses *managed_files* (relative paths) to surgically remove only
        APM-tracked files; falls back to legacy ``*-apm.json`` glob when
        *managed_files* is ``None``. **Never** calls ``shutil.rmtree``.
        Also cleans ``_apm_source`` entries from merged-hook JSON files.
        ``targets`` (#2250) scopes only the merged-hook JSON cleanup below.
        """
        from .targets import KNOWN_TARGETS

        stats: dict[str, Any] = {"files_removed": 0, "errors": 0}
        guard_targets = list(KNOWN_TARGETS.values())
        if targets is not None:
            guard_targets = guard_targets + list(targets)
        if managed_files is not None:
            from apm_cli.integration.cleanup import (
                consent_outcome,
                managed_hook_prefixes,
                remove_synced_files,
            )

            # Deletion needs deployment evidence; None keeps every file (#3701).
            cleanup = remove_synced_files(
                managed_files,
                project_root,
                prefixes=managed_hook_prefixes(targets),
                dep_key="<uninstall hooks>",
                targets=guard_targets,
                evidence=evidence,
                recorded_hashes=managed_file_hashes,
                allow_final_symlink=True,
            )
            stats["files_removed"] += len(cleanup.deleted)
            retained, unsafe = consent_outcome(cleanup, evidence)
            if retained:
                stats["errors"] += len(retained)
                stats.setdefault("failed_paths", []).extend(retained)
            stats.setdefault("unsafe_paths", []).extend(unsafe)
            self.cleanup_empty_parents(cleanup.deleted_targets, stop_at=project_root)
        else:
            hooks_dir = project_root / ".github" / "hooks"
            if hooks_dir.exists():
                for hook_file in hooks_dir.glob("*-apm.json"):
                    try:
                        write_seam.unlink(hook_file)
                        stats["files_removed"] += 1
                    except Exception:
                        stats["errors"] += 1
                        stats.setdefault("failed_paths", []).append(hook_file.as_posix())

        # Clean APM entries from merged-hook JSON configs, scoped to
        # `targets` when supplied -- matches the rebuild phase (#2250).
        merge_source = targets if targets is not None else list(KNOWN_TARGETS.values())
        for t in merge_source:
            config = _MERGE_HOOK_TARGETS.get(t.name)
            if config is not None:
                json_path = project_root / t.root_dir / config.config_filename
                self._clean_apm_entries_from_json(
                    json_path,
                    stats,
                    container=config.event_container_key,
                    sidecar_path=json_path.parent / _APM_HOOKS_SIDECAR,
                    defaults=config.top_level_defaults,
                    root=hook_cleanup_root(t, project_root),
                )

        return stats

    def reconcile_after_removal(
        self,
        apm_package,
        project_root: Path,
        *,
        user_scope: bool = False,
        lockfile: "LockFile | None" = None,
    ) -> dict:
        """Securely wipe and rebuild merged hooks from installed survivors."""
        from apm_cli.agent_plugins.errors import preflight_reintegration_survivors
        from apm_cli.constants import APM_MODULES_DIR
        from apm_cli.install.package_resolution import effective_dependency_selection
        from apm_cli.install.target_filter import resolve_effective_package_targets
        from apm_cli.integration.hook_reintegration import (
            build_hook_reintegration_source_plan,
            merged_hook_state,
        )
        from apm_cli.models.apm_package import (
            surviving_dependency_refs_for_reintegration,
        )
        from apm_cli.security.executables import closed_exec_map, resolve_project_exec_allow_map

        from .targets import resolve_targets

        # Resolve targets and materialize the dependency list BEFORE the
        # destructive wipe below. If either raises (malformed target
        # config, bad dependency data), we abort with nothing written
        # instead of committing a wipe we can never rebuild from -- a
        # zero-hook window for every still-declared package would
        # otherwise persist until the next `apm install`.
        config_target = list(apm_package.canonical_targets)
        targets = resolve_targets(
            project_root, user_scope=user_scope, explicit_target=config_target or None
        )
        surviving_deps = surviving_dependency_refs_for_reintegration(
            apm_package, project_root, lockfile=lockfile
        )
        survivor_plan = preflight_reintegration_survivors(
            surviving_deps,
            project_root / APM_MODULES_DIR,
            require_valid_installed=True,
        )
        allow_map = (
            resolve_project_exec_allow_map(project_root, apm_package, user_scope=user_scope)
            if survivor_plan
            else closed_exec_map(None)
        )
        rebuild_plan = []
        for dep_ref, pkg_info in survivor_plan:
            target_selection = resolve_effective_package_targets(
                targets,
                effective_dependency_selection(dep_ref).target_subset,
                pkg_info,
                None,
                dep_ref.get_identity(),
            )
            source_plan = build_hook_reintegration_source_plan(
                dep_ref,
                pkg_info,
                list(target_selection.targets),
                allow_map,
            )
            if source_plan.hook_source_selection is not None:
                source_plan.hook_source_selection.require_deployable(pkg_info, _HOOK_EVENT_MAP)
            rebuild_plan.append((dep_ref, pkg_info, target_selection, source_plan))

        # Empty managed_files (not None) skips file-level deletion while
        # still triggering the merged-hook JSON wipe, scoped to the same
        # resolved `targets` the rebuild loop below uses (#2250).
        merged_before = merged_hook_state(project_root, targets)
        stats = self.sync_integration(
            apm_package, project_root, managed_files=set(), targets=targets
        )

        for dep_ref, pkg_info, target_selection, source_plan in rebuild_plan:
            try:
                for target in target_selection.targets:
                    self.integrate_hooks_for_target(
                        target,
                        pkg_info,
                        project_root,
                        user_scope=user_scope,
                        source_plan=source_plan,
                    )
            except Exception as e:
                stats["errors"] = stats.get("errors", 0) + 1
                pkg_id = (
                    dep_ref.get_identity() if hasattr(dep_ref, "get_identity") else str(dep_ref)
                )
                _log.warning("Best-effort hook re-integration skipped for %s: %s", pkg_id, e)

        stats["merged_hooks_changed"] = merged_hook_state(project_root, targets) != merged_before
        return stats

    def reconcile_dropped_targets(
        self,
        project_root: Path,
        dropped_target_names: list[str] | set[str],
        *,
        user_scope: bool = False,
    ) -> dict[str, int]:
        """Reconcile dropped-target merge-hook state; see _hook_dropped_targets (#2253)."""
        from ._hook_dropped_targets import reconcile_dropped_targets as _impl

        return _impl(project_root, dropped_target_names, user_scope=user_scope)

    @staticmethod
    def _clean_apm_entries_from_json(
        json_path: Path,
        stats: dict[str, Any],
        container: str = "hooks",
        sidecar_path: Path | None = None,
        defaults: dict[str, Any] | None = None,
        root: Path | None = None,
    ) -> None:
        """Remove externally-owned entries from a native hooks JSON file.

        Filters out entries with ``_apm_source`` markers and cleans up
        empty event arrays and the *container* key itself.  *container*
        defaults to ``"hooks"``; Antigravity passes ``"apm"`` (its reserved
        hook-name container) so sibling user hook-names are left intact.
        The cleaned file replaces *json_path* atomically, so a linked config
        path becomes a regular file and the link's target is not written.
        """
        if not json_path.exists():
            return
        try:
            with open(json_path, encoding="utf-8") as f:
                data = json.load(f)

            if container not in data:
                if sidecar_path is not None and sidecar_path.exists():
                    remove_hook_sidecar(sidecar_path)
                return

            had_sidecar = sidecar_path is not None and sidecar_path.exists()
            if had_sidecar:
                with open(sidecar_path, encoding="utf-8") as f:
                    sidecar_data = json.load(f)
                if isinstance(sidecar_data, dict):
                    _reinject_apm_source_from_sidecar(data[container], sidecar_data)

            # Local-bundle hooks are not dependency-owned; keep them (#3700).
            modified = drop_dependency_owned_entries(data[container])
            kept = _extract_apm_source_sidecar(data[container]) if had_sidecar else {}
            if not data[container]:
                del data[container]

            if modified and remove_emptied_hook_file(json_path, data, defaults or {}, root, stats):
                stats["files_removed"] += 1
            elif modified:
                with provenance.recorded_config_write(json_path, skeleton=defaults or {}):
                    write_seam.atomic_write_text(json_path, json.dumps(data, indent=2) + "\n")
                stats["files_removed"] += 1
            if kept:
                write_hook_sidecar(sidecar_path, kept)
            elif had_sidecar:
                remove_hook_sidecar(sidecar_path)
        except (json.JSONDecodeError, OSError):
            stats["errors"] += 1
            stats.setdefault("failed_paths", []).append(json_path.as_posix())
