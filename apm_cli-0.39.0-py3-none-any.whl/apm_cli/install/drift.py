"""Drift-detection replay engine for ``apm audit --check drift``.

Reproduces the integration step from the lockfile in an isolated scratch
directory, then diffs the resulting tree against the working project to
surface five kinds of divergence:

* ``modified``     -- a tracked deployed file's content differs.
* ``unmanaged-conflict`` -- a replayed file differs at a destination no lockfile entry claims.
* ``unintegrated`` -- a tracked deployed file is missing from the project.
* ``orphaned``     -- a managed-directory file exists in the project but
  is not present in the scratch replay AND not tracked in the lockfile.
* ``unrecorded``   -- the replay deploys the file and the project has it,
  but no lockfile entry claims it, which exempts it from every
  membership-driven check (issue #2379).

Bare ``apm audit`` keeps the original **cache-only** contract: cached package
contents under ``apm_modules/`` are the source of truth and a miss is reported
instead of auto-fetched. ``apm audit --ci`` can opt into a lock-pinned,
scratch-only self-hydration path so cold-cache CI still evaluates drift
without mutating the checkout.

Design constraints (see ``WIP/drift/06-final-plan.md``):
* Pure read-only against the project tree -- writes go to the scratch
  directory only.  ``ensure_path_within`` guards every write redirection.
* ASCII-only console output (Windows cp1252 safety).
* Normalization strips line-ending differences, BOMs, and the APM
  ``Build ID`` header that legitimately changes on every recompile.
"""

from __future__ import annotations

import atexit
import tempfile
import tracemalloc
from dataclasses import dataclass, replace
from pathlib import Path
from shutil import copytree, rmtree
from typing import TYPE_CHECKING, Any

import click

from apm_cli.core import remediation as _advice
from apm_cli.core.scope import InstallScope, get_source_root, manifest_file
from apm_cli.core.target_detection import (
    read_manifest_target as _read_apm_yml_target,  # noqa: F401 -- compatibility re-export
)
from apm_cli.deps.path_anchoring import (
    build_local_parent_index,
    resolve_local_dep_base,
    resolve_local_dep_dir,
)
from apm_cli.install.audit_target_roots import (
    canvas_deploy_prefixes as _canvas_deploy_prefixes,
)
from apm_cli.install.audit_target_roots import (
    governed_root_dirs as _governed_root_dirs,
)
from apm_cli.install.deployment_plan import finish_replayed_package
from apm_cli.install.drift_records import ReplayRecords, replay_all_live
from apm_cli.install.drift_render import (
    _INLINE_DIFF_BYTE_CAP as _INLINE_DIFF_BYTE_CAP,
)
from apm_cli.install.drift_render import (
    CheckLogger as CheckLogger,
)
from apm_cli.install.drift_render import (
    _inline_diff_for,
)
from apm_cli.install.drift_render import (
    render_drift as render_drift,
)
from apm_cli.install.drift_render import (
    render_drift_json as render_drift_json,
)
from apm_cli.install.drift_render import (
    render_drift_sarif as render_drift_sarif,
)
from apm_cli.install.drift_render import (
    render_drift_text as render_drift_text,
)
from apm_cli.install.drift_replay_support import (  # noqa: F401 -- re-exported for callers
    _clear_path,
    _make_integrators,
    _only_retired_sources_differ,
    _owned_entries_by_source,
    _walk_managed,
)
from apm_cli.install.errors import DirectDependencyError
from apm_cli.install.source_helpers import locked_content_failure, locked_content_mismatch
from apm_cli.utils.console import STATUS_SYMBOLS
from apm_cli.utils.guards import _ReadOnlyProjectGuard

if TYPE_CHECKING:
    from collections.abc import Callable

    from apm_cli.deps.lockfile import LockedDependency, LockFile
    from apm_cli.install.replay_transport import DeclaredTransportIndex


# ---------------------------------------------------------------------------
# Public dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ReplayConfig:
    """Locked configuration for a drift replay run.

    Frozen so callers cannot mutate it mid-replay -- any change requires
    a new instance, which keeps the contract auditable.
    """

    project_root: Path
    lockfile_path: Path
    targets: frozenset[str] | None = None
    cache_only: bool = True
    no_hooks: bool = True
    parallel_downloads: int = 1
    scratch_root: Path | None = None
    modules_root: Path | None = None
    user_scope: bool = False
    # Returns the audit's already-fetched org policy for the replayed gate.
    policy_provider: Callable[[], Any] | None = None
    # Returns the discovery result *policy_provider* routes (records bind to it, #4940).
    policy_fetch: Callable[[], Any] | None = None
    # Serve packages proven by their render record (#4940); False replays all live.
    records: bool = True
    # Cleanup evidence (#3701) also renders targets the lock recorded.
    include_recorded_targets: bool = False
    # Gets (package key, deployed paths, scratch root) right after each render (#5048).
    on_package: Callable[[str, list[str], Path], None] | None = None


@dataclass(frozen=True)
class DriftFinding:
    """A single divergence between the replay scratch tree and the project."""

    path: str
    kind: str
    package: str = ""
    inline_diff: str = ""
    # The drift in a config shared with the user (merged hooks) is only
    # APM-owned entries of packages the current gate no longer deploys:
    # 'apm install' retires them, so it is never a local edit (RA-028).
    owned_entries_only: bool = False


# Errors


class CacheMissError(RuntimeError):
    """Raised when ``cache_only=True`` but a package is not in the cache."""


# ---------------------------------------------------------------------------
# Normalization helpers (operate on bytes; bytes-in / bytes-out)
#
# Re-exported from ``apm_cli.utils.normalization`` so existing callers and
# tests that import ``_strip_build_id`` / ``_normalize`` from this module
# keep working. The implementation lives in ``utils/`` so future callers
# (policy linters, content-scan helpers) can reuse it without importing
# the drift module.
# ---------------------------------------------------------------------------

from apm_cli.utils.normalization import (  # noqa: E402, F401  -- re-exported; tests import helpers from apm_cli.install.drift
    _normalize,
    _normalize_line_endings,
    _strip_bom,
    _strip_build_id,
)

# ---------------------------------------------------------------------------
# Scratch directory lifecycle
# ---------------------------------------------------------------------------


def _assert_scratch_bound(project_root: Path, scratch_root: Path) -> None:
    """Defense-in-depth: a scratch dir must NOT live inside the project tree.

    Prevents the replay engine from accidentally writing into the live
    project (which would defeat the read-only contract).
    """
    project_root = project_root.resolve()
    scratch_root = scratch_root.resolve()
    try:
        scratch_root.relative_to(project_root)
    except ValueError:
        return
    raise RuntimeError(
        f"drift scratch dir {scratch_root!s} is inside project tree "
        f"{project_root!s}; refusing to proceed"
    )


def _make_scratch_root(project_root: Path) -> Path:
    """Allocate a scratch dir outside the project tree, with atexit cleanup."""
    scratch = Path(tempfile.mkdtemp(prefix="apm_drift_"))
    _assert_scratch_bound(project_root, scratch)

    def _cleanup() -> None:
        try:
            rmtree(scratch, ignore_errors=False)
        except OSError as exc:
            click.echo(
                f"{STATUS_SYMBOLS['warning']} failed to clean drift scratch dir {scratch}: {exc}",
                err=True,
            )

    atexit.register(_cleanup)
    return scratch


def _copy_install_tree(source: Path, target: Path) -> None:
    """Clone one materialized package tree into the scratch modules root."""
    _clear_path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    copytree(source, target, symlinks=True)


# ---------------------------------------------------------------------------
# Package materialization
# ---------------------------------------------------------------------------


def _verify_remote_cache_candidate(
    lock_dep: LockedDependency, candidate: Path, lockfile: LockFile | None = None
) -> None:
    """Fail closed when a cached remote dependency is absent or unverifiable."""
    if (
        getattr(lock_dep, "source", None) not in {"local", "registry"}
        and not lock_dep.resolved_commit
    ):
        raise CacheMissError(
            f"cannot replay {lock_dep.repo_url}: lockfile entry has no resolved_commit "
            f"(cache freshness unverifiable). {_advice.REMOTE_DEPENDENCY_UNPINNED.sentence()}"
        )
    if not candidate.exists():
        _ref_label = lock_dep.resolved_commit or lock_dep.version or "unknown"
        raise CacheMissError(
            f"cache miss for {lock_dep.repo_url}@{_ref_label}: "
            f"expected {candidate}; {_advice.REPLAY_CACHE_MISSING.clause()}"
        )
    if lock_dep.resolved_commit:
        from apm_cli.drift import locked_copy_holds_commit

        # One copy-validity owner for install and audit (#3964).
        if not locked_copy_holds_commit(lock_dep, candidate):
            raise CacheMissError(
                f"{candidate} does not hold the locked commit {lock_dep.resolved_commit}; "
                f"{_advice.REPLAY_CACHE_STALE.clause()}"
            )
    if locked_content_mismatch(lock_dep.get_unique_key(), lock_dep, candidate, lockfile=lockfile):
        raise CacheMissError(
            f"{candidate} does not hold the locked content of {lock_dep.get_unique_key()}; "
            f"{_advice.REPLAY_CACHE_CONTENT_STALE.clause()}"
        )


def _materialize_install_path(
    lock_dep: LockedDependency,
    project_root: Path,
    apm_modules_dir: Path,
    cache_only: bool,
    *,
    lockfile: LockFile | None = None,
    parent_index: dict[str, tuple[LockedDependency, ...]] | None = None,
    resolved_cache: dict[str, Path] | None = None,
    live_modules_dir: Path | None = None,
    downloader: Any | None = None,
    registry_resolver: Any | None = None,
    registries: dict[str, str] | None = None,
    declared_transports: DeclaredTransportIndex | None = None,
    local_modules_dir: Path | None = None,
) -> Path:
    """Resolve the on-disk path for a locked dep's package contents.

    Local package images are written under ``local_modules_dir`` (default
    ``apm_modules_dir``); replay passes an ungoverned scratch dir instead.

    For local deps -- contents live at the source directory the install
    resolver anchored on: ``project_root`` for direct (root-declared) deps,
    or the declaring package's directory for transitive ``../sibling`` deps
    (``resolved_by``; see :func:`apm_cli.deps.path_anchoring.resolve_local_dep_dir`).
    ``lockfile`` walks that chain; remote and direct local deps do not use it.
    For remote deps -- contents live at the canonical apm_modules subpath.
    In ``cache_only`` mode the replay reads a verified live cache entry. In
    self-hydrating mode it materializes a scratch-private copy using the lock's
    pinned commit or registry URL/hash, never the mutable manifest ref.

    Raises
    ------
    CacheMissError
        If ``cache_only`` is True and the resolved source path does not
        exist (cold-cache-like: the source is simply not present yet).
    LocalResolutionError
        If a local dep's ``resolved_by`` chain is internally inconsistent
        (missing / ambiguous / non-local / cyclic parent). This is a
        corrupt-lockfile condition and MUST fail loud -- it is not caught
        by the drift gate's cache-miss soft-skip.
    """
    if lock_dep.is_local_source:
        if not lock_dep.local_path and lock_dep.replacement is None:
            raise CacheMissError(f"local dep {lock_dep.repo_url!r} has no local_path in lockfile")
        candidate = resolve_local_dep_dir(
            lock_dep,
            lockfile,
            project_root,
            parent_index=parent_index,
            resolved_cache=resolved_cache,
        )
        if not candidate.exists():
            if lock_dep.replacement is not None:
                from apm_cli.deps.path_anchoring import LocalResolutionError

                raise LocalResolutionError(
                    f"local replacement source missing for {lock_dep.get_unique_key()}: "
                    f"expected {candidate}. Restore the source before auditing."
                )
            raise CacheMissError(
                f"local source missing for {lock_dep.local_path!r}: expected {candidate}"
            )
        from apm_cli.install.phases.local_content import materialize_local_package_for_replay

        # Replay the image install copies, never the raw source tree.
        source_base = resolve_local_dep_base(
            lock_dep, lockfile, project_root, parent_index=parent_index
        )
        return materialize_local_package_for_replay(
            lock_dep.to_dependency_ref(), source_base, local_modules_dir or apm_modules_dir
        )

    dep_ref = lock_dep.to_dependency_ref()
    candidate = dep_ref.get_install_path(apm_modules_dir)
    live_root = live_modules_dir or (project_root / "apm_modules")
    live_candidate = dep_ref.get_install_path(live_root)
    if live_candidate.exists():
        try:
            _verify_remote_cache_candidate(lock_dep, live_candidate, lockfile)
        except CacheMissError:
            if cache_only:
                raise
        else:
            if candidate != live_candidate:
                _copy_install_tree(live_candidate, candidate)
            return candidate
    if cache_only:
        _verify_remote_cache_candidate(lock_dep, live_candidate, lockfile)

    if lock_dep.source == "registry":
        if registry_resolver is None:
            raise CacheMissError(
                f"registry replay unavailable for {lock_dep.repo_url}: no registry resolver configured"
            )
        if not lock_dep.resolved_url or not lock_dep.resolved_hash or not lock_dep.version:
            raise CacheMissError(
                f"cannot replay {lock_dep.repo_url}: lockfile entry is missing "
                "resolved_url/resolved_hash/version"
            )
        from apm_cli.deps.registry.auth import (
            dependency_ref_with_registry_name_from_lockfile,
        )

        download_ref = dependency_ref_with_registry_name_from_lockfile(
            dep_ref,
            registries or {},
            locked_dep=lock_dep,
        )
        package_info = registry_resolver.download_from_lockfile(
            download_ref,
            candidate,
            resolved_url=lock_dep.resolved_url,
            resolved_hash=lock_dep.resolved_hash,
            version=lock_dep.version,
        )
    else:
        if downloader is None:
            raise CacheMissError(f"git replay unavailable for {lock_dep.repo_url}: no downloader")
        from apm_cli.drift import build_download_ref

        if declared_transports is not None:
            dep_ref = declared_transports.apply(lock_dep, dep_ref)
        download_ref = build_download_ref(
            dep_ref,
            lockfile,
            update_refs=False,
            ref_changed=False,
        )
        package_info = downloader.download_package(download_ref, candidate)
        resolved_reference = getattr(package_info, "resolved_reference", None)
        if (
            lock_dep.resolved_commit
            and resolved_reference is not None
            and getattr(resolved_reference, "resolved_commit", None)
            not in {None, lock_dep.resolved_commit}
        ):
            raise CacheMissError(
                f"scratch replay resolved {lock_dep.repo_url} to "
                f"{resolved_reference.resolved_commit}, expected {lock_dep.resolved_commit}"
            )
    key = lock_dep.get_unique_key()
    if locked_content_mismatch(
        key, lock_dep, candidate, lockfile=lockfile, package_info=package_info
    ):
        raise DirectDependencyError(locked_content_failure(key, project_root, lock_dep, candidate))
    return candidate


def _normalize_legacy_local_plugin_for_replay(
    lock_dep: LockedDependency, install_path: Path
) -> Path:
    """Normalize a local legacy plugin only in the scratch replay tree."""
    from apm_cli.agent_plugins.loader import detect_agent_plugin
    from apm_cli.deps.plugin_parser import normalize_plugin_directory
    from apm_cli.models.validation import PackageType, detect_package_type
    from apm_cli.utils.helpers import find_plugin_json

    if lock_dep.package_type == PackageType.AGENT_PLUGIN.value:
        return install_path

    if detect_agent_plugin(install_path) is not None:
        return install_path

    # Install normalizes only what the canonical classifier calls a legacy
    # plugin; an apm.yml package that also ships plugin.json is not one.
    if detect_package_type(install_path)[0] != PackageType.MARKETPLACE_PLUGIN:
        return install_path

    plugin_json = find_plugin_json(install_path)
    if plugin_json is None:
        return install_path

    # install_path is the scratch image from materialize_local_package_for_replay;
    # the canonical loader has already excluded native Agent Plugin inputs.
    normalize_plugin_directory(install_path, plugin_json)
    return install_path


def _build_package_info(
    lock_dep: LockedDependency,
    install_path: Path,
):
    """Construct ``PackageInfo`` with the selected manifest's package identity."""
    from apm_cli.agent_plugins.errors import AgentPluginDeploymentBoundaryError, AgentPluginError
    from apm_cli.bundle.local_bundle import route_agent_plugin_package
    from apm_cli.codex_plugins.manifest import is_codex_compatibility_manifest
    from apm_cli.models.apm_package import (
        APMPackage,
        GitReferenceType,
        PackageInfo,
        ResolvedReference,
    )
    from apm_cli.models.validation import (
        PackageType,
        detect_package_type,
        validate_apm_package,
    )

    resolved_ref = ResolvedReference(
        original_ref=lock_dep.resolved_ref or "locked",
        ref_type=GitReferenceType.BRANCH,
        resolved_commit=lock_dep.resolved_commit or "locked",
        ref_name=lock_dep.resolved_ref or "locked",
    )

    try:
        native_detection = route_agent_plugin_package(install_path)
    except AgentPluginError as exc:
        raise AgentPluginDeploymentBoundaryError(str(exc)) from exc

    codex_native = False
    if native_detection is None:
        detected_type, selected_manifest = detect_package_type(install_path)
        codex_native = is_codex_compatibility_manifest(install_path, selected_manifest)
    if native_detection is not None or codex_native:
        validation = validate_apm_package(
            install_path,
            agent_plugin_detection=native_detection,
            read_only=True,
        )
        if not validation.is_valid or validation.package is None:
            raise AgentPluginDeploymentBoundaryError(
                "; ".join(validation.errors) or "Agent Plugin validation produced no package"
            )
        pkg = validation.package
        package_type = validation.package_type
    else:
        apm_yml = manifest_file(install_path)
        pkg = None
        if apm_yml.exists():
            try:
                # Replay reads config; it never creates it (dry-run and audit stay read-only).
                pkg = APMPackage.from_apm_yml(
                    apm_yml, source_path=install_path, create_config=False
                )
            except Exception:
                if lock_dep.replacement is not None:
                    raise
                pkg = None
        if pkg is None:
            pkg = APMPackage(
                name=install_path.name,
                version=lock_dep.version or "unknown",
                package_path=install_path,
                source=lock_dep.repo_url,
            )
        try:
            package_type = PackageType(lock_dep.package_type or detected_type.value)
        except Exception:
            package_type = None
    if not pkg.source:
        pkg.source = lock_dep.repo_url

    return PackageInfo(
        package=pkg,
        install_path=install_path,
        resolved_reference=resolved_ref,
        dependency_ref=lock_dep.to_dependency_ref(),
        package_type=package_type,
    )


def _filter_targets(all_targets, names: frozenset[str] | None):
    """Restrict resolved targets to the explicit allowlist when provided."""
    if not names:
        return all_targets
    return [t for t in all_targets if t.name in names]


def run_replay(config: ReplayConfig, logger: CheckLogger) -> Path:
    """Execute the scratch replay and return the populated scratch dir.

    ``config.records`` lets packages proven by their render record be served
    (``install/drift_records.py``); ``False`` replays every package live.

    The scratch directory is registered for atexit cleanup so callers do
    not need to manage its lifetime.

    Raises
    ------
    CacheMissError
        Surfaced verbatim when a locked dep cannot be materialized.
    """
    from apm_cli.claude_plugins.registrar import verify_claude_native_cache
    from apm_cli.deps.lockfile import _SELF_KEY, LockFile
    from apm_cli.install.audit_target_roots import replay_deployment_frame, replay_targets
    from apm_cli.install.native_plugin_admission import verify_native_plugin_cache
    from apm_cli.install.package_resolution import effective_dependency_selection
    from apm_cli.install.phases.local_content import (
        _project_has_root_primitives,
        _root_holds_only_hook_primitives,
    )
    from apm_cli.install.project_package import build_project_local_package_info
    from apm_cli.install.services import IntegratorBundle, integrate_package_primitives
    from apm_cli.integration.targets import resolve_audit_targets
    from apm_cli.utils.diagnostics import DiagnosticCollector

    if not config.lockfile_path.exists():
        raise CacheMissError(
            f"lockfile not found at {config.lockfile_path}; {_advice.LOCKFILE_MISSING.clause()}"
        )

    lock = LockFile.read(config.lockfile_path)
    if lock is None:
        raise CacheMissError(f"lockfile at {config.lockfile_path} is empty or unreadable")

    project_root = config.project_root.resolve()
    self_source_root = get_source_root(InstallScope.USER) if config.user_scope else project_root
    replays_root = (
        _root_holds_only_hook_primitives(self_source_root)
        if config.user_scope
        else _project_has_root_primitives(project_root)
    )
    if _SELF_KEY not in lock.dependencies and replays_root:
        # Install integrates root .apm/ content whenever the directory exists,
        # even when it only merges hooks into shared configs and so records no
        # local_deployed_files (#3369). Replay the same root package in memory.
        # At user scope only a hooks-only ~/.apm qualifies (#4837).
        lock.dependencies[_SELF_KEY] = lock.project_self_entry()
    scratch_root = (
        config.scratch_root.resolve()
        if config.scratch_root is not None
        else _make_scratch_root(project_root)
    )
    _assert_scratch_bound(project_root, scratch_root)
    logger.scratch_root(scratch_root)
    apm_modules_dir = (
        config.modules_root.resolve()
        if config.modules_root is not None
        else project_root / "apm_modules"
    )
    live_modules_dir = project_root / "apm_modules"
    deployment_modules_dir, deployment_frame = replay_deployment_frame(
        scratch_root, project_root, user_scope=config.user_scope
    )
    codex_records = None

    converged_targets = _filter_targets(
        resolve_audit_targets(
            project_root,
            user_scope=config.user_scope,
            lockfile=lock,
            include_recorded=config.include_recorded_targets,
            recorded_layout=False,
        ),
        config.targets,
    )
    targets = replay_targets(converged_targets, lock=lock)
    from apm_cli.install.replay_transport import replay_sources

    downloader, registry_resolver, registries, declared_transports = replay_sources(
        config.cache_only, project_root, apm_modules_dir
    )
    if downloader is not None:
        from apm_cli.cache.git_cache import attach_persistent_git_cache

        attach_persistent_git_cache(downloader, read_only=True)

    diagnostics = DiagnosticCollector(verbose=logger.verbose)
    integrators = _make_integrators()
    if config.user_scope:
        # Scratch writes, but hook commands name the live user root install -g wrote.
        integrators["hook"].replay_command_root = deployment_frame[1]

    # Pre-create target root dirs in scratch so integrators with
    # auto_create=False do not skip non-skill primitives during replay.
    # During a real install, these directories already exist in the project;
    # in the scratch replay they must be seeded explicitly.
    for _target in targets:
        _scratch_target_root = scratch_root / _target.root_dir
        _scratch_target_root.mkdir(parents=True, exist_ok=True)

    # Defense-in-depth: snapshot every file under a governed root and
    # under apm.lock.yaml, then assert no mutation on exit. The primary
    # write-redirect is ``scratch_root=scratch_root`` threaded into every
    # integrator; this guard catches accidental direct-path writes that
    # bypass the redirect (e.g. an integrator that hard-codes
    # ``project_root / target.root_dir``). See guards.py for semantics.
    governed = _governed_root_dirs(targets)
    protected_subpaths = [*sorted(governed), "apm.lock.yaml", "AGENTS.md"]

    snapshot_started = False
    if logger.verbose:
        try:
            tracemalloc.start()
            snapshot_started = True
        except RuntimeError:
            snapshot_started = False

    logger.replay_start()
    replayed_count = 0
    from apm_cli.install.exec_gate import ReplayExecAllowMap

    served = ReplayRecords.for_replay(
        config, project_root, lock, targets, integrators, scratch_root, enabled=config.records
    )
    # The records' discovery and the executables gate share one policy fetch.
    config = served.config
    gated_allow_map = ReplayExecAllowMap(
        project_root, config.policy_provider, user_scope=config.user_scope
    )
    local_parent_index = build_local_parent_index(lock)
    local_resolved_cache: dict[str, Path] = {}
    from apm_cli.agent_plugins.errors import AgentPluginTargetExcludedError
    from apm_cli.copilot_plugins.capability import native_registration_scope
    from apm_cli.integration import config_file_provenance

    try:
        with native_registration_scope(targets):
            with (
                integrators["skill"].ownership_snapshot(replay_lockfile=lock),
                _ReadOnlyProjectGuard(project_root, protected_subpaths),
                config_file_provenance.replay_render(),
            ):
                for lock_dep in lock.get_all_dependencies():
                    if lock_dep.local_path == _SELF_KEY:
                        # Synthesized self-entry: the root's own local content,
                        # read where install reads it (#3772: $HOME at user scope).
                        install_path = self_source_root
                    else:
                        install_path = _materialize_install_path(
                            lock_dep,
                            project_root,
                            apm_modules_dir,
                            cache_only=config.cache_only,
                            lockfile=lock,
                            parent_index=local_parent_index,
                            resolved_cache=local_resolved_cache,
                            live_modules_dir=live_modules_dir,
                            downloader=downloader,
                            registry_resolver=registry_resolver,
                            registries=registries,
                            declared_transports=declared_transports,
                            local_modules_dir=scratch_root / "apm_modules",
                        )
                        if declared_transports is not None:
                            declared_transports.record_package(install_path, lock_dep)
                        if lock_dep.is_local_source:
                            install_path = _normalize_legacy_local_plugin_for_replay(
                                lock_dep, install_path
                            )

                    if lock_dep.local_path == _SELF_KEY:
                        package_info = build_project_local_package_info(install_path)
                        package_info.root_local_project_root = self_source_root
                        # The root package deploys from where install read it;
                        # its links render in the live frame like any dependency
                        # (#4832: a user-root context link from ~/.apm).
                        package_info.deployment_package_root = self_source_root
                    else:
                        package_info = _build_package_info(lock_dep, install_path)
                        package_info.deployment_package_root = (
                            lock_dep.to_dependency_ref().get_install_path(deployment_modules_dir)
                        )
                    package_info.deployment_frame = deployment_frame
                    package_info.replay_recorded_files = frozenset(lock_dep.deployed_files)
                    dep_key = lock_dep.get_unique_key()

                    # Replay deploys the locked selection, as uninstall does (#3760).
                    selection = effective_dependency_selection(package_info.dependency_ref)
                    if served.serve(lock_dep, install_path, package_info, selection):
                        continue
                    # Withhold what the install gate withheld (#3924) or would
                    # now withhold after a deny no install reconciled (#3958).
                    replay_allow = gated_allow_map.for_dependency(lock_dep, package_info)
                    try:
                        result = integrate_package_primitives(
                            package_info,
                            scratch_root,
                            # Each dependency replays in the skill layout its claims record (#5092).
                            targets=replay_targets(
                                converged_targets, recorded_paths=lock_dep.deployed_files
                            ),
                            integrators=IntegratorBundle(
                                prompt=integrators["prompt"],
                                agent=integrators["agent"],
                                skill=integrators["skill"],
                                instruction=integrators["instruction"],
                                command=integrators["command"],
                                hook=integrators["hook"],
                            ),
                            force=True,
                            managed_files=set(),
                            diagnostics=diagnostics,
                            package_name=dep_key,
                            logger=None,
                            scope=None,
                            native_claude_user_scope=config.user_scope,
                            skill_subset=selection.skill_subset,
                            skill_pairing=selection.skill_pairing,
                            ctx=None,
                            scratch_root=scratch_root,
                            # Honor per-dependency 'targets:' narrowing from apm.yml so the
                            # replay does not write to targets excluded by the consumer (#1923).
                            dep_target_subset=selection.target_subset,
                            allow_executables=replay_allow,
                        )
                    except AgentPluginTargetExcludedError:
                        continue
                    finish_replayed_package(
                        result,
                        lock_dep,
                        (dep_key, deployment_frame[1], scratch_root),
                        config,
                        converged_targets,
                    )
                    if result.get("native_plugin") and not result.get("native_claude_plugin"):
                        verify_native_plugin_cache(
                            lock_dep,
                            install_path,
                            # The materialized replay image, not the link frame (#3901).
                            replay_path=install_path,
                            live_modules=live_modules_dir,
                            scratch_root=scratch_root,
                        )
                        if identity := result.get("codex_source_identity"):
                            from apm_cli.codex_plugins.registrar import verify_codex_source_identity

                            candidate = lock_dep.to_dependency_ref().get_install_path(
                                live_modules_dir
                            )
                            codex_records = verify_codex_source_identity(
                                live_modules_dir,
                                candidate=candidate if candidate.exists() else install_path,
                                records=codex_records,
                                **identity,
                            )
                    if result.get("native_plugin") and lock_dep.native_plugin is not None:
                        verify_claude_native_cache(
                            modules_dir=live_modules_dir, locked=lock_dep, source_root=install_path
                        )
                    replayed_count += 1
    finally:
        if snapshot_started:
            try:
                _, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                click.echo(
                    f"{STATUS_SYMBOLS['info']} drift replay peak memory: "
                    f"{peak / (1024 * 1024):.2f} MB",
                    err=True,
                )
            except RuntimeError:
                pass

    if not served.finish(logger, replayed_count):
        # A live package rendered onto a served destination: replay all live.
        return replay_all_live(replace(config, records=False), logger, scratch_root, run_replay)
    return scratch_root


# Diff engine


def _collect_tracked_files(lockfile: LockFile) -> dict[str, str]:
    """Return scanner membership claims as ``{path: package_owner}``."""
    from apm_cli.core.deployment_ledger import DeploymentLedgerCodec

    return DeploymentLedgerCodec.legacy_deployed_file_claims(lockfile)


def _collect_hashed_files(lockfile: LockFile) -> set[str]:
    """Return every deployed path whose lock claim is explicitly file-shaped."""
    from apm_cli.core.deployment_ledger import DeploymentLedgerCodec

    return set(DeploymentLedgerCodec.legacy_deployed_file_hash_paths(lockfile))


def diff_scratch_against_project(
    scratch_root: Path,
    project_root: Path,
    lockfile: LockFile,
    targets,
    *,
    tracked_files: frozenset[str] | None = None,
    absolute_claims_only: bool = False,
    governed_roots: set[str] | None = None,
) -> list[DriftFinding]:
    """Compare the replay scratch tree against the project tree.

    Five kinds of findings are emitted:

    * ``modified``     -- file exists in both, normalized content differs.
    * ``unmanaged-conflict`` -- a replayed file differs from (or is shadowed
      by a case-only variant of) a file no lockfile entry claims: install
      skipped a user-authored file, so it is never a managed local edit.
    * ``unintegrated`` -- file exists in scratch but not in project, and the
      path is part of the committed working tree when git tracking is known.
    * ``orphaned``     -- file exists in project + tracked in lockfile
      ``deployed_files`` but no longer in scratch.
    * ``unrecorded``   -- the replay deploys the file and the project has it,
      but no lockfile entry claims it: the committed manifest under-records.

    ``unrecorded`` is the mirror image of ``orphaned``. Both are membership
    findings, and between them they make manifest membership symmetric:
    ``orphaned`` catches a claim with nothing behind it, ``unrecorded``
    catches a deployed file with no claim in front of it. The latter matters
    because manifest membership defines the scope of every downstream
    lockfile-driven gate -- ``content-integrity`` hashes and Unicode-scans
    exactly the recorded set, so a file missing from it is exempt from those
    checks for as long as it stays missing (issue #2379).

    Untracked extra files in governed directories that the replay does NOT
    produce are still ignored -- those are user-authored content, and APM
    deploying the file is what makes a missing claim a defect. Hook merge
    targets are exempt for the same reason in reverse: APM writes into them
    but shares them with the user, so it never claims them.
    """
    scratch_root = scratch_root.resolve()
    project_root = project_root.resolve()
    governed = governed_roots if governed_roots is not None else _governed_root_dirs(targets)
    scratch_files = _walk_managed(scratch_root, governed)
    project_files = _walk_managed(project_root, governed)
    # Hook merge targets are shared with the user and never claimed in
    # deployed_files, so they can never be "unrecorded". Their APM-owned slice
    # is compared through hook_ownership; sidecars compare all owned content
    # while ignoring JSON object-key ordering from the live merge.
    from apm_cli.install.manifest_reconcile import merge_hook_config_projection_specs
    from apm_cli.integration.hook_ownership import apm_owned_hook_entries_remain

    merge_config_specs = merge_hook_config_projection_specs(targets)
    merge_sidecar_paths = {sidecar_path for sidecar_path, _ in merge_config_specs.values()}
    from apm_cli.install.drift_claims import ReplayClaims

    claims = ReplayClaims.build(
        _collect_tracked_files(lockfile),
        _collect_hashed_files(lockfile),
        project_root,
        project_files,
        targets=tuple(targets),
        absolute_only=absolute_claims_only,
        shared=set(merge_config_specs) | merge_sidecar_paths,
    )
    tracked = claims.tracked

    # Imperative local bundles have no authored source tree for replay. Their
    # deployed bytes are already bound by local_deployed_file_hashes and the
    # policy/ci_checks.py::_check_content_integrity check, so comparing them to
    # an empty scratch projection would misclassify every clean bundle file as
    # orphaned.
    from apm_cli.core.deployment_ledger import DeploymentLedgerCodec

    local_bundle_paths = DeploymentLedgerCodec.local_bundle_paths(lockfile)
    # An absolute claim under an external target root ($CODEX_HOME) is compared
    # rebased onto that root, as its tracked claim is (#3714).
    local_bundle_paths |= ReplayClaims.rebased(
        local_bundle_paths, project_root, targets=tuple(targets), absolute_only=absolute_claims_only
    )
    if local_bundle_paths:
        scratch_files = {
            relative_path: path
            for relative_path, path in scratch_files.items()
            if relative_path not in local_bundle_paths
        }
        project_files = {
            relative_path: path
            for relative_path, path in project_files.items()
            if relative_path not in local_bundle_paths
        }

    # Canvas extensions are executable bundles that the drift replay does
    # not re-integrate (their integrator is intentionally omitted from the
    # replay bundle). Exclude their deploy prefixes from BOTH trees so a
    # deployed canvas is never mis-reported as orphaned/unintegrated. Full
    # canvas drift detection is a deferred follow-up.
    _canvas_prefixes = _canvas_deploy_prefixes(targets)
    if _canvas_prefixes:

        def _is_canvas(rel: str) -> bool:
            norm = rel.replace("\\", "/")
            return any(norm.startswith(p) for p in _canvas_prefixes)

        scratch_files = {r: p for r, p in scratch_files.items() if not _is_canvas(r)}
        project_files = {r: p for r, p in project_files.items() if not _is_canvas(r)}

    findings: list[DriftFinding] = []
    from apm_cli.integration.base_integrator import BaseIntegrator
    from apm_cli.utils.diagnostics import DiagnosticCollector

    collision_diagnostics = DiagnosticCollector()
    managed = set(tracked)
    skill_roots = [
        target.skills_deploy_path(project_root) for target in targets if target.supports("skills")
    ]

    for rel, scratch_path in sorted(scratch_files.items()):
        project_path = project_files.get(rel)
        if project_path is None:
            # A case-only variant occupies the destination on a
            # case-insensitive filesystem: install skipped it as user-authored.
            if claims.unclaimed(rel) and (project_root / rel).is_file():
                findings.append(DriftFinding(path=rel, kind="unmanaged-conflict", package=""))
                continue
            if tracked_files is not None and rel not in tracked_files:
                continue
            findings.append(
                DriftFinding(
                    path=rel,
                    kind="unintegrated",
                    package=tracked.get(rel, ""),
                )
            )
            continue
        unmanaged_skill = any(project_path.is_relative_to(root) for root in skill_roots) and (
            BaseIntegrator.check_collision(
                project_path, rel, managed, False, diagnostics=collision_diagnostics
            )
        )
        unmanaged = unmanaged_skill or claims.unclaimed(rel)
        try:
            s_bytes = _normalize(scratch_path.read_bytes())
            p_bytes = _normalize(project_path.read_bytes())
            if projection_spec := merge_config_specs.get(rel):
                from apm_cli.integration.hook_ownership import project_apm_owned_hook_entries

                sidecar_rel, event_container_key = projection_spec
                s_bytes = project_apm_owned_hook_entries(
                    s_bytes,
                    _normalize((scratch_root / sidecar_rel).read_bytes()),
                    event_container_key,
                )
                p_bytes = project_apm_owned_hook_entries(
                    p_bytes,
                    _normalize((project_root / sidecar_rel).read_bytes()),
                    event_container_key,
                )
            elif rel in merge_sidecar_paths:
                from apm_cli.integration.hook_ownership import canonicalize_hook_sidecar

                s_bytes = canonicalize_hook_sidecar(s_bytes)
                p_bytes = canonicalize_hook_sidecar(p_bytes)
        except (OSError, ValueError) as exc:
            findings.append(
                DriftFinding(
                    path=rel,
                    kind="unmanaged-conflict" if unmanaged else "modified",
                    package=tracked.get(rel, ""),
                    inline_diff=f"(read error: {exc})",
                )
            )
            continue
        if s_bytes != p_bytes or (
            unmanaged_skill
            and not BaseIntegrator.is_content_identical_to_source(project_path, scratch_path)
        ):
            findings.append(
                DriftFinding(
                    path=rel,
                    kind="unmanaged-conflict" if unmanaged else "modified",
                    package=tracked.get(rel, ""),
                    inline_diff=_inline_diff_for(scratch_path, project_path),
                    owned_entries_only=not unmanaged
                    and (projection_spec is not None or rel in merge_sidecar_paths)
                    and _only_retired_sources_differ(s_bytes, p_bytes),
                )
            )
        elif claims.unclaimed(rel):
            # Content agrees, so nothing else in the audit will ever look at
            # this file again: no manifest entry means no hash baseline and no
            # Unicode scan. Reported only in the content-clean case -- when the
            # bytes differ, a content or ownership finding already reports
            # the failure with its appropriate remedy.
            findings.append(DriftFinding(path=rel, kind="unrecorded", package=""))

    for rel in sorted(project_files.keys()):
        if rel in scratch_files:
            continue
        if rel in tracked:
            findings.append(
                DriftFinding(
                    path=rel,
                    kind="orphaned",
                    package=tracked.get(rel, ""),
                )
            )
        elif (spec := merge_config_specs.get(rel)) and apm_owned_hook_entries_remain(
            project_root / rel, project_root / spec[0], spec[1]
        ):
            # Replay deploys no hooks here, yet APM-owned entries remain (#3924).
            findings.append(
                DriftFinding(path=rel, kind="modified", package="", owned_entries_only=True)
            )
        # else: untracked governed file -- ignore (user authored).

    if local_bundle_paths:
        # A local bundle has no replay source: its locked hashes are the
        # baseline. Plain audit and --ci read them through the one verifier
        # content-integrity and --frozen use (req-lk-017), so both agree.
        from apm_cli.policy.ci_checks import verify_deployed_file_hashes

        drifted, _unresolved = verify_deployed_file_hashes(project_root, lockfile, targets)
        findings.extend(
            DriftFinding(path=item.path, kind="modified", package=item.owner)
            for item in drifted
            if item.path in local_bundle_paths
        )

    return findings
