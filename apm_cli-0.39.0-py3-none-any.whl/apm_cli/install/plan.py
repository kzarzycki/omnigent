"""Update plan: structured diff between current lockfile and fresh resolution.

This module is the support library for the ``apm update`` command (#1203).
It also provides the structural-satisfaction check used by
``apm install --frozen``.

Two responsibilities:

1. ``build_update_plan`` -- pure comparison of an old :class:`LockFile`
   against a list of freshly-resolved :class:`DependencyReference`
   objects (post-resolve, pre-download).  Produces an
   :class:`UpdatePlan` of immutable :class:`PlanEntry` records, each
   capturing one dependency's before/after state.

2. ``render_plan_text`` -- ASCII rendering of an :class:`UpdatePlan`
   suitable for terminal display, using the bracket-status convention
   from ``.github/instructions/encoding.instructions.md``.

3. ``lockfile_satisfies_manifest`` -- structural check: does a lockfile
   carry an entry for every direct dependency declared in the manifest?
   Used to enforce ``--frozen`` without running the resolve phase.

Design notes
------------
* No I/O.  No network.  Every function in this module is pure --
  testable in isolation by feeding fixture lockfiles and dep lists.
* Frozen dataclasses (``PlanEntry``, ``UpdatePlan``) so callers can
  freely pass them across phase boundaries without aliasing risk.
* The ``deployed_files`` shown in a plan entry are taken from the
  EXISTING lockfile (i.e. what is currently on disk).  We do not yet
  know the post-update file list at the plan checkpoint, since
  integration has not run.  Showing the "files at risk" surface is
  honest enough for P0; a richer post-download diff is a P1+
  enhancement.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from apm_cli.utils.console import STATUS_SYMBOLS

if TYPE_CHECKING:
    from collections.abc import Iterable

    from apm_cli.deps.lockfile import LockedDependency, LockFile
    from apm_cli.models.apm_package import APMPackage
    from apm_cli.models.dependency.reference import DependencyReference
    from apm_cli.models.dependency.replacement import ReplacementRule


_ACTION_UPDATE = "update"
_ACTION_ADD = "add"
_ACTION_REMOVE = "remove"
_ACTION_UNCHANGED = "unchanged"


def lockfile_satisfies_replacements(
    lockfile: LockFile | None,
    rules: list[ReplacementRule] | None,
) -> tuple[bool, list[str]]:
    """Compare the complete root replacement intent without accessing sources."""
    from apm_cli.models.dependency.replacement import (
        ReplacementConfigError,
        build_replacement_index,
        replacement_rules_from_dicts,
    )

    if lockfile is None:
        return (
            (True, []) if rules is None else (False, ["  - replacement declaration is not locked"])
        )
    if rules is None and lockfile.replacements is None:
        return True, []
    if rules is None or lockfile.replacements is None:
        return False, ["  - replacement declaration differs from apm.lock.yaml"]
    try:
        locked_rules = replacement_rules_from_dicts(lockfile.replacements)
        build_replacement_index(locked_rules)
    except ReplacementConfigError as exc:
        return False, [f"  - locked replacement table is invalid: {exc}"]
    if frozenset(rules) != frozenset(locked_rules):
        return False, ["  - replacement rules differ from apm.lock.yaml"]
    return True, []


def _dep_ref_key(dep: DependencyReference) -> str:
    """Compute the lockfile-compatible unique key for a manifest dependency.

    Delegates to the same identity function as
    :meth:`LockedDependency.get_unique_key` so that manifest and lockfile
    entries can be matched 1:1 without round-tripping through a full
    resolution.  Non-default git hosts must be part of this key, because
    lockfile entries use host-qualified identity for those repos.
    """
    get_unique_key = getattr(dep, "get_unique_key", None)
    if callable(get_unique_key):
        return get_unique_key()

    from apm_cli.models.dependency.identity import build_dependency_unique_key

    # Test fakes in the integration suite are intentionally lightweight.
    # Keep this mapping in sync with DependencyReference.get_unique_key().
    return build_dependency_unique_key(
        getattr(dep, "repo_url", ""),
        host=getattr(dep, "host", None),
        port=getattr(dep, "port", None),
        source="local" if getattr(dep, "is_local", False) else getattr(dep, "source", None),
        local_path=getattr(dep, "local_path", None),
        is_virtual=getattr(dep, "is_virtual", False),
        virtual_path=getattr(dep, "virtual_path", None),
        registry_prefix=getattr(dep, "artifactory_prefix", None),
    )


def _short_sha(commit: str | None, length: int = 7) -> str:
    """Render a commit SHA (or placeholder) in short form.

    Returns ``-`` when no commit is available, so the diff shows a
    visible delta even on the "before" or "after" side of an
    add / remove entry.
    """
    if not commit:
        return "-"
    return commit[:length]


@dataclass(frozen=True)
class PlanEntry:
    """One dependency's before/after state in an :class:`UpdatePlan`.

    ``action`` is one of ``"update"``, ``"add"``, ``"remove"``, or
    ``"unchanged"`` -- mutually exclusive.  Callers should use the
    ``has_changes`` property rather than comparing strings.

    ``deployed_files`` reflects the existing lockfile only -- see module
    docstring for rationale.
    """

    dep_key: str
    action: str
    display_name: str = ""

    old_resolved_ref: str | None = None
    old_resolved_commit: str | None = None
    old_content_hash: str | None = None

    new_resolved_ref: str | None = None
    new_resolved_commit: str | None = None
    new_content_hash: str | None = None

    deployed_files: tuple[str, ...] = ()

    @property
    def has_changes(self) -> bool:
        return self.action != _ACTION_UNCHANGED

    @property
    def short_old_commit(self) -> str:
        return _short_sha(self.old_resolved_commit)

    @property
    def short_new_commit(self) -> str:
        return _short_sha(self.new_resolved_commit)


@dataclass(frozen=True)
class UpdatePlan:
    """Structured diff between current lockfile and a fresh resolution."""

    entries: tuple[PlanEntry, ...] = ()

    @property
    def has_changes(self) -> bool:
        return any(e.has_changes for e in self.entries)

    @property
    def changed_entries(self) -> tuple[PlanEntry, ...]:
        return tuple(e for e in self.entries if e.has_changes)

    def excluding(self, dep_keys: Iterable[str]) -> UpdatePlan:
        """Return the plan without *dep_keys* (shown elsewhere, e.g. as pin rewrites)."""
        skip = frozenset(dep_keys)
        return UpdatePlan(entries=tuple(e for e in self.entries if e.dep_key not in skip))

    @property
    def summary_counts(self) -> dict[str, int]:
        counts = {
            _ACTION_UPDATE: 0,
            _ACTION_ADD: 0,
            _ACTION_REMOVE: 0,
            _ACTION_UNCHANGED: 0,
        }
        for e in self.entries:
            counts[e.action] = counts.get(e.action, 0) + 1
        return counts


def _display_name(dep_key: str, locked: LockedDependency | None) -> str:
    """Pick a short, human-friendly label for a dep entry.

    Prefers ``repo_url`` (with ``virtual_path`` suffix when present)
    from the locked record, since the manifest reference may be a bare
    shorthand without the resolved host.
    """
    if locked is not None:
        name = locked.repo_url
        if getattr(locked, "virtual_path", None):
            name = f"{name}/{locked.virtual_path}"
        return name
    return dep_key


def build_update_plan(
    old_lockfile: LockFile | None,
    resolved_deps: Iterable[DependencyReference],
    *,
    complete_resolved_dep_keys: Iterable[str] | None = None,
    resolved_content_hashes: dict[str, str] | None = None,
) -> UpdatePlan:
    """Compare an existing lockfile against freshly-resolved deps.

    Args:
        old_lockfile: Current on-disk lockfile, or None when the project
            has never been installed before.
        resolved_deps: Output of the resolve phase -- each
            ``DependencyReference`` carries a ``resolved_reference``
            populated by the resolver.  Typically
            ``InstallContext.deps_to_install``.
        complete_resolved_dep_keys: Optional dep keys from the complete
            post-update dependency graph before selective-update filtering.
            When present, locked entries missing from ``resolved_deps`` but
            still present in this set are retained as unchanged instead of
            being reported as removals.

    Returns:
        A frozen :class:`UpdatePlan` summarising the diff.
    """
    old_entries: dict[str, LockedDependency] = {}
    if old_lockfile is not None:
        from apm_cli.deps.lockfile import _SELF_KEY

        old_entries = {
            key: dep for key, dep in old_lockfile.dependencies.items() if key != _SELF_KEY
        }

    seen_keys: set[str] = set()
    plan_entries: list[PlanEntry] = []
    complete_key_set = (
        set(complete_resolved_dep_keys) if complete_resolved_dep_keys is not None else None
    )

    for dep in resolved_deps:
        key = _dep_ref_key(dep)
        seen_keys.add(key)
        old = old_entries.get(key)
        new_hash = (resolved_content_hashes or {}).get(key)
        same_source = old is not None and old.matches_replacement(dep)
        new_ref, new_commit = _extract_new_ref_and_commit(dep)
        new_ref = _recorded_ref(dep, old, new_ref)
        # Unannotated registry dep (cached, not re-downloaded): no concrete
        # version was resolved this run, so treat the locked value as current.
        # Require the locked entry to also be registry-sourced -- otherwise a
        # dep that transitions sources (e.g. git -> registry) while keeping the
        # same key would be masked as unchanged.
        if (
            new_ref is None
            and old is not None
            and getattr(dep, "source", None) == "registry"
            and old.source == "registry"
        ):
            new_ref = old.resolved_ref

        # Cached git-semver dep at its locked tag: the resolver rewrote
        # ``dep.reference`` but did not attach the resolved SHA to
        # ``dep.resolved_reference``, so ``new_commit`` is None. If the ref still
        # matches a tag-pinned lock entry, borrow its locked SHA, which remains
        # the integrity anchor. ``resolved_tag`` distinguishes tag resolutions
        # from movable branches, whose freshly resolved SHAs must remain visible.
        if (
            new_commit is None
            and old is not None
            and same_source
            and getattr(old, "resolved_tag", None)
            and new_ref == old.resolved_ref
        ):
            new_commit = old.resolved_commit

        if old is None:
            plan_entries.append(
                PlanEntry(
                    dep_key=key,
                    action=_ACTION_ADD,
                    display_name=_display_name(key, None) or dep.repo_url,
                    new_resolved_ref=new_ref,
                    new_resolved_commit=new_commit,
                    new_content_hash=new_hash,
                )
            )
            continue

        old_ref = old.resolved_ref
        old_commit = old.resolved_commit
        deployed = tuple(old.deployed_files)

        if (
            same_source
            and (old_commit or None) == (new_commit or None)
            and (old_ref or None) == (new_ref or None)
            and (new_hash is None or new_hash == old.content_hash)
        ):
            plan_entries.append(
                PlanEntry(
                    dep_key=key,
                    action=_ACTION_UNCHANGED,
                    display_name=_display_name(key, old),
                    old_resolved_ref=old_ref,
                    old_resolved_commit=old_commit,
                    old_content_hash=old.content_hash,
                    new_resolved_ref=new_ref,
                    new_resolved_commit=new_commit,
                    new_content_hash=new_hash,
                    deployed_files=deployed,
                )
            )
            continue

        plan_entries.append(
            PlanEntry(
                dep_key=key,
                action=_ACTION_UPDATE,
                display_name=_display_name(key, old),
                old_resolved_ref=old_ref,
                old_resolved_commit=old_commit,
                old_content_hash=old.content_hash,
                new_resolved_ref=new_ref,
                new_resolved_commit=new_commit,
                new_content_hash=new_hash,
                deployed_files=deployed,
            )
        )

    for key, old in old_entries.items():
        if key in seen_keys:
            continue
        if complete_key_set is not None and key in complete_key_set:
            plan_entries.append(
                PlanEntry(
                    dep_key=key,
                    action=_ACTION_UNCHANGED,
                    display_name=_display_name(key, old),
                    old_resolved_ref=old.resolved_ref,
                    old_resolved_commit=old.resolved_commit,
                    old_content_hash=old.content_hash,
                    new_resolved_ref=old.resolved_ref,
                    new_resolved_commit=old.resolved_commit,
                    deployed_files=tuple(old.deployed_files),
                )
            )
            continue
        plan_entries.append(
            PlanEntry(
                dep_key=key,
                action=_ACTION_REMOVE,
                display_name=_display_name(key, old),
                old_resolved_ref=old.resolved_ref,
                old_resolved_commit=old.resolved_commit,
                old_content_hash=old.content_hash,
                deployed_files=tuple(old.deployed_files),
            )
        )

    plan_entries.sort(key=lambda e: (_ACTION_ORDER.get(e.action, 99), e.display_name or e.dep_key))
    return UpdatePlan(entries=tuple(plan_entries))


_ACTION_ORDER = {
    _ACTION_UPDATE: 0,
    _ACTION_ADD: 1,
    _ACTION_REMOVE: 2,
    _ACTION_UNCHANGED: 3,
}


def _recorded_ref(
    dep: DependencyReference, old: LockedDependency | None, new_ref: str | None
) -> str | None:
    """Return the ref the lockfile records for *dep*, compared against the lock.

    A git dependency declared without a ref follows the remote default
    branch. The resolver names that branch, but the lockfile records the
    declared (absent) ref, so the plan compares absent with absent; a moved
    branch still differs by commit (#4166).
    """
    if (
        new_ref is not None
        and old is not None
        and old.resolved_ref is None
        and getattr(dep, "reference", None) is None
        and getattr(dep, "source", None) != "registry"
    ):
        return None
    return new_ref


def _extract_new_ref_and_commit(dep: DependencyReference) -> tuple[str | None, str | None]:
    """Pull ``(resolved_ref, resolved_commit)`` from a resolved dep.

    ``DependencyReference`` carries an optional ``resolved_reference``
    (a :class:`ResolvedReference`) that the resolve phase populates.
    Both halves are optional; either may be ``None`` if resolution did
    not yield that field.
    """
    resolved = getattr(dep, "resolved_reference", None)
    if resolved is None:
        # Registry deps identify by resolved version, not the manifest range.
        # Return None so the caller can fall back to the locked concrete version
        # rather than treating the range as a ref change.
        if getattr(dep, "source", None) == "registry":
            return (None, None)
        return (getattr(dep, "reference", None), None)
    new_ref = (
        getattr(resolved, "ref_name", None)
        or getattr(resolved, "original_ref", None)
        or getattr(dep, "reference", None)
    )
    new_commit = getattr(resolved, "resolved_commit", None)
    return (new_ref, new_commit)


def _format_ref_change(entry: PlanEntry) -> str:
    """Render the ref/commit transition for a single :class:`PlanEntry`.

    Examples (ASCII only):
        ``main (abc1234 -> def5678)``
        ``v1.0.0 (new)``
        ``main (abc1234 removed)``
    """
    if entry.new_content_hash is not None:
        return (
            f"local content ({(entry.old_content_hash or '-')[:8]} -> {entry.new_content_hash[:8]})"
        )
    if entry.action == _ACTION_ADD:
        ref = entry.new_resolved_ref or "-"
        commit = entry.short_new_commit
        return f"{ref} ({commit}, new)"
    if entry.action == _ACTION_REMOVE:
        ref = entry.old_resolved_ref or "-"
        commit = entry.short_old_commit
        return f"{ref} ({commit}, removed)"
    old_ref = entry.old_resolved_ref or "-"
    new_ref = entry.new_resolved_ref or old_ref
    ref_part = old_ref if old_ref == new_ref else f"{old_ref} -> {new_ref}"
    old_c = entry.short_old_commit
    new_c = entry.short_new_commit
    if old_c == "-" and new_c == "-":
        return ref_part
    return f"{ref_part} ({old_c} -> {new_c})"


def render_plan_text(plan: UpdatePlan, *, verbose: bool = False) -> str:
    """Render an :class:`UpdatePlan` as ASCII terminal output.

    Empty string when ``plan.has_changes`` is False (callers display
    a higher-level "already up to date" message instead).

    Bracket-status symbols:
        ``[~]`` updated
        ``[+]`` added
        ``[-]`` removed
        ``[=]`` unchanged (verbose only)

    The output never includes a trailing newline; callers append one if
    needed.
    """
    if not plan.has_changes and not verbose:
        return ""

    lines: list[str] = ["[i] Update plan for apm.yml", ""]
    for entry in plan.entries:
        if entry.action == _ACTION_UNCHANGED and not verbose:
            continue
        symbol = _ACTION_SYMBOLS.get(entry.action, "[?]")
        lines.append(f"  {symbol} {entry.display_name}")
        lines.append(f"      ref: {_format_ref_change(entry)}")
        if entry.deployed_files:
            preview = ", ".join(entry.deployed_files[:3])
            if len(entry.deployed_files) > 3:
                preview += f", +{len(entry.deployed_files) - 3} more"
            lines.append(f"      files: {preview}")
        lines.append("")

    counts = plan.summary_counts
    summary_parts = []
    if counts.get(_ACTION_UPDATE):
        summary_parts.append(f"{counts[_ACTION_UPDATE]} updated")
    if counts.get(_ACTION_ADD):
        summary_parts.append(f"{counts[_ACTION_ADD]} added")
    if counts.get(_ACTION_REMOVE):
        summary_parts.append(f"{counts[_ACTION_REMOVE]} removed")
    if verbose and counts.get(_ACTION_UNCHANGED):
        summary_parts.append(f"{counts[_ACTION_UNCHANGED]} unchanged")
    if summary_parts:
        lines.append("  " + ", ".join(summary_parts))
        legend_bits = []
        if counts.get(_ACTION_UPDATE):
            legend_bits.append(f"{_ACTION_SYMBOLS[_ACTION_UPDATE]} updated")
        if counts.get(_ACTION_ADD):
            legend_bits.append(f"{_ACTION_SYMBOLS[_ACTION_ADD]} added")
        if counts.get(_ACTION_REMOVE):
            legend_bits.append(f"{_ACTION_SYMBOLS[_ACTION_REMOVE]} removed")
        if verbose and counts.get(_ACTION_UNCHANGED):
            legend_bits.append(f"{_ACTION_SYMBOLS[_ACTION_UNCHANGED]} unchanged")
        if legend_bits:
            lines.append("  " + "  ".join(legend_bits))

    return "\n".join(lines).rstrip()


_ACTION_SYMBOLS = {
    _ACTION_UPDATE: STATUS_SYMBOLS["update"],
    _ACTION_ADD: STATUS_SYMBOLS["check"],
    _ACTION_REMOVE: STATUS_SYMBOLS["remove"],
    _ACTION_UNCHANGED: STATUS_SYMBOLS["equal"],
}


def manifest_requires_lockfile(manifest: APMPackage) -> bool:
    """Whether *manifest* declares state that only a lockfile can pin (#4050).

    The one answer to "is a missing lockfile converged?": ``apm install``
    writes no lockfile when the manifest declares no APM, MCP or LSP
    dependency, so ``apm install --frozen`` replays that state as a no-op and
    ``apm audit --ci`` accepts it; any declaration requires the lockfile.
    """
    return bool(
        manifest.has_any_apm_dependencies()
        or manifest.get_all_mcp_dependencies()
        or manifest.get_lsp_dependencies()
    )


def lockfile_satisfies_manifest(
    lockfile: LockFile,
    manifest_deps: Iterable[DependencyReference],
) -> tuple[bool, list[str]]:
    """Structural satisfaction check for ``apm install --frozen``.

    Verifies that every direct dependency declared in the manifest has
    a corresponding entry in the lockfile and that the manifest still
    points at the same locked identity. Does NOT perform any remote
    resolution; it only compares manifest-declared refs against the
    already-recorded lockfile state.

    Args:
        lockfile: The on-disk lockfile.
        manifest_deps: Direct deps from the apm.yml manifest (regular +
            dev). Local deps require an entry but have no remote ref.

    Returns:
        ``(satisfied, reasons)`` -- ``reasons`` is a list of
        human-readable strings explaining each mismatch, empty when
        ``satisfied`` is True.
    """
    from apm_cli.drift import detect_ref_change, revision_pin_mismatch

    marketplace_index = lockfile.marketplace_index()
    reasons: list[str] = []
    for dep in manifest_deps:
        key = _dep_ref_key(dep)
        display = dep.get_display_name() if dep.is_marketplace else key
        locked_dep = lockfile.get_dependency(key, marketplace_index=marketplace_index)
        if locked_dep is None or key == ".":
            reasons.append(f"  - {display} is declared in apm.yml but missing from apm.lock.yaml")
            continue
        if getattr(dep, "is_local", False):
            if (
                not locked_dep.is_local_source
                or not locked_dep.matches_replacement(dep)
                or not locked_dep.content_hash
            ):
                reasons.append(f"  - local dependency {key!r} has no locked content hash")
            continue
        if pin_reason := revision_pin_mismatch(dep.reference, locked_dep):
            reasons.append(f"  - {display}: {pin_reason}")
            continue
        if detect_ref_change(dep, locked_dep):
            reasons.append(
                f"  - {display}: declared source, ref, host provider, or transport "
                "differs from apm.lock.yaml"
            )

    return (not reasons, reasons)


__all__ = [
    "PlanEntry",
    "UpdatePlan",
    "build_update_plan",
    "lockfile_satisfies_manifest",
    "render_plan_text",
]
