"""Typed inputs for the install pipeline (Application Service input).

Bundles the kwargs previously passed to ``run_install_pipeline`` into a
single immutable record that the Click handler builds from CLI args and
the ``InstallService`` consumes.  This is the typed-IO companion to
``InstallResult`` (the Service output, defined in ``apm_cli.models.results``).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable  # noqa: UP035

if TYPE_CHECKING:
    from apm_cli.core.auth import AuthResolver
    from apm_cli.core.command_logger import InstallLogger
    from apm_cli.core.scope import InstallScope
    from apm_cli.core.target_detection import EffectiveTargetDecision
    from apm_cli.install.plan import UpdatePlan
    from apm_cli.install.transaction import InstallTransaction
    from apm_cli.models.apm_package import APMPackage


@dataclass(frozen=True)
class InstallRequest:
    """User intent for one install invocation.

    Frozen: never mutated by the pipeline.  Built once by the Click
    handler (or test harness) and handed to ``InstallService.run()``.
    """

    apm_package: APMPackage
    update_refs: bool = False
    verbose: bool = False
    only_packages: list[str] | None = None
    force: bool = False
    parallel_downloads: int = 4
    logger: InstallLogger | None = None
    scope: InstallScope | None = None
    auth_resolver: AuthResolver | None = None
    target: str | list[str] | None = None
    target_decision: EffectiveTargetDecision | None = None
    allow_insecure: bool = False
    allow_insecure_hosts: tuple[str, ...] = ()
    marketplace_provenance: dict[str, Any] | None = None
    protocol_pref: Any = None  # ProtocolPreference (NONE/SSH/HTTPS) for shorthand transport
    allow_protocol_fallback: bool | None = None  # None => read APM_ALLOW_PROTOCOL_FALLBACK env
    no_policy: bool = False  # W2-escape-hatch: skip org policy enforcement
    audit_override: str | None = None  # --audit/--no-audit override (off|warn|block)
    skill_subset: tuple[str, ...] | None = None  # --skill filter for SKILL_BUNDLE packages
    skill_subset_from_cli: bool = False  # True when user passed --skill (even --skill '*')
    legacy_skill_paths: bool = False  # --legacy-skill-paths / APM_LEGACY_SKILL_PATHS
    trust_transitive_mcp: bool = False
    # MCP servers the caller integrates after the pipeline; their org policy
    # is enforced by the commit gate before anything deploys.
    install_mcp: bool = True
    mcp_runtime: str | None = None
    # --dry-run: the pipeline resolves into rollback staging, runs its gates
    # in preview mode, and stops before the first write.
    # The caller reconciles MCP/LSP services after the pipeline and fires
    # post-install itself (result.post_install), so scripts see the final
    # lockfile (#4319).
    post_install_after_services: bool = False
    # The caller's MCP/LSP reconciliation, called with the pre-commit
    # InstallResult before native Claude registration commits the lockfile,
    # so the install writes it once (install/phases/services.py, #4329).
    reconcile_services: Callable[[Any], object] | None = None
    dry_run: bool = False
    trust_bin: bool | None = None
    # Set when the caller integrates LSP after the pipeline: declared LSP
    # without a capable target fails before the pipeline writes (#3727).
    lsp_preflight: Any = None  # LspPreflight | None

    # --frozen: refuse to install if lockfile is missing or stale relative
    # to apm.yml.  Enforced in InstallService.run() BEFORE delegating to
    # the pipeline, so the failure surfaces without running resolve.
    frozen: bool = False

    # --lockfile-only: resolve and download deps to get commit SHAs, then
    # write apm.lock.yaml WITHOUT deploying any files to targets.  Set
    # internally by the ``apm lock`` command (mirrors cargo generate-lockfile / pnpm lock).
    lockfile_only: bool = False

    # --refresh: re-resolve all refs against upstream (bypass lockfile
    # pins).  Unlike --update (which restructures the whole graph),
    # --refresh only forces re-resolution without discarding orphans.
    refresh: bool = False

    # Plan-gate hook: if set, run_install_pipeline invokes this callable
    # AFTER resolve completes and BEFORE downloads begin, passing the
    # computed UpdatePlan.  The callable returns True to proceed or
    # False to abort cleanly with a "no changes applied" message.  Used
    # by ``apm update`` to render the plan and prompt the user.
    plan_callback: Callable[[UpdatePlan], bool] | None = None
    transaction: InstallTransaction | None = None

    def hold_deploy_evidence(self) -> None:
        """Hand the deploy-store evidence this install staged to its transaction.

        Deployed bytes enter the store only when the transaction commits; it
        holds them from here, before a post-install script resets the memos.
        """
        if self.transaction is not None:
            self.transaction.hold_deploy_evidence()
