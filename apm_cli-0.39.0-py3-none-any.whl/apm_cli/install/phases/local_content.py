"""Local-content integration: deploy primitives the user authored locally.

This module handles two related scenarios:

1. **Root project as implicit local package (#714)** -- when the project's own
   ``.apm/`` directory contains skills, instructions, agents, prompts, hooks,
   or commands, ``apm install`` deploys them to target directories exactly like
   dependency primitives.  ``_project_has_root_primitives`` and
   ``_has_local_apm_content`` detect this case.

2. **Local-path dependencies from apm.yml** -- ``_copy_local_package`` copies
   a locally-referenced package into ``apm_modules/`` so the downstream
   integration pipeline can treat it uniformly.

The orchestrator ``_integrate_local_content`` lives in
``apm_cli.install.services`` (the DI seam) and is re-exported from
``apm_cli.commands.install`` for backward-compatible patching. Tests should
patch the symbol at the import path used by the code under test rather than
assuming the implementation lives in the commands module.

Functions
---------
_project_has_root_primitives
    Return True when the project root contains a ``.apm/`` directory.
_has_local_apm_content
    Return True when ``.apm/`` contains at least one primitive file.
_root_holds_only_hook_primitives
    Return True when ``.apm/`` carries hooks and no other primitive.
_copy_local_package
    Copy a local-path dependency into ``apm_modules/``.
materialize_local_package
    The single raising owner of a local package image, shared by install,
    the uninstall survivor refresh and the audit replay.
"""

import contextlib
import shutil
import tempfile
from collections.abc import Iterator
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Any

import yaml

from apm_cli.core.remediation import (
    LOCAL_PACKAGE_CONTENT_INVALID,
    LOCAL_PACKAGE_PATH_MISSING,
    LOCAL_PACKAGE_UNREADABLE,
)
from apm_cli.core.scope import manifest_file
from apm_cli.deps.virtual_file import materialize_virtual_file_package, virtual_file_subdirectory
from apm_cli.models.dependency import DependencyReference
from apm_cli.utils.path_security import (
    PathTraversalError,
    ensure_path_within,
    safe_rmtree,
)
from apm_cli.utils.yaml_io import load_frontmatter

# ---------------------------------------------------------------------------
# Root primitive detection helpers
# ---------------------------------------------------------------------------


def _project_has_root_primitives(project_root) -> bool:
    """Return True when *project_root* has a .apm/ directory of its own.

    Used to decide whether ``apm install`` should enter the integration
    pipeline even when no external APM dependencies are declared (#714).
    The integrators themselves determine whether the directory contains
    anything actionable, so we only check for the directory's existence.
    """
    from pathlib import Path as _Path

    root = _Path(project_root)
    return (root / ".apm").is_dir()


_PRIMITIVE_DIRS = (
    "skills",
    "instructions",
    "chatmodes",
    "agents",
    "prompts",
    "hooks",
    "commands",
    "extensions",
)


def _populated_primitive_dirs(apm_dir) -> set[str]:
    """Return the primitive subdirectories of *apm_dir* holding at least one file."""
    return {
        name
        for name in _PRIMITIVE_DIRS
        if (apm_dir / name).is_dir() and any(p.is_file() for p in (apm_dir / name).rglob("*"))
    }


def _has_local_apm_content(project_root):
    """Check if the project has local .apm/ content worth integrating.

    Returns True if .apm/ exists and contains at least one primitive file
    in a recognized subdirectory (skills, instructions, agents/chatmodes,
    prompts, hooks, commands).
    """
    apm_dir = project_root / ".apm"
    if not apm_dir.is_dir():
        return False
    return bool(_populated_primitive_dirs(apm_dir))


def _root_holds_only_hook_primitives(root) -> bool:
    """Return True when *root*/.apm/ carries hooks and no other primitive.

    A hook that names no script merges into a shared config and claims no
    file, so installing such a root records no self-entry (#4837). Every
    other primitive claims files; a lock with no self-entry for a root that
    carries them predates user-root recording (#3772), so audit replay
    leaves that root out exactly as released audits did.
    """
    from pathlib import Path as _Path

    return _populated_primitive_dirs(_Path(root) / ".apm") == {"hooks"}


# ---------------------------------------------------------------------------
# Local-path dependency copy
# ---------------------------------------------------------------------------


def compute_local_package_hash(source: Path, *, framed: bool = True) -> str:
    """Hash the validated local-copy image without changing installed content.

    Use the same directory copier or selected-file materializer as install
    before the existing package hash, rather than hashing transformed output.
    *framed* is the lock row's stream (``content_hash_framed``).
    """
    from apm_cli.config import get_apm_temp_dir
    from apm_cli.utils.content_hash import compute_package_hash

    with tempfile.TemporaryDirectory(prefix="apm-local-snapshot-", dir=get_apm_temp_dir()) as stage:
        snapshot = Path(stage) / "package"
        if source.is_dir():
            _copy_tree_dereferencing_validated(source, snapshot, source)
        else:
            dependency = DependencyReference.parse(source.absolute().as_posix())
            admitted = read_local_package_source(dependency, source.parent)
            if admitted.content is None:
                raise LocalPackageError(
                    f"Local single-file source changed kind during hashing: {source}"
                )
            materialize_virtual_file_package(
                dependency, snapshot, admitted.path.name, admitted.content
            )
        return compute_package_hash(snapshot, framed=framed)


def local_source_matches_copy(
    lock_dep: Any, source: Path, copy: Path, *, source_hash: str | None = None
) -> bool:
    """Whether *source* still yields the image install materialized at *copy*.

    Install validates a legacy plugin's copy in place (a synthesized
    ``apm.yml`` and ``.apm/``), so an unchanged plugin source is compared
    through the same normalization rather than as raw bytes. A source that
    cannot be normalized does not match.
    """
    from apm_cli.config import get_apm_temp_dir
    from apm_cli.install.drift import _normalize_legacy_local_plugin_for_replay
    from apm_cli.utils.content_hash import verify_package_hash

    framed = lock_dep.content_hash_framed
    expected = compute_local_package_hash(copy, framed=framed)
    if source_hash is None:
        source_hash = compute_local_package_hash(source, framed=framed)
    if source_hash == expected:
        return True
    if not source.is_dir():
        return False
    with tempfile.TemporaryDirectory(prefix="apm-local-image-", dir=get_apm_temp_dir()) as stage:
        # The synthesized manifest may take its name from the directory.
        image = Path(stage) / copy.name
        _copy_tree_dereferencing_validated(source, image, source)
        try:
            _normalize_legacy_local_plugin_for_replay(lock_dep, image)
        except (OSError, ValueError, TypeError):
            return False
        return verify_package_hash(image, expected, framed=framed)


class LocalPackageError(ValueError):
    """A local dependency cannot be admitted without changing existing output."""


@dataclass(frozen=True)
class LocalPackageSource:
    """An admitted directory or an already-read, validated primitive file."""

    path: Path
    content: bytes | None = None


def read_local_package_source(dep_ref: DependencyReference, base_dir: Path) -> LocalPackageSource:
    """Admit local input before replacing a prior package or target output."""
    from apm_cli.deps._shared import has_marketplace_deployable_manifest
    from apm_cli.install.primitive_classification import (
        PrimitiveKind,
        classify_agent_source_file,
    )
    from apm_cli.utils.helpers import find_plugin_json

    selected = Path(dep_ref.local_path).expanduser()
    if not selected.is_absolute():
        selected = base_dir / selected
    try:
        local = selected.resolve(strict=True)
        if local.is_dir():
            if (
                manifest_file(local).exists()
                or (local / "SKILL.md").exists()
                or find_plugin_json(local, include_codex=True) is not None
                or has_marketplace_deployable_manifest(dep_ref)
            ):
                return LocalPackageSource(local)
            raise LocalPackageError(
                "Local package is not a valid APM package "
                f"(no apm.yml, SKILL.md, or plugin.json): {dep_ref.local_path}. "
                "Select a package directory or a supported single-file primitive."
            )
        if not local.is_file():
            raise LocalPackageError(
                f"Unsupported local source kind: {dep_ref.local_path}. "
                "Select a regular primitive file or a directory package."
            )
        if selected.is_symlink():
            raise LocalPackageError(
                f"Local single-file dependency is a symlink: {dep_ref.local_path}. "
                "Select a real file or use a directory package with in-package symlinks."
            )
        try:
            subdirectory = virtual_file_subdirectory(selected.name)
        except ValueError as exc:
            raise LocalPackageError(str(exc)) from exc
        content = local.read_bytes()
        load_frontmatter(BytesIO(content))
        if subdirectory == "agents":
            classification = classify_agent_source_file(local, local.parent)
            if classification.kind is not PrimitiveKind.AGENT:
                raise LocalPackageError(
                    f"Invalid primitive content in {dep_ref.local_path}: {classification.warning}"
                )
        return LocalPackageSource(local, content)
    except FileNotFoundError as exc:
        raise LocalPackageError(
            f"Local package path does not exist: {dep_ref.local_path}. "
            f"{LOCAL_PACKAGE_PATH_MISSING.sentence()}"
        ) from exc
    except OSError as exc:
        raise LocalPackageError(
            f"Cannot read local package: {dep_ref.local_path}: {exc}. "
            f"{LOCAL_PACKAGE_UNREADABLE.sentence()}"
        ) from exc
    except (UnicodeError, yaml.YAMLError) as exc:
        raise LocalPackageError(
            f"Invalid primitive content in {dep_ref.local_path}: {exc}. "
            f"{LOCAL_PACKAGE_CONTENT_INVALID.sentence()}"
        ) from exc


def materialize_local_package(
    dep_ref: DependencyReference, install_path: Path, base_dir: Path
) -> Path:
    """Admit a local source and write its package image to *install_path*.

    The single owner of the local package image: install, the uninstall
    survivor refresh and the audit replay all copy through it, so in-package
    links are dereferenced and single files are materialized identically.

    Raises:
        LocalPackageError: The source cannot be admitted.
        PathTraversalError: A link escapes the package, is broken or loops;
            *install_path* is removed so no partial copy remains.
    """
    source = read_local_package_source(dep_ref, base_dir)
    install_path.parent.mkdir(parents=True, exist_ok=True)
    if install_path.exists():
        # install_path is already validated by get_install_path() (Layer 2),
        # but use safe_rmtree for defense-in-depth.
        safe_rmtree(install_path, install_path.parent.parent)
    # Dereference in-package symlinks per-file (fix for #1668), matching the
    # remote install path (robust_copytree with symlinks=False).
    try:
        if source.content is None:
            _copy_tree_dereferencing_validated(source.path, install_path, source.path)
        else:
            materialize_virtual_file_package(
                dep_ref, install_path, source.path.name, source.content
            )
    except PathTraversalError:
        if install_path.exists():
            safe_rmtree(install_path, install_path.parent.parent)
        raise
    return install_path


@contextlib.contextmanager
def staged_local_package_image(dep_ref: DependencyReference, base_dir: Path) -> Iterator[Path]:
    """Yield a private copy of a local package's image, removed on exit (#4566).

    Validation normalizes a plugin directory in place (a synthesized
    ``apm.yml`` and ``.apm/``); a consumer-owned source directory must never
    receive those writes, so callers validate this copy instead.

    Raises:
        LocalPackageError: The source cannot be admitted.
        PathTraversalError: A link escapes the package, is broken or loops.
    """
    from apm_cli.config import get_apm_temp_dir

    with tempfile.TemporaryDirectory(prefix="apm-local-image-", dir=get_apm_temp_dir()) as stage:
        yield materialize_local_package(dep_ref, Path(stage) / "package", base_dir)


def materialize_local_package_for_replay(
    dep_ref: DependencyReference, base_dir: Path, modules_dir: Path
) -> Path:
    """Write the package image install would copy into a scratch replay root."""
    return materialize_local_package(dep_ref, dep_ref.get_install_path(modules_dir), base_dir)


def _copy_tree_dereferencing_validated(
    src: Path, dst: Path, pkg_root: Path, *, _visited: set[Path] | None = None
) -> None:
    """Recursively copy *src* into *dst*, dereferencing in-package symlinks.

    For every entry in *src*:

    * Regular file  -> ``shutil.copy2`` to *dst*.
    * Symlink       -> resolve per-file, validate that the resolved target
                       stays within *pkg_root* via ``ensure_path_within``,
                       then ``shutil.copy2`` the resolved content (or recurse
                       for symlinked directories).  A symlink whose resolved
                       target escapes *pkg_root* raises
                       :class:`~apm_cli.utils.path_security.PathTraversalError`
                       immediately, aborting the copy.
    * Directory     -> recurse.

    Each symlink undergoes a per-file resolve -> validate -> copy2 sequence
    rather than a bulk copytree that resolves and copies in separate passes,
    so the containment check fires before any filesystem write for that entry.
    The containment check is performed against ``pkg_root`` (the top-level
    package directory passed to ``_copy_local_package``) so that symlinks
    that cross sub-directory boundaries but remain inside the package are
    accepted, while any symlink that escapes the package boundary is rejected
    with a hard failure.

    The ``_visited`` set tracks resolved directory paths already entered.
    Circular directory-symlink chains (A -> B -> A) are detected deterministically
    without relying on the OS ELOOP limit (which is platform-dependent).

    A directory that cannot be listed (e.g. ``PermissionError`` from
    ``iterdir``) hard-fails the install with a :class:`PathTraversalError`
    rather than leaking a bare ``OSError`` up the install stack.
    """
    if _visited is None:
        _visited = set()

    dst.mkdir(parents=True, exist_ok=True)

    try:
        entries = sorted(src.iterdir())
    except OSError as exc:
        raise PathTraversalError(
            f"Cannot read package directory '{src}': {exc}. "
            f"Check that the package directory has read permissions. "
            f"Local install aborted."
        ) from exc

    for entry in entries:
        dst_entry = dst / entry.name

        if entry.is_symlink():
            try:
                resolved = entry.resolve(strict=True)
            except OSError as exc:
                raise PathTraversalError(
                    f"Symlink '{entry}' has a broken or unresolvable target: {exc}. "
                    f"Remove the dangling symlink or restore its target. "
                    f"Local install aborted."
                ) from exc

            try:
                ensure_path_within(resolved, pkg_root)
            except PathTraversalError as _exc:
                raise PathTraversalError(
                    f"Symlink '{entry}' resolves to '{resolved}', which escapes "
                    f"the package root '{pkg_root}'. "
                    f"Only in-package symlinks are dereferenced. "
                    f"Remove the symlink or replace it with a real file copy. "
                    f"Local install aborted."
                ) from _exc

            if resolved.is_dir():
                if resolved in _visited:
                    raise PathTraversalError(
                        f"Circular symlink detected: '{entry}' resolves to '{resolved}', "
                        f"which was already visited during this install. "
                        f"Break the cycle by replacing one symlink with a real directory copy. "
                        f"Local install aborted."
                    )
                _copy_tree_dereferencing_validated(
                    resolved, dst_entry, pkg_root, _visited=_visited | {resolved}
                )
                shutil.copystat(resolved, dst_entry)
            else:
                shutil.copy2(resolved, dst_entry)
        elif entry.is_dir():
            _copy_tree_dereferencing_validated(entry, dst_entry, pkg_root, _visited=_visited)
            shutil.copystat(entry, dst_entry)
        else:
            shutil.copy2(entry, dst_entry)


def _copy_local_package(dep_ref, install_path, base_dir, *, project_root, logger):
    """Copy a local package to apm_modules/.

    Args:
        dep_ref: DependencyReference with is_local=True.
        install_path: Target path under apm_modules/.
        base_dir: Directory used to resolve a relative ``dep_ref.local_path``.
            For direct deps from the root project this is the project root;
            for transitive deps it is the source directory of the package
            whose apm.yml declared *dep_ref* (#857). Must NOT be confused
            with ``project_root`` -- the anchoring base and the security
            containment boundary are deliberately distinct concerns.
        project_root: Project root, threaded through for symmetry with the
            anchoring story but NOT used as a hard containment boundary
            here. The actual untrusted-source boundary lives upstream in
            :mod:`apm_cli.deps.apm_resolver` (remote-parent local paths are
            expanded to same-repo virtual deps or rejected before this
            function ever runs). Enforcing project-root containment
            *here* would also block legitimate sibling layouts -- e.g.
            ``apm install ../pkg-a`` from a monorepo workspace -- which
            users explicitly opt into. Kept on the signature so callers
            keep the security model in mind and so a future tightening
            (e.g. opt-in strict mode) has a hook.
        logger: Required CommandLogger for structured output. Callers must
            thread one in; we no longer fall back to a bare console helper
            (#940 SR4) because doing so masked logger threading bugs in
            transitive call stacks.

    Returns:
        install_path on success, None on failure.

    Notes:
        We deliberately do NOT call ``validate_path_segments`` on
        ``dep_ref.local_path``: that helper rejects ``..`` segments, which
        would break the legitimate ``../sibling`` pattern this PR enables.
        The untrusted-source boundary is the resolver-level expansion or
        rejection of remote-parent local_paths; everything reaching this
        function comes from a parent the user already trusts (their own
        manifest, a CLI arg, or another local package they explicitly added).
    """
    # project_root retained on signature for future strict-mode hook (see
    # docstring); not consumed in the current copy path.
    _ = project_root

    # PR #1111 review C1: ``ctx.logger`` is allowed to be None
    # (``run_install_pipeline(logger=None)`` is a public, documented entry
    # point). Without this guard the unconditional ``logger.error(...)``
    # calls below would AttributeError for any local dep when a caller
    # does not thread an InstallLogger through. Defaulting to the rich-
    # console-backed ``NullCommandLogger`` keeps the error visible to the
    # user while preserving the documented "logger is required" contract
    # for callers that DO thread one in (their logger wins).
    if logger is None:
        from apm_cli.core.null_logger import NullCommandLogger

        logger = NullCommandLogger()

    try:
        return materialize_local_package(dep_ref, install_path, base_dir)
    except LocalPackageError as exc:
        logger.error(str(exc))
        return None


def copy_local_dependency(dep_ref, install_path, *, declaring_dir, source_root, user_scope):
    """Anchor and copy a local dependency; return ``None`` or the failure reason.

    The anchor comes from :func:`apm_cli.deps.path_anchoring.local_dep_base_dir`
    so a relative path resolves against the package that declared it.
    """
    from apm_cli.deps.path_anchoring import USER_SCOPE_RELATIVE_PATH_ERROR, local_dep_base_dir

    base_dir = local_dep_base_dir(
        dep_ref.local_path,
        declaring_dir=declaring_dir,
        source_root=source_root,
        user_scope=user_scope,
    )
    if base_dir is None:
        return f"{dep_ref.local_path} -- {USER_SCOPE_RELATIVE_PATH_ERROR}"
    try:
        materialize_local_package(dep_ref, install_path, base_dir)
    except LocalPackageError as exc:
        return str(exc)
    return None
