"""Load the lockfile, initialize downloads, and resolve
the selected dependency tree before integration.
"""

from __future__ import annotations

import builtins
import logging
from collections.abc import Callable
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Any

from apm_cli.core.remediation import REPLACEMENT_RULES_PARTIAL_INSTALL
from apm_cli.install.helpers.ref_reuse import (
    annotate_update_plan_refs,
)
from apm_cli.install.helpers.ref_reuse import (
    maybe_resolve_git_semver as _maybe_resolve_git_semver,
)
from apm_cli.install.helpers.ref_reuse import (
    requires_remote_ref_resolution as _requires_remote_ref_resolution,
)
from apm_cli.install.helpers.ref_seed import seed_ref_resolver_from_lockfile
from apm_cli.install.pipeline_entry import record_preview_resolution
from apm_cli.install.presentation.resolution import report_resolved_dependencies
from apm_cli.install.repository_access import not_found_next_step
from apm_cli.install.source_helpers import (
    download_registry_package,
    with_preserved_install_hint,
)
from apm_cli.install.transaction import resolution_for_context
from apm_cli.models.apm_package import GitReferenceType, ResolvedReference
from apm_cli.models.dependency import materialization as _materialization
from apm_cli.models.dependency.replacement import project_manifest_dependencies
from apm_cli.utils.short_sha import format_short_sha

if TYPE_CHECKING:
    from apm_cli.install.context import InstallContext
    from apm_cli.install.resolution_staging import ResolutionStagingSession

_logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Private helpers (each mutates ctx in-place, following existing pattern)
# ------------------------------------------------------------------


def _lockfile_has_registry_deps(existing_lockfile) -> bool:
    """Return whether the lockfile contains a registry-sourced dependency."""
    if not existing_lockfile:
        return False
    return any(
        getattr(dep, "source", None) == "registry"
        for dep in existing_lockfile.dependencies.values()
    )


def _require_package_registry_feature_if_needed(registries_map, existing_lockfile) -> bool:
    """Validate the gate and return whether registry support is needed."""
    needs_registry = bool(registries_map) or _lockfile_has_registry_deps(existing_lockfile)
    if needs_registry:
        from apm_cli.deps.registry.feature_gate import require_package_registry_enabled

        require_package_registry_enabled("Registry-sourced installs")
    return needs_registry


def _prepare_existing_materialization_paths(
    ctx: InstallContext,
    staging_session: ResolutionStagingSession,
    materialization_reader: _materialization.MaterializationPathReader,
) -> None:
    """Migrate case-only legacy paths before resolver cache checks can bypass callbacks."""
    apm_modules_dir = getattr(ctx, "apm_modules_dir", None)
    if apm_modules_dir is None:
        return
    dependencies = list(getattr(ctx, "all_apm_deps", ()))
    seen_keys = {dependency.get_unique_key() for dependency in dependencies}
    existing_lockfile = getattr(ctx, "existing_lockfile", None)
    if existing_lockfile is not None:
        for locked in existing_lockfile.get_package_dependencies():
            dependency = locked.to_dependency_ref()
            key = dependency.get_unique_key()
            if key in seen_keys:
                continue
            dependencies.append(dependency)
            seen_keys.add(key)

    on_migrate = _materialization_migration_logger(getattr(ctx, "logger", None), apm_modules_dir)
    for dependency in dependencies:
        if dependency.is_marketplace:
            continue
        _materialization.prepare_materialization_path(
            dependency,
            apm_modules_dir,
            staging_session,
            reader=materialization_reader,
            on_migrate=on_migrate,
        )


def _materialization_migration_logger(
    logger,
    apm_modules_dir: Path,
) -> Callable[[Path, Path], None] | None:
    """Build a verbose-only callback for case migration diagnostics."""
    if logger is None:
        return None
    modules = apm_modules_dir.absolute()

    def report(source: Path, destination: Path) -> None:
        source_rel = source.absolute().relative_to(modules).as_posix()
        destination_rel = destination.absolute().relative_to(modules).as_posix()
        logger.verbose_detail(
            f"    Migrated package directory casing: {source_rel} -> {destination_rel}"
        )

    return report


def _prepare_callback_materialization_path(
    dependency: Any,
    modules_dir: Path,
    staging_session: ResolutionStagingSession,
    materialization_reader: _materialization.MaterializationPathReader,
    callback_lock: Any,
    logger: Any,
) -> Path:
    """Serialize transitive casing lookup and migration across resolver workers."""
    with callback_lock:
        return _materialization.prepare_materialization_path(
            dependency,
            modules_dir,
            staging_session,
            reader=materialization_reader,
            on_migrate=_materialization_migration_logger(logger, modules_dir),
        )


def _discard_failed_download(
    staging_session: ResolutionStagingSession, replacement_path: Path, error: Exception
) -> Exception:
    """Keep the download failure visible if removing its partial candidate also fails."""
    try:
        staging_session.discard_replacement(replacement_path)
    except (OSError, ValueError) as cleanup_error:
        combined = RuntimeError(
            f"{error}. Could not discard downloaded candidate {replacement_path}: "
            f"{cleanup_error}. Inspect the retained staging path before retrying."
        )
        combined.__cause__ = error
        return combined
    return error


def _activate_validated_candidate(
    candidate_path: Path,
    *,
    staging_session: ResolutionStagingSession,
    pending_downloads: dict[Path, tuple[str, str | None]],
    callback_downloaded: dict[str, str | None],
    callback_lock: Any,
    tui: Any,
    callback_content_hashes: dict[str, tuple[Path, str]] | None = None,
) -> Path:
    """Publish one accepted candidate, then expose its download metadata."""
    from apm_cli.utils.content_hash import compute_package_hash
    from apm_cli.utils.realpath import resolve_path

    content_hash = compute_package_hash(candidate_path, framed=True)
    live_path = staging_session.publish_replacement(candidate_path)
    with callback_lock:
        pending = pending_downloads.pop(candidate_path, None)
        if pending is None:
            raise RuntimeError(f"Validated candidate has no download record: {candidate_path}")
        dep_key, resolved_sha = pending
        callback_downloaded[dep_key] = resolved_sha
        if callback_content_hashes is not None:
            callback_content_hashes[dep_key] = (resolve_path(live_path), content_hash)
    if tui is not None:
        tui.task_completed(dep_key)
    return live_path


def _load_lockfile(ctx: InstallContext) -> None:
    """Load ``apm.lock.yaml`` and populate ``ctx.existing_lockfile`` / ``ctx.lockfile_path``."""
    # ------------------------------------------------------------------
    # 1. Lockfile loading
    # ------------------------------------------------------------------
    from apm_cli.deps.lockfile import LockFile, get_lockfile_path

    lockfile_path = get_lockfile_path(ctx.apm_dir)
    ctx.lockfile_path = lockfile_path
    existing_lockfile = None
    lockfile_count = 0
    if ctx.early_lockfile is not None:
        existing_lockfile = ctx.early_lockfile
    elif lockfile_path.exists():
        existing_lockfile = LockFile.read(lockfile_path)
    if existing_lockfile and existing_lockfile.dependencies:
        lockfile_count = len(existing_lockfile.dependencies)
        if ctx.logger:
            if ctx.update_refs:
                ctx.logger.verbose_detail(
                    f"Loaded apm.lock.yaml for SHA comparison ({lockfile_count} dependencies)"
                )
            else:
                ctx.logger.verbose_detail(
                    f"Using apm.lock.yaml ({lockfile_count} locked dependencies)"
                )
            if ctx.logger.verbose:
                for locked_dep in existing_lockfile.get_all_dependencies():
                    _sha = format_short_sha(locked_dep.resolved_commit)
                    _ref = (
                        locked_dep.resolved_ref
                        if hasattr(locked_dep, "resolved_ref") and locked_dep.resolved_ref
                        else ""
                    )
                    ctx.logger.lockfile_entry(locked_dep.get_unique_key(), ref=_ref, sha=_sha)
    ctx.existing_lockfile = existing_lockfile


def _ensure_modules_dir(ctx: InstallContext) -> None:
    """Create the ``apm_modules/`` directory and populate ``ctx.apm_modules_dir``."""
    # ------------------------------------------------------------------
    # 2. apm_modules directory
    # ------------------------------------------------------------------
    from apm_cli.core.scope import get_modules_dir

    apm_modules_dir = get_modules_dir(ctx.scope)
    apm_modules_dir.mkdir(parents=True, exist_ok=True)
    ctx.apm_modules_dir = apm_modules_dir


def _setup_downloader(ctx: InstallContext) -> None:
    """Create auth resolver and downloader; populate ``ctx.auth_resolver`` / ``ctx.downloader``."""
    # ------------------------------------------------------------------
    # 3. Auth resolver + downloader
    # ------------------------------------------------------------------

    from apm_cli.core.auth import AuthResolver
    from apm_cli.deps import github_downloader as _ghd_mod

    if ctx.auth_resolver is None:
        ctx.auth_resolver = AuthResolver()

    downloader = _ghd_mod.GitHubPackageDownloader(
        auth_resolver=ctx.auth_resolver,
        protocol_pref=ctx.protocol_pref,
        allow_fallback=ctx.allow_protocol_fallback,
    )
    ctx.downloader = downloader

    # WS2a (#1116): attach a per-run shared clone cache so subdirectory
    # deps from the same upstream repo+ref share a single git clone.
    # The cache is cleaned up after resolution completes (see _resolve_dependencies).
    from apm_cli.deps.shared_clone_cache import SharedCloneCache

    shared_cache = SharedCloneCache()
    downloader.shared_clone_cache = shared_cache

    # WS3 (#1116): attach persistent cross-run git cache unless disabled
    # via APM_NO_CACHE; a --dry-run preview never writes the cache.
    from apm_cli.cache.git_cache import attach_persistent_git_cache

    if not ctx.dry_run:
        attach_persistent_git_cache(downloader, refresh=ctx.refresh)

    # Perf #1433: attach the InstallLogger so the subdir download path
    # can emit verbose-only [perf] lines (subdir cache state, bare
    # clone strategy + elapsed, materialize sparse-applied + size).
    # Optional; tests / non-install drivers leave this None.
    if ctx.logger is not None:
        downloader.install_logger = ctx.logger

    # #1369: tiered ref resolver. Collapses N redundant shallow clones
    # for ref->SHA resolution into a per-run cache + cheap commits API
    # + bare-rev-parse waterfall, falling back to the legacy clone path.
    # Wired AFTER persistent_git_cache so L2 can reach it. Reused by
    # every code path that calls downloader.resolve_git_reference():
    # install, update, outdated, publish.
    from apm_cli.deps.tiered_ref_resolver import (
        build_tiered_ref_resolver,
        ref_freshness_policy_for_install,
    )

    ctx.ref_freshness_policy = ref_freshness_policy_for_install(ctx)
    if ctx.ref_freshness_policy.requires_remote and ctx.logger:
        ctx.logger.verbose_detail("[*] Resolving refs from upstream; local cached refs bypassed")
    try:
        _tiered = build_tiered_ref_resolver(
            downloader=downloader,
            git_cache=getattr(downloader, "persistent_git_cache", None),
            freshness_policy=ctx.ref_freshness_policy,
        )
        if _tiered is not None:
            downloader._tiered_resolver = _tiered
            ctx.ref_resolver = _tiered
    except Exception as exc:  # pragma: no cover - defensive: never block resolve phase
        # Keep non-blocking behavior, but make it diagnosable in --verbose.
        import logging as _logging

        _logging.getLogger(__name__).debug(
            "Tiered ref resolver wiring skipped (%s): %s",
            type(exc).__name__,
            exc,
        )


def _annotate_registry_dep_ref(dep_ref, registry_resolver) -> None:
    reg_res = registry_resolver.last_resolutions.get(dep_ref.get_unique_key())
    if not reg_res or not reg_res.version:
        return
    dep_ref.resolved_reference = ResolvedReference(
        original_ref=dep_ref.reference or reg_res.version,
        ref_type=GitReferenceType.TAG,
        ref_name=reg_res.version,
    )


def _fail_on_resolution_errors(ctx: InstallContext, dependency_graph, failures=()) -> None:
    """Raise on fatal resolution errors; show the download *failures* behind them once."""
    if ctx.dry_run:
        return record_preview_resolution(ctx, dependency_graph)
    if not dependency_graph.resolution_errors:
        return
    for _display, failure in failures if ctx.logger else ():
        ctx.logger.verbose_detail(f"  {failure}")
    from apm_cli.install.errors import DependencyResolutionError

    errors = list(dependency_graph.resolution_errors)
    unprinted = []
    for error in errors:
        if ctx.logger and not error.startswith("Marketplace package materialization failed:"):
            ctx.logger.error(error)
        else:
            unprinted.append(error)
    raise DependencyResolutionError(errors, unprinted=unprinted)


def _judge_resolution(ctx: InstallContext, graph, failures, depth_policy, resolver) -> None:
    """Refuse the resolved graph: policy refusals first, then any other resolution error."""
    from apm_cli.install.commit_gate import refuse_policy_depth_limit
    from apm_cli.install.phases.policy_gate import _drop_policy_refused_replacement_errors

    _drop_policy_refused_replacement_errors(ctx, graph)
    if depth_policy is not None:
        refuse_policy_depth_limit(ctx, depth_policy, resolver.depth_limit_chains)
    _fail_on_resolution_errors(ctx, graph, failures)


def _attach_resolver_marketplace_provenance(ctx: InstallContext, resolver) -> None:
    """Carry manifest-resolved marketplace identity into selection and lockfile assembly."""
    if ctx.only_packages and resolver.selected_marketplace_keys:
        # Selecting ``plugin@marketplace`` selects the package it resolved to.
        ctx.only_packages = [*ctx.only_packages, *resolver.selected_marketplace_keys]
    if not resolver.marketplace_provenance:
        return
    if ctx.marketplace_provenance is None:
        ctx.marketplace_provenance = {}
    ctx.marketplace_provenance.update(resolver.marketplace_provenance)


def _build_dependency_graph(ctx: InstallContext, resolver):
    """Resolve the manifest graph and retain its marketplace provenance."""
    manifest_anchor = ctx.source_root if ctx.source_root != ctx.project_root else ctx.apm_dir
    dependency_graph = resolver.resolve_dependencies(
        manifest_anchor,
        root_package=ctx.apm_package,
    )
    ctx.dependency_graph = dependency_graph
    _attach_resolver_marketplace_provenance(ctx, resolver)
    for warning in dependency_graph.dependency_tree.resolution_warnings if ctx.logger else ():
        ctx.logger.warning(warning)
    return dependency_graph


def _resolve_dependencies(
    ctx: InstallContext,
    staging_session: ResolutionStagingSession,
    materialization_reader: _materialization.MaterializationPathReader,
) -> None:
    """Resolve dependencies and populate the resolution fields on ``ctx``."""
    import threading as _threading

    from apm_cli.core.scope import InstallScope
    from apm_cli.deps.apm_resolver import APMDependencyResolver
    from apm_cli.install.insecure_policy import (
        _check_insecure_dependencies,
        _collect_insecure_dependency_infos,
        _guard_transitive_insecure_dependencies,
        _warn_insecure_dependencies,
    )
    from apm_cli.install.package_selection import selected_dependency_keys
    from apm_cli.install.phases.local_content import copy_local_dependency

    # 3b. Dedicated registry resolver (design §3.1, §8)
    # Built when:
    #   - the manifest's apm.yml has a top-level ``registries:`` block, OR
    #   - the on-disk lockfile has at least one ``source: registry`` entry
    #     (re-install of a project whose authors removed the block but the
    #     locked deps still need somewhere to land).
    # In the second case the URL is the trust anchor — auth resolves by
    # URL prefix against the apm.yml registries map (which may be empty,
    # forcing anonymous fetch).
    registry_resolver = None
    _apply_lockfile_registry_name = None
    existing_lockfile = ctx.existing_lockfile
    registries_map = getattr(ctx.apm_package, "registries", None) or {}
    needs_registry = _require_package_registry_feature_if_needed(registries_map, existing_lockfile)
    if needs_registry:
        from apm_cli.deps.registry.auth import (
            dependency_ref_with_registry_name_from_lockfile,
        )
        from apm_cli.deps.registry.resolver import RegistryPackageResolver

        registry_resolver = RegistryPackageResolver(registries_map)
        _apply_lockfile_registry_name = dependency_ref_with_registry_name_from_lockfile
    ctx.registry_resolver = registry_resolver

    # 4. Tracking variables (phase-local except where noted)
    direct_dep_keys = builtins.set(dep.get_unique_key() for dep in ctx.all_apm_deps)
    callback_downloaded: builtins.dict = {}
    pending_callback_downloads: builtins.dict[Path, tuple[str, str | None]] = {}
    transitive_failures: builtins.list = []
    callback_failures: builtins.set = builtins.set()
    # F7 (#1116): the resolver may dispatch ``download_callback`` calls
    # across a worker pool. CPython's GIL makes individual dict/set/list
    # mutations atomic, but logging emission and the read+update on
    # ``callback_downloaded`` (e.g. duplicate-key races) are not. A single
    # narrow lock around the result-recording sites is sufficient and
    # cheap; the heavy I/O work runs OUTSIDE the lock.
    callback_lock = _threading.Lock()

    # 5. Download callback for transitive resolution
    scope = ctx.scope
    # Local-path package references in apm.yml are relative to the
    # manifest's location (source_root), not the deploy override.
    # source_root is required on InstallContext; equals project_root
    # when --root is not used.
    source_root = ctx.source_root
    # --refresh implies re-resolution of all refs (but does NOT discard
    # lockfile entries for packages not in the manifest, unlike --update
    # which may restructure the whole graph).
    update_refs = _requires_remote_ref_resolution(ctx)
    update_keys = (
        selected_dependency_keys(ctx.only_packages, ctx.all_apm_deps) if ctx.only_packages else None
    )
    if ctx.refresh and ctx.logger:
        ctx.logger.verbose_detail("[*] --refresh: bypassing cached package content")
    logger = ctx.logger
    existing_lockfile = ctx.existing_lockfile
    downloader = ctx.downloader

    from apm_cli.drift import (
        build_download_ref,
        detect_ref_change,
        should_force_ref_recheck,
    )

    verbose = ctx.verbose  # noqa: F841

    from apm_cli.install.phases.policy_gate import _prefetch_policy_refusal

    refuse_before_fetch = _prefetch_policy_refusal(ctx)

    def download_callback(dep_ref, modules_dir, parent_chain="", parent_pkg=None):
        """Download a package during dependency resolution.

        Args:
            dep_ref: The dependency to download.
            modules_dir: Target apm_modules directory.
            parent_chain: Human-readable breadcrumb (e.g. "root > mid")
                showing which dependency path led to this transitive dep.
            parent_pkg: APMPackage that declared *dep_ref*, or None for direct
                deps from the root project. For local deps we use its
                ``source_path`` as the anchor for relative paths so a
                transitive ``../sibling`` resolves against the declaring
                package's directory rather than the root consumer (#857).
        """
        if refuse_before_fetch(dep_ref):
            return None
        install_path = replacement_path = None
        try:
            install_path = _prepare_callback_materialization_path(
                dep_ref,
                modules_dir,
                staging_session,
                materialization_reader,
                callback_lock,
                logger,
            )
            # Cache reuse stays behind the canonical ref-drift owner.
            if install_path.exists():
                _locked_for_recheck = (
                    existing_lockfile.get_dependency(dep_ref.get_unique_key())
                    if existing_lockfile
                    else None
                )
                if not should_force_ref_recheck(
                    dep_ref,
                    _locked_for_recheck,
                    update_refs=update_refs,
                    package_path=install_path,
                    update_keys=update_keys,
                ) or (dep_ref.is_local and staging_session.owns_path(install_path)):
                    return install_path
            replacement_path = staging_session.prepare_replacement(install_path)
            # Emit progress only after the cache fast path decides to fetch.
            if logger:
                with callback_lock:
                    _display = dep_ref.get_display_name()
                    _tui = getattr(ctx, "tui", None)
                    if _tui is not None:
                        _tui.task_started(dep_ref.get_unique_key(), f"resolve {_display}")
                    if _tui is None or not _tui.is_animating():
                        logger.resolving_heartbeat(_display)
            # ─── Registry-sourced dep (design §8) ──────────────────────
            # Routed before local/git so the registry resolver owns the
            # download for source=="registry" entries. Lockfile re-installs
            # may arrive with registry_name=None — look it up by URL prefix
            # against the configured registries map.
            if dep_ref.source == "registry":
                from apm_cli.deps.registry.feature_gate import (
                    require_package_registry_enabled,
                )

                require_package_registry_enabled("Registry-sourced downloads")

                if registry_resolver is None:
                    raise RuntimeError(
                        f"dep {dep_ref.repo_url!r} is registry-sourced but no "
                        f"registries: block is configured in apm.yml and the "
                        f"lockfile carries no resolved_url for it."
                    )
                dep_ref = _apply_lockfile_registry_name(
                    dep_ref,
                    registries_map,
                    existing_lockfile=existing_lockfile,
                )
                # Registry T5: honor lockfile on apm install (mirrors git T5
                # at lines below). When the lockfile has full replay data and
                # the manifest range still covers the locked version, fetch
                # from the locked URL and verify against the locked hash
                # (npm install model — no /versions API call).
                _locked_reg = (
                    existing_lockfile.get_dependency(dep_ref.get_unique_key())
                    if existing_lockfile
                    else None
                )
                if (
                    not update_refs
                    and _locked_reg
                    and _locked_reg.resolved_url
                    and _locked_reg.resolved_hash
                    and _locked_reg.version
                ):
                    from apm_cli.drift import detect_ref_change as _detect_ref_change

                    if not _detect_ref_change(dep_ref, _locked_reg, update_refs=False):
                        registry_resolver.download_from_lockfile(
                            dep_ref,
                            replacement_path,
                            resolved_url=_locked_reg.resolved_url,
                            resolved_hash=_locked_reg.resolved_hash,
                            version=_locked_reg.version,
                        )
                        with callback_lock:
                            pending_callback_downloads[replacement_path] = (
                                dep_ref.get_unique_key(),
                                None,
                            )
                        return replacement_path
                download_registry_package(ctx, dep_ref, replacement_path, _locked_reg)
                _annotate_registry_dep_ref(dep_ref, registry_resolver)
                # Mark as downloaded so pre-download skips it; registry deps have no SHA.
                with callback_lock:
                    pending_callback_downloads[replacement_path] = (
                        dep_ref.get_unique_key(),
                        None,
                    )
                return replacement_path

            # Handle local packages: copy instead of git clone
            if dep_ref.is_local and dep_ref.local_path:
                # The declaring package anchors relative paths (#857, #4153).
                failure = copy_local_dependency(
                    dep_ref,
                    replacement_path,
                    declaring_dir=(
                        parent_pkg.source_path
                        if dep_ref.replacement is None and parent_pkg is not None
                        else None
                    ),
                    source_root=source_root,
                    user_scope=scope is InstallScope.USER,
                )
                dep_key = dep_ref.get_unique_key()
                with callback_lock:
                    if failure is None:
                        pending_callback_downloads[replacement_path] = (dep_key, None)
                        return replacement_path
                    callback_failures.add(dep_key)  # the barrier stops (#3874)
                    if dep_key in direct_dep_keys and logger:
                        logger.error(failure)
                    elif dep_key not in direct_dep_keys:
                        via = f" (via {parent_chain})" if parent_chain else ""
                        transitive_failures.append(
                            (
                                dep_ref.local_path,
                                f"Failed to resolve transitive dep {dep_ref.local_path}{via}: "
                                f"{failure}",
                            )
                        )
                _tui = getattr(ctx, "tui", None)
                if _tui is not None:
                    _tui.task_failed(dep_key)
                return None

            # --- Git-source semver range resolution (issue #1488) ---
            # When the manifest carries a semver range as ``ref:`` and
            # the dep is non-local, non-registry, and non-proxy, resolve
            # it to a concrete tag BEFORE any git operation. The result
            # is stashed on ctx so install/sources.py can plumb it into
            # the lockfile, and the dep_ref's ``reference`` is replaced
            # with the concrete tag so build_download_ref / clone use a
            # literal git ref.
            _semver_resolution = _maybe_resolve_git_semver(
                dep_ref=dep_ref,
                existing_lockfile=existing_lockfile,
                update_refs=update_refs,
                auth_resolver=ctx.auth_resolver,
                ref_resolver_cache=ctx.ref_resolver_cache,
                ref_resolver_cache_lock=callback_lock,
                transport_selector=ctx.downloader._transport_selector,
                protocol_pref=ctx.downloader._protocol_pref,
            )
            if _semver_resolution is not None:
                with callback_lock:
                    ctx.git_semver_resolutions[dep_ref.get_unique_key()] = _semver_resolution
                # Rewrite the dep_ref's ref to the concrete tag so the
                # rest of the pipeline (drift detection, download, etc.)
                # operates on a literal git ref. The original constraint
                # is preserved in the resolution dataclass.
                dep_ref.reference = _semver_resolution.resolved_tag

            # T5: Use locked commit for reproducibility, unless the manifest
            # ref has drifted from what the lockfile recorded (spec drift).
            _locked_dep = (
                existing_lockfile.get_dependency(dep_ref.get_unique_key())
                if existing_lockfile
                else None
            )
            _ref_changed = detect_ref_change(dep_ref, _locked_dep, update_refs=update_refs)

            # When ref drifts, signal downstream that a content-hash change
            # is expected so the supply-chain check in sources.py doesn't
            # treat a legitimate re-resolution as an attack.
            if _ref_changed:
                with callback_lock:
                    ctx.expected_hash_change_deps.add(dep_ref.get_unique_key())
                if logger:
                    _old = (
                        _locked_dep.resolved_ref
                        or (_locked_dep.resolved_commit or "")[:8]
                        or "unresolved"
                        if _locked_dep
                        else "?"
                    )
                    _new = dep_ref.reference or "HEAD"
                    logger.verbose_detail(
                        f"  [!] Spec drift: {dep_ref.get_unique_key()} "
                        f"{_old} -> {_new}, re-resolving"
                    )

            download_dep = build_download_ref(
                dep_ref,
                existing_lockfile,
                update_refs=update_refs,
                ref_changed=_ref_changed,
            )

            # Silent download - no progress display for transitive deps
            result = downloader.download_package(download_dep, replacement_path)
            # Capture resolved commit SHA for lockfile
            resolved_sha = None
            if result and hasattr(result, "resolved_reference") and result.resolved_reference:
                # Download wins over cached pre-plan state; tiered re-resolution is cheap.
                dep_ref.resolved_reference = result.resolved_reference
                resolved_sha = result.resolved_reference.resolved_commit
            callback_downloaded_value = resolved_sha
            with callback_lock:
                pending_callback_downloads[replacement_path] = (
                    dep_ref.get_unique_key(),
                    callback_downloaded_value,
                )
                ctx.package_carried_licenses[dep_ref.get_unique_key()] = result.carried_licenses
            return replacement_path
        except Exception as e:
            if replacement_path is not None:
                e = _discard_failed_download(staging_session, replacement_path, e)
            dep_display = dep_ref.get_display_name()
            dep_key = dep_ref.get_unique_key()
            is_direct = dep_key in direct_dep_keys

            # Distinguish resolution failures (git-semver no-match) from
            # download failures: the dep_ref was rewritten to a concrete
            # tag BEFORE clone, so a NoMatchingTagError means we never
            # got to the download step. Using "download" as the verb
            # would mislead users who are debugging an unsatisfied
            # constraint -- nothing was downloaded yet.
            from apm_cli.deps.git_semver_resolver import NoMatchingTagError
            from apm_cli.models.dependency.reference import InvalidSemverRangeError

            if isinstance(e, InvalidSemverRangeError):
                if is_direct:
                    fail_msg = f"Invalid dependency spec for {dep_ref.repo_url}: {e}"
                else:
                    chain_hint = f" (via {parent_chain})" if parent_chain else ""
                    fail_msg = (
                        f"Invalid dependency spec for transitive dep "
                        f"{dep_ref.repo_url}{chain_hint}: {e}"
                    )
            elif isinstance(e, NoMatchingTagError):
                if is_direct:
                    fail_msg = f"No matching tag for {dep_ref.repo_url}: {e}"
                else:
                    chain_hint = f" (via {parent_chain})" if parent_chain else ""
                    fail_msg = (
                        f"No matching tag for transitive dep {dep_ref.repo_url}{chain_hint}: {e}"
                    )
            # Distinguish direct vs transitive failure messages so users
            # don't see a misleading "transitive dep" label for top-level deps.
            elif is_direct:
                fail_msg = f"Failed to download dependency {dep_ref.repo_url}: {e}"
            else:
                chain_hint = f" (via {parent_chain})" if parent_chain else ""
                fail_msg = f"Failed to resolve transitive dep {dep_ref.repo_url}{chain_hint}: {e}"
            fail_msg = with_preserved_install_hint(fail_msg, install_path)
            fail_msg += not_found_next_step(
                e, dep_ref, is_direct=is_direct, scope=getattr(ctx, "scope", None)
            )

            with callback_lock:
                callback_failures.add(dep_key)
                transitive_failures.append((dep_display, fail_msg))
            _tui = getattr(ctx, "tui", None)
            if _tui is not None:
                _tui.task_failed(dep_key)
            return None

    # ------------------------------------------------------------------
    # 6. Resolver creation + dependency resolution
    # ------------------------------------------------------------------
    from apm_cli.install.commit_gate import policy_depth_limit
    from apm_cli.install.legacy_plugin_compat import validate_cached_legacy_plugin
    from apm_cli.install.service import InstallService

    depth_policy, max_depth = policy_depth_limit(ctx)
    resolver = APMDependencyResolver(
        max_depth=max_depth,
        apm_modules_dir=ctx.apm_modules_dir,
        download_callback=download_callback,
        activation_callback=partial(
            _activate_validated_candidate,
            staging_session=staging_session,
            pending_downloads=pending_callback_downloads,
            callback_downloaded=callback_downloaded,
            callback_lock=callback_lock,
            tui=getattr(ctx, "tui", None),
            callback_content_hashes=ctx.callback_content_hashes,
        ),
        auth_resolver=ctx.auth_resolver,
        update_refs=update_refs,
        update_keys=update_keys,
        existing_lockfile=existing_lockfile,
        reference_resolver=downloader,
        frozen=InstallService.frozen_disposition(ctx).replay,
        preview=ctx.dry_run,
        cache_validation_callback=partial(
            validate_cached_legacy_plugin,
            lockfile=existing_lockfile,
            fetched_this_run=False,
        ),
    )

    # The graph reads source_root; apm_modules_dir remains the deployment root.
    dependency_graph = _build_dependency_graph(ctx, resolver)
    _judge_resolution(ctx, dependency_graph, transitive_failures, depth_policy, resolver)

    # Fold remote-parent local_path rejections into ``callback_failures`` so
    # the integrate phase skips them via the same gate used for download
    # failures (PR #1111 review C2). The resolver has already emitted the
    # red ERROR notice; here we just propagate the dep_key.
    rejected_remote_local = getattr(resolver, "_rejected_remote_local_keys", set())
    if rejected_remote_local:
        callback_failures.update(rejected_remote_local)

    # Check for circular dependencies
    if dependency_graph.circular_dependencies:
        if ctx.logger:
            ctx.logger.error("Circular dependencies detected:")
        for circular in dependency_graph.circular_dependencies:
            cycle_path = " -> ".join(circular.cycle_path)
            if ctx.logger:
                ctx.logger.error(f"  {cycle_path}")
        raise RuntimeError("Cannot install packages with circular dependencies")

    # Get flattened dependencies for installation
    flat_deps = dependency_graph.flattened_dependencies
    deps_to_install = flat_deps.get_installation_list()
    report_resolved_dependencies(ctx, resolver, deps_to_install, dependency_graph.dependency_tree)

    _check_insecure_dependencies(
        project_manifest_dependencies(ctx.apm_package),
        ctx.allow_insecure,
        ctx.logger,
    )
    insecure_infos = _collect_insecure_dependency_infos(
        deps_to_install,
        dependency_graph,
    )
    _warn_insecure_dependencies(insecure_infos, ctx.logger)
    _guard_transitive_insecure_dependencies(
        insecure_infos,
        ctx.logger,
        allow_insecure=ctx.allow_insecure,
        allow_insecure_hosts=ctx.allow_insecure_hosts,
    )

    ctx.deps_to_install = annotate_update_plan_refs(
        deps_to_install,
        downloader,
        update_refs=update_refs,
        # A dependency refused by identity is never contacted, not even for its ref.
        failed_keys=callback_failures
        | {dep.get_unique_key() for dep in ctx.prefetch_policy_denials},
    )

    # ------------------------------------------------------------------
    # 7.5 Build dep_key -> parent source_path map for transitive locals
    # ------------------------------------------------------------------
    # Local deps declared by a transitive parent must be anchored on the
    # parent's source dir, not on the consumer's project root (#857). We
    # walk the dependency tree once here and stash the per-dep base_dir
    # for the integrate phase to consume.
    #
    # Keying caveat (PR #1111 review C3): the map is keyed by
    # ``dep_ref.get_unique_key()``, which for local deps is the raw
    # ``local_path`` string. Two different parents that both declare the
    # same relative ``local_path`` (e.g. both write ``../base``) collapse
    # to the same key. In the current architecture this collision is
    # latent: the BFS walk in ``APMDependencyResolver`` already dedupes
    # by ``get_unique_key()`` so only one node ever exists for that key,
    # and ``DependencyReference.get_install_path`` shares the same
    # ``apm_modules/_local/<basename>`` slot regardless of the parent.
    # That means today the "second parent wins" question never actually
    # fires -- the second occurrence is dropped at queue-time. We still
    # detect divergent-anchor writes here and warn loudly, both because
    # silent first-wins behaviour would mask a real bug if BFS dedup ever
    # changes, and because the warning gives the user a path to diagnose
    # surprising layouts (e.g. ``../base`` from two parents resolving to
    # different absolute directories).
    dep_base_dirs: builtins.dict[str, Path] = {}
    try:
        tree = dependency_graph.dependency_tree
        for node in tree.nodes.values():
            # Only declaring-package dirs; path_anchoring decides the rest.
            parent_node = node.parent
            if node.dependency_ref.replacement is not None or parent_node is None:
                continue
            anchor = getattr(parent_node.package, "source_path", None)
            if anchor is None:
                continue
            key = node.dependency_ref.get_unique_key()
            existing = dep_base_dirs.get(key)
            if existing is not None and existing != anchor:
                # Divergent anchors for the same dep key. Keep the first
                # (deterministic) and surface the conflict so the user can
                # rename one of the colliding refs or use absolute paths.
                _logger.warning(
                    "Local dep %r is referenced from two parents with "
                    "different anchors (%s vs %s). Using the first; "
                    "rename one of the local_path values or use absolute "
                    "paths to disambiguate.",
                    key,
                    existing,
                    anchor,
                )
                continue
            dep_base_dirs[key] = anchor
    except (AttributeError, KeyError):
        # Tree shape may differ across releases; fall back to empty map
        # (callers fall back to the root anchor in path_anchoring).
        # Narrow set: real bugs (TypeError/NameError) should surface, not
        # silently degrade to legacy anchoring.
        dep_base_dirs = {}
    ctx.dep_base_dirs = dep_base_dirs

    ctx.callback_downloaded = callback_downloaded
    ctx.callback_failures = callback_failures
    ctx.transitive_failures = transitive_failures

    # WS2a (#1116): release shared clone temp dirs now that all subdir
    # deps have extracted their subpaths.  Safe to call even if no
    # subdir deps were processed (no-op in that case).
    shared_cache = getattr(ctx.downloader, "shared_clone_cache", None)
    if shared_cache is not None:
        shared_cache.cleanup()

    # Perf #1433: emit ref-resolver tier hit counts at the end of the
    # resolve phase. Verbose only; one line; lets reviewers see which
    # waterfall tier carried the run without attaching a debugger.
    if ctx.logger is not None and ctx.ref_resolver is not None:
        _tier_stats = getattr(ctx.ref_resolver, "stats", None)
        if _tier_stats:
            # tier_summary is install-only; other loggers degrade silently.
            if hasattr(ctx.logger, "tier_summary"):
                ctx.logger.tier_summary(_tier_stats)


def _apply_only_filter(ctx: InstallContext) -> None:
    """Filter ``ctx.deps_to_install`` to the ``--only`` package(s) and their subtrees."""
    from apm_cli.install.package_selection import selected_subtree_dependencies

    ctx.deps_to_install = selected_subtree_dependencies(
        ctx.only_packages, ctx.dependency_graph.dependency_tree, ctx.deps_to_install
    )


def _record_update_plan_complete_dep_keys(ctx: InstallContext) -> None:
    """Record complete graph keys before selective update filtering."""
    ctx.update_plan_complete_dep_keys = builtins.set(
        dep.get_unique_key() for dep in ctx.deps_to_install
    )


def _record_partial_subtree_reconciliation(ctx: InstallContext) -> None:
    """Classify the selected packages' previous descendants for a partial install."""
    if not ctx.only_packages or ctx.existing_lockfile is None:
        return
    from apm_cli.install.package_selection import previous_selected_subtree_keys

    # An incomplete graph cannot prove that no retained package still needs a
    # candidate, so a failed resolution keeps every previous entry.
    dropped, rescued = previous_selected_subtree_keys(
        ctx.only_packages,
        ctx.all_apm_deps,
        ctx.existing_lockfile,
        None if ctx.callback_failures else ctx.update_plan_complete_dep_keys,
    )
    ctx.partial_dropped_dep_keys = dropped
    ctx.partial_rescued_dep_keys = rescued


def _compute_intended_dep_keys(ctx: InstallContext) -> None:
    """Populate ``ctx.intended_dep_keys`` (manifest-intent set for orphan cleanup)."""
    # ------------------------------------------------------------------
    # 8. Orphan detection: intended_dep_keys
    # ------------------------------------------------------------------
    ctx.intended_dep_keys = builtins.set(d.get_unique_key() for d in ctx.deps_to_install)


def run(ctx: InstallContext) -> None:
    """Execute the resolve phase.

    On return every field listed in the *Resolve phase outputs* section of
    :class:`~apm_cli.install.context.InstallContext` is populated.
    """
    _load_lockfile(ctx)
    if ctx.only_packages and ctx.existing_lockfile is not None:
        from apm_cli.install.plan import lockfile_satisfies_replacements

        unchanged, _ = lockfile_satisfies_replacements(
            ctx.existing_lockfile, getattr(ctx.apm_package, "replace_rules", None)
        )
        if not unchanged:
            advice = REPLACEMENT_RULES_PARTIAL_INSTALL.sentence()
            raise RuntimeError(f"Replacement rules changed during a partial install. {advice}")
    _ensure_modules_dir(ctx)
    staging_session = resolution_for_context(ctx)
    materialization_reader = _materialization.CachedMaterializationPathReader()
    _prepare_existing_materialization_paths(ctx, staging_session, materialization_reader)
    _setup_downloader(ctx)
    seed_ref_resolver_from_lockfile(ctx)
    _resolve_dependencies(ctx, staging_session, materialization_reader)
    _record_update_plan_complete_dep_keys(ctx)
    _record_partial_subtree_reconciliation(ctx)
    if ctx.only_packages:
        from apm_cli.install.package_selection import with_unlocked_local_dependencies

        complete = ctx.deps_to_install
        _apply_only_filter(ctx)
        ctx.deps_to_install = with_unlocked_local_dependencies(ctx, complete)
    _compute_intended_dep_keys(ctx)
