"""Target detection and integrator initialization phase.

Reads ``ctx.target_override``, ``ctx.apm_package``, ``ctx.scope``,
``ctx.project_root``; populates ``ctx.targets`` (list of
:class:`~apm_cli.integration.targets.TargetProfile`) and
``ctx.integrators`` (dict of per-primitive-type integrator instances).

This is the second phase of the install pipeline, running after resolve.
"""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path
from typing import TYPE_CHECKING, Any

from apm_cli.core.deprecations import deprecation_message

if TYPE_CHECKING:
    from apm_cli.install.context import InstallContext
    from apm_cli.integration.targets import TargetProfile


def _package_target_value(apm_package: Any) -> str | list[str] | None:
    """Return the package's declared target selection from the declaration owner."""
    from apm_cli.models.apm_package import package_target_selection

    return package_target_selection(apm_package)


def _raise_target_usage_error(ctx: Any, exc: Exception) -> None:
    """Render target field user errors consistently before exiting."""
    if ctx.logger:
        ctx.logger.error(str(exc), symbol="error")
    raise SystemExit(2) from exc


def reject_undeployable_manifest_targets(apm_package: Any, logger: Any) -> None:
    """Exit 2 before any write when the manifest declares a target install cannot deploy."""
    from apm_cli.core.errors import TargetResolutionError
    from apm_cli.models.apm_package import package_target_declaration

    try:
        package_target_declaration(apm_package).validate_for_install()
    except TargetResolutionError as exc:
        if logger:
            logger.error(str(exc), symbol="error")
            logger.render_summary()
        raise SystemExit(2) from exc


def _as_yaml_targets(value: str | list[str] | None) -> list[str] | None:
    """Normalize a package target value to the v2 yaml_targets shape."""
    if value is None:
        return None
    if isinstance(value, str):
        parts = [t.strip() for t in value.split(",") if t.strip()]
    else:
        parts = [str(t).strip() for t in value if str(t).strip()]
    return parts or None


def _normalize_runtime_target_aliases(tokens: Iterable[str]) -> list[str]:
    """Map runtime aliases to canonical target names in first-seen order."""
    from apm_cli.integration.targets import RUNTIME_TO_CANONICAL_TARGET

    normalized: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        raw = str(token).strip()
        if not raw:
            continue
        canonical = RUNTIME_TO_CANONICAL_TARGET.get(raw, raw)
        if canonical in seen:
            continue
        seen.add(canonical)
        normalized.append(canonical)
    return normalized


def _read_yaml_targets(ctx) -> list[str] | None:
    """Return the names the package manifest restricts deployment to.

    ``None`` when nothing restricting is declared (including legacy ``all``).
    Raises ConflictingTargetsError if both keys appear.
    """
    if ctx.apm_package is None:
        return None
    from apm_cli.models.apm_package import package_target_declaration

    return package_target_declaration(ctx.apm_package).restriction()


def declared_target_profiles(ctx: InstallContext) -> list[TargetProfile] | None:
    """Return the scope-applied target profiles whose lockfile entries are legitimate.

    Reads ``targets:``/``target:`` from the consumer's ``apm.yml``, maps the
    canonical names to :class:`~apm_cli.integration.targets.TargetProfile`
    instances scoped the same way ``ctx.targets`` is, and augments them with
    non-canonical gated/dynamic target metadata without probing inactive roots
    (see below). Returns ``None`` when the manifest declares no targets
    (auto-detect or ``--target``-only consumers) -- the signal for lockfile
    reconciliation to fall back to legacy preserve-all.

    Motivation (issue #2059): ``union_preserving`` must distinguish a target the
    consumer legitimately uses but did not install in THIS run (e.g. a
    ``--target``-narrowed sibling target -- preserve) from a target the consumer
    NEVER declares (e.g. a dependency's package-declared ``windsurf`` paths the
    consumer has not activated). The latter are inactive-target *ghosts*: they
    can never be written on disk, yet a plain target-scoped union re-preserves
    them on every install, so ``apm audit --ci`` fails ``deployed-files-present``
    permanently on fresh checkouts. Knowing the declared universe lets the union
    drop those ghosts while still honouring the #1716 multi-target contract.
    """
    from apm_cli.core.scope import InstallScope
    from apm_cli.install.manifest_reconcile import (
        declared_target_profiles as profiles_for_project,
    )

    is_user = getattr(ctx, "scope", None) is InstallScope.USER
    apm_package = getattr(ctx, "apm_package", None)
    package_path = getattr(apm_package, "package_path", None)
    if package_path is None:
        return None
    return profiles_for_project(
        Path(package_path),
        user_scope=is_user,
        active_targets=getattr(ctx, "targets", None),
        diagnostics=getattr(ctx, "diagnostics", None),
    )


def _create_target_dirs(
    targets: Iterable[TargetProfile],
    project_root: Path,
    explicit: str | None,
    logger: Any = None,
) -> list[Path]:
    """Create root_dir for each target when auto_create=True or explicit is set.

    Targets that resolve to an external deploy root (``resolved_deploy_root``)
    are skipped: their directories live outside the project tree and are
    created by the integrator's deploy logic, not here.

    Returns the list of directories actually created.
    """
    created: list[Path] = []
    for _t in targets:
        if not _t.auto_create and not explicit:
            continue
        if _t.resolved_deploy_root is not None:
            continue
        if _t.skills_only:
            # The skill integrator creates the root when it writes a skill, so
            # an install that deploys nothing leaves no empty directory behind.
            continue
        _root = _t.root_dir
        _target_dir = project_root / _root
        if not _target_dir.exists():
            try:
                _target_dir.mkdir(parents=True, exist_ok=True)
            except PermissionError:
                if logger:
                    _display_root = f"~/{_root}/"
                    logger.error(
                        f"Cannot create {_display_root} -- permission denied. "
                        f"Check directory permissions or use a different --target."
                    )
                raise SystemExit(1) from None
            created.append(_target_dir)
            if logger:
                logger.verbose_detail(f"Created {_root}/ ({_t.name} target)")
    return created


def _check_openclaw_flag_gate(
    explicit: str | list[str] | None,
    targets: list,
    ctx: InstallContext,
) -> None:
    """Emit an enable-hint when the user asks for openclaw but the flag is OFF."""
    _check_experimental_target_hint(explicit, targets, ctx, target_name="openclaw")


def _check_grok_cloud_flag_gate(
    explicit: str | list[str] | None,
    targets: list,
    ctx: InstallContext,
) -> None:
    """Emit an enable hint when grok-cloud is requested while disabled."""
    _check_experimental_target_hint(
        explicit,
        targets,
        ctx,
        target_name="grok-cloud",
    )


def _check_experimental_target_hint(
    explicit: str | list[str] | None,
    targets: list,
    ctx: InstallContext,
    *,
    target_name: str,
) -> None:
    """Emit an enable hint when *target_name* is requested but its flag is disabled.

    Shared by the simple experimental targets whose only gate is the
    experimental flag (no extra environment requirement).
    """
    user_asked = False
    if explicit:
        if isinstance(explicit, list):
            user_asked = target_name in explicit
        else:
            user_asked = explicit == target_name
    if not user_asked:
        return

    from apm_cli.install.target_hints import emit_disabled_experimental_target_hint

    emit_disabled_experimental_target_hint(
        target_name,
        targets,
        ctx.logger,
        create_config=getattr(ctx, "create_config", True),
    )


def _gate_cowork_target(
    ctx: InstallContext,
    targets: list,
    explicit: str | list[str] | None,
    is_user: bool,
) -> None:
    """Apply cowork-target gating rules.

    Checks whether the user explicitly requested copilot-cowork and, if so,
    whether the experimental flag is enabled and the target resolved.
    Also enforces the project-scope gate (cowork requires ``--global``).
    May call ``raise SystemExit(1)`` when a gate condition is violated.
    """
    user_asked_cowork = False
    if explicit:
        if isinstance(explicit, list):
            user_asked_cowork = "copilot-cowork" in explicit
        else:
            user_asked_cowork = explicit == "copilot-cowork"

    if user_asked_cowork:
        _cowork_resolved = any(t.name == "copilot-cowork" for t in targets)
        if not _cowork_resolved:
            from apm_cli.install.target_hints import emit_disabled_experimental_target_hint

            if not emit_disabled_experimental_target_hint(
                "copilot-cowork",
                targets,
                ctx.logger,
                create_config=getattr(ctx, "create_config", True),
            ):
                import sys as _sys

                from apm_cli.core.remediation import COWORK_SKILLS_DIR_REQUIRED

                _cowork_fix = (
                    f"Set APM_COPILOT_COWORK_SKILLS_DIR, or {COWORK_SKILLS_DIR_REQUIRED.clause()}."
                )
                if _sys.platform.startswith("linux"):
                    _cowork_msg = f"Cowork has no auto-detection on Linux.\n{_cowork_fix}"
                else:
                    _cowork_msg = f"Cowork: no OneDrive path detected.\n{_cowork_fix}"
                if ctx.logger:
                    ctx.logger.error(_cowork_msg, symbol="cross")
                raise SystemExit(1)

    # Amendment 5: project-scope gate for cowork target.
    if not is_user:
        _cowork_in_set = any(t.name == "copilot-cowork" for t in targets)
        if _cowork_in_set:
            if ctx.logger:
                from apm_cli.core.remediation import COWORK_TARGET_USER_SCOPE

                ctx.logger.error(
                    "The 'copilot-cowork' target requires --global (user scope). "
                    + COWORK_TARGET_USER_SCOPE.sentence()
                )
            raise SystemExit(1)


def _gate_copilot_app_target(
    ctx: InstallContext,
    targets: list,
    explicit: str | list[str] | None,
) -> None:
    """Apply copilot-app target gating rules.

    Checks whether the user explicitly requested copilot-app and, if so,
    whether the experimental flag is enabled and the app is installed.
    May call ``raise SystemExit(1)`` when a gate condition is violated.
    """
    user_asked_copilot_app = False
    if explicit:
        if isinstance(explicit, list):
            user_asked_copilot_app = "copilot-app" in explicit
        else:
            user_asked_copilot_app = explicit == "copilot-app"

    if not user_asked_copilot_app:
        return

    _copilot_app_resolved = any(t.name == "copilot-app" for t in targets)
    if _copilot_app_resolved:
        return

    from apm_cli.install.target_hints import emit_disabled_experimental_target_hint

    if not emit_disabled_experimental_target_hint(
        "copilot-app",
        targets,
        ctx.logger,
        create_config=getattr(ctx, "create_config", True),
    ):
        _app_msg = (
            "GitHub Copilot desktop App not detected.\n"
            "Expected ~/.copilot/data.db but the file is missing.\n"
            "Install the app, or omit '--target copilot-app'."
        )
        if ctx.logger:
            ctx.logger.error(_app_msg, symbol="cross")
        raise SystemExit(1)


def _resolve_targets_by_scope(
    ctx: InstallContext,
    targets: list,
    explicit: str | list[str] | None,
    is_user: bool,
) -> list:
    """Resolve targets for either project scope (v2) or user scope (legacy).

    For project scope, applies the v2 resolution algorithm with signal-based
    provenance, replacing the legacy target list with the v2 list while
    preserving any non-canonical targets (e.g. copilot-cowork).

    For user scope, emits diagnostic logging and creates target directories
    via :func:`_create_target_dirs`.

    Returns the effective ``_targets`` list.
    """
    import click as _click

    from apm_cli.core.target_detection import format_provenance
    from apm_cli.core.target_detection import resolve_targets as _resolve_targets_v2

    if is_user:
        # User-scope: legacy target directory creation and logging.
        if ctx.logger:
            if targets:

                def _fmt_target(t: Any) -> str:
                    if t.resolved_deploy_root is not None:
                        return f"{t.name} ({t.resolved_deploy_root})"
                    return f"{t.name} (~/{t.root_dir}/)"

                _target_names = ", ".join(_fmt_target(t) for t in targets)
                ctx.logger.verbose_detail(f"Active global targets: {_target_names}")
                from apm_cli.deps.lockfile import get_lockfile_path

                ctx.logger.verbose_detail(f"Lockfile: {get_lockfile_path(ctx.apm_dir)}")
            else:
                ctx.logger.warning(
                    "No global targets resolved -- nothing will be "
                    "deployed. Check 'target:' in apm.yml or use --target."
                )
        ctx.created_target_roots.extend(
            _create_target_dirs(targets, ctx.project_root, explicit, ctx.logger)
        )
        return targets

    # Project scope: v2 resolution.
    from apm_cli.core.apm_yml import CANONICAL_TARGETS as _CANONICAL

    _v2_flag: str | list[str] | None = None
    if ctx.target_override:
        raw_override = ctx.target_override
        if isinstance(raw_override, str):
            parts = [t.strip() for t in raw_override.split(",") if t.strip()]
        else:
            parts = list(raw_override)
        from apm_cli.core.target_catalog import expand_all

        parts = [
            expanded
            for part in parts
            for expanded in (expand_all("install") if part == "all" else (part,))
        ]
        # Multi-token CLI parsing returns runtime aliases; convert them before filtering.
        parts = _normalize_runtime_target_aliases(parts)
        parts = [p for p in parts if p in _CANONICAL]
        if len(parts) == 1:
            _v2_flag = parts[0]
        elif len(parts) > 1:
            _v2_flag = parts

    _v2_yaml: list[str] | None = None
    if _v2_flag is None and not ctx.target_override:
        try:
            _v2_yaml = _read_yaml_targets(ctx)
        except _click.UsageError as exc:
            _raise_target_usage_error(ctx, exc)

    _skip_v2 = _v2_flag is None and _v2_yaml is None and ctx.target_override is not None
    if _skip_v2:
        return targets

    try:
        _resolved = _resolve_targets_v2(
            ctx.project_root,
            flag=_v2_flag,
            yaml_targets=_v2_yaml,
            flag_source=getattr(ctx, "target_override_source", None) or "--target flag",
        )
    except _click.UsageError as exc:
        if ctx.logger:
            ctx.logger.error(str(exc), symbol="error")
        raise SystemExit(2) from exc

    _provenance_msg = format_provenance(_resolved)
    from apm_cli.install import verdict_attest

    verdict_attest.note_run_targets(_provenance_msg)
    if ctx.logger:
        ctx.logger.announce_targets(_provenance_msg)
    else:
        from apm_cli.utils.console import _rich_info

        _rich_info(_provenance_msg, symbol="info")

    from apm_cli.integration.targets import materialize_project_target_profiles

    try:
        _v2_targets = materialize_project_target_profiles(
            ctx.project_root, _resolved.targets, ctx.created_target_roots
        )
    except PermissionError as exc:
        if ctx.logger:
            ctx.logger.error(
                f"Cannot create target directory -- permission denied: {exc}. "
                "Check directory permissions or use a different --target."
            )
        raise SystemExit(1) from None

    _v2_names = {t.name for t in _v2_targets}
    _legacy_only = [t for t in targets if t.name not in _v2_names and t.name not in _CANONICAL]
    return _v2_targets + _legacy_only


def run(ctx: InstallContext) -> None:
    """Execute the targets phase.

    On return ``ctx.targets`` and ``ctx.integrators`` are populated.
    """

    import click as _click

    from apm_cli.core.scope import InstallScope
    from apm_cli.core.target_detection import (
        detect_target,
    )
    from apm_cli.integration import AgentIntegrator, PromptIntegrator
    from apm_cli.integration.canvas_integrator import CanvasIntegrator
    from apm_cli.integration.command_integrator import CommandIntegrator
    from apm_cli.integration.copilot_cowork_paths import CoworkResolutionError
    from apm_cli.integration.hook_integrator import HookIntegrator
    from apm_cli.integration.instruction_integrator import InstructionIntegrator
    from apm_cli.integration.skill_integrator import SkillIntegrator
    from apm_cli.integration.targets import (
        resolve_targets as _resolve_targets_legacy,
    )

    # Get config target from apm.yml if available.
    try:
        config_target = _package_target_value(ctx.apm_package)
    except _click.UsageError as exc:
        _raise_target_usage_error(ctx, exc)

    target_decision = ctx.target_decision
    if target_decision is None:
        from apm_cli.core.target_detection import resolve_effective_target_decision

        target_decision = resolve_effective_target_decision(
            ctx.project_root,
            explicit_target=ctx.target_override,
            manifest_target=config_target,
            user_scope=ctx.scope is InstallScope.USER,
            auto_detect=False,
            create_config=getattr(ctx, "create_config", True),
        )
        ctx.target_decision = target_decision
        ctx.target_override = target_decision.value
        ctx.target_override_source = target_decision.source

    _explicit = target_decision.value
    if _explicit == "all":
        from apm_cli.core.target_catalog import expand_all

        _explicit = list(expand_all("install"))

    # ------------------------------------------------------------------
    # Deprecation warning for legacy '--target agents' alias (cli-review §1)
    # Driven by the raw-token flag set in parse_target_field() so that
    # multi-token inputs like "--target copilot,agents" still surface the
    # warning even after alias resolution collapses "agents" away.
    # ------------------------------------------------------------------
    from apm_cli.core.target_detection import agents_alias_was_detected

    if agents_alias_was_detected():
        if ctx.logger:
            ctx.logger.warning(deprecation_message("target-agents"))

    _is_user = ctx.scope is InstallScope.USER

    # Determine active targets using the legacy resolver first.
    try:
        _targets = _resolve_targets_legacy(
            ctx.project_root,
            user_scope=_is_user,
            explicit_target=_explicit,
        )
    except CoworkResolutionError as exc:
        if ctx.logger:
            ctx.logger.error(str(exc), symbol="cross")
        raise SystemExit(1) from exc

    # Target gating: cowork, copilot-app, openclaw, grok-cloud.
    _gate_cowork_target(ctx, _targets, _explicit, _is_user)
    _gate_copilot_app_target(ctx, _targets, _explicit)
    _check_openclaw_flag_gate(_explicit, _targets, ctx)
    _check_grok_cloud_flag_gate(_explicit, _targets, ctx)

    # Resolve v2 targets for project scope, or set up user-scope dirs.
    _targets = _resolve_targets_by_scope(ctx, _targets, _explicit, _is_user)
    if _is_user and ctx.logger:
        from apm_cli.core.scope import warn_unsupported_user_scope

        if scope_warning := warn_unsupported_user_scope(t.name for t in _targets):
            ctx.logger.warning(scope_warning)

    # Legacy detect_target call -- return values are not consumed by any
    # downstream code but the call is preserved for behaviour parity with
    # the pre-refactor mega-function.
    detect_target(
        project_root=ctx.project_root,
        explicit_target=_explicit if isinstance(_explicit, str) else None,
        config_target=config_target if isinstance(config_target, str) else None,
    )

    # ------------------------------------------------------------------
    # Legacy skill paths opt-out (convergence §3)
    # When --legacy-skill-paths is set (or APM_LEGACY_SKILL_PATHS env),
    # reset deploy_root on skills primitives so they fall back to the
    # per-client root_dir instead of the converged .agents/ directory.
    # ------------------------------------------------------------------
    if ctx.legacy_skill_paths:
        from apm_cli.integration.skill_layout import resolve_skill_layout

        _targets = resolve_skill_layout(_targets, legacy_skill_paths=True)

    # ------------------------------------------------------------------
    # Initialize integrators
    # ------------------------------------------------------------------
    ctx.targets = _targets
    ctx.integrators = {
        "prompt": PromptIntegrator(),
        "agent": AgentIntegrator(),
        "skill": SkillIntegrator(),
        "command": CommandIntegrator(),
        "hook": HookIntegrator(),
        "instruction": InstructionIntegrator(),
        "canvas": CanvasIntegrator(),
    }


def run_targets_phase(ctx) -> None:
    """v2 targets phase entry point using the new resolution algorithm (#1154).

    @internal: Test-only thin wrapper around ``resolve_targets()`` +
    deploy-dir materialization. Production install pipelines go through
    :func:`run` above, which composes legacy and v2 resolution in a single
    pass and emits the provenance line. Do not call this from production
    code paths -- it exists so unit tests can exercise the v2 mapping
    without the legacy ``run()`` setup overhead.

    Uses ``resolve_targets()`` from ``core.target_detection`` to determine
    effective targets, then materializes deploy directories and populates
    ``ctx.targets``.

    This is the three-guard collapse: every resolved target always materializes
    its deploy directory (auto_create=True unconditionally post-resolution).
    """
    from pathlib import Path

    import click as _click

    from apm_cli.core.target_detection import resolve_targets
    from apm_cli.integration.targets import KNOWN_TARGETS

    project_root = Path(ctx.project_root)

    # Determine target override from ctx
    flag: str | list[str] | None = None
    if ctx.target_override:
        if isinstance(ctx.target_override, str):
            # Handle CSV form
            parts = [t.strip() for t in ctx.target_override.split(",") if t.strip()]
        else:
            parts = list(ctx.target_override)
        parts = _normalize_runtime_target_aliases(parts)
        flag = parts if len(parts) > 1 else parts[0] if parts else None

    # Get yaml_targets from apm_package.
    try:
        yaml_targets = _as_yaml_targets(_package_target_value(ctx.apm_package))
    except _click.UsageError as exc:
        _raise_target_usage_error(ctx, exc)

    # Resolve targets
    resolved = resolve_targets(project_root, flag=flag, yaml_targets=yaml_targets)

    # Map resolved target names to TargetProfile objects and materialize dirs
    profiles: list = []
    for target_name in resolved.targets:
        profile = KNOWN_TARGETS.get(target_name)
        if profile is None:
            continue

        target_dir = project_root / profile.root_dir
        if not target_dir.exists() and not profile.skills_only:
            target_dir.mkdir(parents=True, exist_ok=True)

        # NOTE: do NOT set resolved_deploy_root on static targets.
        # That field is reserved for dynamic-root targets (cowork) and is
        # treated as the final deploy destination by downstream integrators.
        # Static targets must follow the standard primitive-mapping path so
        # that ``deploy_root`` (e.g. .agents) and ``subdir`` (e.g. skills)
        # are honored.
        profiles.append(profile)

    ctx.targets = profiles
