"""Install pipeline phases."""
