"""Dependency sources -- Strategy pattern for the install pipeline.

Each ``DependencySource`` knows how to *acquire* one dependency: bring its
files onto disk, build a ``PackageInfo``, register it in the lockfile-bound
state, and return the metadata the integration template needs.

After ``acquire()``, all sources flow through the same template
(``apm_cli.install.template.run_integration_template``) which handles the
security gate, primitive integration, and per-package diagnostics.

This module deliberately contains *only* source-specific logic.  Anything
shared across sources lives in the template.

Sources
-------
- ``LocalDependencySource``: ``file://`` deps copied from the workspace.
- ``CachedDependencySource``: deps already extracted in ``apm_modules/``.
- ``FreshDependencySource``: deps that need a network download (with
  supply-chain hash verification on top of the existing lockfile entry).

The root-project integration (``<project_root>/.apm/``) follows a
substantially different shape (no PackageInfo, dedicated tracking on
``ctx.local_deployed_files``) and is handled separately in
``phases/integrate.py``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from apm_cli.core.scope import manifest_file
from apm_cli.install.errors import DirectDependencyError
from apm_cli.install.primitive_classification import warn_unrecognized_plugin_schema
from apm_cli.install.registry_wiring import (
    get_registry_resolver,
    registry_resolution_for_cached_registry_dep,
    resolver_last_registry_resolution,
)
from apm_cli.install.source_helpers import (
    content_hash_mismatch_hint,
    download_registry_package,
    ensure_carried_licenses_match,
    header_ref,
    locked_content_mismatch,
    locked_content_mismatch_line,
    locked_parent_identity,
    materialized_manifest_snapshot,
    record_carried_package_hash,
    record_package_digests,
    record_package_targets,
    update_accepts_new_content,
)
from apm_cli.install.source_helpers import (
    format_package_type_label as _format_package_type_label,
)
from apm_cli.install.source_helpers import (
    rebuild_cached_semver_resolution as _rebuild_cached_semver_resolution,
)
from apm_cli.install.source_helpers import (
    record_declared_license as _record_declared_license,
)
from apm_cli.models.dependency.host_virtual import (
    dependency_repository_owner,
    repository_path_segments,
)
from apm_cli.utils.console import _rich_success
from apm_cli.utils.short_sha import format_short_sha

if TYPE_CHECKING:
    from apm_cli.install.context import InstallContext
    from apm_cli.models.apm_package import PackageInfo


@dataclass
class Materialization:
    """Outcome of ``DependencySource.acquire()``.

    Carries everything the integration template needs to run the security
    gate + primitive integration on a freshly-acquired package.
    """

    package_info: PackageInfo | None
    install_path: Path
    dep_key: str
    deltas: dict[str, int] = field(default_factory=lambda: {"installed": 0})


class DependencySource(ABC):
    """Strategy: acquire one dependency and prepare it for integration.

    Subclasses encapsulate source-specific concerns (filesystem copy,
    cache reuse, fresh download with progress + hash verification).
    The post-acquire template flow is the same for every source.
    """

    INTEGRATE_ERROR_PREFIX: str = "Failed to integrate primitives"
    """Per-source error wording used by the integration template when
    ``integrate_package_primitives`` raises.  Subclasses override to
    preserve the legacy diagnostic text shown to users."""

    def __init__(
        self,
        ctx: InstallContext,
        dep_ref: Any,
        install_path: Path,
        dep_key: str,
    ):
        self.ctx = ctx
        self.dep_ref = dep_ref
        self.install_path = install_path
        self.dep_key = dep_key

    @abstractmethod
    def acquire(self) -> Materialization | None:
        """Materialise the dependency on disk and build PackageInfo.

        Returns ``None`` to skip integration entirely (e.g. local dep at
        user scope, copy/download failure).  Otherwise returns a
        ``Materialization`` consumed by the integration template.
        """


class LocalDependencySource(DependencySource):
    """Local (``file://``) dependency: copy from a filesystem path."""

    INTEGRATE_ERROR_PREFIX = "Failed to integrate primitives from local package"

    def acquire(self) -> Materialization | None:
        from apm_cli.agent_plugins.errors import AgentPluginError
        from apm_cli.bundle.local_bundle import route_agent_plugin_package
        from apm_cli.core.scope import InstallScope
        from apm_cli.deps._shared import materialize_marketplace_manifest
        from apm_cli.deps.installed_package import (
            InstalledPackage,
            extensions_from_resolved_package,
        )
        from apm_cli.deps.path_anchoring import USER_SCOPE_RELATIVE_PATH_ERROR, local_dep_base_dir
        from apm_cli.install.phases.local_content import _copy_local_package
        from apm_cli.install.source_helpers import package_digests
        from apm_cli.models.apm_package import (
            APMPackage,
            GitReferenceType,
            PackageInfo,
            PackageType,
            ResolvedReference,
        )
        from apm_cli.models.validation import validate_apm_package

        ctx = self.ctx
        dep_ref = self.dep_ref
        install_path = self.install_path
        dep_key = self.dep_key
        diagnostics = ctx.diagnostics
        logger = ctx.logger

        # The declaring package anchors relative paths (#857, #4153); resolve
        # captured it in ``ctx.dep_base_dirs``.
        base_dir = local_dep_base_dir(
            dep_ref.local_path or "",
            declaring_dir=(
                None
                if dep_ref.replacement is not None
                else getattr(ctx, "dep_base_dirs", {}).get(dep_key)
            ),
            source_root=ctx.source_root,
            user_scope=ctx.scope is InstallScope.USER,
        )
        if base_dir is None:
            diagnostics.error(
                f"{dep_ref.local_path} -- {USER_SCOPE_RELATIVE_PATH_ERROR}",
                package=dep_ref.local_path,
            )
            return None
        original_src = Path(dep_ref.local_path).expanduser()
        if not original_src.is_absolute():
            original_src = (base_dir / original_src).resolve()
        else:
            original_src = original_src.resolve()

        try:
            native_detection = (
                route_agent_plugin_package(original_src) if original_src.is_dir() else None
            )
        except AgentPluginError as exc:
            raise DirectDependencyError(f"Local Agent Plugin is invalid: {exc}") from exc
        if native_detection is not None:
            native_gate = validate_apm_package(
                original_src,
                agent_plugin_detection=native_detection,
            )
            if not native_gate.is_valid or native_gate.package is None:
                details = "; ".join(native_gate.errors) or "validator returned no package"
                raise DirectDependencyError(f"Local Agent Plugin is invalid: {details}")

        result_path = _copy_local_package(
            dep_ref,
            install_path,
            base_dir,
            project_root=ctx.project_root,
            logger=logger,
        )
        if not result_path:
            diagnostics.error(
                f"Failed to copy local package: {dep_ref.local_path}",
                package=dep_ref.local_path,
            )
            return None

        if logger:
            logger.download_complete(dep_ref.local_path, ref_suffix="local")

        # Hash the validated copy before synthesis or integration, as frozen preflight does.
        local_digests = package_digests(ctx, install_path)
        materialize_marketplace_manifest(dep_ref, install_path)
        validation = validate_apm_package(
            install_path,
            source_path=original_src,
        )
        if validation.is_valid and validation.package is not None:
            local_pkg = validation.package
            pkg_type = validation.package_type
        elif native_detection is not None:
            details = "; ".join(validation.errors) or "validator returned no package"
            raise DirectDependencyError(f"Local Agent Plugin is invalid: {details}")
        elif validation.legacy_metadata_only:
            local_apm_yml = manifest_file(install_path)
            local_pkg = APMPackage.from_apm_yml(
                local_apm_yml,
                source_path=original_src,
            )
            pkg_type = PackageType.APM_PACKAGE
        else:
            details = "; ".join(validation.errors) or "validator returned no package"
            raise DirectDependencyError(f"Local package is invalid: {details}")
        local_pkg = materialized_manifest_snapshot(local_pkg, install_path, pkg_type)
        warn_unrecognized_plugin_schema(diagnostics, dep_key, install_path)
        if not local_pkg.source:
            local_pkg.source = dep_ref.local_path

        local_ref = ResolvedReference(
            original_ref="local",
            ref_type=GitReferenceType.BRANCH,
            resolved_commit="local",
            ref_name="local",
        )
        local_info = PackageInfo(
            package=local_pkg,
            install_path=install_path,
            resolved_reference=local_ref,
            installed_at=datetime.now().isoformat(),
            dependency_ref=dep_ref,
            package_type=pkg_type,
        )

        # Record for lockfile
        node = ctx.dependency_graph.dependency_tree.get_node(dep_key)
        depth = node.depth if node else 1
        resolved_by = locked_parent_identity(ctx, node)
        _is_dev = node.is_dev if node else False
        ctx.installed_packages.append(
            InstalledPackage(
                dep_ref=dep_ref,
                resolved_commit=None,
                depth=depth,
                resolved_by=resolved_by,
                is_dev=_is_dev,
                registry_config=None,
                package_name=local_info.package.name if local_info.package else None,
                package_version=local_info.package.version if local_info.package else None,
                # req-ext-003: copy the dependency manifest's x-* keys.
                extensions=extensions_from_resolved_package(local_info.package),
            )
        )
        if install_path.is_dir():
            record_package_digests(ctx, dep_key, local_digests)

        if local_info.package_type:
            ctx.package_types[dep_key] = local_info.package_type.value
        _record_declared_license(ctx, dep_key, install_path)
        record_package_targets(ctx, dep_key, install_path)

        return Materialization(
            package_info=local_info,
            install_path=install_path,
            dep_key=dep_key,
        )


class CachedDependencySource(DependencySource):
    """Cached dependency: already extracted under ``apm_modules/``."""

    INTEGRATE_ERROR_PREFIX = "Failed to integrate primitives from cached package"

    def __init__(
        self,
        ctx: InstallContext,
        dep_ref: Any,
        install_path: Path,
        dep_key: str,
        resolved_ref: Any,
        dep_locked_chk: Any,
        fetched_this_run: bool = False,
    ):
        super().__init__(ctx, dep_ref, install_path, dep_key)
        self.resolved_ref = resolved_ref
        self.dep_locked_chk = dep_locked_chk
        # Cached sources may wrap fresh bytes; never treat them as prior cache state.
        self.fetched_this_run = fetched_this_run

    def _resolve_cached_commit(self) -> str | None:
        """Return the commit that identifies the bytes currently on disk.

        Fresh materializations use callback/pre-download identity. True cache
        hits use the verified lockfile identity, never a newer remote result.
        """
        ctx = self.ctx
        dep_key = self.dep_key
        resolved_ref = self._materialized_resolved_ref()
        dep_ref = self.dep_ref

        cached_commit: str | None = None
        lock = ctx.existing_lockfile
        locked_dep = lock.get_dependency(dep_key) if lock else None
        if self.fetched_this_run:
            cached_commit = ctx.callback_downloaded.get(dep_key)
            if (
                not cached_commit
                and resolved_ref
                and resolved_ref.resolved_commit
                and resolved_ref.resolved_commit != "cached"
            ):
                cached_commit = resolved_ref.resolved_commit
        elif locked_dep and locked_dep.resolved_commit and locked_dep.resolved_commit != "cached":
            cached_commit = locked_dep.resolved_commit
        proxy_row = locked_dep is not None and bool(locked_dep.registry_prefix)
        # Registry ranges and registry-proxy rows lock no commit identity (#3657).
        if not cached_commit and dep_ref.source != "registry" and not proxy_row:
            cached_commit = dep_ref.reference
        return cached_commit

    def _cached_source_pin(self, cached_commit: str | None) -> str:
        """Return the full commit these bytes vouch for, else ``cached`` (#3388).

        A true cache hit also needs a matching ``.apm-pin`` marker, so native
        source-pin validation fails closed on short, branch or stale identities.
        """
        from apm_cli.codex_plugins.registrar import is_codex_source_pin
        from apm_cli.install.cache_pin import CachePinError, verify_marker

        if cached_commit is None or not is_codex_source_pin(cached_commit):
            return "cached"
        if not self.fetched_this_run:
            try:
                verify_marker(self.install_path, cached_commit)
            except CachePinError:
                return "cached"
        return cached_commit

    def _materialized_resolved_ref(self) -> Any:
        """Return the reference that produced the bytes currently on disk."""
        pre_download_results = self.ctx.pre_download_results
        pre_downloaded = (
            pre_download_results.get(self.dep_key) if self.dep_key in pre_download_results else None
        )
        pre_downloaded_ref = getattr(pre_downloaded, "resolved_reference", None)
        if self.fetched_this_run and pre_downloaded_ref is not None:
            return pre_downloaded_ref
        return self.resolved_ref or pre_downloaded_ref

    def acquire(self) -> Materialization | None:
        from apm_cli.agent_plugins.errors import AgentPluginError
        from apm_cli.bundle.local_bundle import route_agent_plugin_package
        from apm_cli.deps.installed_package import (
            InstalledPackage,
            extensions_from_resolved_package,
        )
        from apm_cli.install.legacy_plugin_compat import (
            preserve_normalized_marketplace_plugin_type,
            upgrade_cached_legacy_plugin,
        )
        from apm_cli.models.apm_package import (
            APMPackage,
            GitReferenceType,
            PackageInfo,
            PackageType,
            ResolvedReference,
        )
        from apm_cli.models.validation import detect_package_type, validate_apm_package

        ctx = self.ctx
        dep_ref = self.dep_ref
        install_path = self.install_path
        dep_key = self.dep_key
        resolved_ref = self._materialized_resolved_ref()
        dep_locked_chk = self.dep_locked_chk
        logger = ctx.logger

        display_name = str(dep_ref) if dep_ref.is_virtual else dep_ref.repo_url
        _rref = getattr(dep_ref, "resolved_reference", None)
        if _rref and getattr(_rref, "ref_name", None):
            _ref = header_ref(_rref, dep_ref, dep_locked_chk)
        elif dep_locked_chk and getattr(dep_locked_chk, "resolved_ref", None):
            _ref = dep_locked_chk.resolved_ref
        elif dep_ref.source == "registry":
            # Fresh install: exact version lives in the resolver's last_resolutions
            # map (populated by the BFS callback). Fall back to dep_ref.reference
            # only if the resolver has no record (should not normally happen).
            from apm_cli.install.registry_wiring import resolver_last_registry_resolution

            _reg_res = resolver_last_registry_resolution(ctx, dep_key)
            _ref = _reg_res.version if _reg_res else (dep_ref.reference or "")
        else:
            _ref = dep_ref.reference or ""
        # Fresh callback bytes have their own identity, not the previous lock SHA.
        _commit = ctx.callback_downloaded.get(dep_key) if self.fetched_this_run else None
        if not _commit and dep_locked_chk:
            _commit = dep_locked_chk.resolved_commit
        _sha = format_short_sha(_commit) if _commit else ""
        if not _sha:
            _callback_sha = ctx.callback_downloaded.get(dep_key)
            if _callback_sha:
                _sha = format_short_sha(_callback_sha)
        if logger:
            logger.download_complete(
                display_name, ref=_ref, sha=_sha, cached=not self.fetched_this_run
            )

        deltas: dict[str, int] = {"installed": int(self.fetched_this_run)}
        if not dep_ref.reference:
            deltas["unpinned"] = 1

        native_validation = None
        from apm_cli.codex_plugins.manifest import is_codex_compatibility_manifest

        try:
            native_detection = route_agent_plugin_package(install_path)
        except AgentPluginError as exc:
            raise DirectDependencyError(f"Cached Agent Plugin is invalid: {exc}") from exc
        if native_detection is not None:
            native_validation = validate_apm_package(
                install_path,
                source_path=install_path,
                agent_plugin_detection=native_detection,
            )
            if not native_validation.is_valid or native_validation.package is None:
                details = "; ".join(native_validation.errors) or "validator returned no package"
                raise DirectDependencyError(f"Cached Agent Plugin is invalid: {details}")
        elif is_codex_compatibility_manifest(install_path, detect_package_type(install_path)[1]):
            native_validation = validate_apm_package(install_path, source_path=install_path)
            if not native_validation.is_valid or native_validation.package is None:
                details = "; ".join(native_validation.errors) or "validator returned no package"
                raise DirectDependencyError(f"Cached Codex plugin is invalid: {details}")

        # Skip integration entirely if no targets. The template leaves this
        # dependency absent from the integration outcome so cleanup and
        # lockfile reconciliation preserve its prior deployment claims.
        # In lockfile_only mode, skip this early return so installed_packages
        # is populated before we return without deploying any files.
        if not ctx.targets and not ctx.lockfile_only and native_validation is None:
            return Materialization(
                package_info=None,
                install_path=install_path,
                dep_key=dep_key,
                deltas=deltas,
            )

        if native_validation is not None:
            validation_result = native_validation
            cached_package = native_validation.package
            if cached_package is None:
                raise DirectDependencyError(
                    "Cached Agent Plugin validation produced no package metadata"
                )
            pkg_type = validation_result.package_type
        else:
            apm_yml_path = manifest_file(install_path)
            pkg_type, _ = detect_package_type(install_path)
            pkg_type = preserve_normalized_marketplace_plugin_type(
                install_path,
                dep_locked_chk,
                pkg_type,
            )
            upgraded_plugin = upgrade_cached_legacy_plugin(
                install_path,
                dep_key,
                lockfile=ctx.existing_lockfile,
                fetched_this_run=self.fetched_this_run,
            )
            if upgraded_plugin is not None:
                cached_package = upgraded_plugin
                pkg_type = PackageType.MARKETPLACE_PLUGIN
            elif apm_yml_path.exists():
                cached_package = APMPackage.from_apm_yml(
                    apm_yml_path,
                    source_path=install_path,
                )
            elif pkg_type == PackageType.CLAUDE_SKILL:
                validation_result = validate_apm_package(install_path)
                if not validation_result.is_valid or validation_result.package is None:
                    details = "; ".join(validation_result.errors) or "validator returned no package"
                    raise DirectDependencyError(f"Cached Claude Skill is invalid: {details}")
                cached_package = validation_result.package
            else:
                repo_segments = repository_path_segments(dep_ref.repo_url)
                cached_package = APMPackage(
                    name=repo_segments[-1] if repo_segments else dep_ref.repo_url,
                    version="unknown",
                    package_path=install_path,
                    source=dep_ref.repo_url,
                )
        cached_package = materialized_manifest_snapshot(cached_package, install_path, pkg_type)
        if not cached_package.source:
            cached_package.source = dep_ref.repo_url

        # Determine commit SHA for the cached path. See _resolve_cached_commit
        # for the invariant ("recorded SHA must match disk identity") and the
        # priority rules (PR #1158 -- branch-ref drift fix).
        cached_commit = self._resolve_cached_commit()

        # Codex admission reads the fallback commit as its source pin.
        resolved_or_cached_ref = (
            resolved_ref
            if resolved_ref
            else ResolvedReference(
                original_ref=dep_ref.reference or "default",
                ref_type=GitReferenceType.BRANCH,
                resolved_commit=self._cached_source_pin(cached_commit),
                ref_name=dep_ref.reference or "default",
            )
        )

        cached_package_info = PackageInfo(
            package=cached_package,
            install_path=install_path,
            resolved_reference=resolved_or_cached_ref,
            installed_at=datetime.now().isoformat(),
            dependency_ref=dep_ref,
            package_type=pkg_type,
        )

        # Collect for lockfile
        node = ctx.dependency_graph.dependency_tree.get_node(dep_key)
        depth = node.depth if node else 1
        resolved_by = locked_parent_identity(ctx, node)
        _is_dev = node.is_dev if node else False

        # Determine if cached package came from registry
        _cached_registry = None
        if (dep_locked_chk and dep_locked_chk.registry_prefix) or (
            ctx.registry_config and not dep_ref.is_local
        ):
            _cached_registry = ctx.registry_config

        _cached_resolution = None
        if dep_ref.source == "registry":
            from apm_cli.deps.registry.feature_gate import (
                require_package_registry_enabled,
            )

            require_package_registry_enabled("Registry-sourced cached installs")
            _cached_resolution = registry_resolution_for_cached_registry_dep(
                ctx, dep_ref, dep_key, dep_locked_chk
            )

        # Cached git-source semver dep (#1488): replay the resolution from
        # either ctx (we resolved earlier in this same run) or the lockfile
        # so re-writing the lockfile from cache preserves constraint /
        # resolved_tag / resolved_at instead of dropping them. The
        # lockfile-backed reconstruction is gated on ALL required fields
        # being present (see ``_rebuild_cached_semver_resolution`` and the
        # PR #1496 review thread).
        _cached_semver = ctx.git_semver_resolutions.get(dep_key)
        if _cached_semver is None:
            _cached_semver = _rebuild_cached_semver_resolution(dep_locked_chk)

        ctx.installed_packages.append(
            InstalledPackage(
                dep_ref=dep_ref,
                resolved_commit=cached_commit,
                depth=depth,
                resolved_by=resolved_by,
                is_dev=_is_dev,
                registry_config=_cached_registry,
                registry_resolution=_cached_resolution,
                git_semver_resolution=_cached_semver,
                package_name=cached_package_info.package.name
                if cached_package_info.package
                else None,
                package_version=cached_package_info.package.version
                if cached_package_info.package
                else None,
                # req-ext-003: copy the dependency manifest's x-* keys.
                extensions=extensions_from_resolved_package(cached_package_info.package),
            )
        )
        record_carried_package_hash(ctx, dep_key, install_path, locked_dep=dep_locked_chk)
        if cached_package_info.package_type:
            ctx.package_types[dep_key] = cached_package_info.package_type.value
        _record_declared_license(ctx, dep_key, install_path)
        record_package_targets(ctx, dep_key, install_path)
        warn_unrecognized_plugin_schema(ctx.diagnostics, dep_key, install_path)

        # Return without deploying integration files when the target set is empty.
        if not ctx.targets and native_validation is None:
            return Materialization(
                package_info=None,
                install_path=install_path,
                dep_key=dep_key,
                deltas=deltas,
            )

        return Materialization(
            package_info=cached_package_info,
            install_path=install_path,
            dep_key=dep_key,
            deltas=deltas,
        )


class FreshDependencySource(DependencySource):
    """Fresh dependency: needs a network download.

    Performs supply-chain hash verification (#763) and raises on mismatch
    because content drift from the lockfile is treated as possible tampering.
    """

    # Inherits the default "Failed to integrate primitives" prefix.

    def __init__(
        self,
        ctx: InstallContext,
        dep_ref: Any,
        install_path: Path,
        dep_key: str,
        resolved_ref: Any,
        dep_locked_chk: Any,
        ref_changed: bool,
        progress: Any = None,
    ):
        super().__init__(ctx, dep_ref, install_path, dep_key)
        self.resolved_ref = resolved_ref
        self.dep_locked_chk = dep_locked_chk
        self.ref_changed = ref_changed
        self.progress = progress

    def acquire(self) -> Materialization | None:
        from apm_cli.deps.installed_package import (
            InstalledPackage,
            extensions_from_resolved_package,
        )
        from apm_cli.drift import build_download_ref
        from apm_cli.install.transaction import stage_existing_copy
        from apm_cli.utils.path_security import safe_rmtree

        ctx = self.ctx
        dep_ref = self.dep_ref
        install_path = self.install_path
        dep_key = self.dep_key
        dep_locked_chk = self.dep_locked_chk
        ref_changed = self.ref_changed
        progress = self.progress
        diagnostics = ctx.diagnostics
        logger = ctx.logger

        try:
            display_name = str(dep_ref) if dep_ref.is_virtual else dep_ref.repo_url
            short_name = display_name.split("/")[-1] if "/" in display_name else display_name

            # Workstream B (#1116): the shared InstallTui ``ctx.tui`` owns per-dep
            # progress; legacy local Progress is kept only for back-compat.
            task_id = None
            if progress is not None:
                task_id = progress.add_task(
                    description=f"Fetching {short_name}",
                    total=None,
                )
            if ctx.tui is not None:
                ctx.tui.task_started(dep_key, f"fetch {short_name}")

            download_ref = build_download_ref(
                dep_ref,
                ctx.existing_lockfile,
                update_refs=ctx.update_refs,
                ref_changed=ref_changed,
            )

            stage_existing_copy(
                ctx, install_path, dep_locked_chk, skip=dep_key in ctx.pre_download_results
            )
            if dep_key in ctx.pre_download_results:
                package_info = ctx.pre_download_results[dep_key]
            elif dep_ref.source == "registry":
                if dep_key in ctx.callback_failures:
                    # Resolve already surfaced the registry failure; do not
                    # retry through the git fallback path.
                    return None
                from apm_cli.deps.registry.feature_gate import (
                    require_package_registry_enabled,
                )

                require_package_registry_enabled("Registry-sourced downloads")

                # Registry-sourced dep: dispatch to the dedicated-registry
                # resolver instead of the GitHub downloader. This branch
                # fires when (a) the BFS callback skipped due to existing
                # install path on a re-install, or (b) parallel pre-download
                # was skipped (registry deps aren't pre-downloaded).
                _registry_resolver = get_registry_resolver(ctx)
                if _registry_resolver is None:
                    raise RuntimeError(
                        f"dep {dep_ref.repo_url!r} is registry-sourced but "
                        f"no registry resolver was constructed (apm.yml may "
                        f"be missing a 'registries:' block)."
                    )
                # Lockfile re-install path: registry_name might be absent -
                # look it up from the lockfile's resolved_url.
                from apm_cli.deps.registry.auth import (
                    dependency_ref_with_registry_name_from_lockfile,
                )

                _regs = getattr(ctx.apm_package, "registries", None) or {}
                download_ref = dependency_ref_with_registry_name_from_lockfile(
                    download_ref,
                    _regs,
                    locked_dep=dep_locked_chk,
                )
                # Lockfile replay (npm install model): fetch directly from the
                # locked URL and verify against the locked hash when available
                # and the manifest range still covers the locked version.
                if (
                    not ctx.update_refs
                    and dep_locked_chk
                    and dep_locked_chk.resolved_url
                    and dep_locked_chk.resolved_hash
                    and dep_locked_chk.version
                    and not ref_changed
                ):
                    package_info = _registry_resolver.download_from_lockfile(
                        download_ref,
                        install_path,
                        resolved_url=dep_locked_chk.resolved_url,
                        resolved_hash=dep_locked_chk.resolved_hash,
                        version=dep_locked_chk.version,
                    )
                else:
                    package_info = download_registry_package(
                        ctx, download_ref, install_path, dep_locked_chk
                    )
            else:
                package_info = ctx.downloader.download_package(
                    download_ref,
                    install_path,
                    progress_task_id=task_id,
                    progress_obj=progress,
                )

            if package_info.package is not None:
                package_info.package = materialized_manifest_snapshot(
                    package_info.package, install_path, package_info.package_type
                )

            # CRITICAL: hide progress BEFORE printing success to avoid overlap
            if progress is not None and task_id is not None:
                progress.update(task_id, visible=False)
                progress.refresh()
            if ctx.tui is not None:
                ctx.tui.task_completed(dep_key)

            deltas: dict[str, int] = {"installed": 1}

            resolved = getattr(package_info, "resolved_reference", None)
            _ref = header_ref(resolved, dep_ref, dep_locked_chk)
            if logger:
                # F3 (#1116): centralised hex/sentinel-aware short SHA helper.
                _sha = format_short_sha(resolved.resolved_commit) if resolved else ""
                logger.download_complete(display_name, ref=_ref, sha=_sha)
                # Only emit the per-package git auth diagnostic for git deps.
                # Registry-sourced deps don't talk to git hosts; resolving
                # github.com auth here for them is misleading (and can issue
                # network calls via auth.AuthResolver providers).
                if ctx.auth_resolver and dep_ref.source in (None, "git"):
                    try:
                        _host = dep_ref.host or "github.com"
                        _org = (
                            dependency_repository_owner(dep_ref)
                            if dep_ref.repo_url and "/" in dep_ref.repo_url
                            else None
                        )
                        _ctx = ctx.auth_resolver.resolve(_host, org=_org, port=dep_ref.port)
                        logger.package_auth(_ctx.source, _ctx.token_type or "none")
                    except Exception:
                        pass
            else:
                _ref_suffix = ""
                if resolved:
                    _r = _ref
                    _s = format_short_sha(resolved.resolved_commit)
                    if _r and _s:
                        _ref_suffix = f" #{_r} @{_s}"
                    elif _r:
                        _ref_suffix = f" #{_r}"
                    elif _s:
                        _ref_suffix = f" @{_s}"
                _rich_success(f"[+] {display_name}{_ref_suffix}")

            if not dep_ref.reference:
                deltas["unpinned"] = 1

            # Lockfile bookkeeping
            resolved_commit = None
            if resolved:
                resolved_commit = package_info.resolved_reference.resolved_commit
            node = ctx.dependency_graph.dependency_tree.get_node(dep_key)
            depth = node.depth if node else 1
            resolved_by = locked_parent_identity(ctx, node)
            _is_dev = node.is_dev if node else False
            # Registry-sourced deps: pull the captured resolution out of
            # the resolver's per-graph map so the lockfile records
            # resolved_url + resolved_hash + version (design sec. 6.1).
            _registry_resolution = (
                resolver_last_registry_resolution(ctx, dep_key)
                if dep_ref.source == "registry"
                else None
            )
            # Git-source semver-range deps (#1488): the resolution was
            # captured by the BFS download_callback in phases/resolve.py.
            _git_semver_resolution = ctx.git_semver_resolutions.get(dep_key)
            ctx.installed_packages.append(
                InstalledPackage(
                    dep_ref=dep_ref,
                    resolved_commit=resolved_commit,
                    depth=depth,
                    resolved_by=resolved_by,
                    is_dev=_is_dev,
                    registry_config=(ctx.registry_config if not dep_ref.is_local else None),
                    registry_resolution=_registry_resolution,
                    git_semver_resolution=_git_semver_resolution,
                    package_name=package_info.package.name
                    if package_info and package_info.package
                    else None,
                    package_version=package_info.package.version
                    if package_info and package_info.package
                    else None,
                    # req-ext-003: copy the dependency manifest's x-* keys.
                    extensions=extensions_from_resolved_package(
                        package_info.package if package_info else None
                    ),
                )
            )
            _carried_paths = record_carried_package_hash(ctx, dep_key, install_path, package_info)

            # Supply-chain protection: verify content hash on fresh downloads
            # when the lockfile records one, unless an update moved the commit
            # or ``ctx.expected_hash_change_deps`` marks this dep (resolve.py's
            # BFS callback and _resolve_download_strategy set it when branch-ref
            # drift or the v<=0.12.2 self-heal makes a hash change expected).
            # Thread-safety: the set is stable once resolve completes, and
            # integrate.py's own .add() is idempotent and single-threaded.
            _expected_hash_deps = ctx.expected_hash_change_deps
            if (
                not update_accepts_new_content(ctx, dep_locked_chk, resolved_commit)
                and dep_key not in _expected_hash_deps
                and dep_locked_chk
                and dep_locked_chk.content_hash
                and dep_key in ctx.package_hashes
            ):
                _fresh_hash = ctx.package_hashes[dep_key]
                if locked_content_mismatch(
                    dep_key,
                    dep_locked_chk,
                    install_path,
                    lockfile=ctx.existing_lockfile,
                    package_info=package_info,
                    exclude=_carried_paths,
                    fresh_hash=_fresh_hash,
                ):
                    safe_rmtree(install_path, ctx.apm_modules_dir)
                    raise DirectDependencyError(
                        locked_content_mismatch_line(
                            dep_key, dep_locked_chk.content_hash, _fresh_hash
                        )
                        + " The downloaded content differs from the lockfile record. "
                        + content_hash_mismatch_hint(ctx, dep_key)
                    )
            ensure_carried_licenses_match(
                ctx, dep_key, install_path, dep_locked_chk, resolved_commit
            )

            if hasattr(package_info, "package_type") and package_info.package_type:
                ctx.package_types[dep_key] = package_info.package_type.value
            _record_declared_license(ctx, dep_key, install_path)
            record_package_targets(ctx, dep_key, install_path)
            warn_unrecognized_plugin_schema(diagnostics, dep_key, install_path)

            if hasattr(package_info, "package_type"):
                package_type = package_info.package_type
                _type_label = _format_package_type_label(package_type)
                if _type_label and logger:
                    logger.package_type_info(_type_label)

            from apm_cli.models.validation import PackageType

            # Native metadata must survive even with no targets so the
            # unconditional deployment boundary cannot be bypassed.
            if (
                not ctx.targets
                and getattr(package_info, "package_type", None) is not PackageType.AGENT_PLUGIN
            ):
                return Materialization(
                    package_info=None,
                    install_path=install_path,
                    dep_key=dep_key,
                    deltas=deltas,
                )

            return Materialization(
                package_info=package_info,
                install_path=package_info.install_path,
                dep_key=dep_key,
                deltas=deltas,
            )

        except DirectDependencyError:
            raise
        except Exception as e:
            display_name = str(dep_ref) if dep_ref.is_virtual else dep_ref.repo_url
            # task_id may not exist if progress.add_task failed; guard it.
            try:  # noqa: SIM105
                progress.remove_task(task_id)  # type: ignore[name-defined]
            except Exception:
                pass
            diagnostics.error(
                f"Failed to install {display_name}: {e}",
                package=dep_key,
            )
            return None


def make_dependency_source(
    ctx: InstallContext,
    dep_ref: Any,
    install_path: Path,
    dep_key: str,
    *,
    resolved_ref: Any = None,
    dep_locked_chk: Any = None,
    ref_changed: bool = False,
    skip_download: bool = False,
    fetched_this_run: bool = False,
    progress: Any = None,
) -> DependencySource:
    """Factory: pick the right ``DependencySource`` for *dep_ref*.

    Caller is responsible for resolving the download strategy (cached vs
    fresh) before invoking the factory; the resolved-ref and
    locked-checksum data flow into the appropriate source.

    ``fetched_this_run`` (F2): when ``skip_download=True`` AND the
    package was actually downloaded earlier in this run by the resolver
    callback, set this to ``True`` so the cached source emits the
    download-complete line WITHOUT the misleading ``(cached)`` suffix.
    """
    if dep_ref.is_local and dep_ref.local_path:
        return LocalDependencySource(ctx, dep_ref, install_path, dep_key)
    if skip_download:
        return CachedDependencySource(
            ctx,
            dep_ref,
            install_path,
            dep_key,
            resolved_ref,
            dep_locked_chk,
            fetched_this_run=fetched_this_run,
        )
    return FreshDependencySource(
        ctx,
        dep_ref,
        install_path,
        dep_key,
        resolved_ref,
        dep_locked_chk,
        ref_changed,
        progress,
    )
