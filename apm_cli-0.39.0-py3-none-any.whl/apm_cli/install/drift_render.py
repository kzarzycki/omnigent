"""Output renderers for install-replay drift findings."""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

import click

from apm_cli.core.command_logger import CommandLogger
from apm_cli.core.remediation import (
    RESYNC_AFTER_UNMANAGED_CONFLICT,
    RESYNC_DEPLOYED,
    RESYNC_UNRECORDED,
    either_sentence,
)
from apm_cli.deps.file_provenance import LOCAL_BUNDLE_OWNER
from apm_cli.install.local_edits import (
    edited_file_remediations,
    exportable_edit_paths,
    install_keeps_edit,
    local_edit_hint,
    rendering_change_hint,
    unedited_modified_paths,
)
from apm_cli.utils.console import STATUS_SYMBOLS
from apm_cli.utils.diagnostics import printable_ascii_text

if TYPE_CHECKING:
    from apm_cli.deps.lockfile import LockFile
    from apm_cli.install.drift import DriftFinding

_INLINE_DIFF_BYTE_CAP = 100 * 1024  # 100 KB


class CheckLogger(CommandLogger):
    """CheckLogger emits drift phase markers to stderr.

    ``CommandLogger._rich_*`` writes to stdout (intended for human
    install output).  Audit/drift output must stay on stderr so that
    machine-parseable JSON/SARIF on stdout is never polluted.
    """

    def __init__(self, verbose: bool = False) -> None:
        super().__init__("audit-drift", verbose=verbose)

    def _emit(self, symbol_key: str, msg: str) -> None:
        click.echo(f"{STATUS_SYMBOLS[symbol_key]} {msg}", err=True)

    def replay_start(self) -> None:
        self._emit("running", "Replaying install (cache-only)...")

    def scratch_root(self, path: Path) -> None:
        """Verbose-only: announce the scratch tmpdir to stderr.

        Stays on stderr so JSON/SARIF stdout payloads remain
        machine-parseable. Self-gates on ``self.verbose`` so the
        normal-mode user never sees it.
        """
        if not self.verbose:
            return
        click.echo(
            f"{STATUS_SYMBOLS['info']} drift scratch root: {path}",
            err=True,
        )

    def diff_start(self) -> None:
        self._emit("running", "Diffing scratch vs working tree...")

    def replay_complete(self, n: int) -> None:
        self._emit("check", f"Replayed {n} package(s)")

    def clean(self) -> None:
        self._emit("check", "No drift detected")

    def findings(self, n: int) -> None:
        self._emit("warning", f"Drift detected: {n} file(s)")


# Why a shared hook config drifts after a deny or a revoked approval (RA-028).
RETIRED_HOOK_ENTRIES_CAUSE = "APM-owned hook entries retired by an executables decision"


def _inline_diff_for(scratch_path: Path, project_path: Path) -> str:
    """Build an inline diff hint, capped to keep findings compact."""
    try:
        scratch_size = scratch_path.stat().st_size
        project_size = project_path.stat().st_size
    except OSError:
        return ""
    if scratch_size > _INLINE_DIFF_BYTE_CAP or project_size > _INLINE_DIFF_BYTE_CAP:
        return "(file too large for inline diff; use 'git diff --no-index' to compare)"
    return ""


def render_drift_text(
    findings: list[DriftFinding],
    verbose: bool = False,
    *,
    lockfile: LockFile | None = None,
    project_root: Path | None = None,
    advisory: bool = False,
) -> str:
    """Render drift findings as grouped terminal text.

    *lockfile* lets the export-patch hint skip local-path packages; with
    *project_root* it also tells local edits from rendering changes.
    *advisory* marks drift that does not fail the run, so the header is a
    warning rather than an error.
    """
    if not findings:
        return f"{STATUS_SYMBOLS['check']} No drift detected"

    status = (
        "error"
        if not advisory
        and any(
            finding.kind in {"modified", "unrecorded", "unmanaged-conflict"} for finding in findings
        )
        else "warning"
    )
    lines = [f"{STATUS_SYMBOLS[status]} Drift detected: {len(findings)} file(s)", ""]
    by_kind: dict[str, list[DriftFinding]] = {}
    for finding in findings:
        by_kind.setdefault(finding.kind, []).append(finding)

    for kind in ("unmanaged-conflict", "modified", "unintegrated", "orphaned", "unrecorded"):
        items = by_kind.get(kind, [])
        if not items:
            continue
        lines.append(f"  {kind} ({len(items)}):")
        for item in items:
            suffix = f"  [{item.package}]" if item.package else ""
            if item.owned_entries_only:
                suffix += f" ({RETIRED_HOOK_ENTRIES_CAUSE})"
            # A file name may hold a newline or non-ASCII: one escaped line each (#5279).
            lines.append(printable_ascii_text(f"    - {item.path}{suffix}"))
            if verbose and item.inline_diff:
                lines.append(printable_ascii_text(f"      {item.inline_diff}"))
        lines.append("")

    unedited = unedited_modified_paths(findings, lockfile, project_root)
    exportable = exportable_edit_paths(findings, lockfile, unedited=unedited)
    if exportable:
        overwritten = sum(1 for path in exportable if not install_keeps_edit(path))
        hint = local_edit_hint(len(exportable), overwritten=overwritten)
        lines.append(f"  {STATUS_SYMBOLS['info']} {hint}")
    if unedited:
        lines.append(f"  {STATUS_SYMBOLS['info']} {rendering_change_hint(len(unedited))}")

    if by_kind.get("unmanaged-conflict"):
        lines.append(
            f"  {STATUS_SYMBOLS['info']} Rename the conflicting local file or skill (APM "
            "does not own it), or choose a valid skill/target selection, before "
            "reinstalling. Ordinary 'apm install' skips or refuses unmanaged "
            "conflicts; it cannot repair these files."
        )
        if any(finding.kind != "unmanaged-conflict" for finding in findings):
            lines.append(f"  {STATUS_SYMBOLS['info']} {RESYNC_AFTER_UNMANAGED_CONFLICT.sentence()}")
    elif by_kind.get("unrecorded"):
        lines.append(f"  {STATUS_SYMBOLS['info']} {RESYNC_UNRECORDED.sentence()}")
    else:
        edited = [
            finding
            for finding in by_kind.get("modified", [])
            if finding.path not in unedited and not finding.owned_entries_only
        ]
        # Never destructive (RA-044): see install/local_edits.py.
        for bundle in sorted({finding.package == LOCAL_BUNDLE_OWNER for finding in edited}):
            choices = edited_file_remediations(bundle=bundle, exportable=bool(exportable))
            lines.append(f"  {STATUS_SYMBOLS['info']} {either_sentence(*choices)}")
        if len(edited) < len(findings):
            lines.append(f"  {STATUS_SYMBOLS['info']} {RESYNC_DEPLOYED.sentence()}")
    return "\n".join(lines).rstrip() + "\n"


def render_drift_json(findings: list[DriftFinding]) -> dict:
    """Render drift findings in the machine-readable JSON shape."""
    return {
        "drift": [
            {
                "path": finding.path,
                "kind": finding.kind,
                "package": finding.package,
                "inline_diff": finding.inline_diff,
            }
            for finding in findings
        ]
    }


def render_drift_sarif(findings: list[DriftFinding]) -> list[dict]:
    """Render the SARIF results array using ``apm/drift/<kind>`` rule IDs."""
    return [
        {
            "ruleId": f"apm/drift/{finding.kind}",
            "level": (
                "error"
                if finding.kind in {"modified", "unrecorded", "unmanaged-conflict"}
                else "warning"
            ),
            "message": {"text": f"drift ({finding.kind}): {finding.path}"},
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {"uri": finding.path},
                    }
                }
            ],
            "properties": {"package": finding.package},
        }
        for finding in findings
    ]


def render_drift(
    findings: list[DriftFinding],
    fmt: str = "text",
    verbose: bool = False,
) -> str:
    """Render findings through the requested output format."""
    if fmt == "json":
        return json.dumps(render_drift_json(findings), indent=2)
    if fmt == "sarif":
        return json.dumps({"results": render_drift_sarif(findings)}, indent=2)
    return render_drift_text(findings, verbose=verbose)
