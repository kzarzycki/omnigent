"""Integration template -- shared post-acquire flow for all DependencySources.

After ``DependencySource.acquire()`` materialises a package, every source
funnels through the same template:

1. Pre-deploy security gate (``_pre_deploy_security_scan``).
2. Primitive integration (``integrate_package_primitives``).
3. Per-package verbose diagnostics (skip / error counts).

This is the Template Method companion to the Strategy pattern in
``apm_cli.install.sources``.
"""

from __future__ import annotations

import shlex
from contextlib import nullcontext
from pathlib import Path
from typing import TYPE_CHECKING, cast

from apm_cli.agent_plugins.errors import (
    AgentPluginDeploymentBoundaryError,
    AgentPluginTargetExcludedError,
)
from apm_cli.install.outcome import package_install_count
from apm_cli.install.package_resolution import effective_dependency_selection, is_implicit_local
from apm_cli.install.services import (
    IntegratorBundle,
    PackageDeploymentPlan,
    enforce_agent_plugin_deployment_boundary,
    integrate_package_primitives,
    prepare_package_deployment,
)
from apm_cli.install.sources import (
    DependencySource,
    Materialization,
)
from apm_cli.utils.file_ops import describe_path_obstruction

if TYPE_CHECKING:
    from apm_cli.install.context import InstallContext

_MATERIALIZATION_UNSET = object()


def effective_allow_map(ctx) -> dict | None:
    """Return the effective (deny-wins) allow-map for the install context.

    Builds the #1873 trust context from three layers and materialises the
    decision map via the shared resolver:

    * org policy -- ``ctx.policy_fetch.policy`` (the deny ceiling, Gap A);
    * project ``apm.yml`` -- the ``executables`` block (or legacy
      ``allowExecutables`` alias) read from disk;
    * user consent -- ``~/.apm/config.json`` (lowest authority).

    Returns an explicit gate-disabled map when no layer opts into the gate
    (backward-compatible: every executable deploys).
    """
    from apm_cli.security.executables import (
        exec_trust_context_for_project,
        materialize_exec_map,
    )

    if getattr(ctx, "exec_trust_ctx", None) is not None:
        return getattr(ctx, "exec_allow_map", None)

    from apm_cli.core.scope import is_user_scope, scope_manifest_path

    policy = getattr(getattr(ctx, "policy_fetch", None), "policy", None)
    project_root = getattr(ctx, "source_root", None) or getattr(ctx, "project_root", None)
    # The scope owner names the manifest (APM_HOME/apm.yml under -g, #3954);
    # the trust owner reads that file.
    manifest_path = scope_manifest_path(
        project_root, user_scope=is_user_scope(getattr(ctx, "scope", None))
    )
    project_allow = getattr(getattr(ctx, "apm_package", None), "allow_executables", None)
    trust_ctx = exec_trust_context_for_project(
        manifest_path,
        policy=policy,
        fallback_allow_executables=project_allow,
        logger=getattr(ctx, "logger", None),
        migrate_user_legacy=not getattr(ctx, "dry_run", False),
    )
    allow_map = materialize_exec_map(trust_ctx)
    # Cache the resolved context and allow map once per install so each
    # dependency uses the same precedence ladder without re-reading policy files.
    if hasattr(ctx, "exec_trust_ctx"):
        ctx.exec_trust_ctx = trust_ctx
    if hasattr(ctx, "exec_allow_map"):
        ctx.exec_allow_map = allow_map
    return allow_map


def run_integration_template(
    source: DependencySource,
    *,
    materialization: Materialization | None | object = _MATERIALIZATION_UNSET,
    deployment_plan: PackageDeploymentPlan | None = None,
) -> dict[str, int] | None:
    """Run the shared post-acquire integration flow for one dependency.

    Returns a counter-delta dict for accumulation by the caller, or
    ``None`` if the source declined to acquire (skipped, failed).
    """
    if materialization is _MATERIALIZATION_UNSET:
        materialization, terminal_deltas = prepare_integration_materialization(source)
        if terminal_deltas is not None:
            return terminal_deltas
    announce_package(source)
    if materialization is None:
        return None

    return _integrate_materialization(
        source, cast(Materialization, materialization), deployment_plan=deployment_plan
    )


def prepare_integration_materialization(
    source: DependencySource,
) -> tuple[Materialization | None, dict[str, int] | None]:
    """Acquire one package without deploying it.

    Its ``[+]`` header is held for :func:`announce_package`, so each header
    prints above its own integration tree even when every package is
    acquired first (#3994).
    """
    from apm_cli.deps.plugin_parser import DeclaredPluginComponentError

    hold = getattr(getattr(source.ctx, "logger", None), "held_package_header", None)
    with hold() if callable(hold) else nullcontext([]) as held:
        source._held_header_lines = held
        try:
            return source.acquire(), None
        except DeclaredPluginComponentError as exc:
            source.ctx.diagnostics.error(str(exc), package=source.dep_key)
            return None, {}


def announce_package(source: DependencySource) -> None:
    """Emit the header lines held while *source* was acquired."""
    for emit in list(vars(source).pop("_held_header_lines", None) or ()):
        emit()


def preflight_agent_plugin_materializations(
    prepared: list[tuple[DependencySource, Materialization]],
) -> None:
    """Reject the batch once, before any package can mutate a target.

    A native Agent Plugin whose effective targets simply do not select
    ``copilot`` is not a structural package failure: it is skipped per-package
    during integration (:func:`_record_agent_plugin_target_skip`), so it must
    not abort a batch that can still deploy other packages. The final install
    outcome may still fail a pure no-op run.
    Anything else raised here (missing canonical IR, the imperative bundle
    route) is a real, actionable failure and aborts the whole batch.
    """
    for _, materialization in prepared:
        try:
            enforce_agent_plugin_deployment_boundary(materialization.package_info)
        except AgentPluginTargetExcludedError:
            continue


def preflight_skill_materializations(
    ctx: InstallContext,
    prepared: list[tuple[DependencySource, Materialization]],
) -> tuple[dict[str, PackageDeploymentPlan], PackageDeploymentPlan | None]:
    """Refuse unmanaged collisions and untrusted replacements before any package deploys."""
    from apm_cli.copilot_plugins.capability import admits_native_plugin
    from apm_cli.install.errors import DirectDependencyError
    from apm_cli.install.project_package import build_project_local_package_info
    from apm_cli.integration.base_integrator import BaseIntegrator
    from apm_cli.integration.skill_preflight import format_skill_conflicts

    if not ctx.targets:
        return {}, None
    plans: dict[str, PackageDeploymentPlan] = {}
    conflicts = []
    skill = ctx.integrators["skill"]
    managed = BaseIntegrator.normalize_managed_files(
        set(ctx.managed_files) | set(ctx.old_local_deployed)
    )

    def check(package_info, plan: PackageDeploymentPlan) -> None:
        if plan.source_plan is None or admits_native_plugin(package_info):
            return
        conflicts.extend(
            skill.find_unmanaged_conflicts(
                package_info,
                ctx.project_root,
                targets=plan.projection_targets,
                source_plan=plan.source_plan,
                managed_files=managed,
                force=ctx.force,
                skip_bin=plan.skip_bin,
            )
        )

    for source, materialization in prepared:
        if materialization.package_info is None or not ctx.targets:
            continue
        try:
            enforce_agent_plugin_deployment_boundary(materialization.package_info)
        except AgentPluginTargetExcludedError:
            continue
        selection = effective_dependency_selection(source.dep_ref, ctx)
        plan = prepare_package_deployment(
            materialization.package_info,
            ctx.project_root,
            targets=ctx.targets,
            diagnostics=ctx.diagnostics,
            package_name=materialization.dep_key,
            logger=ctx.logger,
            scope=ctx.scope,
            skill_subset=selection.skill_subset,
            skill_pairing=selection.skill_pairing,
            dep_target_subset=selection.target_subset,
            ctx=ctx,
            allow_executables=effective_allow_map(ctx),
            trust_bin=ctx.trust_bin,
        )
        plans[materialization.dep_key] = plan
        check(materialization.package_info, plan)

    local_plan = None
    if ctx.root_has_local_primitives and ctx.targets:
        from apm_cli.security.executables import AUTHORIZED_FIRST_PARTY, authorized_exec_map

        local = build_project_local_package_info(ctx.source_root or ctx.project_root)
        local_plan = prepare_package_deployment(
            local,
            ctx.project_root,
            targets=ctx.targets,
            diagnostics=ctx.diagnostics,
            package_name="_local",
            logger=ctx.logger,
            scope=ctx.scope,
            skill_subset=effective_dependency_selection(None, ctx).skill_subset,
            ctx=ctx,
            is_first_party=True,
            allow_executables=authorized_exec_map(AUTHORIZED_FIRST_PARTY),
        )
        check(local, local_plan)
    unmanaged = [conflict for conflict in conflicts if not conflict.untrusted]
    if unmanaged:
        raise DirectDependencyError(format_skill_conflicts(unmanaged))
    refused = [conflict for conflict in conflicts if conflict.untrusted]
    if refused and ctx.diagnostics is None:
        raise DirectDependencyError("\n".join(conflict.message() for conflict in refused))
    for conflict in refused:
        ctx.diagnostics.error(conflict.message(), package=conflict.package)
    # Receipt-less replacement is all-or-nothing: refuse before any package writes (#3625).
    ctx.skill_baseline_refused = bool(refused)
    return plans, local_plan


def preflight_agent_plugin_dry_run(
    ctx: InstallContext,
    dependencies: list,
    *,
    apm_package,
) -> None:
    """Reject a cached or local native package without mutating its source.

    The native-registration capability is published for the duration of the
    preview so a project whose effective targets exclude ``copilot`` yields
    the SAME precise reason a real install would, instead of the generic
    'no native harness' fallback. Admission never depends on whether a
    Copilot binary exists or which version it reports.

    Target exclusion (``AgentPluginTargetExcludedError``) is non-fatal during
    preflight and per-package integration: a real install skips that package
    with one warning and can still install the rest of the batch. The command
    outcome owner may still fail a pure no-op install after integration. Only a
    genuine structural failure (missing canonical IR, the imperative bundle
    route) aborts here.
    """
    from apm_cli.bundle.local_bundle import route_agent_plugin_package
    from apm_cli.copilot_plugins.capability import native_registration_scope
    from apm_cli.core.scope import get_modules_dir, is_user_scope
    from apm_cli.models.apm_package import PackageInfo, package_target_selection
    from apm_cli.models.validation import validate_apm_package

    source_root = ctx.project_root
    modules_dir = get_modules_dir(ctx.scope)
    explicit_target = ctx.target or package_target_selection(apm_package)
    try:
        from apm_cli.integration.targets import resolve_targets

        targets = resolve_targets(
            source_root,
            user_scope=is_user_scope(ctx.scope),
            explicit_target=explicit_target,
            create_config=ctx.create_config,
        )
    except Exception:
        targets = getattr(ctx, "targets", None)
    with native_registration_scope(targets):
        for dependency in dependencies:
            if dependency.is_marketplace:
                # Not resolved by the offline preview: nothing materialized to inspect.
                continue
            if dependency.is_local and dependency.local_path:
                package_path = Path(dependency.local_path).expanduser()
                if not package_path.is_absolute():
                    package_path = (source_root / package_path).resolve()
            else:
                package_path = dependency.get_install_path(modules_dir)
            if not package_path.is_dir():
                continue
            detection = route_agent_plugin_package(package_path)
            if detection is None:
                continue
            if dependency.is_local:
                validation = validate_apm_package(
                    package_path,
                    source_path=package_path,
                    agent_plugin_detection=detection,
                    read_only=True,
                )
            else:
                validation = validate_apm_package(
                    package_path,
                    agent_plugin_detection=detection,
                    read_only=True,
                )
            if validation.is_valid and validation.package is not None:
                try:
                    enforce_agent_plugin_deployment_boundary(
                        PackageInfo(
                            package=validation.package,
                            install_path=package_path,
                            dependency_ref=dependency,
                            package_type=validation.package_type,
                        )
                    )
                except AgentPluginTargetExcludedError:
                    continue


def _record_agent_plugin_boundary_diagnostic(
    diagnostics,
    *,
    package_key: str,
    prefix: str,
    error: AgentPluginDeploymentBoundaryError,
) -> None:
    """Record one package-attributed native deployment failure."""
    diagnostics.error(f"{prefix}: {error}", package=package_key)


def _record_agent_plugin_boundary_failure(
    source: DependencySource,
    materialization: Materialization,
    error: AgentPluginDeploymentBoundaryError,
) -> dict[str, int]:
    """Record one typed boundary failure as a canonical install diagnostic."""
    ctx = source.ctx
    deltas = materialization.deltas
    dep_ref = source.dep_ref
    dep_key = materialization.dep_key
    deltas["installed"] = 0
    ctx.package_deployed_files[dep_key] = []
    package_key = dep_ref.local_path if (dep_ref.is_local and dep_ref.local_path) else dep_key
    _record_agent_plugin_boundary_diagnostic(
        ctx.diagnostics,
        package_key=package_key,
        prefix=source.INTEGRATE_ERROR_PREFIX,
        error=error,
    )
    return deltas


def _target_names_for_hint(ctx: InstallContext) -> str:
    """Return the target argument to use in a recovery command."""
    names: list[str] = []
    for target in getattr(ctx, "targets", None) or ():
        name = getattr(target, "name", target)
        if isinstance(name, str) and name:
            names.append(name)
    return ",".join(sorted(set(names))) or "<target>"


def _dependency_parts_for_skill_subpath(dep_ref) -> tuple[str, str]:
    """Return dependency base and ref suffix for a skill-subpath command."""
    if getattr(dep_ref, "is_local", False) and getattr(dep_ref, "local_path", None):
        display = dep_ref.local_path
    elif hasattr(dep_ref, "to_display_reference"):
        display = dep_ref.to_display_reference()
    elif hasattr(dep_ref, "get_identity"):
        display = dep_ref.get_identity()
    else:
        display = getattr(dep_ref, "repo_url", "")
    base, separator, reference = str(display).partition("#")
    return base.rstrip("/"), f"{separator}{reference}" if separator else ""


def _reinstall_spec(dep_ref) -> str:
    """Return the ``apm install`` argument that reinstalls *dep_ref*."""
    dep_base, ref_suffix = _dependency_parts_for_skill_subpath(dep_ref)
    return f"{dep_base}{ref_suffix}"


def _retry_scope_args(ctx) -> tuple[str, ...]:
    """Return the scope and explicit --target flags a retry hint must repeat."""
    from apm_cli.core.scope import is_user_scope

    args: list[str] = []
    target = getattr(ctx, "target_override", None)
    if target and getattr(ctx, "target_override_source", None) is None:
        args.extend(("--target", target if isinstance(target, str) else ",".join(target)))
    if is_user_scope(getattr(ctx, "scope", None)):
        args.append("--global")
    return tuple(args)


def _agent_plugin_skill_name_for_hint(
    source: DependencySource,
    materialization: Materialization,
) -> str | None:
    """Return one skill name that can be installed through the subpath route."""
    package = getattr(materialization.package_info, "package", None)
    plugin = getattr(package, "agent_plugin", None)
    if plugin is None or not plugin.components.skills:
        return None
    requested = frozenset(getattr(source.ctx, "skill_subset", None) or ())
    for skill in plugin.components.skills:
        if skill.directory_name in requested or skill.name in requested:
            return skill.directory_name
    return plugin.components.skills[0].directory_name


def _agent_plugin_target_skip_message(
    source: DependencySource,
    materialization: Materialization,
    error: AgentPluginTargetExcludedError,
) -> str:
    """Return the actionable target-exclusion diagnostic for one package."""
    message = str(error)
    skill_name = _agent_plugin_skill_name_for_hint(source, materialization)
    if skill_name is None:
        return (
            f"{message} No selected target received this package. "
            "Select --target copilot or install a target-compatible package."
        )

    dep_base, ref_suffix = _dependency_parts_for_skill_subpath(source.dep_ref)
    target_arg = _target_names_for_hint(source.ctx)
    dependency = f"{dep_base}/skills/{skill_name}{ref_suffix}"
    command = f"apm install {shlex.quote(dependency)} --target {shlex.quote(target_arg)}"
    shell_note = " (POSIX shell)" if shlex.quote(dependency) != dependency else ""
    return (
        f"{message} No selected target received this package. "
        f"To install available skill '{skill_name}' as a plain skill bundle, "
        f"use{shell_note}: {command}"
    )


def _record_agent_plugin_target_skip(
    source: DependencySource,
    materialization: Materialization,
    error: AgentPluginTargetExcludedError,
) -> dict[str, int]:
    """Record a target skip for a package this project does not target at copilot.

    Mirrors the per-dependency ``targets:`` subset already handled in
    ``finalize_native_plugin``: native registration is skipped, ONE warning
    names the package, and the rest of the batch can still install. The
    install outcome owner fails later only when no package deployed.
    """
    ctx = source.ctx
    deltas = materialization.deltas
    dep_ref = source.dep_ref
    dep_key = materialization.dep_key
    deltas["installed"] = 0
    ctx.package_deployed_files[dep_key] = []
    package_key = dep_ref.local_path if (dep_ref.is_local and dep_ref.local_path) else dep_key
    ctx.diagnostics.agent_plugin_target_excluded(
        _agent_plugin_target_skip_message(source, materialization, error),
        package=package_key,
    )
    return deltas


def _integrate_materialization(
    source: DependencySource,
    m: Materialization,
    *,
    deployment_plan: PackageDeploymentPlan | None = None,
) -> dict[str, int]:
    """Apply security gate + primitive integration on a materialised package.

    The caller has already populated ``ctx.installed_packages`` /
    ``ctx.package_hashes`` / ``ctx.package_types`` inside ``acquire()``.
    Here we focus on the deployment side: security scan, primitive
    integration, deployed-files tracking, and per-package diagnostics.
    """
    ctx = source.ctx
    dep_ref = source.dep_ref
    deltas = m.deltas
    dep_key = m.dep_key
    diagnostics = ctx.diagnostics
    logger = ctx.logger

    try:
        enforce_agent_plugin_deployment_boundary(m.package_info)
    except AgentPluginTargetExcludedError as exc:
        return _record_agent_plugin_target_skip(source, m, exc)
    except AgentPluginDeploymentBoundaryError as exc:
        return _record_agent_plugin_boundary_failure(source, m, exc)

    if ctx.skill_subset_from_cli and ctx.skill_subset and not is_implicit_local(dep_ref, ctx):
        from apm_cli.install.outcome import require_requested_components
        from apm_cli.integration.skill_integrator import SkillIntegrator

        available_skills = SkillIntegrator.available_skill_names(m.package_info)
        if available_skills is not None and not require_requested_components(
            diagnostics,
            option="--skill",
            component="skill",
            requested=ctx.skill_subset,
            available=available_skills,
            package=dep_key,
            install_spec=_reinstall_spec(dep_ref),
            retry_args=_retry_scope_args(ctx),
        ):
            ctx.package_deployed_files[dep_key] = []
            return deltas

    # No-op when targets are empty or acquire decided to skip integration
    # (signalled by package_info=None). Leave this dependency absent from the
    # integration outcome so cleanup does not treat every prior file as stale.
    if m.package_info is None or not ctx.targets:
        return deltas

    from apm_cli.native_plugins.scopes import carried_native_row

    carried = carried_native_row(
        ctx.existing_lockfile, dep_key, dep_ref.target_subset, [t.name for t in ctx.targets]
    )
    if carried is not None:
        from apm_cli.claude_plugins.admission import refuse_disallowed_carried_native

        refuse_disallowed_carried_native(ctx, dep_key, m.package_info)
        # The run never reaches this native plugin: deploy nothing for it. Left
        # out of the outcome, its files and ledger records keep agreeing with
        # the row the lockfile phase keeps whole (#3921).
        ctx.native_carried_keys.add(dep_key)
        return deltas

    try:
        # Per-package effective selection: ``--skill`` is additive (issue
        # #1786), so the owner unions the persisted apm.yml ``skills:``
        # with the current CLI ``--skill`` values. ``--skill '*'`` resets
        # to the full bundle (None).
        selection = effective_dependency_selection(dep_ref, ctx)
        # When the additive union deploys more skills than the user named on
        # this invocation, name the retained pins so the deployed set is not
        # a silent surprise (verbose only -- the count already renders).
        if logger and ctx.skill_subset and selection.skill_subset:
            retained = sorted(set(selection.skill_subset) - set(ctx.skill_subset))
            if retained:
                logger.verbose_detail(
                    f"    [i] {dep_key}: retaining previously pinned "
                    f"skill(s): {', '.join(retained)}"
                )
        from apm_cli.install.diff_apply import capture_body

        int_result = integrate_package_primitives(
            m.package_info,
            ctx.project_root,
            targets=ctx.targets,
            integrators=IntegratorBundle(
                prompt=ctx.integrators["prompt"],
                agent=ctx.integrators["agent"],
                skill=ctx.integrators["skill"],
                instruction=ctx.integrators["instruction"],
                command=ctx.integrators["command"],
                hook=ctx.integrators["hook"],
                canvas=ctx.integrators.get("canvas"),
            ),
            force=ctx.force,
            managed_files=ctx.managed_files,
            diagnostics=diagnostics,
            package_name=dep_key,
            logger=capture_body(logger, dep_key),
            scope=ctx.scope,
            skill_subset=selection.skill_subset,
            skill_pairing=selection.skill_pairing,
            dep_target_subset=selection.target_subset,
            ctx=ctx,
            allow_executables=effective_allow_map(ctx),
            trust_bin=getattr(ctx, "trust_bin", None),
            deployment_plan=deployment_plan,
        )
        mutation_keys = (
            "prompts",
            "agents",
            "skills",
            "sub_skills",
            "instructions",
            "commands",
            "hooks",
            "canvases",
        )
        for k in (*mutation_keys, "links_resolved"):
            deltas[k] = int_result[k]
        # Fetched bytes or changed deployed files make an install (#4184); a
        # natively registered Agent Plugin deploys no primitives by design.
        deltas["installed"] = package_install_count(
            int_result, fetched=bool(deltas.get("installed"))
        )
        # A parked native bundle deployed nothing: it is not an install (#4154).
        if int_result.get("parked_native"):
            deltas["installed"] = 0
        ctx.package_deployed_files[dep_key] = int_result["deployed_files"]
        from apm_cli.core.deployment_state import CompletedReintegration

        completed = int_result.get("completed_reintegration")
        if isinstance(completed, CompletedReintegration) and completed.owner == dep_key:
            ctx.package_completed_reintegrations[dep_key] = completed
    except Exception as e:
        # Per-source error wording: each DependencySource subclass
        # declares its own INTEGRATE_ERROR_PREFIX (Strategy pattern).
        # Local packages key the diagnostic by local_path; cached/fresh
        # key by dep_key -- a behavioural detail preserved from legacy.
        package_key = dep_ref.local_path if (dep_ref.is_local and dep_ref.local_path) else dep_key
        reason = describe_path_obstruction(e, Path(ctx.project_root)) or e
        diagnostics.error(
            f"{source.INTEGRATE_ERROR_PREFIX}: {reason}",
            package=package_key,
        )

    # Verbose: inline skip / error count for this package
    if logger and logger.verbose:
        _skip_count = diagnostics.count_for_package(dep_key, "collision")
        _err_count = diagnostics.count_for_package(dep_key, "error")
        if _skip_count > 0:
            noun = "file" if _skip_count == 1 else "files"
            logger.package_inline_warning(
                f"    [!] {_skip_count} {noun} skipped (local files exist)"
            )
        if _err_count > 0:
            noun = "error" if _err_count == 1 else "errors"
            logger.package_inline_warning(f"    [!] {_err_count} integration {noun}")

    return deltas
