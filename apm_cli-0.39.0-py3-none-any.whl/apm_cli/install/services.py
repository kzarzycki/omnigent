"""Coordinate primitive integration and source-backed completion receipts.

The install engine owns target dispatch, counters and deployed paths.
``commands/install`` retains compatibility re-exports. Local content calls
``integrate_package_primitives`` by name so patches in this module intercept
both package and local integration.
Authorization preparation is shared through ``deployment_plan``.
"""

from __future__ import annotations

import builtins
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from apm_cli.agent_plugins.errors import enforce_agent_plugin_deployment_boundary
from apm_cli.core.remediation import claude_native_switch_loose_hooks

from .deployed_paths import bundle_entry_within
from .deployed_paths import deployed_path_entry as _deployed_path_entry
from .deployed_paths import destination_tree_lines as _destination_tree_lines
from .deployed_paths import format_target_collapse as _format_target_collapse
from .deployed_paths import log_hook_display_payloads as _log_hook_display_payloads
from .deployed_paths import skill_summary_paths as _skill_summary_paths
from .deployment_plan import PackageDeploymentPlan, prepare_package_deployment
from .exec_gate import plugin_bin_deployable, resolve_bin_skip
from .local_bundle_agents import deploy_bundle_codex_agent as _deploy_bundle_codex_agent
from .local_bundle_markdown_hooks import record_bundle_markdown_hooks as _record_md_hooks
from .local_bundle_markdown_hooks import retire_before_bundle_install as _retire_md_hooks
from .local_bundle_paths import bundle_deploy_relative_path as _bundle_rel
from .local_bundle_paths import bundle_deploy_skip_warning as _bundle_skip_warning
from .local_bundle_paths import bundle_render_format_id as _bundle_render_format
from .local_bundle_paths import bundle_rendering_extensions as _bundle_renderings
from .local_bundle_paths import bundle_rule_format_id as _bundle_rule_format
from .local_bundle_paths import bundle_slug_validation_error as _bundle_slug_error
from .local_bundle_paths import deployable_bundle_pack_files as _deployable_pack_files
from .local_bundle_paths import known_bundle_deploy_prefixes as _known_bundle_prefixes
from .local_bundle_paths import superseded_bundle_renderings as _superseded_renderings
from .local_bundle_paths import target_bundle_deploy_prefixes as _target_bundle_prefixes
from .local_bundle_renderings import normalized_bundle_text as _normalized_bundle_text
from .local_bundle_renderings import render_bundle_rule as _render_bundle_rule
from .local_bundle_renderings import warn_superseded_renderings as _warn_superseded
from .project_package import build_project_local_package_info
from .target_filter import announced_reconcile
from .target_filter import warn_target_reconcile_failure as _warn_target_reconcile_failure
from .target_warnings import log_canvas_skip as _log_canvas_skip
from .target_warnings import warn_unsupported_primitives

if TYPE_CHECKING:
    from ..core.command_logger import InstallLogger
    from ..core.scope import InstallScope
    from ..install.context import InstallContext
    from ..integration.base_integrator import BaseIntegrator
    from ..models.dependency.subsets import SkillTargetSelection
    from ..utils.diagnostics import DiagnosticCollector


# CRITICAL: Shadow Python builtins that share names with Click commands so
# ``set()`` / ``list()`` / ``dict()`` resolve to the builtins, not Click
# subcommand objects.  ``commands/install`` and ``install/pipeline`` do the
# same dance for the same reason.
set = builtins.set
list = builtins.list
dict = builtins.dict


@dataclass(frozen=True)
class IntegratorBundle:
    """Groups the six primitive integrators passed to ``integrate_package_primitives``.

    Using a bundle reduces the public argument count of
    ``integrate_package_primitives`` below the PLR0913 threshold (≤15) while
    keeping the integrator objects strongly typed and discoverable.
    """

    prompt: BaseIntegrator
    agent: BaseIntegrator
    skill: BaseIntegrator
    instruction: BaseIntegrator
    command: BaseIntegrator
    hook: BaseIntegrator
    # Optional so the ~16 existing test/prod construction sites that omit it
    # keep working. Production sites (template.py, integrate_local_content,
    # drift.py) pass a real CanvasIntegrator; when None the loop skips canvas.
    canvas: BaseIntegrator | None = None


def _label_and_deploy_dir(prim_name: str, mapping, target, deploy_dir: str) -> tuple[str, str]:
    """Return ``(label, deploy_dir)`` for a per-kind integration line."""
    if prim_name == "instructions" and mapping.output_compare:
        # Rule-dir formats (cursor/claude/windsurf) are the output_compare
        # set; derive the label from the same flag so a new rule format
        # needs no edit here.
        return "rule(s)", deploy_dir
    if prim_name == "instructions":
        return "instruction(s)", deploy_dir
    if prim_name == "hooks":
        if target.hooks_config_display:
            deploy_dir = target.hooks_config_display
        return "hook(s)", deploy_dir
    if prim_name == "canvas":
        return "canvas extension(s)", deploy_dir
    return prim_name, deploy_dir


def _emit_integration_hints(prim_name: str, info: dict, log_integration) -> None:
    """Emit per-primitive 'next step' hints after an integration line."""
    # copilot-app workflows arrive disabled: the row lands enabled=0 and the
    # user must flip the toggle in the Copilot App's Workflows tab before the
    # schedule fires.
    if any(p.startswith("copilot-app/") for p in info["paths"]) and info["files"] > 0:
        log_integration(
            "  |-- workflows arrive disabled; enable from the Copilot App's Workflows tab"
        )
    # Canvas extensions are discovered by Copilot CLI at session start, so a
    # freshly-deployed canvas is not picked up mid-session.
    if prim_name == "canvas" and (info["files"] > 0 or info["adopted"] > 0):
        log_integration("  |-- reload the Copilot session (/clear) or restart to load the canvas")


def _targets_explicitly_requested(ctx: InstallContext | None) -> bool:
    """Return True only when the active targets came from ``--target``."""
    decision = getattr(ctx, "target_decision", None)
    return getattr(decision, "source", None) == "--target flag"


def _check_native_claude_transition(
    reconcile_package_targets: Any,
    package_info: Any,
    project_root: Path,
    targets: list[Any],
    package: str,
    flag: str = "",
) -> None:
    """Refuse native activation over retained or unreadable loose hook state."""
    from apm_cli.claude_plugins.admission import ClaudeNativePluginError

    if not callable(reconcile_package_targets):
        return
    reconcile_stats = reconcile_package_targets(
        package_info,
        project_root,
        targets,
        dry_run=True,
    )
    if reconcile_stats.get("errors") or reconcile_stats.get("files_removed"):
        failed = ", ".join(reconcile_stats.get("failed_paths", []))
        recovery = f"Repair unreadable hook settings or ownership. Inspect: {failed}"
        if not reconcile_stats.get("errors"):
            switch = claude_native_switch_loose_hooks(user_scope=bool(flag))
            recovery = switch.bind(package=package).sentence()
        raise ClaudeNativePluginError(
            f"Cannot switch {package} to a native plugin. Hook settings were preserved. {recovery}"
        )


def integrate_package_primitives(  # noqa: PLR0913
    package_info: Any,
    project_root: Path,
    *,
    targets: Any,
    integrators: IntegratorBundle,
    force: bool,
    managed_files: Any,
    diagnostics: DiagnosticCollector,
    package_name: str = "",
    logger: InstallLogger | None = None,
    scope: InstallScope | None = None,
    skill_subset: tuple | None,
    skill_pairing: SkillTargetSelection | None = None,  # per-target skills (req-rs-018)
    ctx: InstallContext | None = None,
    scratch_root: Path | None = None,
    policy: Any = None,
    is_first_party: bool = False,
    allow_executables: builtins.dict[str, builtins.dict[str, bool]] | None = None,
    dep_target_subset: list[str] | None = None,
    trust_bin: bool | None = None,
    bin_skip_reason_override: str | None = None,
    native_claude_user_scope: bool = False,
    deployment_plan: PackageDeploymentPlan | None = None,
) -> dict:
    """Run the full integration pipeline for a single package.

    Iterates over *targets* (``TargetProfile`` list) and dispatches each
    primitive to the appropriate integrator via the target-driven API.
    Skills are handled separately because ``SkillIntegrator`` already
    routes across all targets internally.

    When *scope* is ``InstallScope.USER``, targets and primitives that
    do not support user-scope deployment are silently skipped.

    When *ctx* is provided, the cowork non-skill primitive warning
    (Amendment 6) is emitted once per install run for packages that
    contain non-skill primitives when the cowork target is active.

    Executable primitives (hooks, bin/, MCP servers, canvas extensions) are
    only deployed for packages the trust owner approves in
    *allow_executables*; an omitted (``None``) map approves nothing, and only
    an explicit ``authorized_exec_map`` approves everything. Local project
    content (``package_name == "_local"``) is always trusted.

    When *trust_bin* is ``False`` (``--no-trust-bin``), bin/ deployment
    is skipped with reason ``"not_trusted"`` only when ``allowExecutables``
    would otherwise permit deployment.  When ``allowExecutables`` blocks
    deployment first, the skip reason is ``"not_approved"`` regardless of
    *trust_bin*.  When *trust_bin* is ``True`` (``--trust-bin``), the
    trust-posture warning is suppressed.  When ``None`` (default), bin/
    deploys but a prominent warning is emitted.

    Returns a dict with integration counters and the list of deployed file paths.

    Raises:
        AgentPluginDeploymentBoundaryError: If native Agent Plugin content reaches deployment.
    """
    enforce_agent_plugin_deployment_boundary(package_info)

    from apm_cli.core.deployment_ledger import recorded_writes
    from apm_cli.integration.dispatch import get_dispatch_table

    from ..core.scope import InstallScope

    _dispatch = get_dispatch_table()
    result = {
        "prompts": 0,
        "agents": 0,
        "skills": 0,
        "sub_skills": 0,
        "instructions": 0,
        "commands": 0,
        "hooks": 0,
        "canvases": 0,
        "links_resolved": 0,
        "deployed_files": [],
        "native_plugin": False,
    }

    deployed = result["deployed_files"]

    # Drift replay must prove every write is redirected before target cleanup
    # or any other integration side effect can run.
    if scratch_root is not None:
        from apm_cli.utils.path_security import ensure_path_within

        scratch_root = Path(scratch_root).resolve()
        ensure_path_within(Path(project_root).resolve(), scratch_root)

    # SECURITY: package intent may only narrow the consumer-authorized active
    # target set. It never activates a target or expands dependency reach.
    deployment_plan = deployment_plan or prepare_package_deployment(
        package_info,
        project_root,
        targets=targets,
        dep_target_subset=dep_target_subset,
        diagnostics=diagnostics,
        package_name=package_name,
        logger=logger,
        scope=scope,
        skill_subset=skill_subset,
        skill_pairing=skill_pairing,
        ctx=ctx,
        policy=policy,
        is_first_party=is_first_party,
        allow_executables=allow_executables,
        trust_bin=trust_bin,
        bin_skip_reason_override=bin_skip_reason_override,
        read_only=scratch_root is not None,
        native_claude_user_scope=native_claude_user_scope,
    )
    target_selection = deployment_plan.target_selection
    targets = list(target_selection.targets)
    allowed_dep_targets = set(target_selection.consumer_allowed_targets)
    dep_targets_active = target_selection.consumer_restriction_active

    reconcile_package_targets = announced_reconcile(integrators.hook, logger, package_name, scope)

    def _reconcile_excluded_targets() -> None:
        if target_selection.excluded_targets and callable(reconcile_package_targets):
            reconcile_stats = reconcile_package_targets(
                package_info,
                project_root,
                target_selection.excluded_targets,
            )
            _warn_target_reconcile_failure(diagnostics, package_name, reconcile_stats)

    if not targets:
        _reconcile_excluded_targets()
        return result

    # Executable approval gate (npm v12-style default-deny); all five verdicts feed the gates.
    (
        _hooks_approved,
        _bin_approved,
        _mcp_approved,
        _canvas_approved,
        _lsp_approved,
    ) = deployment_plan.approvals
    _skip_bin = deployment_plan.skip_bin
    _bin_skip_reason_override = deployment_plan.bin_skip_reason
    from apm_cli.codex_plugins.admission import finalize_codex_native
    from apm_cli.install.helpers.security_scan import _pre_deploy_security_scan

    codex_native = deployment_plan.codex_native
    native_claude_plugin = deployment_plan.claude_native
    native_target_names = native_claude_plugin.harnesses if native_claude_plugin else set()
    # Compatibility-only Codex data is opaque to every loose target adapter.
    projection_targets = deployment_plan.projection_targets
    source_plan = deployment_plan.source_plan
    if source_plan is None:
        raise RuntimeError("Selected targets require an authorized source plan")
    if not _pre_deploy_security_scan(
        source_plan,
        diagnostics,
        package_name=package_name,
        force=force,
        logger=logger,
    ):
        return result

    # A native Agent Plugin stays opaque (Copilot loads it whole from .agents/plugins); this
    # fires only AFTER target narrowing and AFTER the executable trust gate.
    from apm_cli.copilot_plugins.capability import admits_native_plugin
    from apm_cli.install.native_plugin_admission import finalize_native_plugin

    if admits_native_plugin(package_info):
        _reconcile_excluded_targets()
        return finalize_native_plugin(
            result,
            package_info,
            package_name,
            targets,
            hooks_approved=_hooks_approved,
            mcp_approved=_mcp_approved,
            bin_approved=_bin_approved,
            canvas_approved=_canvas_approved,
            lsp_approved=_lsp_approved,
            ctx=ctx,
            diagnostics=diagnostics,
            logger=logger,
        )

    warn_unsupported_primitives(
        package_info,
        package_name,
        projection_targets,
        ctx,
        diagnostics,
        logger,
    )

    def _log_integration(msg):
        if logger:
            logger.tree_item(msg)

    _verbose = bool(getattr(ctx, "verbose", False)) if ctx is not None else False

    _INTEGRATOR_KWARGS = {
        "prompts": integrators.prompt,
        "agents": integrators.agent,
        "commands": integrators.command,
        "instructions": integrators.instruction,
        "hooks": integrators.hook,
        "canvas": integrators.canvas,
        "skills": integrators.skill,
    }

    # An unmatched skills: selection fails the package; refuse it before any
    # primitive kind writes so the failed install leaves every file untouched.
    preflight_skill_selection = getattr(integrators.skill, "preflight_skill_selection", None)
    if (
        codex_native is None
        and callable(preflight_skill_selection)
        and not preflight_skill_selection(
            package_info,
            skill_subset=skill_subset,
            source_plan=source_plan,
            diagnostics=diagnostics,
            logger=logger,
        )
    ):
        return result

    preflight_hooks = getattr(integrators.hook, "preflight_hooks_for_targets", None)
    if _hooks_approved and callable(preflight_hooks) and codex_native is None:
        preflight_hooks(
            package_info,
            project_root,
            source_plan,
            user_scope=scope is InstallScope.USER or native_claude_user_scope,
            retiring_targets=frozenset(target.name for target in target_selection.excluded_targets),
        )

    # Validate every converted instruction target before any primitive kind can
    # write. A rejected instruction must not leave prompts, agents, commands,
    # or identity-target instructions from the same package active.
    if integrators.instruction is not None:
        integrators.instruction.preflight_instructions_for_targets(
            projection_targets,
            package_info,
            project_root,
            source_plan,
            force=force,
            diagnostics=diagnostics,
        )

    _reconcile_excluded_targets()
    from apm_cli.install.deployment_plan import keep_loose_for_parked_native

    keep_loose_for_parked_native(
        deployment_plan, ctx, package_name, diagnostics=diagnostics, logger=logger
    )
    # Drift replay asks the same plan which locked loose values it keeps (#5036).
    result["deployment_plan"] = deployment_plan
    if native_claude_plugin is not None:
        result["native_plugin"] = True
        result["native_claude_plugin"] = True
        _check_native_claude_transition(
            reconcile_package_targets,
            package_info,
            project_root,
            [target for target in targets if target.name in native_target_names],
            package_name,
            " --global" if scope is InstallScope.USER else "",
        )
        if not projection_targets:
            from apm_cli.claude_plugins.admission import queue_native_claude

            queue_native_claude(ctx, package_name, native_claude_plugin, diagnostics)
            return result

    if codex_native is not None:
        _rc = (
            reconcile_package_targets(package_info, project_root, targets)
            if callable(reconcile_package_targets)
            else None
        )
        return finalize_codex_native(result, codex_native, source_plan, _rc, ctx, scratch_root)

    # Aggregate per-primitive across targets so we emit ONE line per kind
    # (per the 1/2/3+ collapse rule), not one per target.
    # Structure: { prim_name: {"files": int, "adopted": int, "label": str, "paths": [str]} }
    _per_kind: dict[str, dict[str, Any]] = {}
    _hooks_registered = 0

    for _prim_name, _entry in _dispatch.items():
        if _entry.multi_target:
            continue  # skills handled separately
        # Executable approval gate: skip hooks if not approved, and retire
        # the hooks this package deployed before it was gated (#3924).
        if _prim_name == "hooks" and not _hooks_approved:
            from apm_cli.install.exec_gate import log_hooks_skip

            log_hooks_skip(package_name, package_info, logger, ctx)
            if callable(reconcile_package_targets):
                _warn_target_reconcile_failure(
                    diagnostics,
                    package_name,
                    reconcile_package_targets(package_info, project_root, targets),
                    "Could not fully remove hooks the executables gate no longer deploys",
                )
            from apm_cli.install.withheld_hooks import announce_withheld_hook_files

            announce_withheld_hook_files(
                package_name,
                package_info,
                project_root,
                targets,
                managed_files,
                logger,
                user_scope=scope is InstallScope.USER,
            )
            continue
        # Executable approval gate: skip canvas if not approved.
        # First-party (is_first_party=True) always deploys.
        # Dependency canvas requires allowExecutables approval; the _local
        # name shortcut in check_executable_approval does NOT bypass this
        # gate when is_first_party=False (defence-in-depth: a malicious dep
        # named _local must not bypass canvas trust via the name alone).
        if _prim_name == "canvas" and not is_first_party:
            from apm_cli.install.exec_gate import resolve_package_key as _rpk
            from apm_cli.security.executables import (
                EXEC_TYPE_CANVAS,
                exec_map_authorizes_all,
                package_type_approved,
            )

            _dep_canvas_ok = exec_map_authorizes_all(allow_executables) or package_type_approved(
                allow_executables,
                (_rpk(package_info, package_name), package_name),
                EXEC_TYPE_CANVAS,
            )
            if not _dep_canvas_ok:
                _log_canvas_skip(package_name, package_info, logger, ctx)
                continue
        _integrator = _INTEGRATOR_KWARGS[_prim_name]
        # A primitive can be statically present on a target (e.g. the
        # copilot canvas mapping) while a given IntegratorBundle omits its
        # integrator (None). Skip rather than crash so test/replay bundles
        # that don't wire the integrator simply no-op that primitive.
        if _integrator is None:
            continue
        _agg_files = 0
        _agg_adopted = 0
        _agg_paths: list[str] = []
        _agg_hook_payloads: list = []
        _label = _prim_name
        for _target in targets:
            if _target not in projection_targets:
                continue
            _mapping = _target.primitives.get(_prim_name)
            if _mapping is None:
                continue
            _call_kwargs: dict[str, Any] = {
                "force": force,
                "managed_files": managed_files,
                "diagnostics": diagnostics,
                "scope": scope,
                "source_plan": source_plan,
            }
            # Hook integrator alone needs the scope signal: project-scope
            # deploys keep ``command`` paths repo-relative (#1394), user-scope
            # deploys make them cwd-independent (#1310 / #1354), anchored to
            # home where the target declares a verified home reference.
            # Sibling integrators don't accept this kwarg, so include it only
            # for hooks.
            if _prim_name == "hooks":
                _call_kwargs["user_scope"] = scope is InstallScope.USER or native_claude_user_scope
                _call_kwargs["dep_targets_active"] = dep_targets_active
                _call_kwargs["allowed_targets"] = allowed_dep_targets
                # Mirror retiring_targets (#3129) so a fallback preflight isn't
                # misflagged as an import-coexistence conflict on retirement.
                _call_kwargs["retiring_targets"] = frozenset(
                    t.name for t in target_selection.excluded_targets
                )
            # Canvas integration: always pass is_first_party.  Approval
            # is enforced by the gate above (canvas already skipped if
            # not approved and not is_first_party), so here we always
            # pass trust_canvas=True to let the integrator proceed.
            if _prim_name == "canvas":
                _call_kwargs["trust_canvas"] = True
                _call_kwargs["is_first_party"] = is_first_party
                _call_kwargs["package_name"] = package_name
            with recorded_writes(integrators.skill, _integrator, [_target], package_info):
                _int_result = getattr(_integrator, _entry.integrate_method)(
                    _target, package_info, project_root, **_call_kwargs
                )
            result["links_resolved"] += _int_result.links_resolved
            for tp in _int_result.target_paths:
                deployed.append(_deployed_path_entry(tp, project_root, targets))
            _adopted_attr = getattr(_int_result, "files_adopted", 0)
            # Coerce defensively: subclasses (e.g. HookIntegrationResult)
            # always set this, but tests use MagicMock results which
            # auto-attribute to MagicMock objects whose ``__int__`` is 1.
            # Treat anything that is not a real int as 0 so we never
            # invent fake adopt counts.
            _adopted = _adopted_attr if isinstance(_adopted_attr, int) else 0
            _registered = getattr(_int_result, "hooks_registered", 0)
            _hooks_registered += _registered if isinstance(_registered, int) else 0
            # Show the per-kind line whenever ANY work happened -- either
            # a fresh integrate or a silent adopt of pre-existing
            # byte-identical files. Adopt-only runs (e.g. re-install
            # after lockfile wipe) used to print nothing here, which made
            # the install summary look like a no-op even though the
            # lockfile WAS being repopulated. Surfacing adopt counts
            # restores operator trust in CI.
            if _int_result.files_integrated <= 0 and _adopted <= 0:
                continue
            _agg_files += _int_result.files_integrated
            _agg_adopted += _adopted
            # Only count fresh integrations against the package counter
            # so totals like "3 prompts integrated" stay truthful;
            # adopted files are surfaced separately in the per-kind
            # line.
            result[_entry.counter_key] += _int_result.files_integrated
            _effective_root = _mapping.deploy_root or _target.root_dir
            _deploy_dir = (
                f"{_effective_root}/{_mapping.subdir}/"
                if _mapping.subdir
                else f"{_effective_root}/"
            )
            _label, _deploy_dir = _label_and_deploy_dir(_prim_name, _mapping, _target, _deploy_dir)
            if _prim_name == "hooks":
                _agg_hook_payloads.extend(
                    p for p in getattr(_int_result, "display_payloads", []) or []
                )
            _agg_paths.append(_deploy_dir)

        if _agg_files > 0 or _agg_adopted > 0:
            _per_kind[_prim_name] = {
                "files": _agg_files,
                "adopted": _agg_adopted,
                "label": _label,
                "paths": _agg_paths,
                "hook_payloads": _agg_hook_payloads,
            }

    # Emit aggregated per-kind lines in dispatch order so output is stable.
    for _prim_name in _dispatch:
        if _prim_name not in _per_kind:
            continue
        _info = _per_kind[_prim_name]
        # Build the verb + count phrase. Adoption (a file already holding the
        # render) changes nothing, so it is silent unless --verbose: a repeat
        # install is a quiet no-op (#4382/#4360, I2).
        _files = _info["files"]
        _adopted = _info["adopted"] if _verbose else 0
        _noun = _info["label"].removesuffix("s") if (_files or _adopted) == 1 else _info["label"]
        if _files > 0:
            _verb_phrase = f"{_files} {_noun} integrated"
            if _adopted > 0:
                _verb_phrase = f"{_verb_phrase} ({_adopted} adopted)"
        else:
            _verb_phrase = f"{_adopted} {_noun} adopted" if _adopted else ""
        if _verb_phrase:
            for line in _destination_tree_lines(_verb_phrase, _info["paths"], _verbose):
                _log_integration(line)
        # Emit per-hook-file action summaries for the hooks primitive.
        # display_payloads reflects post-path-rewrite data (what is
        # actually written to disk and executed), so this is faithful.
        if _prim_name == "hooks" and _info["files"] > 0:
            _hook_verbose = _verbose or (
                bool(getattr(logger, "verbose", False)) if logger is not None else False
            )
            _log_hook_display_payloads(
                _info.get("hook_payloads", []),
                _hook_verbose,
                _log_integration,
                logger,
            )
        _emit_integration_hints(_prim_name, _info, _log_integration)

    getattr(integrators.skill, "serve_natively", lambda _harnesses: None)(
        frozenset(native_target_names)
    )
    with recorded_writes(integrators.skill, integrators.skill, projection_targets, package_info):
        skill_result = integrators.skill.integrate_package_skill(
            package_info,
            project_root,
            diagnostics=diagnostics,
            managed_files=managed_files,
            force=force,
            targets=projection_targets,
            skill_subset=skill_subset,
            skill_pairing=skill_pairing,
            scope=scope,
            policy=policy,
            skip_bin=_skip_bin,
            bin_skip_reason_override=_bin_skip_reason_override,
            trust_bin=trust_bin,
            source_plan=source_plan,
        )
    _skill_target_paths = _skill_summary_paths(
        skill_result.target_paths, project_root, targets
    ) or ["skills/"]
    _skill_suffix, _skill_expansion = _format_target_collapse(_skill_target_paths, _verbose)
    if skill_result.skill_created:
        result["skills"] += 1
    if skill_result.sub_skills_promoted > 0:
        result["sub_skills"] += skill_result.sub_skills_promoted
    # One tree line per package, whatever mix of root and promoted skills (#4089).
    from apm_cli.integration.skill_support import skill_line_label, skills_integrated

    _skill_count = skills_integrated(skill_result)
    if _skill_count > 0:
        _skill_label = skill_line_label(skill_result, _skill_count)
        if _skill_expansion:
            _log_integration(f"  |-- {_skill_label}:")
            for line in _skill_expansion:
                _log_integration(line)
        else:
            _log_integration(f"  |-- {_skill_label} -> {_skill_suffix}")
    if skill_result.bin_deployed > 0 or skill_result.bin_skipped_reason:
        from apm_cli.install.exec_gate import log_bin_status

        log_bin_status(
            skill_result, _skill_suffix, package_name, package_info, _log_integration, ctx=ctx
        )
    for tp in skill_result.target_paths:
        deployed.append(_deployed_path_entry(tp, project_root, targets))
    deployed.extend(
        _deployed_path_entry(path, project_root, targets) for path in skill_result.deployed_files
    )
    if source_plan.skill_discovery_complete is True and skill_result.complete is True:
        from apm_cli.core.deployment_state import CompletedReintegration

        result["completed_reintegration"] = CompletedReintegration(
            owner=package_name,
            targets=frozenset(
                target.name for target in projection_targets if target.supports("skills")
            ),
            current_values=frozenset(deployed),
            skill_values=frozenset(
                _deployed_path_entry(path, project_root, targets)
                for path in skill_result.deployed_files
            ),
        )

    # A3: warm-cache visibility. If nothing changed (adopted files never count),
    # say so once; the [+] header above already carries the SHA.
    _total_integrated = sum(_info["files"] for _info in _per_kind.values())
    _total_integrated += _skill_count
    _total_integrated += int(skill_result.bin_deployed)
    result["files_changed"] = _total_integrated
    # Hook files this package registers, written or unchanged (#4033).
    result["hooks_contributed"] = _hooks_registered
    if _total_integrated == 0:
        _log_integration("  |-- (files unchanged)")

    from apm_cli.claude_plugins.admission import queue_native_claude

    queue_native_claude(ctx, package_name, native_claude_plugin, diagnostics)
    return result


def integrate_local_content(  # noqa: PLR0913
    project_root: Path,
    *,
    targets: Any,
    prompt_integrator: Any,
    agent_integrator: Any,
    skill_integrator: Any,
    instruction_integrator: Any,
    command_integrator: Any,
    hook_integrator: Any,
    force: bool,
    managed_files: Any,
    diagnostics: DiagnosticCollector,
    logger: InstallLogger | None = None,
    scope: InstallScope | None = None,
    source_root: Path | None = None,
    ctx: InstallContext | None = None,
    deployment_plan: PackageDeploymentPlan | None = None,
) -> dict:
    """Integrate primitives from the project's own .apm/ directory.

    This treats the project root as a synthetic package so that local
    skills, instructions, agents, prompts, hooks, and commands in .apm/
    are deployed to target directories exactly like dependency primitives.

    Only .apm/ sub-directories are processed.  A root-level SKILL.md is
    intentionally ignored (it describes the project itself, not a
    deployable skill).

    Args:
        project_root: Deploy root -- where ``.claude/``, ``.codex/``,
            etc. are written.  Also used to compute relative paths for
            tracking deployed files.
        source_root: Where to discover the synthetic local package's
            ``.apm/`` content.  Defaults to ``project_root`` when not
            provided.  When ``apm install --root`` is in play,
            ``source_root`` stays at ``$PWD`` while ``project_root``
            points to the override.

    Returns a dict with integration counters and deployed file paths,
    same shape as ``integrate_package_primitives()``.
    """
    from ..integration.canvas_integrator import CanvasIntegrator
    from ..security.executables import AUTHORIZED_FIRST_PARTY, authorized_exec_map
    from .package_resolution import effective_dependency_selection

    if source_root is None:
        source_root = project_root

    local_info = build_project_local_package_info(source_root)

    return integrate_package_primitives(
        local_info,
        project_root,
        targets=targets,
        integrators=IntegratorBundle(
            prompt=prompt_integrator,
            agent=agent_integrator,
            skill=skill_integrator,
            instruction=instruction_integrator,
            command=command_integrator,
            hook=hook_integrator,
            canvas=CanvasIntegrator(),
        ),
        force=force,
        managed_files=managed_files,
        diagnostics=diagnostics,
        package_name="_local",
        logger=logger,
        scope=scope,
        skill_subset=effective_dependency_selection(None, ctx).skill_subset,
        skill_pairing=None,  # first-party content has no per-edge pairing (req-rs-018)
        ctx=ctx,
        is_first_party=True,
        deployment_plan=deployment_plan,
        allow_executables=authorized_exec_map(AUTHORIZED_FIRST_PARTY),
    )


# Underscore-prefixed aliases for backward compatibility with existing
# imports/patches in tests and elsewhere that use the old names.
_integrate_package_primitives = integrate_package_primitives
_integrate_local_content = integrate_local_content
_resolve_bin_skip = resolve_bin_skip
_plugin_bin_deployable = plugin_bin_deployable


# ---------------------------------------------------------------------------
# Local bundle integration (issue #1098)
# ---------------------------------------------------------------------------


def integrate_local_bundle(
    bundle_info: Any,
    project_root: Path,
    *,
    targets: Any,
    force: bool = False,
    dry_run: bool = False,
    diagnostics: DiagnosticCollector | None = None,
    logger: InstallLogger | None = None,
    scope: InstallScope | None = None,
    alias: str | None = None,
    allow_executables: builtins.dict[str, builtins.dict[str, bool]] | None = None,
    approval_key: str | None = None,
    create_config: bool = True,
) -> dict:
    """Integrate a detected local bundle into project / user scope.

    Local bundles are produced by ``apm pack`` and shipped (via shared file,
    USB, etc.) to environments that cannot reach the source registry.  This
    orchestrator deploys the bundle's plugin-format files into each active
    target's deploy root and returns a result dict mirroring
    ``integrate_local_content()``'s shape so the caller can persist
    ``local_deployed_files`` / ``local_deployed_file_hashes`` into the
    project lockfile.

    The bundle is treated as a *synthetic* package -- its slug derives from
    *alias* (``--as``) when provided, else from ``bundle_info.package_id``.

    Important contract: this function does **NOT** mutate ``apm.yml``.  Local
    bundles are imperative deploys, not declarative dependencies.

    Args:
        bundle_info: ``LocalBundleInfo`` describing the verified bundle.
        project_root: Workspace root (or ``Path.home()`` for ``--global``).
        targets: Resolved ``TargetProfile`` instances from
            ``resolve_targets()``.
        force: When ``True``, overwrite locally-modified files on collision.
        dry_run: When ``True``, report what would be deployed without
            writing to disk.
        diagnostics: Diagnostic collector for structured warnings.
        logger: Install-flow logger.
        scope: ``InstallScope`` (project vs user) for downstream consumers.
        alias: Slug override from ``--as``.
        allow_executables: Effective executable approvals; ``None`` approves nothing.
        approval_key: Exact local-bundle content identity for executable approval.
        create_config: Whether config reads may create the user config file.

    Returns:
        Dict with keys ``deployed_files`` (list[str]),
        ``deployed_file_hashes``, ``staged_files`` / ``staged_file_hashes`` (compile
        input under ``apm_modules/``, never deployment claims), ``staged_file_fallback_hashes``
        (bundle digests of collision-skipped staging), ``skipped`` (int), and per-primitive
        counters (``skills``, ``agents``, ``commands``, ...).
    """
    enforce_agent_plugin_deployment_boundary(bundle_info=bundle_info)

    import hashlib

    from apm_cli.integration import write_seam
    from apm_cli.utils.content_hash import compute_file_hash

    from ..core.scope import InstallScope
    from ..utils.path_security import (
        PathTraversalError,
        ensure_path_within,
        validate_path_segments,
    )

    bundle_dir: Path = bundle_info.source_dir
    pack_files = _deployable_pack_files(bundle_info)
    _retire_md_hooks(
        scope, project_root, targets, allow_executables, logger=logger, dry_run=dry_run
    )

    deployed_files: list[str] = []
    deployed_hashes: dict[str, str] = {}
    written_files: list[str] = []
    staged_files: list[str] = []
    staged_hashes: dict[str, str] = {}
    staged_fallback_hashes: dict[str, str] = {}
    skipped = 0

    slug = alias or bundle_info.package_id
    _renderings = _bundle_renderings(bundle_info)  # #3686: rendering provenance
    _known_deploy_prefixes = _known_bundle_prefixes()

    # Canvas extensions are executable: gated and retired like hooks and MCP.
    from ..security.executables import EXEC_TYPE_HOOKS, package_type_approved
    from .local_bundle_canvas import gate_bundle_canvas

    _bundle_keys = () if approval_key is None else (approval_key,)
    _hooks_approved_bundle = package_type_approved(allow_executables, _bundle_keys, EXEC_TYPE_HOOKS)
    _canvas_ok, _canvas_blocked = gate_bundle_canvas(
        pack_files,
        project_root,
        targets=targets,
        slug=str(slug),
        approval_key=approval_key,
        allow_executables=allow_executables,
        create_config=create_config,
        scope=scope,
        dry_run=dry_run,
        report=lambda message: (
            diagnostics.warn(message=message, package=str(slug))
            if diagnostics is not None
            else logger.warning(message)
            if logger is not None
            else None
        ),
    )
    skipped += _canvas_blocked

    if logger:
        logger.verbose_detail(
            f"Integrating local bundle '{slug}' "
            f"({len(pack_files)} file(s), targets={[t.name for t in targets]})"
        )

    # NOTE(M-arch-1): Local bundles intentionally do NOT route through
    # ``integrate_package_primitives`` -- they are an imperative deploy of
    # opaque files keyed by ``pack.bundle_files`` rather than a primitive
    # tree.  Revisit when local-bundle install needs to share collision /
    # link-resolution logic with the dependency-resolver pipeline.
    # TODO(#1098-v0.13): unify with integrate_package_primitives if/when
    # the bundle format grows primitive-typed transforms.
    for target in targets:
        _allowed_deploy_prefixes = _target_bundle_prefixes(target)
        # Resolve deploy root for this target.  Cowork targets can return
        # a dynamically-resolved path; fall back to root_dir under
        # project_root otherwise.
        resolved_root = getattr(target, "resolved_deploy_root", None)
        if resolved_root is not None:
            default_deploy_root = Path(resolved_root)
        else:
            default_deploy_root = project_root / target.root_dir

        # Build a primitive→deploy_root lookup so bundle entries that fall
        # under a primitive with an explicit ``deploy_root`` (e.g.
        # skills→.agents) are routed to the converged directory rather
        # than the per-client ``target.root_dir``.
        _primitive_roots: dict[str, Path] = {}
        for prim_name, prim_mapping in (target.primitives or {}).items():
            if getattr(prim_mapping, "deploy_root", None) and resolved_root is None:
                _primitive_roots[prim_name] = project_root / prim_mapping.deploy_root

        # #3686: an older bundle may hold several renderings of one primitive.
        _superseded = _superseded_renderings(
            list(pack_files),
            _allowed_deploy_prefixes,
            _known_deploy_prefixes,
            target=target,
            renderings=_renderings,
        )
        _warn_superseded(target.name, _superseded, diagnostics=diagnostics, logger=logger)
        skipped += len(_superseded)
        for rel in sorted(pack_files.keys() - _superseded.keys()):
            expected_hash = pack_files[rel]
            # CR1: bundle_files keys come from untrusted lockfile YAML
            # inside the bundle.  Reject traversal sequences before
            # constructing any filesystem path, then assert the resolved
            # destination stays inside ``deploy_root``.
            try:
                validate_path_segments(str(rel), context="bundle_files key")
            except PathTraversalError as exc:
                if logger is not None:
                    logger.warning(f"Skipped unsafe bundle entry {rel!r}: {exc}")
                skipped += 1
                continue
            src = bundle_dir / rel
            if not src.is_file() or src.is_symlink():
                skipped += 1
                continue

            # Issue #1207 D2.b: targets without an ``instructions`` primitive
            # (opencode, codex, gemini) get bundle instructions staged under
            # ``apm_modules/<slug>/.apm/instructions/`` for ``apm compile``.
            _rel_norm = rel.replace("\\", "/")
            _deploy_rel = _bundle_rel(
                _rel_norm,
                _allowed_deploy_prefixes,
                _known_deploy_prefixes,
                target=target,
                hooks_approved=_hooks_approved_bundle,
                canvas_approved=_canvas_ok,
                rendering_extension=_renderings.get(_rel_norm),
                source=src,
            )
            if _deploy_rel is None:
                if _skip_warning := _bundle_skip_warning(
                    _rel_norm,
                    _allowed_deploy_prefixes,
                    _known_deploy_prefixes,
                    target=target,
                    hooks_approved=_hooks_approved_bundle,
                    canvas_approved=_canvas_ok,
                    source=src,
                ):
                    if diagnostics is not None:
                        diagnostics.warn(message=_skip_warning, package=str(slug))
                    elif logger is not None:
                        logger.warning(_skip_warning)
                    skipped += 1
                continue
            _first_seg = _deploy_rel.split("/", 1)[0] if "/" in _deploy_rel else ""
            _staged = _first_seg == "instructions" and "instructions" not in target.primitives
            if _staged:
                _slug_str = str(slug)
                if _slug_error := _bundle_slug_error(_slug_str):
                    if logger is not None:
                        logger.warning(
                            f"Skipped instruction staging for unsafe slug "
                            f"{_slug_str!r}: {_slug_error}"
                        )
                    skipped += 1
                    continue
                stage_root = project_root / "apm_modules" / _slug_str / ".apm" / "instructions"
                try:
                    ensure_path_within(stage_root, project_root / "apm_modules")
                except PathTraversalError as exc:
                    if logger is not None:
                        logger.warning(f"Skipped unsafe stage root for {slug!r}: {exc}")
                    skipped += 1
                    continue
                # PR #1217 review: preserve nested subdirs under
                # ``instructions/`` so two files with the same basename
                # (e.g. ``instructions/a/x.md`` and
                # ``instructions/b/x.md``) do not collide at the staged
                # location.  ``rel`` already starts with
                # ``instructions/`` so we strip that prefix before
                # joining under the stage root (which itself ends in
                # ``.apm/instructions``).
                _rel_under_instructions = (
                    _deploy_rel.split("/", 1)[1] if "/" in _deploy_rel else Path(_deploy_rel).name
                )
                dest = stage_root / _rel_under_instructions
                deploy_root = stage_root
            else:
                # Route the file to the correct deploy root.  If the first
                # path segment matches a primitive with an explicit
                # ``deploy_root`` (e.g. ``skills/`` -> ``.agents/``), use
                # the converged directory.  Otherwise fall back to the
                # target's default root.
                deploy_root = _primitive_roots.get(_first_seg, default_deploy_root)
                dest = deploy_root / _deploy_rel
            if not bundle_entry_within(dest, deploy_root, project_root, rel, logger):
                skipped += 1
                continue
            try:
                if scope == InstallScope.USER:
                    # User scope: record absolute paths.
                    record = dest.as_posix()
                else:
                    # Project scope: record paths relative to project_root.
                    record = (
                        dest.relative_to(project_root).as_posix()
                        if dest.is_relative_to(project_root)
                        else dest.as_posix()
                    )
            except ValueError:
                record = dest.as_posix()

            if _bundle_render_format(  # rendered (Codex TOML), never copied (#3714)
                _rel_norm, _allowed_deploy_prefixes, _known_deploy_prefixes, target=target
            ):
                skipped += _deploy_bundle_codex_agent(
                    src,
                    dest,
                    rel_path=_rel_norm,
                    record=record,
                    collision_roots=(project_root, deploy_root),
                    expected_hash=expected_hash,
                    target_name=target.name,
                    slug=str(slug),
                    force=force,
                    dry_run=dry_run,
                    diagnostics=diagnostics,
                    logger=logger,
                    deployed_files=deployed_files,
                    deployed_hashes=deployed_hashes,
                    written_files=written_files,
                )
                continue

            normalized_text, _unrenderable = _render_bundle_rule(
                _normalized_bundle_text(src),
                _bundle_rule_format(
                    _rel_norm, _allowed_deploy_prefixes, _known_deploy_prefixes, target=target
                ),
                record=record,
                force=force,
                package_name=str(slug),
                diagnostics=diagnostics,
                logger=logger,
            )
            if _unrenderable:
                skipped += 1
                continue
            if normalized_text is None:
                desired_hash = expected_hash
            else:
                desired_hash = hashlib.sha256(normalized_text.encode("utf-8")).hexdigest()

            # Skip an existing file with different content unless --force (a dry run too).
            if dest.exists() and not force:
                try:
                    existing_hash = hashlib.sha256(dest.read_bytes()).hexdigest()
                except OSError:
                    existing_hash = None
                if existing_hash and existing_hash != desired_hash:
                    skipped += 1
                    if _staged:  # an edited, unrestaged file stays drift (#3718)
                        staged_fallback_hashes[record] = f"sha256:{desired_hash}"
                    msg = (
                        f"Skipped {record}: file exists with different "
                        "content. Re-run with --force to overwrite."
                    )
                    if diagnostics is not None:
                        diagnostics.warn(msg)
                    elif logger is not None:
                        logger.warning(msg)
                    continue
            if not dry_run:
                # Through the write seam: the install journals each write (#5046).
                write_seam.mkdir(dest.parent, parents=True, exist_ok=True)
                if normalized_text is None:
                    write_seam.copy2(src, dest)
                else:
                    write_seam.write_text_lf(dest, normalized_text)
            # Staged instructions are compile input, never deployment claims (#3705).
            claims = staged_files if _staged else deployed_files
            claims.append(record)
            written_files.extend(() if dry_run or _staged else (record,))
            # Canonical ``sha256:<hex>`` claims, staged ones included (#3718); IM4: a
            # real deploy hashes LF-normalized disk bytes, a dry run previews them.
            (staged_hashes if _staged else deployed_hashes)[record] = (
                f"sha256:{desired_hash}" if dry_run else compute_file_hash(dest)
            )
            if logger:
                logger.verbose_detail(
                    f"[dry-run] would deploy {record}" if dry_run else f"deployed {record}"
                )

    if _canvas_ok and not dry_run:
        from .local_bundle_canvas import record_bundle_canvas

        user_scope = scope is InstallScope.USER
        record_bundle_canvas(
            project_root, targets, str(slug), approval_key, deployed_files, user_scope=user_scope
        )

    _record_md_hooks(scope, project_root, targets, str(slug), approval_key, deployed_files, dry_run)
    from .local_bundle_hooks import hooks_denied_bundle as _hooks_denied_bundle
    from .local_bundle_hooks import integrate_local_bundle_hooks

    hook_result = integrate_local_bundle_hooks(
        bundle_info,
        pack_files,
        project_root,
        targets=targets,
        slug=str(slug),
        hooks_approved=(
            None
            if not _hooks_approved_bundle and _hooks_denied_bundle(allow_executables, approval_key)
            else _hooks_approved_bundle
        ),
        approval_key=approval_key,
        force=force,
        dry_run=dry_run,
        scope=scope,
        diagnostics=diagnostics,
        logger=logger,
    )
    deployed_files.extend(record for record in hook_result.scripts if record not in deployed_hashes)
    written_files.extend(hook_result.written)
    deployed_hashes.update(hook_result.script_hashes)
    skipped += hook_result.skipped

    return {
        "deployed_files": deployed_files,
        "deployed_file_hashes": deployed_hashes,
        "written_files": written_files,
        "staged_files": staged_files,
        "staged_file_hashes": staged_hashes,
        "staged_file_fallback_hashes": staged_fallback_hashes,
        "skipped": skipped,
        "skills": 0,
        "agents": 0,
        "commands": 0,
        "hooks": hook_result.hook_files,
        "instructions": 0,
        "prompts": 0,
        "sub_skills": 0,
    }
