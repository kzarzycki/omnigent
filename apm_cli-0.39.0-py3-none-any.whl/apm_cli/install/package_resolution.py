"""Helpers for install-time package reference resolution (structured apm.yml entries).

Extracted from ``apm_cli.commands.install`` to keep the command module smaller.
Call sites pass ``dependency_reference_cls`` and GitLab resolver callables so
tests that patch ``apm_cli.commands.install.DependencyReference`` and
``_try_resolve_gitlab_direct_shorthand`` keep working.
"""

from __future__ import annotations

import builtins
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from typing import Any, NamedTuple

from apm_cli.install import registry_wiring
from apm_cli.install.gitlab_resolver import _GITLAB_DIRECT_SHORTHAND_UNRESOLVED
from apm_cli.models.dependency.subsets import (
    SKILL_SELECT_ALL,
    SkillTargetSelection,
    skill_subset_selects_all,
    union_selection_names,
)
from apm_cli.utils.github_host import build_ssh_url

GIT_PARENT_USER_SCOPE_ERROR = (
    "git: parent dependencies are not supported at user scope. "
    "Use project scope or specify explicit git URL."
)


def dependency_reference_to_yaml_entry(dep_ref: Any) -> dict:
    """Serialize a structured dependency reference for ``apm.yml`` storage.

    A registry-sourced reference (a catalog entry routed to a registry) keeps
    its registry form; it is never rewritten as a ``git:`` entry (#4009).
    """
    if getattr(dep_ref, "source", None) == "registry":
        return dep_ref.to_apm_yml_entry()
    git_url = dep_ref.to_github_url()
    if dep_ref.explicit_scheme == "ssh":
        git_url = build_ssh_url(
            dep_ref.host,
            dep_ref.repo_url,
            port=dep_ref.port,
            user=dep_ref.ssh_user or "git",
        )
    entry = {"git": git_url}
    if dep_ref.virtual_path:
        entry["path"] = dep_ref.virtual_path
    if dep_ref.reference:
        entry["ref"] = dep_ref.reference
    if dep_ref.alias:
        entry["alias"] = dep_ref.alias
    return entry


def resolve_parsed_dependency_reference(
    package: str,
    marketplace_dep_ref: Any | None,
    *,
    dependency_reference_cls: Any,
    try_resolve_gitlab_direct_shorthand: Callable[..., Any],
    auth_resolver: Any,
    verbose: bool,
    resolve_artifactory_boundary: Callable[..., Any] | None = None,
    logger: Any = None,
) -> tuple[Any, bool]:
    """Parse or probe *package* into a ``DependencyReference``.

    Returns ``(dep_ref, direct_virtual_resolved)`` where the second flag is
    True when the dep should be persisted as a structured ``git:`` + ``path:``
    entry in ``apm.yml`` (the canonical shorthand cannot round-trip the probed
    boundary).  The two probe paths gate this flag differently:

    * **GitLab shorthand** -- True only when the resolved ref is a virtual
      package (``is_virtual and virtual_path``); a probe that lands on a bare
      repo with no virtual path stays in canonical shorthand form.
    * **Artifactory boundary** -- True whenever the probe rebuilt the ref
      (parse-time guess differed from the proxy-verified split); a probe that
      merely confirms the parse-time boundary keeps the original ref so
      apm.yml stays in its existing shape.

    For Artifactory deps the optional ``resolve_artifactory_boundary`` is
    authoritative: it returns the proxy-verified boundary or raises -- there
    is no silent fallback to the parse-time guess.

    Raises:
        ValueError: When GitLab or Artifactory probing fails to resolve.
    """
    dep_ref = (
        marketplace_dep_ref
        if marketplace_dep_ref is not None
        else dependency_reference_cls.parse(package)
    )
    if (
        marketplace_dep_ref is None
        and dependency_reference_cls.needs_gitlab_direct_shorthand_probing(package, dep_ref)
    ):
        resolved = try_resolve_gitlab_direct_shorthand(
            package,
            auth_resolver,
            verbose=verbose,
        )
        if resolved is None:
            raise ValueError(_GITLAB_DIRECT_SHORTHAND_UNRESOLVED)
        dep_ref = resolved
        direct_virtual_resolved = bool(dep_ref.is_virtual and dep_ref.virtual_path)
        return dep_ref, direct_virtual_resolved
    if marketplace_dep_ref is None and resolve_artifactory_boundary is not None:
        # The resolver decides its own applicability -- it short-circuits for
        # deps that don't route through the Artifactory proxy.  When it rebuilds
        # the dep_ref, the canonical shorthand can't round-trip the verified
        # boundary, so persist as a structured ``git:`` + ``path:`` entry.
        resolved = resolve_artifactory_boundary(
            package,
            auth_resolver,
            verbose=verbose,
            dep_ref=dep_ref,
            logger=logger,
        )
        if resolved is not dep_ref:
            return resolved, True
    return dep_ref, False


def user_scope_rejection_reason(dep_ref: Any, scope: Any) -> str | None:
    """Return a validation-fail reason if *dep_ref* is invalid at user scope.

    Per #937, only relative local paths are rejected at user scope -- absolute
    local paths are unambiguous and flow through the same _copy_local_package
    code path as project scope.
    """
    if scope is None:
        return None
    from apm_cli.core.scope import InstallScope
    from apm_cli.deps.path_anchoring import USER_SCOPE_RELATIVE_PATH_ERROR, local_dep_base_dir

    # A CLI argument is root-declared: the anchor owner decides (#4153).
    if (
        dep_ref.is_local
        and scope is InstallScope.USER
        and local_dep_base_dir(
            dep_ref.local_path or "", declaring_dir=None, source_root=None, user_scope=True
        )
        is None
    ):
        return USER_SCOPE_RELATIVE_PATH_ERROR
    if dep_ref.is_parent_repo_inheritance and scope is InstallScope.USER:
        return GIT_PARENT_USER_SCOPE_ERROR
    return None


def get_existing_dep_ref_for_identity(
    current_deps: builtins.list,
    identity: str,
    *,
    dependency_reference_cls: Any,
) -> Any | None:
    """Return the parsed existing manifest entry matching *identity*, or None."""
    for dep_entry in current_deps:
        try:
            if isinstance(dep_entry, builtins.str):
                existing_ref = dependency_reference_cls.parse(dep_entry)
            elif isinstance(dep_entry, builtins.dict):
                existing_ref = dependency_reference_cls.parse_from_dict(dep_entry)
            else:
                continue
        except (ValueError, TypeError, AttributeError, KeyError):
            continue
        if existing_ref.get_identity() == identity:
            return existing_ref
    return None


def propagate_existing_registry_source(
    dep_ref: Any,
    current_deps: builtins.list,
    identity: str,
    *,
    dependency_reference_cls: Any,
    logger: Any | None = None,
) -> bool:
    """Carry an existing registry-sourced entry's source onto a fresh dep_ref.

    A bare CLI positional (e.g. ``owner/repo#1.0.0``) always parses with
    ``source=None``/``"git"`` -- the string parser has no registry
    awareness. When *identity* is already declared as a registry
    dependency in apm.yml, propagate that onto *dep_ref* in place so
    downstream serialization (``to_apm_yml_entry``) doesn't silently
    convert it to a git dependency.

    Returns True when the existing entry was registry-sourced, so the
    caller can also short-circuit its probe-skip decision the same way.
    """
    existing_ref = get_existing_dep_ref_for_identity(
        current_deps, identity, dependency_reference_cls=dependency_reference_cls
    )
    is_registry = existing_ref is not None and getattr(existing_ref, "source", None) == "registry"
    if is_registry:
        dep_ref.source = "registry"
        dep_ref.registry_name = existing_ref.registry_name
        if logger:
            logger.verbose_detail(
                f"[i] {identity}: registry source propagated from existing manifest entry"
            )
    return is_registry


def get_existing_skill_subset(
    current_deps: builtins.list,
    identity: str,
    *,
    dependency_reference_cls: Any,
) -> builtins.list[str] | None:
    """Return the persisted ``skills:`` list for *identity*, or None."""
    existing_ref = get_existing_dep_ref_for_identity(
        current_deps, identity, dependency_reference_cls=dependency_reference_cls
    )
    if existing_ref is None:
        return None
    subset = getattr(existing_ref, "skill_subset", None)
    return list(subset) if subset else None


def normalize_and_merge_skill_subset(
    cli_subset: builtins.tuple[str, ...],
    current_deps: builtins.list,
    identity: str,
    *,
    dependency_reference_cls: Any,
) -> builtins.list[str]:
    """Normalize CLI ``--skill`` names and merge with existing manifest skills.

    Strips whitespace, drops empty strings, deduplicates, then unions with
    the persisted ``skills:`` list from ``apm.yml`` so that repeated
    ``--skill`` invocations are additive (issue #1771).

    Returns a sorted, deduplicated list ready for ``dep_ref.skill_subset``.
    """
    seen: builtins.set[str] = builtins.set()
    for s in cli_subset:
        s = s.strip()
        if s:
            seen.add(s)
    existing = get_existing_skill_subset(
        current_deps, identity, dependency_reference_cls=dependency_reference_cls
    )
    if existing:
        seen.update(existing)
    if skill_subset_selects_all(seen):
        return [SKILL_SELECT_ALL]  # "*" absorbs named skills (req-rs-018)
    return sorted(seen)


def effective_deploy_skill_subset(
    *,
    skill_subset_from_cli: bool,
    cli_subset: builtins.tuple[str, ...] | builtins.list[str] | None,
    persisted_subset: builtins.tuple[str, ...] | builtins.list[str] | None,
) -> builtins.tuple[str, ...] | None:
    """Resolve the skill subset to *deploy* for a SKILL_BUNDLE.

    ``--skill`` is additive (issue #1786): a targeted ``--skill B`` install must
    land on top of skills already pinned for the bundle instead of erasing them.
    The deployment therefore uses the union of the persisted manifest subset and
    the current CLI ``--skill`` values -- not the raw CLI subset alone.

    ``--skill '*'`` (signalled by ``skill_subset_from_cli`` True with an empty
    ``cli_subset``) resets the bundle to its full set, so this returns ``None``
    meaning "deploy all skills".

    Returns a sorted, deduplicated tuple, or ``None`` for "deploy all".
    """
    if skill_subset_from_cli and not cli_subset:
        return None  # --skill '*' -> full bundle
    return union_selection_names(persisted_subset, cli_subset)


class EffectiveDependencySelection(NamedTuple):
    """Skill and target selection one package deployment must honor.

    ``skill_pairing`` narrows ``skill_subset`` per target when the flat
    ``skill_subset x target_subset`` product would over-select (req-rs-018);
    ``None`` means every selected target receives every selected skill.
    """

    skill_subset: builtins.tuple[str, ...] | None
    target_subset: builtins.list[str] | None
    skill_pairing: SkillTargetSelection | None = None


def is_implicit_local(dep_ref: Any, ctx: Any | None) -> bool:
    """Return True for a local dep a partial install adds only for lock coverage."""
    implicit = getattr(ctx, "implicit_local_keys", None)
    if not implicit:
        return False
    try:
        return dep_ref.get_unique_key() in implicit
    except (AttributeError, TypeError):
        return False


def effective_dependency_selection(
    dep_ref: Any | None,
    ctx: Any | None = None,
) -> EffectiveDependencySelection:
    """Return the effective deploy selection for one dependency (#3760).

    This is the single owner every ``prepare_package_deployment`` and
    ``integrate_package_primitives`` caller routes through: install
    preflight and deploy, audit replay and uninstall survivor
    re-integration. ``None`` in either field means "no restriction".

    *dep_ref* ``None`` is first-party project content, which has no
    selection. *ctx* carries the install invocation's CLI ``--skill``
    overlay; lifecycle paths without an install context (uninstall,
    audit replay) pass ``None`` and deploy exactly the persisted selection.
    """
    if dep_ref is None:
        return EffectiveDependencySelection(None, None)
    if is_implicit_local(dep_ref, ctx):
        ctx = None  # #4198: the CLI --skill overlay targets the named packages only
    skill_subset = effective_deploy_skill_subset(
        skill_subset_from_cli=bool(getattr(ctx, "skill_subset_from_cli", False)),
        cli_subset=getattr(ctx, "skill_subset", None),
        persisted_subset=getattr(dep_ref, "skill_subset", None),
    )
    target_subset = getattr(dep_ref, "target_subset", None)
    pairing = getattr(dep_ref, "subset_pairings", None)
    if not isinstance(pairing, SkillTargetSelection):
        pairing = None  # raw lock records are decoded via LockedDependency.selection()
    cli_subset = getattr(ctx, "skill_subset", None)
    if pairing is not None and getattr(ctx, "skill_subset_from_cli", False) and not cli_subset:
        pairing = None  # --skill '*': every skill on every selected target
    elif pairing is not None and cli_subset:
        # The CLI overlay acts as one more edge over the dependency's targets.
        pairing = pairing.with_edge(cli_subset, target_subset)
        pairing = None if pairing.is_product else pairing
    return EffectiveDependencySelection(
        skill_subset,
        builtins.list(target_subset) if target_subset else None,
        pairing,
    )


def cli_skill_subset(
    skill_names: builtins.tuple[str, ...],
) -> builtins.tuple[str, ...] | None:
    """Resolve raw CLI ``--skill`` names to a subset, or None for absent / ``'*'``.

    ``--skill '*'`` means "all skills" (same as absent); the resolver still
    learns the flag was present via a separate CLI-origin flag, so this
    collapses both the absent and ``'*'`` cases to None.
    """
    if skill_names and not any(s == "*" for s in skill_names):
        return builtins.tuple(skill_names)
    return None


def apply_cli_skill_pin(
    dep_ref: Any,
    cli_subset: builtins.tuple[str, ...] | None,
    skill_subset_from_cli: bool,
    current_deps: builtins.list,
    apm_yml_entries: dict,
    *,
    dependency_reference_cls: Any,
    logger: Any | None = None,
) -> None:
    """Attach, merge, or reset a CLI ``--skill`` pin on ``dep_ref`` in place.

    With an explicit ``cli_subset``, merge it additively with any persisted
    ``skills:`` so repeated ``--skill`` invocations union rather than replace
    (issue #1771). With ``--skill '*'`` (``skill_subset_from_cli`` True and an
    empty ``cli_subset``), reset the pin back to the full bundle and record the
    refreshed plain-string ``apm.yml`` entry under the reference's canonical key
    so manifest and on-disk state agree on the whole bundle (issue #1786 reset).
    """
    identity = dep_ref.get_identity()
    if cli_subset:
        dep_ref.skill_subset = normalize_and_merge_skill_subset(
            cli_subset,
            current_deps,
            identity,
            dependency_reference_cls=dependency_reference_cls,
        )
        return
    if skill_subset_from_cli:
        dep_ref.skill_subset = None
        apm_yml_entries[dep_ref.to_canonical()] = dep_ref.to_apm_yml_entry()
        if logger:
            logger.verbose_detail(
                f"    [i] {identity}: skill pin reset to full bundle "
                "(--skill '*'); a later bare 'apm install' deploys all skills"
            )


def manifest_has_different_entry_for_identity(
    current_deps: builtins.list,
    identity: str,
    canonical: str,
    *,
    dependency_reference_cls: Any,
) -> bool:
    """Return True when apm.yml already has *identity* but not *canonical*."""
    for dep_entry in current_deps:
        try:
            if isinstance(dep_entry, builtins.str):
                existing_ref = dependency_reference_cls.parse(dep_entry)
            elif isinstance(dep_entry, builtins.dict):
                existing_ref = dependency_reference_cls.parse_from_dict(dep_entry)
            else:
                continue
        except (ValueError, TypeError, AttributeError, KeyError):
            continue
        if existing_ref.get_identity() == identity:
            return existing_ref.to_canonical() != canonical
    return False


def update_existing_dependency_entry_if_needed(
    current_deps: builtins.list,
    *,
    already_in_deps: bool,
    apm_yml_entries: dict,
    canonical: str,
    dep_ref: Any,
    identity: str,
    dependency_reference_cls: Any,
    default_registry: str | None = None,
    logger: Any = None,
    ref_only: bool = False,
) -> bool:
    """Apply explicit reference, selection or HTTPS-upgrade intent."""
    requested_entry = apm_yml_entries.get(canonical, dep_ref.to_apm_yml_entry())
    https_upgrade = False
    if already_in_deps and getattr(dep_ref, "explicit_scheme", None) == "https":
        existing_ref = get_existing_dep_ref_for_identity(
            current_deps, identity, dependency_reference_cls=dependency_reference_cls
        )
        if existing_ref is not None and getattr(existing_ref, "is_insecure", False) is True:
            https_upgrade = True
            if canonical not in apm_yml_entries:
                requested_entry = existing_ref.to_apm_yml_entry()
                requested_entry.update(dependency_reference_to_yaml_entry(existing_ref))
                if dep_ref.reference:
                    requested_entry["ref"] = dep_ref.reference
            elif isinstance(requested_entry, str):
                requested_entry = dependency_reference_to_yaml_entry(dep_ref)
            else:
                requested_entry = dict(requested_entry)
            requested_entry["git"] = dep_ref.to_github_url()
            requested_entry.pop("allow_insecure", None)

    should_update = already_in_deps and (
        https_upgrade
        or canonical in apm_yml_entries
        or (
            dep_ref.reference
            and manifest_has_different_entry_for_identity(
                current_deps,
                identity,
                canonical,
                dependency_reference_cls=dependency_reference_cls,
            )
        )
    )
    if should_update:
        return merge_structured_entry_into_current_deps(
            current_deps,
            requested_entry,
            identity,
            canonical,
            dependency_reference_cls=dependency_reference_cls,
            default_registry=default_registry,
            logger=logger,
            ref_only=ref_only and not https_upgrade,
        )
    return False


def try_update_existing_dependency_entry(
    current_deps: builtins.list,
    *,
    already_in_deps: bool,
    apm_yml_entries: dict,
    canonical: str,
    dep_ref: Any,
    identity: str,
    dependency_reference_cls: Any,
    default_registry: str | None = None,
    logger: Any = None,
    ref_only: bool = False,
) -> tuple[bool, str | None]:
    """Like update_existing_dependency_entry_if_needed, but returns
    (updated, error) instead of raising, so callers can report a refused
    registry-to-git conversion as an ordinary invalid-package outcome."""
    try:
        updated = update_existing_dependency_entry_if_needed(
            current_deps,
            already_in_deps=already_in_deps,
            apm_yml_entries=apm_yml_entries,
            canonical=canonical,
            dep_ref=dep_ref,
            identity=identity,
            dependency_reference_cls=dependency_reference_cls,
            default_registry=default_registry,
            logger=logger,
            ref_only=ref_only,
        )
    except ValueError as e:
        return False, str(e)
    return updated, None


def _ref_only_update(existing: Any, existing_ref: Any, requested_ref: Any) -> dict | None:
    """The existing ``git:`` object entry with only its ref changed (#5154).

    ``install <pkg>#<ref>`` with no other selection intent carries identity
    and ref only, so the object's other fields (skills, targets, alias, path)
    stay. A ``ref:`` field overrides an inline ``git: ...#ref``. ``None``
    when *existing* is not a ``git:`` object entry.
    """
    if not isinstance(existing, dict) or not isinstance(existing.get("git"), str):
        return None
    if existing_ref.reference == requested_ref.reference:
        return existing
    return {**existing, "ref": requested_ref.reference}


def merge_structured_entry_into_current_deps(
    current_deps: builtins.list,
    structured_entry: str | dict,
    identity: str,
    canonical: str,
    *,
    dependency_reference_cls: Any,
    default_registry: str | None = None,
    logger: Any = None,
    ref_only: bool = False,
) -> bool:
    """Replace by identity only when effective manifest intent changes.

    *ref_only* marks ``install <pkg>#<ref>`` with no other selection intent:
    an existing ``git:`` object entry then changes only its ref (#5154).
    """
    for idx, dep_entry in enumerate(current_deps):
        try:
            if isinstance(dep_entry, builtins.str):
                existing_ref = dependency_reference_cls.parse(dep_entry)
            elif isinstance(dep_entry, builtins.dict):
                existing_ref = dependency_reference_cls.parse_from_dict(dep_entry)
            else:
                continue
        except (ValueError, TypeError, AttributeError, KeyError):
            continue
        if existing_ref.get_identity() == identity:
            if getattr(existing_ref, "source", None) == "registry" and not (
                isinstance(structured_entry, dict)
                and ("id" in structured_entry or "registry" in structured_entry)
            ):
                raise ValueError(
                    f"'{identity}' is already declared as a registry dependency; "
                    f"refusing to silently convert it to a git dependency. Use the "
                    f"object form ('- id: ...' / '- registry: ...') to change its "
                    f"version, or an explicit '- git:' entry to intentionally "
                    f"switch resolvers."
                )
            requested_ref = (
                dependency_reference_cls.parse(structured_entry)
                if isinstance(structured_entry, str)
                else dependency_reference_cls.parse_from_dict(structured_entry)
            )
            requires_explicit_path = (
                isinstance(structured_entry, dict)
                and "git" in structured_entry
                and "path" in structured_entry
            )
            has_explicit_path = (
                isinstance(dep_entry, dict) and "git" in dep_entry and "path" in dep_entry
            )
            # Flattened references cannot preserve a probed repository boundary.
            if (
                existing_ref.to_apm_yml_entry() == requested_ref.to_apm_yml_entry()
                and existing_ref.repo_url == requested_ref.repo_url
                and existing_ref.virtual_path == requested_ref.virtual_path
                and existing_ref.alias == requested_ref.alias
                and registry_wiring.should_skip_github_probe_for_dep(existing_ref, default_registry)
                == registry_wiring.should_skip_github_probe_for_dep(requested_ref, default_registry)
                and (not requires_explicit_path or has_explicit_path)
            ):
                return False
            if ref_only and (update := _ref_only_update(dep_entry, existing_ref, requested_ref)):
                if update is dep_entry:
                    return False
                structured_entry = update
            current_deps[idx] = structured_entry
            if logger:
                logger.verbose_detail(
                    f"Updated existing dependency entry to structured form: {canonical}"
                )
            return True
    current_deps.append(structured_entry)
    return True


def persist_dependency_list_if_changed(
    *,
    dependencies_changed: bool,
    data: dict,
    dep_section: str,
    current_deps: builtins.list,
    apm_yml_path: Any,
    apm_yml_filename: str,
    logger: Any = None,
    rich_error: Callable[[str], None],
    sys_exit: Callable[[int], None],
) -> None:
    """Write *apm.yml* when *current_deps* was updated without new packages."""
    if not dependencies_changed:
        return
    data[dep_section]["apm"] = current_deps
    try:
        from apm_cli.utils.yaml_io import dump_yaml_roundtrip

        dump_yaml_roundtrip(data, apm_yml_path)
        if logger:
            logger.success(f"Updated {apm_yml_filename} dependency entries")
    except Exception as e:
        if logger:
            logger.error(f"Failed to write {apm_yml_filename}: {e}")
        else:
            rich_error(f"Failed to write {apm_yml_filename}: {e}")
        sys_exit(1)


def dependency_sections(data: Any, *, dev: bool) -> tuple[str, builtins.list, builtins.list]:
    """Return the install target section, its APM list and the other section's list.

    The target section is created when missing; the other section is only read.
    An empty or null target list is returned detached: the persist helpers
    reattach it with ``data[target]["apm"] = current_deps`` before writing.
    """
    target, other = (
        ("devDependencies", "dependencies") if dev else ("dependencies", "devDependencies")
    )
    data.setdefault(target, {})
    data[target].setdefault("apm", [])
    other_section = data.get(other)
    other_deps = other_section.get("apm") if isinstance(other_section, dict) else None
    return target, data[target]["apm"] or [], other_deps or []


@dataclass(frozen=True)
class CrossSectionDeclarations:
    """Requested packages already declared in the other dependency section."""

    dev: bool
    moved: tuple[str, ...] = ()
    borrowed: tuple[tuple[int, str], ...] = ()


def borrow_cross_section_declarations(
    packages: Iterable[str],
    current_deps: builtins.list,
    other_deps: builtins.list,
    *,
    dev: bool,
) -> CrossSectionDeclarations:
    """Expose a requested package's existing declaration to validation (#3693).

    Validation then applies its explicit-change rules to that declaration, so
    omitted CLI options keep its ref, source, registry and selection fields.
    npm semantics: ``install --dev X`` moves X's ``dependencies`` declaration
    into ``devDependencies`` (one declaration per package); a plain
    ``install X`` validates X's ``devDependencies`` declaration in place --
    it is lent to *current_deps* and returned by
    :func:`settle_cross_section_declarations`.
    """
    from apm_cli.models.dependency.selection import (
        manifest_declarations_of,
        parse_dependency_entry,
    )

    moved: builtins.list[str] = []
    borrowed: builtins.list[tuple[int, str]] = []
    for package in packages:
        declared = manifest_declarations_of(other_deps, [package])
        if not declared:
            continue
        identity = parse_dependency_entry(declared[0]).get_identity()
        already_declared = manifest_declarations_of(current_deps, declared[:1])
        if dev:
            for declaration in declared:
                other_deps.remove(declaration)
            if not already_declared:
                current_deps.append(declared[0])
            moved.append(identity)
        elif not already_declared:
            index = next(i for i, entry in enumerate(other_deps) if entry is declared[0])
            current_deps.append(declared[0])
            borrowed.append((index, identity))
    return CrossSectionDeclarations(dev, tuple(moved), tuple(borrowed))


def settle_cross_section_declarations(
    declarations: CrossSectionDeclarations,
    current_deps: builtins.list,
    other_deps: builtins.list,
    *,
    dry_run: bool = False,
    logger: Any = None,
) -> bool:
    """Return lent declarations to their section and report moves.

    A lent declaration that validation updated replaces the original at its
    position. Returns whether apm.yml must be written for these sections.
    """
    from apm_cli.models.dependency.selection import manifest_declarations_of

    changed = bool(declarations.moved)
    for index, identity in declarations.borrowed:
        # Exactly one match: the lent entry, possibly replaced by validation.
        declaration = manifest_declarations_of(current_deps, [other_deps[index]])[0]
        current_deps.remove(declaration)
        if declaration != other_deps[index]:
            other_deps[index] = declaration
            changed = True
        if logger:
            logger.progress(f"{identity} is declared in devDependencies; kept it there")
    action = "Would move" if dry_run else "Moved"
    for identity in declarations.moved if logger else ():
        logger.progress(f"{action} {identity} from dependencies to devDependencies")
    return changed
