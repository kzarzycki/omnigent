"""APM self-update command (renamed from ``update`` in #1203).

This is the platform-aware self-updater for the APM CLI binary itself.
The command is exposed as ``apm self-update`` to free the ``apm update``
verb for dependency-graph refresh (the package-manager convention).

A back-compat shim in :mod:`apm_cli.cli` keeps ``apm update`` working as
a deprecated alias when invoked outside an APM project (no ``apm.yml``
in the current directory).
"""

import os
import sys
from dataclasses import dataclass

import click

from apm_cli.core.remediation import (
    CLI_BINARY_OUTDATED,
    CLI_INSTALLER_UNREACHABLE,
)
from apm_cli.utils import git_env

from ..bootstrap_mirror import (
    append_url_path,
    get_installer_base_url,
    get_release_metadata_url,
    installer_public_download_blocked,
    release_metadata_public_lookup_blocked,
)
from ..core.command_logger import CommandLogger
from ..install.locking import serialized_lifecycle_unless
from ..update_policy import get_self_update_disabled_message, is_self_update_enabled
from ..utils.subprocess_env import external_process_env
from ..version import get_version

_DEFAULT_GITHUB_URL = "https://github.com"
_DEFAULT_APM_REPO = "microsoft/apm"
_INSTALL_SCRIPT_REF = "main"
_ENV_SELF_UPDATE_CHANNEL = "APM_SELF_UPDATE_CHANNEL"
_ENV_INSTALL_DIR = "APM_INSTALL_DIR"
_ENV_VERSION = "VERSION"
_ENV_PS_MODULE_PATH = "PSMODULEPATH"


@dataclass(frozen=True)
class _ResolvedSelfUpdateRelease:
    """One validated release selection shared by every installer input."""

    version: str
    tag: str


def _resolve_self_update_release(version: str) -> _ResolvedSelfUpdateRelease:
    """Normalize one release version and reject malformed installer refs."""
    from ..utils.version_checker import parse_version

    normalized_version = version[1:] if version.startswith("v") else version
    if version != version.strip() or parse_version(normalized_version) is None:
        raise ValueError(
            "Invalid self-update release version; expected X.Y.Z or vX.Y.Z "
            "with an optional aN, bN, or rcN suffix."
        )
    return _ResolvedSelfUpdateRelease(
        version=normalized_version,
        tag=f"v{normalized_version}",
    )


def _is_windows_platform() -> bool:
    """Return True when running on native Windows."""
    return sys.platform == "win32"


def _get_update_installer_url(
    release: _ResolvedSelfUpdateRelease | None = None,
) -> str:
    """Return the installer URL for the current platform, respecting mirror env vars.

    ``APM_INSTALLER_BASE_URL`` wins when configured, using ``install.sh`` on
    Unix and ``install.ps1`` on Windows under that base URL. A resolved release
    uses its exact tag on public GitHub or a custom ``GITHUB_URL``. Without a
    resolved release, existing aka.ms and ``main`` fallbacks are preserved.
    """
    github_url = os.environ.get("GITHUB_URL", _DEFAULT_GITHUB_URL).rstrip("/")
    apm_repo = os.environ.get("APM_REPO", _DEFAULT_APM_REPO)
    script_name = "install.ps1" if _is_windows_platform() else "install.sh"

    installer_base_url = get_installer_base_url()
    if installer_base_url is not None:
        return append_url_path(installer_base_url, script_name)

    if installer_public_download_blocked(github_url):
        raise RuntimeError(
            "APM_NO_DIRECT_FALLBACK is set, but APM_INSTALLER_BASE_URL is not configured. "
            "Set APM_INSTALLER_BASE_URL to a mirror containing install.sh/install.ps1."
        )

    if release is None and github_url == _DEFAULT_GITHUB_URL:
        return "https://aka.ms/apm-windows" if _is_windows_platform() else "https://aka.ms/apm-unix"

    resolved_ref = release.tag if release is not None else _INSTALL_SCRIPT_REF
    return f"{github_url}/{apm_repo}/raw/{resolved_ref}/{script_name}"


def _get_update_installer_suffix() -> str:
    """Return the file suffix for the downloaded installer script."""
    return ".ps1" if _is_windows_platform() else ".sh"


def _get_manual_update_command(
    release: _ResolvedSelfUpdateRelease | None = None,
) -> str:
    """Return the manual update action for the current platform."""
    if _is_windows_platform():
        if get_installer_base_url() is not None:
            installer_url = "$env:APM_INSTALLER_BASE_URL/install.ps1"
        else:
            try:
                installer_url = _get_update_installer_url(release)
            except RuntimeError:
                return CLI_INSTALLER_UNREACHABLE.sentence()
        command = f"powershell -ExecutionPolicy Bypass -c 'irm \"{installer_url}\" | iex'"
        if release is not None:
            return f"$env:VERSION='{release.tag}'; {command}"
        return command

    if get_installer_base_url() is not None:
        installer_url = "$APM_INSTALLER_BASE_URL/install.sh"
    else:
        try:
            installer_url = _get_update_installer_url(release)
        except RuntimeError:
            return CLI_INSTALLER_UNREACHABLE.sentence()
    command = f'curl -sSL "{installer_url}"'
    if release is not None:
        return f"{command} | env VERSION='{release.tag}' sh"
    return f"{command} | sh"


def _log_no_direct_metadata_error(logger: CommandLogger) -> None:
    """Emit the actionable fail-closed metadata configuration error."""
    logger.error("APM_NO_DIRECT_FALLBACK is set, but no release metadata mirror is configured.")
    logger.info(
        "Set APM_RELEASE_METADATA_URL to mirrored latest.json, or set VERSION to a pinned release."
    )


def _get_installer_run_command(script_path: str) -> list[str]:
    """Return the installer execution command for the current platform."""
    if _is_windows_platform():
        powershell_path = git_env.trusted_executable("powershell") or git_env.trusted_executable(
            "pwsh"
        )
        if not powershell_path:
            raise FileNotFoundError("PowerShell executable not found in PATH")
        return [powershell_path, "-ExecutionPolicy", "Bypass", "-File", script_path]

    shell_path = git_env.trusted_executable("bash")
    if not shell_path:
        if os.path.exists("/bin/bash"):
            shell_path = "/bin/bash"
        else:
            raise FileNotFoundError("bash executable not found; cannot run installer script")
    return [shell_path, script_path]


def _get_effective_self_update_channel() -> str:
    """Return the invocation-scoped or persisted self-update channel."""
    from ..config import get_self_update_channel, normalize_self_update_channel

    env_value = os.environ.get(_ENV_SELF_UPDATE_CHANNEL, "").strip()
    if env_value:
        return normalize_self_update_channel(env_value)
    return get_self_update_channel()


def get_latest_version_for_self_update(channel: str) -> str | None:
    """Return the latest version for a supported self-update channel."""
    from ..utils.version_checker import get_latest_version_from_github

    return get_latest_version_from_github(
        include_prerelease=(channel == "prerelease"), raise_errors=True
    )


def _build_self_update_installer_env(
    release: _ResolvedSelfUpdateRelease,
) -> dict[str, str]:
    """Build the installer subprocess environment from non-secret preferences.

    Invocation-scoped environment variables win over persisted config. This
    helper only maps the bounded non-secret installer preferences accepted by
    ``apm config``; credentials and mirror URLs stay on the existing auth/env
    paths and are never read from persisted self-update config.
    """
    from ..config import get_self_update_install_dir

    # APM authored the installer: what it calls resolves outside the project.
    env = git_env.trusted_path_environment(external_process_env())
    install_dir = get_self_update_install_dir()
    if install_dir and _ENV_INSTALL_DIR not in env:
        env[_ENV_INSTALL_DIR] = install_dir

    channel = _get_effective_self_update_channel()
    if _ENV_SELF_UPDATE_CHANNEL not in env:
        env[_ENV_SELF_UPDATE_CHANNEL] = channel
    env[_ENV_VERSION] = release.tag
    if _is_windows_platform():
        # A PowerShell 7 parent leaks its module path into Windows PowerShell
        # through apm.exe, loading incompatible built-in modules (#3926). Without
        # PSModulePath, each host rebuilds its own default module path.
        for key in [key for key in env if key.upper() == _ENV_PS_MODULE_PATH]:
            del env[key]
    else:
        # Pass identity, not a second destination policy: install.sh owns routing.
        env["APM_SELF_UPDATE_SOURCE"] = os.path.abspath(
            sys.executable if getattr(sys, "frozen", False) else sys.argv[0]
        )
    return env


@click.command(
    name="self-update",
    help=(
        "Update the APM CLI binary itself to the latest version.\n\n"
        "Set these to route updates through an internal mirror (optional):\n"
        "  APM_RELEASE_METADATA_URL  latest.json mirror URL.\n"
        "  APM_RELEASE_BASE_URL      release asset mirror base URL.\n"
        "  APM_INSTALLER_BASE_URL    install.sh/install.ps1 mirror base URL.\n"
        "  APM_PYPI_INDEX_URL        PyPI mirror for installer fallback.\n"
        "  APM_NO_DIRECT_FALLBACK    1 means fail closed on public fallback.\n"
    ),
)
@click.option("--check", is_flag=True, help="Only check for updates without installing")
@serialized_lifecycle_unless("check")
def self_update(check: bool) -> None:
    """Update APM CLI to the latest version (like npm update -g npm).

    This command fetches and installs the latest version of APM using the
    official install script. It will detect your platform and architecture
    automatically.

    Examples:
        apm self-update         # Update to latest version
        apm self-update --check # Only check if update is available
    """
    try:
        import subprocess
        import tempfile

        logger = CommandLogger("self-update")

        if not is_self_update_enabled():
            logger.warning(get_self_update_disabled_message())
            return

        current_version = get_version()

        # Skip check for development versions
        if current_version == "unknown":
            logger.warning("Cannot determine current version. Running in development mode?")
            if not check:
                logger.progress("To update, reinstall from the repository.")
            return

        from ..deps.egress_route import EgressRoute, EgressSurface, route_for

        route = route_for(EgressSurface.SELF_UPDATE)
        if route is not EgressRoute.DIRECT:
            logger.error(f"The APM release route is {route.value}; cannot self-update.")
            sys.exit(1)

        logger.progress(f"Current version: {current_version}")
        logger.start("Checking for updates...")

        _github_url = os.environ.get("GITHUB_URL", "").rstrip("/")
        if _github_url and _github_url != _DEFAULT_GITHUB_URL:
            logger.progress(f"GITHUB_URL override active -- using host: {_github_url!r}")
        _release_metadata_url = get_release_metadata_url()
        if _release_metadata_url:
            logger.progress("APM_RELEASE_METADATA_URL override active -- using mirrored metadata")
        try:
            _channel = _get_effective_self_update_channel()
        except ValueError as exc:
            logger.error(str(exc))
            sys.exit(1)
        if _channel != "stable":
            logger.progress(f"Self-update channel: {_channel}")

        _pinned = os.environ.get("VERSION", "")
        if _pinned:
            logger.progress(f"VERSION env var set -- API call skipped, using: {_pinned!r}")

        if release_metadata_public_lookup_blocked(_github_url or _DEFAULT_GITHUB_URL):
            _log_no_direct_metadata_error(logger)
            sys.exit(1)

        # Check for latest version
        from ..utils.version_checker import ReleaseMetadataError

        try:
            latest_version = get_latest_version_for_self_update(_channel)
        except ReleaseMetadataError as exc:
            logger.error(str(exc))
            sys.exit(1)

        if not latest_version:
            if _pinned:
                logger.error(
                    "Invalid VERSION value; expected X.Y.Z or vX.Y.Z "
                    "with an optional aN, bN, or rcN suffix."
                )
                sys.exit(1)
            if _release_metadata_url:
                logger.error("Unable to fetch latest version from APM_RELEASE_METADATA_URL mirror")
                logger.info(
                    "Check the mirror URL, publish latest.json, or set VERSION to a pinned release."
                )
            elif _channel == "prerelease":
                logger.error("Unable to fetch a prerelease version from remote")
                logger.info(
                    "No prerelease was found or the lookup failed; switch to stable with "
                    "`apm config set self-update.channel stable`."
                )
            else:
                logger.error("Unable to fetch latest version from remote")
                logger.info("Check your internet connection or try again later.")
            sys.exit(1)

        try:
            release = _resolve_self_update_release(latest_version)
        except ValueError as exc:
            logger.error(str(exc))
            sys.exit(1)

        from ..utils.version_checker import is_newer_version

        if not is_newer_version(current_version, release.version):
            logger.success(
                f"You're already on the latest version: {current_version}",
                symbol="check",
            )
            return

        logger.progress(f"Latest version available: {release.version}", symbol="sparkles")

        if check:
            logger.warning(f"Update available: {current_version} -> {release.version}")
            logger.progress(CLI_BINARY_OUTDATED.sentence())
            return

        # Proceed with update
        logger.start("Downloading and installing update...")

        # Download install script to temp file
        try:
            import requests

            try:
                install_script_url = _get_update_installer_url(release)
            except RuntimeError as exc:
                logger.error(str(exc))
                logger.info(
                    "Unset APM_NO_DIRECT_FALLBACK only if public installer fallback is allowed."
                )
                sys.exit(1)
            logger.progress(f"Installer release: {release.tag}")
            response = requests.get(install_script_url, timeout=10)
            response.raise_for_status()

            # Create temporary file for install script
            from ..config import get_apm_temp_dir

            with tempfile.NamedTemporaryFile(
                mode="w",
                suffix=_get_update_installer_suffix(),
                delete=False,
                dir=get_apm_temp_dir(),
            ) as f:
                temp_script = f.name
                f.write(response.text)

            if not _is_windows_platform():
                os.chmod(temp_script, 0o755)  # noqa: S103

            # Run install script
            logger.progress("Running installer...", symbol="gear")

            # Note: We don't capture output so the installer can prompt when needed.
            # Sanitise the environment so the installer (and the system binaries
            # it spawns -- curl and tar) do not inherit the PyInstaller
            # bootloader's LD_LIBRARY_PATH / DYLD_* overrides, which would
            # otherwise redirect system linkers at this binary's bundled
            # _internal directory.  See issue #894.
            try:
                result = subprocess.run(
                    _get_installer_run_command(temp_script),
                    check=False,
                    env=_build_self_update_installer_env(release),
                )
            finally:
                try:  # noqa: SIM105
                    os.unlink(temp_script)
                except OSError:
                    # Non-fatal: failed to delete temp install script
                    pass

            if result.returncode == 0:
                logger.success(
                    f"Successfully updated to version {release.version}!",
                )
                if _is_windows_platform():
                    logger.progress("Please restart your terminal or run 'apm --version' to verify")
            else:
                logger.error("Installation failed - see output above for details")
                sys.exit(1)

        except ImportError:
            logger.error("'requests' library not available")
            logger.info("Update manually using:")
            click.echo(f"  {_get_manual_update_command(release)}")
            sys.exit(1)
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            logger.error(f"Update failed: {exc}")
            logger.info("Update manually using:")
            click.echo(f"  {_get_manual_update_command(release)}")
            sys.exit(1)

    except (OSError, ValueError) as exc:
        _logger = CommandLogger("self-update")
        _logger.error(f"Error during update: {exc}")
        sys.exit(1)
