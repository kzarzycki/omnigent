"""APM audit command -- content integrity scanning for installed primitives.

Scans installed APM primitives (or arbitrary files) for hidden Unicode
characters, drift, and lockfile/policy violations.

Exit codes:
    0 -- clean (no findings, or info-only)
    1 -- critical findings detected
    2 -- warnings only (no critical)
"""

import dataclasses
import functools
import os
import sys
from pathlib import Path

import click

from apm_cli.core.scope import manifest_file

from ..core.command_logger import CommandLogger
from ..core.deployment_ledger import (
    DEPLOYMENT_OWNER_REMEDIATION,
    DeploymentLedgerCodec,
    DeploymentOwnerViolation,
)
from ..core.remediation import HIDDEN_CHARACTERS_FOUND, HIDDEN_CHARACTERS_PREVIEWED
from ..deps.lockfile import LockFile, get_lockfile_path
from ..install.locking import serialized_lifecycle_when
from ..policy._help_text import POLICY_SOURCE_FORMS_HELP
from ..security.content_scanner import ContentScanner, ScanFinding
from ..security.file_scanner import CoverageEntry, scan_project_result
from ..utils.console import (
    STATUS_SYMBOLS,
    _get_console,
    _rich_echo,
    _rich_error,
    _rich_success,
    _rich_warning,
    ascii_safe,
)
from ..utils.diagnostics import printable_ascii_text

# -- Shared config --------------------------------------------------


@dataclasses.dataclass(frozen=True)
class _AuditConfig:
    """Bundled configuration shared by both audit modes.

    Reduces parameter counts on extracted handler functions so each
    receives a single config object plus its mode-specific arguments.
    """

    project_root: Path
    logger: "CommandLogger"
    verbose: bool
    output_format: str
    output_path: str | None


# -- Helpers --------------------------------------------------------


def _audit_outcome_cause(outcome: str, source: str | None, err_text: str | None) -> str:
    """Render the per-outcome cause line for audit --ci policy-discovery messages."""
    from ..policy.outcome_routing import outcome_cause

    return outcome_cause(outcome, source, err_text)


def _is_explicit_policy_source(policy_source: str | None) -> bool:
    """Return True when ``--policy`` names one concrete policy to enforce.

    ``--policy org`` keeps auto-discovery semantics (#829 / #1159); every
    other value (path, ``owner/repo``, https URL) is an explicit request
    that must fail closed when it cannot be loaded (#3195).
    """
    return bool(policy_source) and policy_source != "org"


def _explicit_policy_load_reason(policy_source: str, fetch_result) -> str:
    """Explain why an explicit ``--policy`` source produced no policy."""
    if fetch_result.error or fetch_result.fetch_error:
        return fetch_result.error or fetch_result.fetch_error
    if fetch_result.outcome == "absent" and not policy_source.startswith("https://"):
        return f"no apm-policy.yml found in repository '{policy_source}'"
    return fetch_result.outcome or "no policy was resolved"


def _policy_enforcement_report(fetch_result) -> dict:
    """Summarize whether the CI gate evaluated a policy (JSON / SARIF)."""
    from ..policy.discovery import _redact_policy_ref

    policy = fetch_result.policy if fetch_result is not None else None
    if policy is None:
        return {"enforced": False, "source": None, "enforcement": None}
    report = {
        "enforced": policy.enforcement != "off",
        "source": _redact_policy_ref(fetch_result.source) if fetch_result.source else None,
        "enforcement": policy.enforcement,
    }
    chain = getattr(fetch_result, "chain_sources", None)
    if chain:
        # Ordered (root first), credential-redacted composed chain (#2753).
        report["chain"] = [_redact_policy_ref(ref) for ref in chain]
    return report


def _scan_single_file(file_path: Path, logger) -> tuple[dict[str, list[ScanFinding]], int]:
    """Scan a single arbitrary file.

    Returns (findings_by_file, files_scanned).
    """
    if not file_path.exists():
        logger.error(f"File not found: {file_path}")
        sys.exit(1)
    if file_path.is_dir():
        logger.error(f"Path is a directory, not a file: {file_path}")
        sys.exit(1)

    findings = ContentScanner.scan_file(file_path)
    files_scanned = 1
    if findings:
        # Resolve to absolute so --strip can locate the file reliably
        return {str(file_path.resolve()): findings}, files_scanned
    return {}, files_scanned


def _has_actionable_findings(
    findings_by_file: dict[str, list[ScanFinding]],
) -> bool:
    """Return True if any finding is critical or warning (not just info)."""
    return any(
        f.severity in ("critical", "warning") for ff in findings_by_file.values() for f in ff
    )


def _finding_source(finding: ScanFinding) -> str:
    """Derive the scanner source from a finding's category prefix."""
    if "/" in finding.category:
        prefix = finding.category.split("/", 1)[0]
        if prefix != "apm":
            return prefix
    return "apm"


def _has_external_findings(rows: list[ScanFinding]) -> bool:
    """Return True if any finding originates from an external scanner."""
    return any(_finding_source(f) != "apm" for f in rows)


def _source_counts(rows: list[ScanFinding]) -> dict[str, int]:
    """Count findings by source for the table title."""
    counts: dict[str, int] = {}
    for f in rows:
        src = _finding_source(f)
        counts[src] = counts.get(src, 0) + 1
    return counts


def _findings_title(rows: list[ScanFinding], has_external: bool) -> str:
    """Build the findings table title, with per-source counts when mixed."""
    base = f"{STATUS_SYMBOLS['search']} Audit Findings"
    if not has_external:
        return f"{STATUS_SYMBOLS['search']} Content Scan Findings"
    counts = _source_counts(rows)
    parts = [f"{src}: {n}" for src, n in sorted(counts.items())]
    return f"{base}  ({', '.join(parts)})"


def _render_findings_table(
    findings_by_file: dict[str, list[ScanFinding]],
    verbose: bool = False,
) -> None:
    """Render a Rich table of scan findings."""
    from ..security.audit_report import finding_location, relative_path_for_report

    console = _get_console()

    # Flatten into rows, sorted by severity (critical first)
    severity_order = {"critical": 0, "warning": 1, "info": 2}
    rows: list[ScanFinding] = []
    for findings in findings_by_file.values():
        rows.extend(findings)
    rows.sort(key=lambda f: (severity_order.get(f.severity, 3), f.file, f.line))

    # Filter out info-level in non-verbose mode
    if not verbose:
        rows = [r for r in rows if r.severity != "info"]

    if not rows:
        return

    has_external = _has_external_findings(rows)
    title = _findings_title(rows, has_external)

    if console:
        try:
            from rich.text import Text

            from apm_cli.utils.console import new_table

            table = new_table(
                title=title,
                show_header=True,
                header_style="bold cyan",
            )
            table.add_column("Severity", style="bold", width=10)
            if has_external:
                table.add_column("Source", style="cyan", width=14)
            table.add_column("File", style="white")
            table.add_column("Location", style="dim")
            if has_external:
                table.add_column("Category", style="bold white")
            else:
                table.add_column("Codepoint", style="bold white", width=10)
            table.add_column("Description", style="white")

            sev_styles = {
                "critical": "bold red",
                "warning": "yellow",
                "info": "dim",
            }
            for f in rows:
                category_or_codepoint = (
                    f.category.split("/", 1)[1]
                    if has_external and "/" in f.category
                    else f.category
                    if has_external
                    else f.codepoint
                )
                row_cells = [f.severity.upper()]
                if has_external:
                    row_cells.append(_finding_source(f))
                row_cells.extend(
                    [
                        relative_path_for_report(f.file),
                        finding_location(f),
                        category_or_codepoint,
                        f.description,
                    ]
                )
                table.add_row(
                    *(Text(printable_ascii_text(cell)) for cell in row_cells),
                    style=sev_styles.get(f.severity, "white"),
                )
            console.print()
            console.print(table)
            return
        except (ImportError, Exception):
            pass

    # Fallback: plain text
    _rich_echo("")
    _rich_echo(title, color="cyan", bold=True)
    for f in rows:
        sev_label = f.severity.upper()
        color = (
            "red" if f.severity == "critical" else ("yellow" if f.severity == "warning" else "dim")
        )
        source_part = f" [{_finding_source(f)}]" if has_external else ""
        detail = f.category if has_external else f.codepoint
        _rich_echo(
            printable_ascii_text(
                f"  {sev_label:<10}{source_part} {f.file} {finding_location(f)}  {detail}  "
                f"{f.description}"
            ),
            color=color,
        )


def _deployed_canvas_bundles(project_root: Path, package_filter: str | None) -> list[str]:
    """Return sorted canvas bundle roots deployed per apm.lock.yaml.

    A canvas bundle is an executable Copilot extension (``extension.mjs``)
    deployed under a client ``extensions/`` directory (``.github/extensions/``
    project scope, ``.copilot/extensions/`` user scope). Surfacing them lets an
    audit reader see at a glance that executable extension code is installed,
    even when the content scan finds no hidden characters. Returns bundle roots
    such as ``.copilot/extensions/widget`` (one entry per bundle).
    """
    from ..integration.canvas_integrator import is_canvas_bundle_path

    lock = LockFile.read(get_lockfile_path(project_root))
    if lock is None:
        return []

    roots: set[str] = set()
    for dep_key, dep in lock.dependencies.items():
        if package_filter and dep_key != package_filter:
            continue
        for rel in dep.deployed_files:
            norm = rel.replace("\\", "/").strip("/")
            if not norm or not is_canvas_bundle_path(norm):
                continue
            parts = norm.split("/")
            for idx, seg in enumerate(parts):
                if seg == "extensions" and idx + 1 < len(parts):
                    roots.add("/".join(parts[: idx + 2]))
                    break
    return sorted(roots)


def _render_canvas_note(project_root: Path, package_filter: str | None, logger) -> None:
    """Emit an informational note listing deployed canvas extensions."""
    bundles = _deployed_canvas_bundles(project_root, package_filter)
    if not bundles:
        return
    logger.info(
        f"{len(bundles)} executable canvas extension(s) deployed (experimental, trust-gated):"
    )
    for root in bundles:
        logger.info(f"  {root}", symbol="info")


def _render_summary(
    findings_by_file: dict[str, list[ScanFinding]],
    files_scanned: int,
    logger,
    *,
    coverage: tuple[CoverageEntry, ...] = (),
) -> None:
    """Render a summary panel with counts."""
    all_findings: list[ScanFinding] = []
    for findings in findings_by_file.values():
        all_findings.extend(findings)

    counts = ContentScanner.summarize(all_findings)
    critical = counts.get("critical", 0)
    warning = counts.get("warning", 0)
    info = counts.get("info", 0)
    affected = len(findings_by_file)
    remedy = (
        "Review structured or external prompt fields manually; --strip does not rewrite native settings."
        if any(not entry.strippable and entry.file in findings_by_file for entry in coverage)
        else f"  {HIDDEN_CHARACTERS_FOUND.sentence()}"
    )

    _rich_echo("")
    if critical > 0:
        logger.error(
            f"{critical} critical finding(s) in {affected} file(s) -- hidden characters detected"
        )
        logger.progress("  These characters may embed invisible instructions")
        logger.progress(remedy)
    elif warning > 0:
        logger.warning(f"{warning} warning(s) in {affected} file(s) -- hidden characters detected")
        logger.progress(remedy)
    elif info > 0:
        logger.progress(
            f"{info} info-level finding(s) in "
            f"{affected} file(s) -- unusual characters (use --verbose to see)"
        )
    elif not any(entry.status == "incomplete" for entry in coverage):
        logger.success(f"{files_scanned} file(s) scanned -- no issues found")

    if info > 0 and (critical > 0 or warning > 0):
        logger.progress(f"  Plus {info} info-level finding(s) (use --verbose to see)")


def _render_coverage(coverage: tuple[CoverageEntry, ...], logger: CommandLogger) -> None:
    """Keep discovery visible without inventing ownership or unsafe-content findings."""
    for entry in coverage:
        label = printable_ascii_text(entry.location)
        if entry.status == "incomplete":
            logger.error(
                f"Incomplete coverage: {label}: {printable_ascii_text(entry.diagnostic or '')}. "
                "Review the format or file access and rerun audit."
            )
        elif entry.kind == "hooks":
            logger.progress(
                f"Discovered/{entry.tracking}: {label} (prompt check: {entry.status}; "
                "ownership and hash verification are separate)"
            )


def _render_owner_violations(
    violations: tuple[DeploymentOwnerViolation, ...],
    logger: CommandLogger,
) -> None:
    """Render invalid canonical owner references with one remediation."""
    if not violations:
        return
    logger.error(f"{len(violations)} invalid deployment ownership record(s) in apm.lock.yaml")
    for violation in violations:
        invalid = ", ".join(violation.invalid_owners)
        active = (
            f"; active owner={violation.invalid_active_owner}"
            if violation.invalid_active_owner is not None
            else ""
        )
        logger.error_detail(f"  {violation.locator.key}: invalid owner(s)={invalid}{active}")
    logger.error_detail(DEPLOYMENT_OWNER_REMEDIATION)


def _apply_strip(
    findings_by_file: dict[str, list[ScanFinding]],
    project_root: Path,
    logger,
) -> int:
    """Strip dangerous and suspicious characters from affected files.

    Only modifies files that resolve within *project_root* (for lockfile
    paths) or that are given as absolute paths (for ``--file`` mode).
    Returns number of files modified.
    """
    modified = 0
    for rel_path, findings in findings_by_file.items():  # noqa: B007
        abs_path = Path(rel_path)
        if not abs_path.is_absolute():
            # Relative path from lockfile: validate within project_root
            abs_path = project_root / rel_path
            try:
                abs_path.resolve().relative_to(project_root.resolve())
            except ValueError:
                logger.warning(f"  Skipping {rel_path}: outside project root")
                continue

        if not abs_path.exists():
            continue

        try:
            original = abs_path.read_text(encoding="utf-8")
            cleaned = ContentScanner.strip_dangerous(original)
            if cleaned != original:
                abs_path.write_text(cleaned, encoding="utf-8")
                modified += 1
                logger.progress(f"  Cleaned: {rel_path}", symbol="check")
        except (OSError, UnicodeDecodeError) as exc:
            logger.warning(f"  Could not clean {rel_path}: {exc}")

    return modified


def _preview_strip(
    findings_by_file: dict[str, list[ScanFinding]],
    logger,
) -> int:
    """Preview what --strip would remove without modifying files.

    Shows a summary of strippable characters per file.
    Returns the number of files that would be modified.
    """
    console = _get_console()
    affected = 0

    for rel_path, findings in findings_by_file.items():  # noqa: B007
        # Only critical+warning chars are stripped
        strippable = [f for f in findings if f.severity in ("critical", "warning")]
        if not strippable:
            continue
        affected += 1

    if affected == 0:
        logger.progress("Nothing to clean -- no strippable characters found")
        return 0

    _rich_echo("")
    logger.progress("Dry run -- the following would be removed by --strip:", symbol="search")
    _rich_echo("")

    if console:
        try:
            from rich.text import Text

            from apm_cli.utils.console import new_table

            table = new_table(
                show_header=True,
                header_style="bold cyan",
            )
            table.add_column("File", style="white")
            table.add_column("Critical", style="bold red", justify="right", width=10)
            table.add_column("Warning", style="yellow", justify="right", width=10)
            table.add_column("Total", style="bold white", justify="right", width=10)

            for rel_path, findings in findings_by_file.items():
                strippable = [f for f in findings if f.severity in ("critical", "warning")]
                if not strippable:
                    continue
                crit = sum(1 for f in strippable if f.severity == "critical")
                warn = sum(1 for f in strippable if f.severity == "warning")
                table.add_row(
                    Text(rel_path),
                    str(crit) if crit else "-",
                    str(warn) if warn else "-",
                    str(len(strippable)),
                )

            console.print(table)
        except (ImportError, Exception):
            # Fallback: plain text
            for rel_path, findings in findings_by_file.items():
                strippable = [f for f in findings if f.severity in ("critical", "warning")]
                if not strippable:
                    continue
                _rich_echo(f"  {rel_path}: {len(strippable)} character(s)", color="white")
    else:
        for rel_path, findings in findings_by_file.items():
            strippable = [f for f in findings if f.severity in ("critical", "warning")]
            if not strippable:
                continue
            _rich_echo(f"  {rel_path}: {len(strippable)} character(s)", color="white")

    _rich_echo("")
    logger.progress(f"{affected} file(s) would be modified")
    logger.progress(HIDDEN_CHARACTERS_PREVIEWED.sentence())
    return affected


def _report_passed(ci_result: "CIAuditResult", total: int) -> None:
    """Summarize a passing run; warn-mode violations are not a clean pass (#3994)."""
    warned = sum(1 for check in ci_result.checks if check.warned)
    if not warned:
        _rich_success(f"{STATUS_SYMBOLS['success']} All {total} check(s) passed")
        return
    _rich_warning(
        f"{total} check(s) passed; {warned} {'reports' if warned == 1 else 'report'} violations under "
        "'enforcement: warn' and fail once the policy switches to block."
    )


def _render_ci_failures_to_stderr(ci_result: "CIAuditResult") -> None:
    """Name each failed check and its details on stderr (#4224).

    A structured report (json/sarif) keeps stdout machine-readable, so a
    failing run states its verdict and next steps on stderr, as text does.
    """
    if ci_result.passed:
        return
    failed = [check for check in ci_result.checks if not check.passed and not check.warned]
    for check in failed:
        click.echo(
            f"{STATUS_SYMBOLS['cross']} {check.name}: {printable_ascii_text(check.message)}",
            err=True,
        )
        for detail in check.details:
            click.echo(f"    - {printable_ascii_text(detail)}", err=True)
        if check.next_step:
            click.echo(f"    {printable_ascii_text(check.next_step)}", err=True)
    summary = ci_result.to_json()["summary"]
    click.echo(
        f"{STATUS_SYMBOLS['cross']} {summary['failed']} of {summary['total']} check(s) failed",
        err=True,
    )


def _warn_unhashed_dependencies(project_root: Path, fetch_result) -> None:
    """Name locked entries without a content hash when policy does not require one."""
    from ..deps.lockfile import LockFile, LockfileFormatError, get_lockfile_path
    from ..install.integrity import unhashed_dependencies_advisory

    try:
        lockfile = LockFile.read(get_lockfile_path(project_root))
    except LockfileFormatError:
        return  # the lockfile checks already fail closed and name the remedy
    if lockfile is None:
        return
    policy = fetch_result.policy if fetch_result is not None and fetch_result.found else None
    integrity = getattr(getattr(policy, "security", None), "integrity", None)
    advisory = unhashed_dependencies_advisory(lockfile.get_package_dependencies(), integrity)
    if advisory is not None:
        _rich_warning(advisory, symbol="warning", err=True)


def _render_ci_results(ci_result: "CIAuditResult") -> None:
    """Render CI check results as a Rich table (text format)."""

    console = _get_console()
    for check in ci_result.checks:
        _render_coverage(check.coverage, CommandLogger("audit"))

    if console:
        try:
            from rich.text import Text

            from apm_cli.utils.console import new_table

            table = new_table(
                title=f"{STATUS_SYMBOLS['search']} APM Policy Compliance",
                show_header=True,
                header_style="bold cyan",
            )
            table.add_column("Status", style="bold", width=8)
            table.add_column("Check", style="white")
            table.add_column("Message", style="white")

            for check in ci_result.checks:
                # Text, not markup: Rich would parse "[x]" as a tag (#3845).
                status = (
                    Text(STATUS_SYMBOLS["warning"], style="yellow")
                    if check.warned
                    else Text(STATUS_SYMBOLS["check"], style="green")
                    if check.passed
                    else Text(STATUS_SYMBOLS["cross"], style="red")
                )
                table.add_row(status, Text(check.name), Text(printable_ascii_text(check.message)))

            console.print()
            console.print(table)

            # Show details for failed and warned checks
            for check in ci_result.checks:
                if check.details and (check.warned or not check.passed):
                    console.print()
                    _rich_echo(
                        f"  {check.name} details:",
                        color="yellow" if check.warned else "red",
                        bold=True,
                    )
                    # Details follow their header's stream (failed checks: stderr).
                    for detail in check.details:
                        _rich_echo(
                            f"    - {printable_ascii_text(detail)}",
                            color="dim",
                            err=not check.warned,
                        )
                    if check.next_step and not check.passed:
                        _rich_echo(f"    {printable_ascii_text(check.next_step)}", err=True)

            console.print()
            summary = ci_result.to_json()["summary"]
            if ci_result.passed:
                _report_passed(ci_result, summary["total"])
            else:
                _rich_error(
                    f"{STATUS_SYMBOLS['error']} {summary['failed']} of "
                    f"{summary['total']} check(s) failed"
                )
            return
        except (ImportError, Exception):
            pass

    # Fallback: plain text
    _rich_echo("")
    _rich_echo(
        f"{STATUS_SYMBOLS['search']} APM Policy Compliance",
        color="cyan",
        bold=True,
    )
    for check in ci_result.checks:
        symbol = STATUS_SYMBOLS["check"] if check.passed else STATUS_SYMBOLS["cross"]
        color = "green" if check.passed else "red"
        if check.warned:
            symbol, color = STATUS_SYMBOLS["warning"], "yellow"
        _rich_echo(printable_ascii_text(f"  {symbol} {check.name}: {check.message}"), color=color)
        if (check.warned or not check.passed) and check.details:
            for detail in check.details:
                _rich_echo(f"      - {printable_ascii_text(detail)}", color="dim")
        if check.next_step and not check.passed:
            _rich_echo(f"      {printable_ascii_text(check.next_step)}")

    _rich_echo("")
    summary = ci_result.to_json()["summary"]
    if ci_result.passed:
        _report_passed(ci_result, summary["total"])
    else:
        _rich_error(
            f"{STATUS_SYMBOLS['error']} {summary['failed']} of {summary['total']} check(s) failed"
        )


# -- Mode handlers --------------------------------------------------


def _routable_discovery(discover):
    """Run policy *discover*; a known discovery error becomes a routable result.

    The policy-outcome owner then routes it like any other unusable policy
    source, so a required policy that cannot be resolved fails closed with a
    named cause. Any other exception propagates.
    """
    from ..policy.outcome_routing import POLICY_DISCOVERY_ERRORS, discovery_failure_result

    try:
        return discover()
    except POLICY_DISCOVERY_ERRORS as exc:
        return discovery_failure_result(exc)


def _policy_outcome_cause(fetch_result) -> str:
    err_text = fetch_result.error or fetch_result.fetch_error or fetch_result.outcome
    return _audit_outcome_cause(fetch_result.outcome, fetch_result.source, err_text)


def _render_policy_block(route, fetch_result, *, prefix: str = "") -> None:
    """Render the routed block decision for an unresolvable org policy as ``[x]``."""
    cause = prefix + _policy_outcome_cause(fetch_result)
    if route.from_fetch_failure_default:
        click.echo(f"[x] {cause} (policy.fetch_failure_default=block)", err=True)
    else:
        click.echo(f"[x] {cause}", err=True)
        click.echo(f"    Blocked by org policy: {route.block_reason}", err=True)
    if fetch_result.discovery_hint:
        click.echo(f"[i] {fetch_result.discovery_hint}", err=True)


def _route_ci_policy_outcome(cfg: _AuditConfig, fetch_result, *, auto_discovered: bool):
    """Render the routed policy outcome for ``audit --ci``; return the result to enforce.

    Returns ``None`` when no policy applies; exits 1 when the outcome blocks.
    """
    # The routing owner decides every outcome exactly as install does
    # (#1159, #4084); audit only renders the decision:
    #   * block -> `[x]` and exit 1
    #   * no usable policy -> `[!]` and skip enforcement (absent /
    #     no_git_remote / empty only under auto-discovery; `--policy org`
    #     reports fetch failures)
    #   * disabled (auto-discovery) -> forensic `[i]` breadcrumb
    from ..policy.outcome_routing import classify_discovery_outcome
    from ..policy.project_config import read_project_fetch_failure_default

    route = classify_discovery_outcome(
        fetch_result,
        fetch_failure_default=read_project_fetch_failure_default(cfg.project_root),
    )
    cause = _policy_outcome_cause(fetch_result)

    if route.disabled:
        if auto_discovered:
            click.echo(
                "[i] Org-policy auto-discovery disabled by project apm.yml "
                "(policy.discovery_enabled=false); no enforcement applied",
                err=True,
            )
        fetch_result = None
    elif route.blocks:
        _render_policy_block(route, fetch_result)
        sys.exit(1)
    elif route.policy is None:
        if auto_discovered or route.unresolved:
            click.echo(
                f"[!] {cause}; enforcement skipped "
                "(set policy.fetch_failure_default=block in apm.yml to fail closed)",
                err=True,
            )
            if cfg.verbose and fetch_result.discovery_hint:
                click.echo(f"[i] {fetch_result.discovery_hint}", err=True)
        # A named source that resolved a rule-less (empty) policy is still the
        # policy this audit evaluated and reports; it has nothing to enforce.
        if auto_discovered or fetch_result.policy is None:
            fetch_result = None
    return fetch_result


def _echo_replay_summary(verbose: bool) -> None:
    """Under --verbose, one line: how many packages the drift replay served from records (#4940)."""
    from ..install.drift_records import last_replay_summary

    summary = last_replay_summary() if verbose else None
    if summary is not None:
        served, live = summary
        click.echo(
            f"{STATUS_SYMBOLS['info']} drift replay: {served} package(s) from records, {live} live",
            err=True,
        )


def _audit_ci_gate(
    cfg: _AuditConfig,
    policy_source: str | None,
    no_cache: bool,
    no_policy: bool,
    no_fail_fast: bool,
    no_drift: bool = False,
) -> None:
    """Handle ``apm audit --ci`` -- lockfile consistency gate.

    Runs baseline lockfile checks, drift detection (unless ``--no-drift``),
    and (optionally) org-policy checks, then emits a structured report
    and exits with 0 (clean) or 1 (violations).
    """
    logger = cfg.logger

    from ..install.audit_replay import resolve_ci_audit_materialization
    from ..install.exec_gate import exec_policy_from_discovery
    from ..policy.ci_checks import _check_drift, replay_failure_check, run_baseline_checks
    from ..policy.policy_checks import run_policy_checks

    fail_fast = not no_fail_fast

    from ..policy.discovery import discover_policy_with_chain

    # One policy discovery per run, shared by drift replay and policy checks.
    fetch_policy = functools.cache(
        lambda: _routable_discovery(
            lambda: discover_policy_with_chain(
                cfg.project_root, policy_override=policy_source or None, no_cache=no_cache
            )
        )
    )

    def replay_policy():
        if no_policy and not policy_source:
            return None
        from ..policy.outcome_routing import resolve_trust_policy

        # Routed like install: a blocking outcome raises PolicyViolationError,
        # which the replay reports as a failed check. This command reports the
        # policy outcome itself below.
        return resolve_trust_policy(cfg.project_root, announce=False, fetch_result=fetch_policy())

    # The discovery replay_policy routes; render records bind to it (#4940).
    replay_fetch = None if no_policy and not policy_source else fetch_policy
    materialization = resolve_ci_audit_materialization(
        cfg.project_root,
        verbose=cfg.verbose,
        policy_provider=replay_policy,
        policy_fetch=replay_fetch,
    )
    prepared_replay = materialization.prepared_replay
    prepared_replay_error = materialization.error

    # Always run baseline checks
    ci_result = run_baseline_checks(
        cfg.project_root,
        fail_fast=fail_fast,
        ci_mode=True,
        prepared_replay=prepared_replay,
        prepared_replay_error=prepared_replay_error,
        # A failed replay is one finding, reported in full under drift when drift runs.
        replay_error_owner=None if no_drift else "drift",
        no_policy=no_policy,
        policy_provider=(
            None
            if no_policy and not policy_source
            else lambda: exec_policy_from_discovery(fetch_policy)
        ),
        policy_fetch=None if no_policy and not policy_source else fetch_policy,
    )

    # Resolve policy source: explicit --policy wins; otherwise mirror
    # install's auto-discovery (closes #827) so CI catches sideloaded
    # files via unmanaged-files checks. --no-policy skips discovery.
    fetch_result = None
    auto_discovered = not policy_source
    # Explicit --policy and auto-discovery (mirror install path) share one
    # discovery call so --no-cache forces a fresh fetch for both (#3659).
    if (policy_source or not no_policy) and (not fail_fast or ci_result.passed):
        fetch_result = fetch_policy()

    # An explicit --policy <source> names the exact policy the caller wants
    # enforced, so failing to load it fails closed regardless of
    # policy.fetch_failure_default (#3195). A stale-but-valid cached policy
    # still resolves to a policy object and is enforced as usual.
    if fetch_result is not None and _is_explicit_policy_source(policy_source):
        from ..policy.discovery import _redact_policy_ref

        display_source = _redact_policy_ref(policy_source)
        if fetch_result.outcome == "disabled":
            click.echo(
                f"{STATUS_SYMBOLS['warning']} --policy {display_source} ignored: "
                "APM_POLICY_DISABLE=1 disables policy enforcement; no policy checks ran",
                err=True,
            )
            fetch_result = None
        elif not fetch_result.found:
            reason = _explicit_policy_load_reason(policy_source, fetch_result)
            click.echo(
                f"{STATUS_SYMBOLS['error']} Policy '{display_source}' could not be loaded: "
                f"{reason}",
                err=True,
            )
            click.echo(
                "    --policy was passed explicitly, so the audit fails closed instead "
                "of skipping enforcement. Fix the policy source above and re-run.",
                err=True,
            )
            sys.exit(1)

    if fetch_result is not None:
        fetch_result = _route_ci_policy_outcome(cfg, fetch_result, auto_discovered=auto_discovered)

    if fetch_result is not None and fetch_result.found:
        policy_obj = fetch_result.policy

        # Respect enforcement level
        if policy_obj.enforcement == "off":
            pass  # Policy checks disabled
        else:
            from ..policy.models import CheckResult
            from ..policy.policy_checks import FAIL_CLOSED_POLICY_CHECKS

            policy_result = run_policy_checks(
                cfg.project_root,
                policy_obj,
                fail_fast=fail_fast,
                modules_root=(
                    prepared_replay.modules_root if prepared_replay is not None else None
                ),
                no_policy=no_policy,
                policy_source=fetch_result.source,
            )
            if policy_obj.enforcement == "block":
                ci_result.checks.extend(policy_result.checks)
            else:
                # enforcement == "warn": include results but don't fail
                for check in policy_result.checks:
                    if check.name in FAIL_CLOSED_POLICY_CHECKS and not check.passed:
                        ci_result.checks.append(check)
                        continue
                    ci_result.checks.append(
                        CheckResult(
                            name=check.name,
                            passed=True,  # downgrade to pass
                            message=check.message
                            + (" (enforcement: warn)" if not check.passed else ""),
                            details=check.details,
                            warned=not check.passed,
                        )
                    )

    _warn_unhashed_dependencies(cfg.project_root, fetch_result)

    # -- Drift detection (default-on per ADR-02) --------------------
    drift_findings: list = []
    if not no_drift and manifest_file(cfg.project_root).exists():
        from ..deps.lockfile import LockFile, UnsupportedLockfileVersionError, get_lockfile_path

        lockfile_path = get_lockfile_path(cfg.project_root)
        if lockfile_path.exists():
            try:
                lockfile = LockFile.read(lockfile_path)
            except UnsupportedLockfileVersionError:
                lockfile = None  # the lockfile-exists check already failed with both remedies
            if lockfile is not None:
                if prepared_replay_error is not None:
                    drift_check = replay_failure_check(
                        "drift", prepared_replay_error, label="drift replay failed"
                    )
                    drift_findings = []
                else:
                    drift_check, drift_findings = _check_drift(
                        cfg.project_root,
                        lockfile,
                        cache_only=prepared_replay is None,
                        verbose=cfg.verbose,
                        prepared_replay=prepared_replay,
                        policy_provider=replay_policy,
                        policy_fetch=replay_fetch,
                    )
                    _echo_replay_summary(cfg.verbose)
                ci_result.checks.append(drift_check)
    elif no_drift and cfg.output_format == "text":
        # In structured output (json/sarif), --no-drift is implicit from
        # the absence of the drift check entry; no need to pollute output.
        click.echo(
            f"{STATUS_SYMBOLS['warning']} drift detection skipped (--no-drift); "
            "coverage reduced -- hand-edits and missing integrations will not be caught",
            err=True,
        )

    # Resolve effective format
    effective_format = cfg.output_format
    if cfg.output_path and effective_format == "text":
        from ..security.audit_report import detect_format_from_extension

        effective_format = detect_format_from_extension(Path(cfg.output_path))

    if effective_format in ("json", "sarif"):
        import json as _json

        from ..install.drift import render_drift_json, render_drift_sarif

        policy_report = _policy_enforcement_report(fetch_result)
        if effective_format == "sarif":
            payload = ci_result.to_sarif()
            if drift_findings:
                payload["runs"][0]["results"].extend(render_drift_sarif(drift_findings))
            run = payload["runs"][0]
            invocation = run.setdefault("invocations", [{}])[0]
            invocation.setdefault("properties", {})["policy"] = policy_report
        else:
            payload = ci_result.to_json()
            if drift_findings or not no_drift:
                payload["drift"] = render_drift_json(drift_findings)
            payload["policy"] = policy_report

        output = _json.dumps(payload, indent=2)
        if cfg.output_path:
            Path(cfg.output_path).parent.mkdir(parents=True, exist_ok=True)
            Path(cfg.output_path).write_text(output, encoding="utf-8")
            logger.success(f"CI audit report written to {cfg.output_path}")
        else:
            click.echo(output)
        _render_ci_failures_to_stderr(ci_result)
    else:
        policy_report = _policy_enforcement_report(fetch_result)
        if policy_report["source"]:
            # Name the effective policy sources in text mode too (#1925).
            chain = policy_report.get("chain") or []
            chain_text = f" (chain: {' -> '.join(chain)})" if len(chain) > 1 else ""
            click.echo(
                f"{STATUS_SYMBOLS['info']} Policy: {policy_report['source']}{chain_text} "
                f"-- enforcement={policy_report['enforcement']}",
                err=True,
            )
        _render_ci_results(ci_result)
        if drift_findings:
            from ..install.drift import render_drift_text

            click.echo("")
            click.echo(
                ascii_safe(
                    render_drift_text(
                        drift_findings,
                        verbose=cfg.verbose,
                        lockfile=lockfile,
                        project_root=cfg.project_root,
                    )
                )
            )

    sys.exit(0 if ci_result.passed else 1)


def _resolve_external_options(
    external: tuple[str, ...],
    external_llm: bool | None,
    external_args: str | None,
) -> "dict[str, object]":
    """Resolve per-scanner :class:`ScannerOptions` from CLI + config layers.

    Policy ``allow_args`` governance is applied at the install-time audit
    phase (where org policy is already loaded), not in the interactive
    ``apm audit`` path; the per-adapter allowlist still validates every token.
    """
    import shlex

    from ..config import get_scanner_options
    from ..security.external.options import resolve_scanner_options

    if external_args is not None:
        try:
            cli_args: tuple[str, ...] | None = tuple(
                shlex.split(external_args, posix=(os.name != "nt"))
            )
        except ValueError as exc:
            raise click.UsageError(f"--external-args could not be parsed: {exc}") from exc
    else:
        cli_args = None
    options_by_name: dict[str, object] = {}
    for name in external:
        config_llm, config_args = get_scanner_options(name)
        options_by_name[name] = resolve_scanner_options(
            cli_llm=external_llm,
            cli_args=cli_args,
            config_llm=config_llm,
            config_args=config_args,
            policy_allow_args=None,
        )
    return options_by_name


def _run_external_scanners(
    cfg: _AuditConfig,
    external: tuple[str, ...],
    external_sarif: str | None,
    scan_paths: list[Path],
    options_by_name: "dict[str, object] | None" = None,
) -> dict[str, list[ScanFinding]]:
    """Run opted-in external SARIF-native scanners and return merged findings.

    Fail-closed: the ``external_scanners`` experimental flag must be enabled
    (exit 2 otherwise) and each adapter must be available (exit 2 otherwise).
    APM's own content scan is never weakened -- external findings are purely
    additive.  The resolve/validate/run/merge loop is shared with the
    install-time audit phase via
    :func:`apm_cli.security.external.runner.run_external_scanners`.
    """
    from ..security.external.base import ExternalScanError
    from ..security.external.gate import (
        ExternalScannersFeatureDisabledError,
        require_external_scanners_enabled,
    )
    from ..security.external.runner import run_external_scanners

    logger = cfg.logger

    try:
        require_external_scanners_enabled("Ingesting external scanners with --external")
    except ExternalScannersFeatureDisabledError as exc:
        logger.error(str(exc))
        sys.exit(3)

    try:
        return run_external_scanners(
            external,
            external_sarif,
            scan_paths,
            options_by_name=options_by_name,
            logger=logger,
        )
    except ExternalScanError as exc:
        logger.error(str(exc))
        sys.exit(3)


_FAIL_ON_DRIFT_UNRESOLVED = "Org policy could not be resolved; fail_on_drift could not be applied: "


def _resolve_fail_on_drift(project_root: Path) -> bool:
    """Return True when drift must gate the exit code of a bare ``apm audit``.

    That is the case when the resolved org policy enables
    ``security.audit.fail_on_drift``, and also when the project requires an
    org policy that could not be resolved: the policy-outcome owner decides
    "required" (``policy.fetch_failure_default: block`` and the always-block
    outcomes), and this audit then fails closed with an ``[x]`` cause line.
    An optional policy that could not be resolved keeps drift advisory and
    prints a ``[!]`` notice. ``APM_POLICY_DISABLE`` skips discovery. Discovery
    runs only when drift was actually detected, keeping the no-drift common
    path free of extra work.
    """
    from ..policy.discovery import discover_policy_with_chain, policy_disabled_by_env
    from ..policy.outcome_routing import classify_project_policy

    if policy_disabled_by_env():
        return False
    fetch_result = _routable_discovery(lambda: discover_policy_with_chain(project_root))
    route = classify_project_policy(project_root, fetch_result=fetch_result)
    if route.blocks:
        _render_policy_block(route, fetch_result, prefix=_FAIL_ON_DRIFT_UNRESOLVED)
        return True
    if route.policy is None:
        if route.unresolved:
            click.echo(
                f"{STATUS_SYMBOLS['warning']} {_FAIL_ON_DRIFT_UNRESOLVED}"
                f"{_policy_outcome_cause(fetch_result)}",
                err=True,
            )
        return False
    return bool(route.policy.security.audit.fail_on_drift)


def _require_installed_package_key(
    package: str, lockfile: LockFile | None, logger, project_root: Path
) -> str:
    """Return the ``apm.lock.yaml`` key for *package* or exit 1 (#3840, #3953).

    Selection routes through the ``apm uninstall`` selector, offline, so every
    form uninstall accepts (lock key, URL, ``host/owner/repo``,
    ``owner/repo#ref``, ``plugin@marketplace``, ``_local/<name>``) resolves
    exactly as install recorded it under the project manifest's
    ``default_host:`` (req-mf-019, #3843). An unknown package fails so a typo
    in a CI gate cannot pass silently.
    """
    from ..constants import APM_YML_FILENAME
    from ..models.dependency.manifest_host import manifest_host_scope_for
    from ..models.manifest_io import load_manifest
    from .uninstall.engine import select_installed_lock_key

    manifest_path = manifest_file(project_root)
    try:
        manifest = load_manifest(manifest_path) if manifest_path.is_file() else None
    except Exception as e:
        logger.error(f"Failed to read {APM_YML_FILENAME}: {e}")
        sys.exit(1)
    try:
        host_scope = manifest_host_scope_for(manifest)
    except ValueError as e:
        logger.error(str(e))
        sys.exit(1)
    try:
        with host_scope:
            selection = select_installed_lock_key(package, manifest, lockfile)
    except ValueError as e:
        logger.error(str(e))
        sys.exit(1)
    if selection is not None:
        if selection.installed_via:
            logger.warning(
                f"'{package}' is not installed from that marketplace; auditing "
                f"{selection.key}, installed via {selection.installed_via}."
            )
        return selection.key
    logger.error(
        f"Package '{package}' is not installed: no matching dependency in apm.lock.yaml. "
        "Run 'apm deps list' to see installed packages."
    )
    sys.exit(1)


def _reject_invalid_manifest(project_root: Path, logger: CommandLogger) -> None:
    """Refuse an apm.yml every command refuses, before scanning or stripping."""
    from ..models.manifest_io import InvalidManifestError, read_manifest_text

    manifest_path = manifest_file(project_root)
    if not manifest_path.is_file():
        return
    try:
        read_manifest_text(manifest_path)
    except InvalidManifestError as exc:
        logger.error(str(exc))
        sys.exit(1)


def _audit_content_scan(
    cfg: _AuditConfig,
    package: str | None,
    file_path: str | None,
    strip: bool,
    dry_run: bool,
    no_drift: bool = False,
    external: tuple[str, ...] = (),
    external_sarif: str | None = None,
    external_llm: bool | None = None,
    external_args: str | None = None,
) -> None:
    """Handle default ``apm audit`` -- content integrity scanning.

    Scans deployed prompt files (or a single file via ``--file``) for
    hidden Unicode characters, optionally stripping them.
    """
    logger = cfg.logger
    project_root = cfg.project_root
    coverage: tuple[CoverageEntry, ...] = ()
    protected_files: frozenset[str] = frozenset()

    # Resolve effective format (auto-detect from extension when needed)
    effective_format = cfg.output_format
    if cfg.output_path and effective_format == "text":
        from ..security.audit_report import detect_format_from_extension

        effective_format = detect_format_from_extension(Path(cfg.output_path))

    # --format json/sarif/markdown is incompatible with --strip / --dry-run
    if effective_format != "text" and (strip or dry_run):
        raise click.UsageError(
            f"--format {effective_format} cannot be combined with --strip or --dry-run"
        )

    if file_path:
        # -- File mode: scan a single arbitrary file --
        findings_by_file, files_scanned = _scan_single_file(Path(file_path), logger)
        scan_paths = [Path(file_path)]
        owner_violations: tuple[DeploymentOwnerViolation, ...] = ()
    else:
        scan_paths = [project_root]
        # -- Package mode: scan from lockfile --
        lockfile_path = get_lockfile_path(project_root)
        if effective_format == "text":
            if package:
                logger.progress(f"Scanning package: {package}")
            else:
                logger.start("Scanning installed packages and deployed files...")

        from apm_cli.deps.lockfile import LockfileFormatError

        try:
            lockfile = LockFile.read(lockfile_path)
            if package:
                package = _require_installed_package_key(package, lockfile, logger, project_root)
            owner_violations = (
                DeploymentLedgerCodec.owner_reference_violations(lockfile)
                if lockfile is not None
                else ()
            )
            scan = scan_project_result(
                project_root,
                package_filter=package,
                lockfile=lockfile,
                include_deployed_trees=package is None,
            )
            findings_by_file = scan.findings_by_file
            files_scanned = len(scan.scanned_files)
            coverage = scan.inventory
            protected_files = scan.protected_files
        except LockfileFormatError as exc:
            logger.error(f"Cannot audit invalid apm.lock.yaml: {exc}")
            sys.exit(1)

        if files_scanned == 0 and not coverage and not external and not owner_violations:
            if package:
                logger.warning(f"Package '{package}' has no deployed files -- nothing to scan")
            elif effective_format == "text":
                logger.progress("No recognized deployed primitives found -- nothing to scan")
            if effective_format == "text":
                sys.exit(0)

    # -- External scanners (opt-in, additive) -----------------------
    if external:
        options_by_name = _resolve_external_options(external, external_llm, external_args)
        external_findings = _run_external_scanners(
            cfg, external, external_sarif, scan_paths, options_by_name
        )
        from ..security.external.runner import merge_findings

        merge_findings(findings_by_file, external_findings)

    # -- Warn if --dry-run used without --strip --
    if dry_run and not strip:
        logger.progress("--dry-run only works with --strip (e.g. apm audit --strip --dry-run)")

    # -- Strip mode --
    if strip:
        blocked = protected_files.intersection(findings_by_file)
        if blocked or any(entry.status == "incomplete" for entry in coverage):
            _render_coverage(coverage, logger)
            for entry in coverage:
                if entry.file in blocked and not entry.strippable:
                    logger.error_detail(
                        "Manual review required: " + printable_ascii_text(entry.location)
                    )
            logger.error(
                "Content was not modified: structured/shared or external prompt findings, or incomplete coverage, "
                "require manual review. --strip does not rewrite native configuration."
            )
            sys.exit(1)
        if owner_violations:
            _render_owner_violations(owner_violations, logger)
            logger.error_detail("Content was not modified while lockfile ownership is invalid.")
            sys.exit(1)
        if not findings_by_file:
            logger.progress("Nothing to clean -- no hidden characters found")
            sys.exit(0)
        if dry_run:
            _preview_strip(findings_by_file, logger)
            sys.exit(0)
        from ..core.scope import get_workspace_deploy_root

        modified = _apply_strip(findings_by_file, get_workspace_deploy_root(project_root), logger)
        if modified > 0:
            logger.success(f"Cleaned {modified} file(s)")
        else:
            logger.progress("Nothing to clean -- no strippable characters found")
        sys.exit(0)

    # -- Drift detection (default-on per ADR-02) --------------------
    # Drift only applies to whole-project audit (not --file or --strip
    # modes; not single-package scoped).  Mutex on no_drift+strip/file
    # is enforced earlier via UsageError.
    drift_findings: list = []
    drift_failed = False
    if (
        not no_drift
        and not strip
        and not file_path
        and not package
        and manifest_file(project_root).exists()
    ):
        from ..policy.ci_checks import DRIFT_SKIP_PREFIX, _check_drift

        lockfile_path = get_lockfile_path(project_root)
        if lockfile_path.exists():
            lockfile = LockFile.read(lockfile_path)
            if lockfile is not None:
                drift_check, drift_findings = _check_drift(
                    project_root,
                    lockfile,
                    cache_only=True,
                    verbose=cfg.verbose,
                )
                drift_failed = not drift_check.passed
                # Bare `apm audit` is advisory: drift_failed does not gate
                # the exit code (that lives in --ci). But silence on a
                # cache-pin / cache-miss skip or failure is a UX trap: the
                # user cannot tell whether drift was clean or whether it was
                # never attempted. Surface the reason on stderr whenever the
                # drift check produced no findings.
                if drift_failed and not drift_findings:
                    click.echo(
                        f"{STATUS_SYMBOLS['warning']} drift check could not run: "
                        f"{drift_check.message}",
                        err=True,
                    )
                elif (
                    drift_check.passed
                    and not drift_findings
                    and drift_check.message.startswith(DRIFT_SKIP_PREFIX)
                ):
                    click.echo(
                        f"{STATUS_SYMBOLS['warning']} {drift_check.message}",
                        err=True,
                    )
    elif no_drift and cfg.output_format == "text":
        # In structured output (json/sarif), --no-drift is implicit from
        # the absence of the drift check entry; no need to pollute output.
        click.echo(
            f"{STATUS_SYMBOLS['warning']} drift detection skipped (--no-drift); "
            "coverage reduced -- hand-edits and missing integrations will not be caught",
            err=True,
        )

    # -- Display findings --
    # Determine exit code first (shared by all formats)
    if not findings_by_file or not _has_actionable_findings(findings_by_file):
        exit_code = 0
    else:
        all_findings = [f for ff in findings_by_file.values() for f in ff]
        exit_code = 1 if ContentScanner.has_critical(all_findings) else 2
    if owner_violations or any(entry.status == "incomplete" for entry in coverage):
        exit_code = 1

    # Bare `apm audit` is advisory for drift by default: drift findings are
    # rendered (text/json/sarif) but DO NOT escalate the exit code. When
    # `security.audit.fail_on_drift` is enabled, any drift-check FAILURE
    # escalates a clean run to exit 1 -- matching the `apm audit --ci` gate,
    # which fails on the same `drift_check.passed is False` signal. That covers
    # both detected drift AND a drift check that could not run (corrupt local
    # graph, unsupported replay); an advisory cache-miss SKIP stays passed=True
    # and does NOT gate. Policy is discovered only when a drift failure
    # occurred, so the clean common case is unchanged. Advisory drift renders
    # as a warning so an [x] drift line always comes with a failing exit.
    drift_gates = drift_failed and _resolve_fail_on_drift(project_root)
    if drift_gates:
        exit_code = 1

    if effective_format == "text":
        if cfg.output_path:
            logger.error(
                "Text format does not support --output. "
                "Use --format json, sarif, or markdown to write to a file."
            )
            sys.exit(1)
        if findings_by_file:
            _render_findings_table(findings_by_file, verbose=cfg.verbose)
            _render_summary(findings_by_file, files_scanned, logger, coverage=coverage)
        elif not owner_violations:
            _render_summary(findings_by_file, files_scanned, logger, coverage=coverage)
        _render_coverage(coverage, logger)
        _render_owner_violations(owner_violations, logger)
        if not file_path:
            _render_canvas_note(cfg.project_root, package, logger)
            from ..compilation.link_resolver import warn_missing_module_links

            warn_missing_module_links(cfg.project_root, logger, package)
        if drift_findings:
            from ..install.drift import render_drift_text

            click.echo("")
            click.echo(
                ascii_safe(
                    render_drift_text(
                        drift_findings,
                        verbose=cfg.verbose,
                        lockfile=lockfile,
                        project_root=cfg.project_root,
                        advisory=not drift_gates,
                    )
                )
            )
    elif effective_format == "markdown":
        from ..security.audit_report import findings_to_markdown

        md_report = findings_to_markdown(
            findings_by_file,
            files_scanned=files_scanned,
            owner_violations=owner_violations,
            coverage=coverage,
        )
        if cfg.output_path:
            Path(cfg.output_path).parent.mkdir(parents=True, exist_ok=True)
            Path(cfg.output_path).write_text(md_report, encoding="utf-8")
            logger.success(f"Audit report written to {cfg.output_path}")
        else:
            click.echo(md_report)
    else:
        from ..security.audit_report import (
            findings_to_json,
            findings_to_sarif,
            serialize_report,
            write_report,
        )

        if effective_format == "sarif":
            report = findings_to_sarif(
                findings_by_file,
                files_scanned=files_scanned,
                owner_violations=owner_violations,
                coverage=coverage,
            )
        else:
            report = findings_to_json(
                findings_by_file,
                files_scanned=files_scanned,
                exit_code=exit_code,
                owner_violations=owner_violations,
                coverage=coverage,
            )

        if cfg.output_path:
            write_report(report, Path(cfg.output_path))
            logger.success(f"Audit report written to {cfg.output_path}")
        else:
            click.echo(serialize_report(report))

    # -- Exit code --
    sys.exit(exit_code)


# -- Command --------------------------------------------------------


@click.command(
    help="Scan installed primitives for hidden Unicode, drift, and lockfile/policy violations",
    short_help="Scan for hidden Unicode, drift, and policy violations",
)
@click.argument("package", required=False)
@click.option(
    "--file",
    "file_path",
    type=click.Path(exists=False),
    help="Scan an arbitrary file (not just APM-managed files)",
)
@click.option(
    "--strip",
    is_flag=True,
    help="Remove hidden characters from scanned files (preserves emoji and whitespace)",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Show all findings including harmless ones",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Preview what --strip would remove without modifying files",
)
@click.option(
    "--format",
    "-f",
    "output_format",
    type=click.Choice(["text", "json", "sarif", "markdown"], case_sensitive=False),
    default="text",
    help="Output format: text (default), json, sarif (GitHub Code Scanning), markdown (step summaries).",
)
@click.option(
    "--output",
    "-o",
    "output_path",
    type=click.Path(),
    default=None,
    help="Write output to file (auto-detects format from extension: .sarif, .json, .md).",
)
@click.option(
    "--ci",
    is_flag=True,
    help="Run lockfile consistency checks for CI/CD gates. Exit 0 if clean, 1 if violations found.",
)
@click.option(
    "--policy",
    "policy_source",
    default=None,
    help=f"Policy source. {POLICY_SOURCE_FORMS_HELP} Used with --ci for policy checks.",
)
@click.option(
    "--no-cache",
    "no_cache",
    is_flag=True,
    help="Force fresh policy fetch (skip cache).",
)
@click.option(
    "--no-policy",
    "no_policy",
    is_flag=True,
    help=(
        "Skip org policy discovery and enforcement. Overridden when --policy is passed explicitly."
    ),
)
@click.option(
    "--no-fail-fast",
    "no_fail_fast",
    is_flag=True,
    help="Run all checks even after a failure (default: stop at first failure).",
)
@click.option(
    "--no-drift",
    "no_drift",
    is_flag=True,
    help=(
        "Skip the install-replay drift check. Reduces coverage; "
        "use only for performance-constrained CI loops."
    ),
)
@click.option(
    "--external",
    "external",
    multiple=True,
    metavar="NAME",
    help=(
        "Ingest findings from an external SARIF-native scanner "
        "(repeatable). Names: skillspector, sarif. "
        "Not supported with --ci. "
        "Requires 'apm experimental enable external-scanners'. [experimental]"
    ),
)
@click.option(
    "--external-sarif",
    "external_sarif",
    type=click.Path(exists=False),
    default=None,
    help="SARIF file to ingest for '--external sarif'. [experimental]",
)
@click.option(
    "--external-llm/--no-external-llm",
    "external_llm",
    default=None,
    help=(
        "Force LLM-powered analysis on/off for external scanners this run "
        "(overrides config). LLM mode makes outbound API calls and needs an "
        "API key. Requires --external. [experimental]"
    ),
)
@click.option(
    "--external-args",
    "external_args",
    default=None,
    metavar="TEXT",
    help=(
        "Extra argv tokens for external scanners this run (shlex-split, "
        "allowlist-validated per scanner). Overrides config args. "
        "Requires --external. [experimental]"
    ),
)
@click.pass_context
@serialized_lifecycle_when("strip", unless_argument="dry_run")
def audit(  # noqa: PLR0913 -- Click handler
    ctx,
    package,
    file_path,
    strip,
    verbose,
    dry_run,
    output_format,
    output_path,
    ci,
    policy_source,
    no_cache,
    no_policy,
    no_fail_fast,
    no_drift,
    external,
    external_sarif,
    external_llm,
    external_args,
):
    """Scan deployed prompt files for hidden Unicode characters.

    Detects invisible characters that could embed hidden instructions in
    prompt, instruction, and rules files. Dangerous and suspicious
    characters can be removed with --strip.

    By default, also runs install-replay drift detection: catches
    hand-edits to deployed files, missing integrations, and orphaned
    files vs the lockfile.  Use --no-drift to skip (reduces coverage).

    With --ci, runs lockfile consistency checks AND drift in machine-
    readable format, suitable for CI/CD pipeline gates.

    \b
    Exit codes:
        0  Clean, info-only findings, or drift-only (advisory) in bare
           audit, or successful strip
        1  Critical findings detected, or --ci with violations
           (including drift in --ci mode)
        2  Warning-only findings (suspicious but not critical), or
           usage error (mutually exclusive flags)
        3  Configuration or infrastructure error (experimental feature
           disabled, external scanner not installed or unavailable)

    \b
    Examples:
        apm audit                      # Scan + drift (all checks)
        apm audit my-package           # Scan a specific package
        apm audit --file .cursorrules  # Scan any file (no drift)
        apm audit --strip              # Remove dangerous/suspicious chars
        apm audit --no-drift           # Skip drift only (escape hatch)
        apm audit --ci                 # CI gate (lockfile + drift)
        apm audit --ci --no-drift      # CI gate without drift (rare)
        apm audit --ci --policy org    # CI gate with org policy checks
        apm audit --ci -f json         # JSON CI report
        apm audit --ci -f sarif        # SARIF for GitHub Code Scanning
        apm audit -o report.sarif      # Write SARIF to file
        apm audit --external skillspector                    # SkillSpector
        apm audit --external sarif --external-sarif r.sarif  # Any SARIF
    """
    project_root = Path.cwd()
    if not file_path:
        # Lockfile-backed audits must not certify a newer generator's lockfile.
        from ..deps.lockfile_generator import require_current_cli

        require_current_cli(project_root, command="apm audit")
    logger = CommandLogger("audit", verbose=verbose)

    cfg = _AuditConfig(
        project_root=project_root,
        logger=logger,
        verbose=verbose,
        output_format=output_format,
        output_path=output_path,
    )

    # --no-drift is a different audit mode from --strip / --file (those
    # are content-scanning operations unrelated to integration drift).
    # Click-native UsageError gives exit code 2 with "Usage:" prefix.
    if no_drift and (strip or file_path):
        raise click.UsageError(
            "--no-drift cannot be combined with --strip or --file "
            "(those modes do not run drift detection)"
        )

    # -- CI mode: lockfile consistency gate -------------------------
    if ci:
        if verbose:
            logger.warning("--verbose has no effect in --ci mode (output is structured)")
        if strip or dry_run or file_path or package:
            raise click.UsageError(
                "--ci cannot be combined with --strip, --dry-run, --file, or PACKAGE"
            )
        if output_format == "markdown":
            logger.error("--ci does not support --format markdown. Use json or sarif.")
            sys.exit(1)
        if external:
            raise click.UsageError(
                "--ci does not support --external scanners yet. "
                "Run external scanners in bare 'apm audit' mode."
            )

        _audit_ci_gate(cfg, policy_source, no_cache, no_policy, no_fail_fast, no_drift)
        return  # _audit_ci_gate calls sys.exit; return guards against fall-through

    # -- External scanners are an additive, opt-in content-scan source.
    # They cannot be combined with --strip/--dry-run (APM only knows how to
    # strip the Unicode characters its own scanner detects).
    if external and (strip or dry_run):
        raise click.UsageError("--external cannot be combined with --strip or --dry-run")
    if external_sarif and not external:
        raise click.UsageError("--external-sarif requires '--external sarif'")
    # Orphan-flag guards: scanner-config flags are meaningless without a
    # scanner. UsageError yields exit 2 (usage error), matching --no-drift.
    if external_llm is not None and not external:
        raise click.UsageError("--external-llm/--no-external-llm requires '--external <name>'")
    if external_args is not None and not external:
        raise click.UsageError("--external-args requires '--external <name>'")

    # -- Content scan mode ------------------------------------------
    if policy_source:
        logger.warning(
            "--policy requires --ci mode. "
            "Use 'apm audit --ci --policy <source>' to run policy checks."
        )

    if not file_path:
        _reject_invalid_manifest(project_root, logger)

    _audit_content_scan(
        cfg,
        package,
        file_path,
        strip,
        dry_run,
        no_drift,
        external,
        external_sarif,
        external_llm,
        external_args,
    )
