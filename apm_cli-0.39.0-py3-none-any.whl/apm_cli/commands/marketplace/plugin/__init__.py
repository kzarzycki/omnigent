"""Marketplace package subgroup helpers and click wiring."""

from __future__ import annotations

import re
import sys
from pathlib import Path

import click

from apm_cli.core.remediation import (
    MARKETPLACE_CONFIG_DUPLICATE,
    MARKETPLACE_CONFIG_MISSING,
)
from apm_cli.core.scope import manifest_file

from ....core.command_logger import CommandLogger
from ....marketplace.errors import (
    GitLsRemoteError,
    OfflineMissError,
)

_SHA_RE = re.compile(r"^[0-9a-f]{40}$")


def _yml_path() -> Path:
    """Return the active marketplace authoring config path in CWD."""
    cwd = Path.cwd()
    apm_path = manifest_file(cwd)
    legacy_path = cwd / "marketplace.yml"

    if _has_marketplace_block(apm_path):
        return apm_path
    if legacy_path.exists():
        return legacy_path
    return apm_path


def _ensure_yml_exists(logger: CommandLogger) -> Path:
    """Return the yml path or exit with guidance if it does not exist."""
    cwd = Path.cwd()
    apm_path = manifest_file(cwd)
    legacy_path = cwd / "marketplace.yml"

    if _has_marketplace_block(apm_path) and legacy_path.exists():
        logger.error(
            "Both apm.yml (with a 'marketplace:' block) and "
            "marketplace.yml exist. Remove marketplace.yml, or "
            f"{MARKETPLACE_CONFIG_DUPLICATE.clause()}.",
            symbol="error",
        )
        sys.exit(1)

    path = _yml_path()
    if not path.exists() or (path == apm_path and not _has_marketplace_block(path)):
        logger.error(
            f"No marketplace authoring config found. {MARKETPLACE_CONFIG_MISSING.sentence()}",
            symbol="error",
        )
        sys.exit(1)
    return path


def _has_marketplace_block(apm_path: Path) -> bool:
    """Return True when *apm_path* has a populated ``marketplace:`` block."""
    if not apm_path.exists():
        return False
    import yaml

    try:
        # Bounded loader so a hostile apm.yml cannot wedge this probe with a
        # merge/alias expansion bomb (fails closed as yaml.YAMLError).
        from apm_cli.utils.yaml_io import load_yaml

        data = load_yaml(apm_path)
    except (OSError, yaml.YAMLError):
        return False
    return isinstance(data, dict) and "marketplace" in data and data["marketplace"] is not None


def _parse_tags(raw: str | None) -> list[str] | None:
    """Split a comma-separated tag string into a list, or return None."""
    if raw is None:
        return None
    parts = [t.strip() for t in raw.split(",") if t.strip()]
    return parts if parts else None


def _verify_source(logger: CommandLogger, source: str, *, host: str | None = None) -> None:
    """Run ``git ls-remote`` against *source* to verify reachability."""
    from ....marketplace.ref_resolver import RefResolver

    resolver = RefResolver(host=host)
    try:
        resolver.list_remote_refs(source)
    except GitLsRemoteError as exc:
        logger.error(
            f"Source '{source}' is not reachable: {exc}",
            symbol="error",
        )
        sys.exit(2)
    except OfflineMissError:
        logger.warning(
            f"Cannot verify source '{source}' (offline / no cache).",
            symbol="warning",
        )


def _resolve_ref(
    logger: CommandLogger,
    source: str,
    ref: str | None,
    version: str | None,
    no_verify: bool,
    *,
    host: str | None = None,
) -> str | None:
    """Resolve *ref* to a concrete SHA when it is mutable.

    Returns the (possibly resolved) ref string, or ``None`` when
    *version* is set (version-based pinning, no ref needed).
    """
    from ....marketplace.ref_resolver import RefResolver, explicit_ref_error

    # Version-based - no ref resolution needed.
    if version is not None:
        return None

    # Already a concrete SHA - store as-is.
    if ref is not None and _SHA_RE.match(ref):
        return ref

    # HEAD (explicit or implicit) requires network access.
    is_head = ref is None or ref.upper() == "HEAD"
    if is_head:
        if no_verify:
            logger.error(
                "Cannot resolve HEAD ref without network access. Provide an explicit --ref SHA.",
                symbol="error",
            )
            sys.exit(2)
        if ref is not None:
            logger.warning(
                "'HEAD' is a mutable ref. Resolving to current SHA for safety.",
                symbol="warning",
            )
        resolver = RefResolver(host=host)
        try:
            sha = resolver.resolve_ref_sha(source, "HEAD")
        except GitLsRemoteError as exc:
            logger.error(
                f"Failed to resolve HEAD for '{source}': {exc}",
                symbol="error",
            )
            sys.exit(2)
        logger.progress(
            f"Resolved HEAD to {sha[:12]}",
            symbol="info",
        )
        return sha

    # Non-HEAD, non-SHA ref - verify it exists the same way ``check`` does.
    resolver = RefResolver(host=host)
    try:
        remote_refs = resolver.list_remote_refs(source)
    except (GitLsRemoteError, OfflineMissError) as exc:
        detail = exc.summary_text if isinstance(exc, GitLsRemoteError) else str(exc)
        if not no_verify:
            logger.error(f"Cannot verify ref '{ref}' for '{source}': {detail}", symbol="error")
            sys.exit(2)
        logger.warning(
            f"Could not verify ref '{ref}' for '{source}' ({detail}). Storing unresolved.",
            symbol="warning",
        )
        return ref

    for remote_ref in remote_refs:
        if remote_ref.name == f"refs/heads/{ref}":
            if no_verify:
                logger.error(
                    "Cannot resolve branch ref without network access. "
                    "Provide an explicit --ref SHA.",
                    symbol="error",
                )
                sys.exit(2)
            logger.warning(
                f"'{ref}' is a branch (mutable ref). Resolving to current SHA for safety.",
                symbol="warning",
            )
            logger.progress(
                f"Resolved {ref} to {remote_ref.sha[:12]}",
                symbol="info",
            )
            return remote_ref.sha

    # Not a branch - a tag must exist on the remote, as ``marketplace check``
    # requires; --no-verify keeps the explicit opt-out.
    error = explicit_ref_error(
        ref, remote_refs, resolver=resolver, owner_repo=source, offline=False
    )
    if error and not no_verify:
        logger.error(f"{error} for '{source}'", symbol="error")
        sys.exit(2)
    return ref


@click.group(help="Manage packages in marketplace authoring config")
def package():
    """Add, update, or remove packages in marketplace authoring config."""


from .add import add  # noqa: E402
from .remove import remove  # noqa: E402
from .set import set_cmd  # noqa: E402

__all__ = [
    "_SHA_RE",
    "_ensure_yml_exists",
    "_has_marketplace_block",
    "_parse_tags",
    "_resolve_ref",
    "_verify_source",
    "_yml_path",
    "add",
    "package",
    "remove",
    "set_cmd",
]
