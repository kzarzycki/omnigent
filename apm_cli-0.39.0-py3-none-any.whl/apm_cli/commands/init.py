"""APM init command."""

import os
import shlex
import sys
from functools import wraps
from pathlib import Path

import click

from apm_cli.core.remediation import (
    INIT_TARGETS_UNDETECTED,
)
from apm_cli.core.scope import manifest_file

from ..bundle.formats import PREFERRED_PLUGIN_FORMAT, BundleFormat
from ..bundle.plugin_layout import find_plugin_root_sources
from ..constants import APM_YML_FILENAME
from ..core.command_logger import CommandLogger
from ..core.project_name import (
    resolve_bootstrap_project_name as _resolve_bootstrap_project_name,
)
from ..core.project_name import validate_project_name as _validate_project_name
from ..core.target_detection import (
    EXPLICIT_ONLY_TARGETS,
    TargetParamType,
    detect_signals,
)
from ..install.locking import serialized_lifecycle_unless
from ..models.manifest_io import InvalidManifestError
from ..models.manifest_targets import IdeTargetError, option_target_names, rewrite_target_names
from ..utils.console import (
    _create_files_table,
    _rich_panel,
)
from ._helpers import (
    ERROR,
    INFO,
    RESET,
    _create_minimal_apm_yml,
    _create_plugin_json,
    _get_console,
    _get_default_config,
    _rich_blank_line,
    _validate_plugin_name,
)
from .discover import discover_options, run_discover


def _detect_agentrc(project_root: Path) -> tuple[bool, bool]:
    """Return (agentrc_installed, has_instructions).

    has_instructions is True when any known agent-instructions artifact exists
    under project_root, meaning the user already has instructions and does not
    need a suggestion.
    """
    from apm_cli.utils.git_env import trusted_executable

    installed = trusted_executable("agentrc") is not None
    has_instructions = any(
        (
            (project_root / ".github" / "copilot-instructions.md").exists(),
            (project_root / "AGENTS.md").exists(),
            (project_root / ".github" / "instructions").is_dir(),
        )
    )
    return installed, has_instructions


# Display order for the prompt (matches scope S1 UX spec)
_PROMPT_TARGETS_ORDERED: list[str] = [
    "copilot",
    "claude",
    "cursor",
    "opencode",
    "codex",
    "gemini",
    "windsurf",
]


def _invalid_project_name_message(name: str) -> str:
    """Return the project-name rule shared by the argument, --name, and prompts."""
    return (
        f"Invalid project name '{name}': "
        "project names must not be empty or whitespace-only and must not contain "
        "path separators ('/' or '\\\\') or be '..'."
    )


def _refuse_ide_target_first(source):
    """Refuse an IDE ``--target`` before the lifecycle lock is taken (#3878).

    Applied outside the lifecycle decorator so a refused ``apm init`` or
    ``apm plugin init`` creates no lock, project directory or manifest.
    """

    def decorate(run):
        @wraps(run)
        def wrapped(*args, **kwargs):
            target_flag = kwargs.get("target_flag")
            if target_flag is not None:
                logger = CommandLogger(source, verbose=kwargs.get("verbose", False))
                _option_targets_or_exit(target_flag, logger)
            return run(*args, **kwargs)

        return wrapped

    return decorate


def _option_targets_or_exit(target_flag, logger):
    """Map ``--target`` through the declaration owner; refuse IDE targets (#3878)."""
    try:
        targets = option_target_names(target_flag)
    except IdeTargetError as exc:
        logger.error(f"Cannot record --target {exc.token} in {APM_YML_FILENAME}: {exc}")
        logger.progress("Nothing was written.", symbol="info")
        sys.exit(1)
    return targets


@click.command(help="Initialize a new APM project")
@click.option(
    "--discover",
    "discover_flag",
    is_flag=True,
    help="Inventory existing local packages without writes",
)
@discover_options
@click.argument("project_name", required=False)
@click.option(
    "--yes", "-y", is_flag=True, help="Skip interactive prompts and use auto-detected defaults"
)
# Removed in 0.37 (#4073): hidden stubs that name the replacement and exit 2.
@click.option("--plugin", is_flag=True, hidden=True)
@click.option("--marketplace", "marketplace_flag", is_flag=True, hidden=True)
@click.option(
    "--target",
    "target_flag",
    type=TargetParamType(),
    default=None,
    help="Comma-separated target list (skip prompt, write directly)",
)
@click.option(
    "--name",
    default=None,
    help="Project name written to apm.yml. Ignored when a positional project name is given.",
)
@click.option("--description", default=None, help="Project description (default: auto-detected)")
@click.option(
    "--version",
    default=None,
    help="Project version (default: 1.0.0)",
)
@click.option("--author", default=None, help="Project author (default: git config user.name)")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed output")
@click.pass_context
@_refuse_ide_target_first("init")
# --apply implies --discover; discovery takes its own lock only when it writes.
@serialized_lifecycle_unless("discover_flag", "write")
def init(
    ctx: click.Context,
    project_name: str | None,
    yes: bool,
    plugin: bool,
    marketplace_flag: bool,
    target_flag: str | list[str] | None,
    verbose: bool,
    name: str | None = None,
    description: str | None = None,
    version: str | None = None,
    author: str | None = None,
    discover_flag: bool = False,
    write: bool = False,
    output_format: str = "text",
    global_: bool = False,
) -> None:
    """Initialize a new APM project (like npm init).

    Creates a minimal apm.yml with auto-detected metadata.

    Metadata flags (--name, --description, --version, --author) set the
    corresponding apm.yml field without a prompt, so scripted and CI init
    can produce a finished manifest. Outside --yes they seed the prompt
    defaults rather than being discarded.

    Producers: use 'apm plugin init' (plugin scaffold) or
    'apm marketplace init' (marketplace block).
    """
    _refuse_removed_init_flags(
        plugin=plugin,
        marketplace=marketplace_flag,
        project_name=project_name,
        yes=yes,
        target_flag=target_flag,
        description=description,
        version=version,
        author=author,
    )
    if write:
        discover_flag = True
    if discover_flag:
        metadata_flags = (name, description, version, author)
        if project_name or target_flag or any(flag is not None for flag in metadata_flags):
            raise click.UsageError(
                "--discover cannot scaffold a name, set project metadata, or select targets."
            )
        run_discover(
            write=write, output_format=output_format, global_=global_, yes=yes, verbose=verbose
        )
        return
    if write or global_ or output_format != "text":
        raise click.UsageError("--global and --format require --discover.")
    _init_scaffold(
        ctx,
        project_name,
        yes,
        target_flag,
        verbose,
        name=name,
        description=description,
        version=version,
        author=author,
    )


def _refuse_removed_init_flags(
    *,
    plugin: bool,
    marketplace: bool,
    project_name: str | None = None,
    yes: bool = False,
    target_flag: str | list[str] | None = None,
    description: str | None = None,
    version: str | None = None,
    author: str | None = None,
) -> None:
    """Refuse the flags removed in 0.37 with the full replacement command (#4073).

    The ``apm plugin init`` command keeps the arguments the user passed so
    recovery is one paste. ``apm marketplace init`` runs in the project
    directory and takes none of them.
    """
    if not (plugin or marketplace):
        return
    removed = " and ".join(
        f"'apm init {flag}'"
        for flag, used in (("--plugin", plugin), ("--marketplace", marketplace))
        if used
    )
    verb = "were" if plugin and marketplace else "was"
    click.echo(f"[x] {removed} {verb} removed in 0.37.", err=True)
    if plugin:
        args = ["apm", "plugin", "init"]
        if project_name:
            args.append(project_name)
        if yes:
            args.append("--yes")
        if target_flag:
            targets = target_flag if isinstance(target_flag, str) else ",".join(target_flag)
            args += ["--target", targets]
        for option, value in (
            ("--version", version),
            ("--author", author),
            ("--description", description),
        ):
            if value is not None:
                args += [option, value]
        click.echo(f"    Run: {shlex.join(args)}", err=True)
    if marketplace:
        where = f" (inside {project_name}/)" if plugin and project_name else ""
        prefix = "Then run" if plugin else "Run"
        click.echo(f"    {prefix}{where}: apm marketplace init", err=True)
    raise SystemExit(2)


def _init_scaffold(
    ctx,
    project_name,
    yes,
    target_flag,
    verbose,
    *,
    name: str | None = None,
    description: str | None = None,
    version: str | None = None,
    author: str | None = None,
):
    """Keep the pre-existing init flow serialized, outside read-only discovery."""
    _perform_init(
        project_name=project_name,
        yes=yes,
        plugin=False,
        target_flag=target_flag,
        name=name,
        description=description,
        version=version,
        author=author,
        verbose=verbose,
        source="init",
    )


def _perform_init(
    *,
    project_name,
    yes,
    plugin,
    target_flag,
    verbose,
    name: str | None = None,
    description: str | None = None,
    version: str | None = None,
    author: str | None = None,
    source="init",
    plugin_mode: str | None = None,
):
    """Shared init body. Called by `apm init` and `apm plugin init`.

    ``source`` controls the "Next steps" hint shape:
      - "init"   -> consumer-focused, teaches the noun-verb namespace
      - "plugin" -> plugin-author next steps

    ``name``/``description``/``version``/``author`` are the optional
    metadata overrides (#2146). They default to ``None`` so callers that
    predate them -- ``apm plugin init`` -- keep their existing behavior.
    """
    logger = CommandLogger(source, verbose=verbose)
    try:
        effective_plugin_mode = plugin_mode
        if effective_plugin_mode is None:
            effective_plugin_mode = (
                "agent" if PREFERRED_PLUGIN_FORMAT is BundleFormat.AGENT_PLUGIN else "claude"
            )

        # Handle explicit current directory
        if project_name == ".":
            project_name = None

        # Reject names containing path separators before any filesystem use
        if project_name is not None and not _validate_project_name(project_name):
            logger.error(_invalid_project_name_message(project_name))
            sys.exit(1)

        # Metadata flags get the same whitespace trimming as prompt answers.
        name, description, version, author = (
            None if value is None else value.strip()
            for value in (name, description, version, author)
        )

        # The positional argument also creates and enters a directory, so it
        # keeps precedence over --name, which only labels the manifest. Report
        # the ignored flag rather than dropping it silently.
        if project_name and name is not None:
            logger.warning(
                f"--name '{name}' ignored: positional project name "
                f"'{project_name}' takes precedence."
            )
            name = None

        if name is not None and not _validate_project_name(name):
            logger.error(_invalid_project_name_message(name))
            sys.exit(1)

        # apm.yml requires a non-empty version string.
        if version is not None and not version:
            logger.error(
                "Invalid project version: --version must not be empty or whitespace-only. "
                "Provide a version such as '1.0.0', or omit --version to use the default."
            )
            sys.exit(1)

        # Refuse a --target that apm.yml cannot record before creating anything.
        if target_flag is not None:
            _option_targets_or_exit(target_flag, logger)

        # Determine project name
        if project_name:
            final_project_name = project_name
        else:
            project_dir = Path.cwd()
            if name is not None:
                final_project_name = name
            else:
                # A filesystem root has no directory name, so resolve a valid fallback.
                derived_project_name = project_dir.name
                final_project_name = _resolve_bootstrap_project_name(derived_project_name)
                if final_project_name != derived_project_name:
                    logger.verbose_detail(
                        f'Using default project name "{final_project_name}" because '
                        f"derived name {derived_project_name!a} is invalid"
                    )

        # Validate the plugin name before creating anything (#5404)
        if plugin and not _validate_plugin_name(final_project_name):
            logger.error(
                f"Invalid plugin name '{final_project_name}'. "
                "Use 1-64 lowercase letters, numbers, dots, or hyphens; "
                "begin and end with a letter or number; and do not use '..' or '--'."
            )
            sys.exit(1)

        if project_name:
            Path(project_name).mkdir(exist_ok=True)
            os.chdir(project_name)
            logger.progress(f"Created project directory: {project_name}", symbol="folder")
        project_root = Path.cwd()

        # Check for existing generated files
        apm_yml_exists = manifest_file(Path(".")).exists()
        generated_paths = [manifest_file(Path("."))]
        if plugin:
            generated_paths.append(Path("plugin.json"))
            if effective_plugin_mode == "agent":
                generated_paths.append(Path("mcp.json"))
        existing_generated_paths = [path for path in generated_paths if path.exists()]

        # Handle existing generated files in brownfield projects
        if existing_generated_paths:
            rendered_paths = ", ".join(path.as_posix() for path in existing_generated_paths)
            if existing_generated_paths == [manifest_file(Path("."))]:
                logger.warning("apm.yml already exists")
            else:
                logger.warning(f"Generated files already exist: {rendered_paths}")

            if not yes:
                try:
                    confirm = click.confirm("Continue and overwrite?")
                except click.exceptions.Abort:
                    # No answer (closed stdin): refuse with the way forward.
                    logger.error(
                        f"{rendered_paths} not overwritten; rerun with --yes to overwrite, "
                        "or pass a new project name to scaffold into its own directory."
                    )
                    sys.exit(1)

                if not confirm:
                    logger.progress("Initialization cancelled.")
                    return
            else:
                logger.progress(f"--yes specified, overwriting: {rendered_paths}")

        # Get project configuration (interactive mode or defaults)
        if not yes:
            config = _interactive_project_setup(
                final_project_name,
                logger,
                description=description,
                version=version,
                author=author,
            )
        else:
            # Use auto-detected defaults, then let explicit flags win.
            config = _get_default_config(final_project_name)
            for field, override in (
                ("description", description),
                ("version", version),
                ("author", author),
            ):
                if override is not None:
                    config[field] = override

        # --- Target selection (must run before the confirmation panel so
        #     the chosen targets render in the "About to create" summary). ---
        resolved_targets = _resolve_init_targets(
            project_root=project_root,
            target_flag=target_flag,
            yes=yes,
            apm_yml_exists=apm_yml_exists,
            logger=logger,
        )
        if resolved_targets is not None:
            config["targets"] = sorted(resolved_targets)

        # Final confirmation panel (interactive only) -- now includes targets.
        if not yes:
            _confirm_setup_summary(config, logger)

        # Plugin mode uses 0.1.0 as default version, unless --version set one.
        # Check the raw flag, not config["version"], so an explicit value wins.
        if plugin and yes and version is None:
            config["version"] = "0.1.0"

        logger.start(f"Initializing APM project: {config['name']}", symbol="running")

        native_sources = find_plugin_root_sources(project_root)
        if native_sources and not (project_root / ".apm").is_dir():
            rendered_sources = ", ".join(
                source if source.endswith(".json") else f"{source}/" for source in native_sources
            )
            logger.warning(
                "Found plugin-native sources at the project root: "
                f"{rendered_sources}. They remain included by apm pack. "
                "Move publishable files under .apm/ when you want apm pack "
                "to source from that directory.",
            )

        if plugin and effective_plugin_mode == "agent":
            _write_and_validate_agent_plugin_scaffold(project_root, config)
        else:
            _create_minimal_apm_yml(config, plugin=plugin)
            if plugin:
                _create_plugin_json(config, mode=effective_plugin_mode)

        logger.success("APM project initialized successfully!")

        # Display created file info
        try:
            console = _get_console()
            if console:
                files_data = [
                    (APM_YML_FILENAME, "Project configuration"),
                ]
                if plugin:
                    files_data.append(("plugin.json", "Plugin metadata"))
                    if effective_plugin_mode == "agent":
                        files_data.append(("mcp.json", "MCP server configuration"))
                table = _create_files_table(files_data, title="Created Files")
                console.print(table)
        except (ImportError, NameError):
            logger.progress("Created:")
            click.echo("  * apm.yml - Project configuration")
            if plugin:
                click.echo("  * plugin.json - Plugin metadata")
                if effective_plugin_mode == "agent":
                    click.echo("  * mcp.json - MCP server configuration")

        _rich_blank_line()

        # Next steps - actionable commands matching README workflow
        # Branch on ``source`` so that:
        #   * ``apm init`` (consumer)  teaches the noun-verb namespace
        #     (apm plugin init / apm marketplace init).
        #   * ``apm plugin init``      shows plugin-author next steps.
        if plugin:
            next_steps = [
                "Add dev dependencies:    apm install --dev <owner>/<repo>",
                "Pack as Agent Plugins v1:             apm pack --format agent-plugin",
                "Pack as Claude plugin:                apm pack --format claude-plugin",
            ]
            # A Claude-only scaffold has nothing for an Agent Plugin to carry;
            # pack refuses that format, so do not advertise it (#3994).
            if resolved_targets and set(resolved_targets) <= {"claude"}:
                del next_steps[1]
        elif source == "init":
            install_step = "apm install <owner>/<repo>"
            # No targets written and none detectable: install would stop at
            # "No harness detected" unless it names one (#3994).
            if not resolved_targets and not _has_install_target(project_root):
                install_step += " -t <harness>"
            next_steps = [
                f"Install a package:               {install_step}",
                "Build a plugin? Scaffold one:    apm plugin init <name>",
                "Publishing a marketplace?:       apm marketplace init",
            ]
        else:
            next_steps = [
                "Install a skill:                apm install github/awesome-copilot/skills/documentation-writer",
                "Install a marketplace plugin:   apm install frontend-web-dev@awesome-copilot",
                "Install a versioned package:    apm install microsoft/apm-sample-package#v1.0.0",
                "Author your own plugin:         apm pack --format agent-plugin",
            ]

        # Agentrc integration (#518): when agentrc is already installed and no
        # instructions exist, name its step. Consumer init only (not plugin
        # mode); the default path names APM steps only (#4089).
        if not plugin and source == "init":
            agentrc_installed, has_instructions = _detect_agentrc(project_root)
            if agentrc_installed and not has_instructions:
                next_steps.insert(
                    1,
                    "Generate agent instructions:     agentrc init",
                )

        try:
            _rich_panel(
                "\n".join(f"* {step}" for step in next_steps),
                title=" Next Steps",
                style="cyan",
            )
        except (ImportError, NameError):
            logger.progress("Next steps:")
            for step in next_steps:
                click.echo(f"  * {step}")

        # Codex tip: suggest agent-skills target when .codex/ exists
        if Path(".codex").is_dir():
            logger.progress(
                "Tip: Use '--target agent-skills' to also deploy skills to "
                ".agents/skills/ for other clients.",
                symbol="info",
            )

        # Footer with links
        try:
            console = _get_console()
            if console:
                console.print(
                    "  Docs: https://microsoft.github.io/apm  |  "
                    "Star: https://github.com/microsoft/apm",
                    style="dim",
                    soft_wrap=True,
                )
            else:
                click.echo(
                    "  Docs: https://microsoft.github.io/apm  |  "
                    "Star: https://github.com/microsoft/apm"
                )
        except (ImportError, NameError):
            click.echo(
                "  Docs: https://microsoft.github.io/apm  |  Star: https://github.com/microsoft/apm"
            )

    except Exception as e:
        logger.error(f"Error initializing project: {e}")
        sys.exit(1)


def _write_and_validate_agent_plugin_scaffold(project_root: Path, config: dict) -> None:
    """Stage, validate, and commit all native scaffold files as one transaction."""
    import json
    import tempfile

    from ..agent_plugins import (
        MCP_SCHEMA_ID,
        DiagnosticSeverity,
        load_agent_plugin,
    )

    mcp_document = {"$schema": MCP_SCHEMA_ID, "mcpServers": {}}
    with tempfile.TemporaryDirectory(prefix=".apm-plugin-init-", dir=project_root) as stage:
        staged_root = Path(stage)
        staged_manifest = manifest_file(staged_root)
        _create_minimal_apm_yml(config, plugin=True, target_path=staged_manifest)
        _create_plugin_json(config, mode="agent", target_path=staged_root / "plugin.json")
        (staged_root / "mcp.json").write_text(
            json.dumps(mcp_document, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        plugin = load_agent_plugin(staged_root)
        errors = [
            diagnostic.message
            for diagnostic in plugin.diagnostics
            if diagnostic.severity is DiagnosticSeverity.ERROR
        ]
        if errors:
            raise ValueError("Generated Agent Plugin scaffold is invalid: " + "; ".join(errors))

        _commit_staged_scaffold(
            staged_root,
            project_root,
            (APM_YML_FILENAME, "plugin.json", "mcp.json"),
        )


def _commit_staged_scaffold(
    staged_root: Path,
    project_root: Path,
    filenames: tuple[str, ...],
) -> None:
    """Replace a generated file set, restoring every prior file on failure."""
    backup_root = staged_root / ".backup"
    backup_root.mkdir()
    backups: dict[str, Path] = {}
    committed: list[str] = []
    try:
        for filename in filenames:
            destination = project_root / filename
            if destination.exists():
                backup = backup_root / filename
                os.replace(destination, backup)
                backups[filename] = backup
        for filename in filenames:
            os.replace(staged_root / filename, project_root / filename)
            committed.append(filename)
    except Exception:
        for filename in committed:
            (project_root / filename).unlink(missing_ok=True)
        for filename, backup in backups.items():
            if backup.exists():
                os.replace(backup, project_root / filename)
        raise


def _interactive_project_setup(
    default_name, logger, *, description=None, version=None, author=None
):
    """Interactive setup for new APM projects with auto-detection.

    Collects only the metadata fields here; target selection and final
    confirmation are run by the caller via ``_confirm_setup_summary`` so
    targets can be shown in the same "About to create" panel.

    Any metadata passed via flags seeds the matching prompt default, so a
    flag given without ``--yes`` is still honored on an empty answer (#2146).
    """
    from ._helpers import _auto_detect_author, _auto_detect_description, _validate_project_name

    auto_author = author if author is not None else _auto_detect_author()
    auto_description = (
        description if description is not None else _auto_detect_description(default_name)
    )
    auto_version = version if version is not None else "1.0.0"

    try:
        from rich.prompt import Prompt  # type: ignore

        from apm_cli.utils.console import new_console

        console = _get_console() or new_console()
        console.print("\n[info]Setting up your APM project...[/info]")
        console.print("[muted]Press ^C at any time to quit.[/muted]\n")

        while True:
            name = Prompt.ask("Project name", default=default_name).strip()
            if _validate_project_name(name):
                break
            console.print(f"[error]{_invalid_project_name_message(name)}[/error]")

        version = Prompt.ask("Version", default=auto_version).strip()
        description = Prompt.ask("Description", default=auto_description).strip()
        author = Prompt.ask("Author", default=auto_author).strip()

    except (ImportError, NameError):
        logger.progress("Setting up your APM project...")
        logger.progress("Press ^C at any time to quit.")

        while True:
            name = click.prompt("Project name", default=default_name).strip()
            if _validate_project_name(name):
                break
            click.echo(f"{ERROR}{_invalid_project_name_message(name)}{RESET}")

        version = click.prompt("Version", default=auto_version).strip()
        description = click.prompt("Description", default=auto_description).strip()
        author = click.prompt("Author", default=auto_author).strip()

    return {
        "name": name,
        "version": version,
        "description": description,
        "author": author,
    }


def _confirm_setup_summary(config: dict, logger) -> None:
    """Render the 'About to create' panel (including targets) and confirm.

    Aborts via ``sys.exit(0)`` if the user declines.
    """
    targets = config.get("targets")  # architecture-authority-exempt: bootstrap-writer
    targets_line = ", ".join(targets) if targets else "(none -- auto-detect at compile time)"

    try:
        from rich.panel import Panel  # type: ignore
        from rich.prompt import Confirm  # type: ignore

        from apm_cli.utils.console import new_console

        console = _get_console() or new_console()
        summary_content = (
            f"name: {config['name']}\n"
            f"version: {config['version']}\n"
            f"description: {config['description']}\n"
            f"author: {config['author']}\n"
            f"targets: {targets_line}"
        )
        console.print(Panel(summary_content, title="About to create", border_style="cyan"))

        if not Confirm.ask("\nIs this OK?", default=True):
            console.print("[info]Aborted.[/info]")
            sys.exit(0)
    except (ImportError, NameError):
        click.echo(f"\n{INFO}About to create:{RESET}")
        click.echo(f"  name: {config['name']}")
        click.echo(f"  version: {config['version']}")
        click.echo(f"  description: {config['description']}")
        click.echo(f"  author: {config['author']}")
        click.echo(f"  targets: {targets_line}")

        if not click.confirm("\nIs this OK?", default=True):
            logger.progress("Aborted.")
            sys.exit(0)


def _stdin_is_tty() -> bool:
    """Return whether sys.stdin is a TTY. Indirection for test patchability.

    The CliRunner's piped stdin reports ``isatty=False`` even when the test
    intends to exercise the interactive prompt; tests patch this helper to
    True to traverse the prompt path. Production callers see real terminal
    state.
    """
    try:
        return bool(sys.stdin.isatty())
    except (AttributeError, ValueError):
        return False


def _has_install_target(project_root: Path) -> bool:
    """Whether a plain ``apm install`` here resolves a target without a flag."""
    from ..config import get_install_target

    try:
        if get_install_target(create_config=False):
            return True
    except Exception:
        return False
    return any(sig.target not in EXPLICIT_ONLY_TARGETS for sig in detect_signals(project_root))


def _resolve_init_targets(
    project_root: Path,
    *,
    target_flag: str | list[str] | None,
    yes: bool,
    apm_yml_exists: bool,
    logger: CommandLogger,
) -> list[str] | None:
    """Resolve targets for init. Returns list of targets or None (auto-detect).

    Priority: --target flag > interactive prompt > auto-detect (--yes/non-TTY).
    """
    # Case 1: --target flag provided -- wins unconditionally
    if target_flag is not None:
        targets = _option_targets_or_exit(target_flag, logger)
        if not targets:
            return None
        logger.progress(f"Targets set: {', '.join(targets)} (via --target flag)", symbol="info")
        return targets

    # Determine pre-check state
    prechecked: set[str] = set()
    signal_hints: dict[str, str] = {}
    is_tty = _stdin_is_tty()

    if apm_yml_exists:
        # Re-init: seed from existing apm.yml target field
        try:
            existing_targets = _read_existing_targets(project_root)
        except (ValueError, click.UsageError) as exc:
            detail = exc.format_message() if isinstance(exc, click.ClickException) else str(exc)
            message = (
                f"Cannot carry the targets of the existing {APM_YML_FILENAME} into the new "
                f"one: {detail.strip()}"
            )
            if yes or not is_tty:
                logger.error(message)
                logger.progress(
                    INIT_TARGETS_UNDETECTED.sentence(),
                    symbol="info",
                )
                sys.exit(1)
            logger.warning(message)
            existing_targets = []
        if existing_targets:
            prechecked = set(existing_targets)
            for t in existing_targets:
                signal_hints[t] = "(from existing apm.yml)"

    if not prechecked:
        # Fresh init: seed from filesystem signals
        signals = detect_signals(project_root)
        for sig in signals:
            if sig.target not in EXPLICIT_ONLY_TARGETS:
                prechecked.add(sig.target)
                signal_hints[sig.target] = f"(detected {sig.source})"

    # Case 2: non-interactive (--yes OR non-TTY stdin -- never block CI on
    # this prompt; emit explicit provenance so users see what was chosen).
    if yes or not is_tty:
        if not yes and not is_tty:
            logger.progress(
                "Non-interactive stdin: skipping target prompt "
                "(use --yes or --target to silence this notice).",
                symbol="info",
            )
        if prechecked:
            targets = sorted(prechecked)
            sources = ", ".join(dict.fromkeys(signal_hints.get(t, "") for t in targets))
            logger.progress(
                f"Auto-detected targets: {', '.join(targets)} {sources}".rstrip(),
                symbol="info",
            )
            return targets
        # No signals, no flag -> omit targets (Tier 3 auto-detect at compile/install)
        return None

    # Case 3: interactive prompt (TTY confirmed)
    return _prompt_target_selection(prechecked, signal_hints)


def _read_existing_targets(project_root: Path) -> list[str]:
    """Return the ``targets:`` a re-init writes for the existing apm.yml.

    Routes through the declaration owner's one target rewrite mapping
    (``rewrite_target_names``): for example legacy ``target: agents`` becomes
    ``copilot``. An unreadable manifest yields no targets, since re-init
    replaces it.

    Raises:
        ValueError, click.UsageError: The declaration is invalid, a declared
            target has no ``targets:`` equivalent (``TargetRewriteError``), or
            the manifest uses a YAML anchor, alias or duplicate top-level key
            (``InvalidManifestError``).
    """
    import yaml

    from ..models.manifest_io import load_manifest
    from ..models.manifest_targets import ManifestTargetDeclaration

    apm_yml_path = manifest_file(project_root)
    try:
        data = load_manifest(apm_yml_path) if apm_yml_path.is_file() else None
    except InvalidManifestError:
        raise
    except (OSError, ValueError, yaml.YAMLError):
        return []
    return list(
        rewrite_target_names(ManifestTargetDeclaration.from_mapping(data, apm_yml_path)) or ()
    )


def _parse_toggle_input(response: str, max_n: int) -> tuple[list[int], str | None]:
    """Parse toggle input. Returns (zero-based indices, error message or None).

    Accepts:
      - single number:        ``3``
      - csv:                  ``1,3,5``
      - range:                ``1-3``
      - mixed:                ``1,3-5,7``
      - 'all' / 'none':       toggle every entry / clear every entry
    Whitespace and trailing punctuation are ignored.
    """
    response = response.strip().lower().replace(" ", "")
    if not response:
        return [], None
    if response in ("all", "none"):
        return list(range(max_n)), None
    indices: list[int] = []
    for chunk in response.split(","):
        if not chunk:
            continue
        if "-" in chunk:
            parts = chunk.split("-")
            if len(parts) != 2 or not all(p.isdigit() for p in parts):
                return [], f"Invalid range '{chunk}'. Use form 'N-M'."
            lo, hi = int(parts[0]), int(parts[1])
            if lo < 1 or hi > max_n or lo > hi:
                return [], f"Range '{chunk}' out of bounds (valid: 1-{max_n})."
            indices.extend(range(lo - 1, hi))
        else:
            if not chunk.isdigit():
                return [], f"Invalid token '{chunk}'."
            n = int(chunk)
            if n < 1 or n > max_n:
                return [], f"Number {n} out of bounds (valid: 1-{max_n})."
            indices.append(n - 1)
    return indices, None


def _prompt_target_selection(
    prechecked: set[str],
    signal_hints: dict[str, str],
) -> list[str] | None:
    """Interactive numbered-toggle target selection.

    Returns list of selected targets or None if user confirms empty selection.
    """
    targets = [t for t in _PROMPT_TARGETS_ORDERED if t not in EXPLICIT_ONLY_TARGETS]
    selected: list[bool] = [t in prechecked for t in targets]

    def _render_choices() -> str:
        lines = []
        for i, target in enumerate(targets):
            mark = "[x]" if selected[i] else "[ ]"
            hint = signal_hints.get(target, "")
            line = f"  {i + 1}. {mark} {target}"
            if hint:
                line += f"  {hint}"
            lines.append(line)
        return "\n".join(lines)

    click.echo("\nSelect targets for this project:")
    click.echo(_render_choices())

    if not any(signal_hints.values()):
        click.echo("  (no signals detected)")

    click.echo(
        f"\n{INFO}[i] Tip: select the tools your team uses. You can change this later"
        f"\n    by editing 'targets:' in apm.yml.{RESET}"
    )
    click.echo(
        f"{INFO}[i] Type a number to toggle, ranges like '1-3' or '1,3,5' for multiple,"
        f"\n    'all' / 'none' to flip every entry, or press Enter to confirm.{RESET}"
    )

    while True:
        response = click.prompt(
            f"Toggle (1-{len(targets)}, ranges, 'all'/'none', or Enter to confirm)",
            default="",
            show_default=False,
        )
        if not response.strip():
            break
        if response.strip().lower() == "done":
            break

        indices, err = _parse_toggle_input(response, len(targets))
        if err:
            click.echo(f"  {err}")
            continue
        for idx in indices:
            selected[idx] = not selected[idx]
        click.echo(_render_choices())

    chosen = [targets[i] for i in range(len(targets)) if selected[i]]

    if not chosen:
        click.echo(
            f"\n{INFO}[!] No targets selected. APM will auto-detect targets from your"
            "\n    filesystem on every compile (e.g. .github/ -> copilot)."
            f"\n    To pin targets later, list them under 'targets:' in apm.yml.{RESET}"
        )
        if click.confirm("\nContinue without pinning targets?", default=True):
            return None
        return _prompt_target_selection(prechecked, signal_hints)

    return chosen
