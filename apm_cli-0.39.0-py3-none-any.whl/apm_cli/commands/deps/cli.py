"""APM dependency management CLI commands."""

import re
import shutil
import sys
from collections.abc import Iterator
from pathlib import Path, PurePosixPath, PureWindowsPath

import click

from apm_cli.core.remediation import (
    DEPENDENCIES_NOT_INSTALLED,
    DEPENDENCY_UNPLACED,
    ORPHANED_PACKAGES_PRUNE,
)
from apm_cli.core.scope import manifest_file
from apm_cli.deps.lockfile_write_authority import LockfileWriter, lockfile_writer
from apm_cli.install.locking import serialized_lifecycle, serialized_lifecycle_unless

# Import existing APM components
from ...constants import APM_MODULES_DIR, APM_YML_FILENAME, SKILL_MD_FILENAME
from ...core.command_logger import CommandLogger
from ...core.deployment_ledger import DeploymentLedgerCodec
from ...core.deprecations import deprecation_message
from ...core.project_name import DEFAULT_BOOTSTRAP_PROJECT_NAME
from ...core.target_catalog import target_all_exclusion_help, target_help_fragment
from ...core.target_detection import TargetParamType
from ...deps.lock_parent_placement import installed_manifest_children, place_legacy_lock_parents
from ...deps.lockfile import LockedDependency, LockfileConflictError
from ...models.apm_package import APMPackage
from ...models.dependency.materialization import (
    CachedMaterializationPathReader,
    installed_package_path,
)
from ...models.manifest_io import InvalidManifestError
from ...utils.path_security import PathTraversalError
from .._helpers import (
    UnknownPackageError,
    _expand_with_ancestors,
    _inspect_installed_orphans,
    _standalone_installed_packages,
    resolve_requested_packages,
)
from ._inventory import (
    format_mcps,
    format_targets,
    package_mcp_count,
    package_targets,
    targets_legend,
)
from ._utils import (
    _count_primitives,
    _get_package_display_info,
    _is_agent_plugin_root,
    _is_nested_under_package,
    _tolerant_identity,
)
from .why import why as _why_cmd

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _format_primitive_counts(primitives):
    """Format primitive type counts into a comma-separated summary string."""
    parts = []
    for ptype, count in primitives.items():
        if count > 0:
            parts.append(f"{count} {ptype}")
    return ", ".join(parts)


_PROVIDER_SOURCE_LABELS = {"ado": "azure-devops", "gitlab": "gitlab", "generic": "git"}


def _deps_list_source_label(
    host: str | None,
    *,
    is_local: bool = False,
    lockfile_source: str | None = None,
    host_type: str | None = None,
) -> str:
    """Map a dependency's provider to the ``apm deps list`` Source column.

    Remote hosts classify through the canonical provider registry, so a
    declared or locked ``host_type`` labels a self-hosted GitLab correctly,
    and an unrecognized host is labeled ``git`` rather than ``github``.
    """
    from ...core.host_providers import classify_host_provider

    if is_local or lockfile_source == "local":
        return "local"
    if lockfile_source == "registry":
        return "registry"
    try:
        kind = classify_host_provider(host, host_type=host_type).kind if host else "github"
    except (ValueError, RuntimeError):
        kind = "github"
    return _PROVIDER_SOURCE_LABELS.get(kind, "github")


_LOCAL_HASH_SLOT_RE = re.compile(r"^(_local)/[0-9a-f]{12}/(.+)$")


def _is_absolute_local_path(path: str) -> bool:
    """True if a declared local path embeds host filesystem structure.

    Absolute POSIX paths (``/Users/...``), home-relative paths (``~/...``), and
    Windows drive/UNC paths (``C:\\...``, ``\\\\server\\share``) all leak the
    author's machine layout and must not reach user-facing output. Relative
    declared paths (``../pkg``, ``./packages/foo``) are portable and safe.
    """
    if not path:
        return False
    if path.startswith("~"):
        return True
    return PurePosixPath(path).is_absolute() or PureWindowsPath(path).is_absolute()


def _absolute_local_display(path: str, fallback: str) -> str:
    """Return a portable logical name for an absolute local dependency."""
    windows_path = PureWindowsPath(path)
    parsed_path = (
        windows_path
        if windows_path.is_absolute() or path.startswith("~\\")
        else PurePosixPath(path)
    )
    return f"_local/{parsed_path.name}" if parsed_path.name else fallback


def _logical_local_display(physical_name: str) -> str:
    """Strip the physical hash segment from an unmapped local slot.

    Orphaned local transitive slots (``_local/<12hex>/pkg``) have no lockfile
    entry, so ``physical_to_logical`` cannot resolve them. Orphan *detection*
    keeps the raw physical identity, but the name shown to the user must be the
    hash-free logical form (``_local/pkg``). Non-local names pass through.
    """
    match = _LOCAL_HASH_SLOT_RE.match(physical_name)
    if match:
        return f"{match.group(1)}/{match.group(2)}"
    return physical_name


def _dep_display_key(dep: LockedDependency) -> str:
    """Return the user-facing key that ``apm uninstall`` accepts for a locked dependency.

    Local deps render a logical, portable identity instead of the lockfile
    unique key. For anchored transitive local deps the unique key is an
    absolute ``local:/...`` slot (see build_dependency_unique_key), which would
    leak the host filesystem path into user-facing tree output. Prefer the
    declared relative ``local_path`` (``../pkg``); fall back to the logical
    ``repo_url`` (``_local/pkg``) when the path is absent or itself absolute
    (``/Users/...``, ``~/...``, ``C:\\...``). Remote deps keep their canonical
    unique key (host-qualified for non-default hosts).
    """
    if dep.source != "local":
        return dep.get_unique_key()
    if dep.local_path and not _is_absolute_local_path(dep.local_path):
        return dep.local_path
    if dep.local_path:
        return _absolute_local_display(dep.local_path, dep.repo_url)
    return dep.repo_url


def _dep_display_name(dep: LockedDependency) -> str:
    """Get display name for a locked dependency (``key@version``)."""
    key = _dep_display_key(dep)
    version = (
        dep.version
        or (dep.resolved_commit[:7] if dep.resolved_commit else None)
        or dep.resolved_ref
        or "latest"
    )
    if dep.replacement is not None:
        return (
            f"{key}@{version} -> {dep.to_dependency_ref().source_reference.to_display_reference()}"
        )
    return f"{key}@{version}"


def _walk_tree_children(
    parent_key: str,
    children_map: dict[str, list[LockedDependency]],
) -> Iterator[tuple[LockedDependency, tuple[int, ...], tuple[bool, ...], bool]]:
    """Yield dependency-tree descendants depth-first without Python recursion."""
    ancestors = frozenset({parent_key})
    children = children_map.get(parent_key, [])
    stack: list[tuple[LockedDependency, tuple[int, ...], tuple[bool, ...], frozenset[str]]] = []
    for index in range(len(children) - 1, -1, -1):
        stack.append(
            (
                children[index],
                (index,),
                (index == len(children) - 1,),
                ancestors,
            )
        )

    while stack:
        child_dep, path, last_flags, parent_ancestors = stack.pop()
        child_key = child_dep.get_unique_key()
        is_circular = child_key in parent_ancestors
        yield child_dep, path, last_flags, is_circular
        if is_circular:
            continue

        child_ancestors = parent_ancestors | {child_key}
        grandchildren = children_map.get(child_key, [])
        for index in range(len(grandchildren) - 1, -1, -1):
            stack.append(
                (
                    grandchildren[index],
                    (*path, index),
                    (*last_flags, index == len(grandchildren) - 1),
                    child_ancestors,
                )
            )


def _add_tree_children(
    parent_branch,
    parent_key: str,
    children_map: dict[str, list[LockedDependency]],
) -> None:
    """Add every transitive dependency to a Rich tree without a depth limit."""
    branches = {(): parent_branch}
    for child_dep, path, _, is_circular in _walk_tree_children(parent_key, children_map):
        child_name = _dep_display_name(child_dep)
        suffix = " (circular)" if is_circular else ""
        child_branch = branches[path[:-1]].add(f"[dim]{child_name}{suffix}[/dim]")
        if not is_circular:
            branches[path] = child_branch


def _echo_tree_children(
    parent_key: str,
    children_map: dict[str, list[LockedDependency]],
    prefix: str = "",
) -> None:
    """Render every transitive dependency without Rich or a depth limit."""
    for child_dep, _, last_flags, is_circular in _walk_tree_children(parent_key, children_map):
        indentation = "".join("    " if is_last else "|   " for is_last in last_flags[:-1])
        child_prefix = "+-- " if last_flags[-1] else "|-- "
        suffix = " (circular)" if is_circular else ""
        click.echo(f"{prefix}{indentation}{child_prefix}{_dep_display_name(child_dep)}{suffix}")


# ---------------------------------------------------------------------------
# Data resolution — deps list
# ---------------------------------------------------------------------------


def _resolve_scope_deps(apm_dir, logger, insecure_only=False, scope="project"):
    """Resolve installed packages and orphan status for a single scope.

    Returns ``(installed_packages, orphaned_packages)`` where
    *installed_packages* is a list of dicts and *orphaned_packages* is a
    list of name strings, or ``(None, None)`` when no ``apm_modules``
    directory exists. *scope* (``"project"`` or ``"user"``) selects which
    recorded deployment rows feed each package's Targets column.
    """
    from ...deps.lockfile import LockFile, get_lockfile_path

    apm_modules_path = apm_dir / APM_MODULES_DIR
    insecure_lock_deps = {}

    # Check if apm_modules exists
    if not apm_modules_path.exists():
        return None, None

    # Load project dependencies to check for orphaned packages
    # GitHub: owner/repo or owner/virtual-pkg-name (2 levels)
    # Azure DevOps: org/project/repo or org/project/virtual-pkg-name (3 levels)
    declared_sources = {}  # dep_path -> 'github' | 'gitlab' | 'azure-devops' | 'local'
    physical_to_logical: dict[str, str] = {}
    # Host-blind logical key -> the identity ``apm deps tree`` and uninstall use.
    display_keys: dict[str, str] = {}
    declared_deps = []
    # materialized package path (relative to apm_modules) -> its exact lockfile
    # key, the owner string ledger rows use; host-aware, so aliased packages that
    # share an owner/repo on different hosts stay distinct
    owner_by_path: dict[str, str] = {}
    inventory_lockfile = None
    try:
        apm_yml_path = manifest_file(apm_dir)
        if apm_yml_path.exists():
            project_package = APMPackage.from_apm_yml(apm_yml_path)
            declared_deps = project_package.get_all_apm_dependencies()
            for dep in project_package.get_apm_dependencies():
                # Build the expected installed package name
                repo_parts = dep.repo_url.split("/")
                source = _deps_list_source_label(
                    dep.host,
                    is_local=dep.is_local,
                    lockfile_source=dep.source,
                    host_type=dep.host_type,
                )
                if dep.alias is not None:
                    install_path = dep.get_install_path(apm_modules_path)
                    physical_key = install_path.relative_to(apm_modules_path).as_posix()
                    # An aliased slot keeps host and port in its row (B4, #3967).
                    dep_key = dep.get_unique_key()
                    physical_to_logical[physical_key] = dep_key
                    declared_sources[dep_key] = source
                    continue
                is_ado = dep.is_azure_devops() and len(repo_parts) >= 3
                is_gh = len(repo_parts) >= 2

                if not dep.is_virtual:
                    # Regular package: use full repo_url path
                    if is_ado:
                        declared_sources[f"{repo_parts[0]}/{repo_parts[1]}/{repo_parts[2]}"] = (
                            source
                        )
                    elif is_gh:
                        declared_sources[f"{repo_parts[0]}/{repo_parts[1]}"] = source
                    continue

                if dep.is_virtual_subdirectory() and dep.virtual_path:
                    # Virtual subdirectory packages keep natural path structure.
                    if is_ado:
                        declared_sources[
                            f"{repo_parts[0]}/{repo_parts[1]}/{repo_parts[2]}/{dep.virtual_path}"
                        ] = source
                    elif is_gh:
                        declared_sources[f"{repo_parts[0]}/{repo_parts[1]}/{dep.virtual_path}"] = (
                            source
                        )
                    continue

                # Virtual file/collection packages are flattened.
                package_name = dep.get_virtual_package_name()
                if is_ado:
                    declared_sources[f"{repo_parts[0]}/{repo_parts[1]}/{package_name}"] = source
                elif is_gh:
                    declared_sources[f"{repo_parts[0]}/{package_name}"] = source
    except (PathTraversalError, InvalidManifestError):
        raise
    except Exception:
        pass  # Continue without orphan detection if apm.yml parsing fails

    # Also load lockfile deps to avoid false orphan flags on transitive deps.
    # Local transitive deps are installed into hashed physical slots
    # (``_local/<hash>/pkg``) to prevent sibling collisions (#2155), but their
    # logical identity is the un-hashed lockfile ``repo_url`` (``_local/pkg``).
    # Key orphan/insecure state on the logical id and remember each physical
    # slot -> logical id so the scan below can report the logical name instead
    # of leaking the hash slot into user-facing output.
    try:
        lockfile_path = get_lockfile_path(apm_dir)
        if lockfile_path.exists():
            lockfile = LockFile.read(lockfile_path)
            inventory_lockfile = lockfile
            reader = CachedMaterializationPathReader()
            for dep in lockfile.get_package_dependencies():
                owner_key = dep.get_unique_key()
                try:
                    installed = installed_package_path(
                        dep.to_dependency_ref(), apm_modules_path, reader=reader
                    )
                    owner_by_path[installed.relative_to(apm_modules_path).as_posix()] = owner_key
                except (ValueError, OSError):
                    # Read-only Targets lookup only: an entry whose path cannot be
                    # resolved gets no owner (its Targets read ``unknown``) and
                    # must not disturb the bookkeeping below or other packages.
                    pass
                # Local slots and explicit aliases retain their logical lockfile identity.
                if dep.source == "local" or dep.alias is not None or dep.replacement is not None:
                    install_path = dep.to_dependency_ref().get_install_path(apm_modules_path)
                    physical_key = install_path.relative_to(apm_modules_path).as_posix()
                    # An aliased slot keeps host and port in its row (B4, #3967).
                    dep_key = dep.repo_url if dep.source == "local" else dep.get_unique_key()
                    physical_to_logical[physical_key] = dep_key
                else:
                    dep_key = dep.get_canonical_dependency_string()
                if dep_key and dep_key not in declared_sources:
                    declared_sources[dep_key] = _deps_list_source_label(
                        dep.host, lockfile_source=dep.source, host_type=dep.host_type
                    )
                if dep.source != "local":
                    display_keys[dep_key] = _dep_display_key(dep)
                if dep.replacement is not None:
                    selected = dep.to_dependency_ref()
                    declared_sources[dep_key] = _deps_list_source_label(
                        selected.host,
                        is_local=selected.is_local,
                        lockfile_source=selected.source,
                        host_type=selected.host_type,
                    )
                if getattr(dep, "is_insecure", False):
                    insecure_lock_deps[dep_key] = dep
    except (PathTraversalError, LockfileConflictError):
        raise
    except Exception:
        pass  # Continue without lockfile if it can't be read

    # Scan for installed packages in org-namespaced structure
    # Walks the tree to find directories containing apm.yml or SKILL.md,
    # handling GitHub (2-level), ADO (3-level), and subdirectory (4+ level) packages.
    # First pass: collect valid candidate paths for ancestor-aware orphan check.
    scanned_candidates = []
    for candidate in apm_modules_path.rglob("*"):
        if candidate.is_symlink() or not candidate.is_dir():
            continue
        if candidate.name.startswith(".") and candidate.parent != apm_modules_path:
            continue
        has_apm_yml = manifest_file(candidate).exists()
        has_skill_md = (candidate / SKILL_MD_FILENAME).exists()
        # A canonical Agent Plugin root is a package even though it carries
        # neither apm.yml nor a root SKILL.md -- it is installed as one unit.
        has_plugin_manifest = _is_agent_plugin_root(candidate)
        if not has_apm_yml and not has_skill_md and not has_plugin_manifest:
            continue
        rel_parts = candidate.relative_to(apm_modules_path).parts
        if len(rel_parts) < 2 and "/".join(rel_parts) not in physical_to_logical:
            continue
        # Skip sub-skills inside .apm/ directories -- they belong to the parent package
        if ".apm" in rel_parts:
            continue

        # Nested manifests are deployment artifacts owned by the parent package.
        if _is_nested_under_package(candidate, apm_modules_path):
            continue
        scanned_candidates.append((candidate, "/".join(rel_parts), has_apm_yml, has_skill_md))

    # Precompute expected paths + ancestors for O(1) orphan checks.
    # Mirror prune.py / _check_orphaned_packages: pass the standalone
    # installed paths (lockfile-membership + apm.yml fallback) so a
    # genuinely orphaned ``owner/repo`` package is not masked when a
    # sibling subdirectory dep shares the same install root.
    try:
        try:
            lockfile_path_for_check = get_lockfile_path(apm_dir)
            lockfile_for_check = (
                LockFile.read(lockfile_path_for_check) if lockfile_path_for_check.exists() else None
            )
        except Exception:
            lockfile_for_check = None
        scanned_names = [name for _c, name, _h, _s in scanned_candidates]
        standalone_installed_for_check = _standalone_installed_packages(
            scanned_names, apm_modules_path, lockfile=lockfile_for_check
        )
    except Exception:
        standalone_installed_for_check = []
    declared_with_ancestors = _expand_with_ancestors(
        declared_sources.keys(), standalone_installed_for_check
    )
    # Content bundled inside an expected install path belongs to that package,
    # exactly as prune keeps it (#2926), so the shared selector decides it. The
    # stricter warning for a real package above a declared subdirectory stays,
    # at every depth (unlike the depth-capped suppression set above).
    try:
        inspection = _inspect_installed_orphans(
            declared_deps,
            lockfile_for_check,
            apm_modules_path,
            [name for _c, name, _h, _s in scanned_candidates],
        )
        expected_paths = inspection.expected_paths
        selected_orphans = set(inspection.removed_paths)
        expected_ancestors = {
            "/".join(parts[:depth])
            for parts in (path.replace("\\", "/").split("/") for path in expected_paths)
            for depth in range(1, len(parts))
        }
    except PathTraversalError:
        raise
    except Exception:
        selected_orphans, expected_ancestors = None, set()

    # Scope-filtered owner -> records, built once so each package row is a lookup.
    owner_index = (
        DeploymentLedgerCodec.recorded_owner_index(inventory_lockfile, scope=scope)
        if inventory_lockfile is not None
        else None
    )
    installed_packages = []
    orphaned_packages = []
    for candidate, org_repo_name, has_apm_yml, _has_skill_md in scanned_candidates:
        # Local transitive deps are scanned at their physical hash slot
        # (``_local/<hash>/pkg``); report and orphan-check against the
        # logical lockfile key (``_local/pkg``) instead of leaking the slot.
        # A genuinely orphaned slot has no lockfile entry, so it stays keyed by
        # its raw physical identity for correct detection. Only confirmed
        # orphans have their physical hash redacted; declared remote identities
        # that happen to match the slot shape remain unchanged.
        logical_name = physical_to_logical.get(org_repo_name, org_repo_name)
        is_orphaned = logical_name not in declared_with_ancestors and (
            selected_orphans is None
            or org_repo_name in selected_orphans
            or org_repo_name in expected_ancestors
        )
        display_name = (
            _logical_local_display(logical_name)
            if is_orphaned
            else display_keys.get(logical_name, logical_name)
        )
        try:
            version = "unknown"
            if has_apm_yml:
                identity = _tolerant_identity(candidate, manifest_file(candidate))
                if identity is None:
                    raise ValueError("unreadable package manifest")
                version = identity["version"]
            else:
                version = _agent_plugin_version(candidate) or version
            primitives = _count_primitives(candidate)
            mcps = package_mcp_count(candidate)
            # None when there is nothing to read: no recorded evidence, or the
            # package is not in the lockfile.
            owner = owner_by_path.get(org_repo_name)
            owned_records = (
                None if owner_index is None or owner is None else owner_index.get(owner, ())
            )

            if is_orphaned:
                orphaned_packages.append(display_name)

            locked_dep = insecure_lock_deps.get(logical_name)
            installed_packages.append(
                {
                    "name": display_name,
                    "version": version,
                    "source": "orphaned"
                    if is_orphaned
                    else declared_sources.get(logical_name, "github"),
                    "primitives": primitives,
                    "recorded_targets": package_targets(
                        owned_records,
                        mcp_count=mcps.count,
                        has_lsp=mcps.has_lsp,
                        has_primitives=mcps.has_other_content or any(primitives.values()),
                    ),
                    "mcps": mcps,
                    "path": str(candidate),
                    "is_orphaned": is_orphaned,
                    "is_insecure": locked_dep is not None,
                    "insecure_via": (
                        f"via {locked_dep.resolved_by}"
                        if locked_dep and locked_dep.resolved_by
                        else "direct"
                    ),
                }
            )
        except Exception:
            # The raised error (e.g. malformed-YAML ValueError) embeds the
            # absolute apm.yml path; never forward it. Emit a stable, actionable
            # public warning keyed on the hash-free display name.
            logger.warning(
                f"Failed to inspect package {display_name}. Check its package files and rerun."
            )

    if insecure_only:
        installed_packages = [pkg for pkg in installed_packages if pkg["is_insecure"]]

    return installed_packages, sorted(orphaned_packages)


@click.group(help="Manage APM package dependencies")
def deps():
    """APM dependency management commands."""
    pass


deps.add_command(_why_cmd)


def _agent_plugin_version(candidate) -> str | None:
    """Return the declared version of a canonical Agent Plugin root."""
    from ...agent_plugins.errors import AgentPluginError
    from ...bundle.local_bundle import route_agent_plugin_package

    try:
        detection = route_agent_plugin_package(candidate)
    except (AgentPluginError, OSError):
        return None
    if detection is None or detection.plugin is None:
        return None
    return detection.plugin.identity.version


def _report_native_plugins(apm_dir, logger) -> None:
    """Report the plugins APM activates natively, from apm.lock.yaml."""
    from pathlib import Path

    from ...deps.lockfile import LockFile, LockfileFormatError, get_lockfile_path
    from ...native_plugins.record import lock_native_plugins

    try:
        lockfile = LockFile.read(get_lockfile_path(Path(apm_dir)))
    except (LockfileFormatError, OSError):
        return
    names = sorted(record.name for record in lock_native_plugins(lockfile).values())
    if not names:
        return
    shown = ", ".join(names[:3])
    if len(names) > 3:
        shown += f", and {len(names) - 3} more"
    logger.info(
        f"{len(names)} native plugin(s) activated from .agents/plugins: {shown}",
        symbol="info",
    )
    if len(names) > 3:
        logger.verbose_detail(f"    plugins: {', '.join(names)}")


def _show_scope_deps(scope_label, apm_dir, logger, console, has_rich, insecure_only=False):
    """Display dependencies for a single scope (Project or Global)."""
    scope = "user" if scope_label == "Global" else "project"
    installed_packages, orphaned_packages = _resolve_scope_deps(
        apm_dir, logger, insecure_only, scope=scope
    )

    if installed_packages is None:
        logger.progress(f"No APM dependencies installed ({scope_label} scope)")
        logger.verbose_detail(DEPENDENCIES_NOT_INSTALLED.sentence())
        return

    if not installed_packages:
        if insecure_only:
            logger.progress(f"No insecure APM dependencies installed ({scope_label} scope)")
        else:
            logger.progress(
                f"apm_modules/ directory exists but contains no valid packages ({scope_label} scope)"
            )
        _report_native_plugins(apm_dir, logger)
        return

    # Display packages in table format
    if has_rich:
        from apm_cli.utils.console import new_table

        table = new_table(
            title=(
                f" Insecure APM Dependencies ({scope_label})"
                if insecure_only
                else f" APM Dependencies ({scope_label})"
            ),
            show_header=True,
            header_style="bold cyan",
        )
        table.add_column(
            "Package",
            style="bold white",
            overflow="fold",
            min_width=max(len(pkg["name"]) for pkg in installed_packages),
        )
        table.add_column("Version", style="yellow")
        table.add_column("Source", style="blue")
        if insecure_only:
            table.add_column("Origin", style="bold red")
        table.add_column("Prompts", style="magenta", justify="center")
        table.add_column("Instructions", style="green", justify="center")
        table.add_column("Agents", style="cyan", justify="center")
        table.add_column("Skills", style="yellow", justify="center")
        table.add_column("Hooks", style="red", justify="center")
        table.add_column("MCPs", style="blue", justify="center")
        table.add_column("Targets", style="green")

        for pkg in installed_packages:
            p = pkg["primitives"]
            table.add_row(
                pkg["name"],
                pkg["version"],
                pkg["source"],
                *([pkg["insecure_via"]] if insecure_only else []),
                str(p.get("prompts", 0)) if p.get("prompts", 0) > 0 else "-",
                str(p.get("instructions", 0)) if p.get("instructions", 0) > 0 else "-",
                str(p.get("agents", 0)) if p.get("agents", 0) > 0 else "-",
                str(p.get("skills", 0)) if p.get("skills", 0) > 0 else "-",
                str(p.get("hooks", 0)) if p.get("hooks", 0) > 0 else "-",
                format_mcps(pkg.get("mcps")),
                format_targets(pkg.get("recorded_targets")),
            )

        # Expand only when the table needs more room for its contents.
        measured_width = console.measure(table, options=console.options.update_width(sys.maxsize))
        console.print(table, width=max(console.width, measured_width.maximum), crop=False)
        legend = targets_legend(pkg.get("recorded_targets") for pkg in installed_packages)
        if legend:
            console.print(legend, style="dim", markup=False, highlight=False)

        # Show orphaned packages warning -- routed through CommandLogger
        # so output goes through the central STATUS_SYMBOLS prefix path
        # (no raw `[!]` literal that Rich would parse as markup) and so
        # behaviour is consistent with prune.py.
        if orphaned_packages:
            logger.warning(
                f"{len(orphaned_packages)} orphaned package(s) found "
                "(not in resolved dependency graph):"
            )
            for pkg in orphaned_packages:
                logger.warning(f"  - {pkg}")
            logger.info(ORPHANED_PACKAGES_PRUNE.sentence())
    else:
        # Fallback text table
        if insecure_only:
            click.echo(f" Insecure APM Dependencies ({scope_label}):")
            header = (
                f"{'Package':<30} {'Version':<10} {'Source':<12} {'Origin':<18} "
                f"{'Prompts':>7} {'Instr':>7} {'Agents':>7} {'Skills':>7} {'Hooks':>7} "
                f"{'MCPs':>4} Targets"
            )
            click.echo(header)
            click.echo("-" * len(header))
        else:
            click.echo(f" APM Dependencies ({scope_label}):")
            header = (
                f"{'Package':<30} {'Version':<10} {'Source':<12} {'Prompts':>7} {'Instr':>7} "
                f"{'Agents':>7} {'Skills':>7} {'Hooks':>7} {'MCPs':>4} Targets"
            )
            click.echo(header)
            click.echo("-" * len(header))

        for pkg in installed_packages:
            p = pkg["primitives"]
            name = pkg["name"][:28]
            version = pkg["version"][:8]
            source = pkg["source"][:10]
            insecure_via = pkg["insecure_via"][:16]
            prompts = str(p.get("prompts", 0)) if p.get("prompts", 0) > 0 else "-"
            instructions = str(p.get("instructions", 0)) if p.get("instructions", 0) > 0 else "-"
            agents = str(p.get("agents", 0)) if p.get("agents", 0) > 0 else "-"
            skills = str(p.get("skills", 0)) if p.get("skills", 0) > 0 else "-"
            hooks = str(p.get("hooks", 0)) if p.get("hooks", 0) > 0 else "-"
            mcps = format_mcps(pkg.get("mcps"))
            targets = format_targets(pkg.get("recorded_targets"))
            if insecure_only:
                click.echo(
                    f"{name:<30} {version:<10} {source:<12} {insecure_via:<18} "
                    f"{prompts:>7} {instructions:>7} {agents:>7} {skills:>7} {hooks:>7} "
                    f"{mcps:>4} {targets}"
                )
            else:
                click.echo(
                    f"{name:<30} {version:<10} {source:<12} {prompts:>7} {instructions:>7} "
                    f"{agents:>7} {skills:>7} {hooks:>7} {mcps:>4} {targets}"
                )
        legend = targets_legend(pkg.get("recorded_targets") for pkg in installed_packages)
        if legend:
            click.echo(legend)

        # Show orphaned packages warning -- route through CommandLogger
        # for consistency with the rich branch above and with prune.py.
        if orphaned_packages:
            logger.warning(
                f"{len(orphaned_packages)} orphaned package(s) found "
                "(not in resolved dependency graph):"
            )
            for pkg in orphaned_packages:
                logger.warning(f"  - {pkg}")
            logger.info(ORPHANED_PACKAGES_PRUNE.sentence())

    _report_native_plugins(apm_dir, logger)


@deps.command(name="list", help="List installed APM dependencies and their primitives")
@click.option(
    "--global",
    "-g",
    "global_",
    is_flag=True,
    default=False,
    help="List dependencies in the APM user home instead of the project",
)
@click.option(
    "--all",
    "show_all",
    is_flag=True,
    default=False,
    help="Show both project and user-scope dependencies",
)
@click.option(
    "--insecure",
    "insecure_only",
    is_flag=True,
    default=False,
    help="Show only installed dependencies locked to http:// sources",
)
def list_packages(global_, show_all, insecure_only):
    """Show all installed APM dependencies with context files and agent workflows."""
    logger = CommandLogger("deps-list")

    try:
        # Import Rich components with fallback
        import shutil

        from apm_cli.utils.console import new_console

        term_width = shutil.get_terminal_size((120, 24)).columns
        console = new_console(width=max(120, term_width))
        has_rich = True
    except ImportError:
        has_rich = False
        console = None

    try:
        from ...core.scope import InstallScope, get_apm_dir

        if show_all:
            # Show both scopes
            _show_scope_deps(
                "Project",
                get_apm_dir(InstallScope.PROJECT),
                logger,
                console,
                has_rich,
                insecure_only=insecure_only,
            )
            if console and has_rich:
                console.print()  # spacing between tables
            _show_scope_deps(
                "Global",
                get_apm_dir(InstallScope.USER),
                logger,
                console,
                has_rich,
                insecure_only=insecure_only,
            )
        elif global_:
            _show_scope_deps(
                "Global",
                get_apm_dir(InstallScope.USER),
                logger,
                console,
                has_rich,
                insecure_only=insecure_only,
            )
        else:
            _show_scope_deps(
                "Project",
                get_apm_dir(InstallScope.PROJECT),
                logger,
                console,
                has_rich,
                insecure_only=insecure_only,
            )
    except Exception as e:
        logger.error(f"Error listing dependencies: {e}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Data resolution — deps tree
# ---------------------------------------------------------------------------


def _build_dep_tree(apm_dir):
    """Build dependency tree data from lockfile or directory scan.

    Returns a dict describing the tree structure::

        {
            'project_name': str,
            'apm_modules_path': Path,
            'source': 'lockfile' | 'directory',
            'direct': [dep, ...],           # lockfile mode only
            'children_map': {unique_key: [dep]},  # lockfile mode only
            'unresolved': [dep, ...],       # lockfile mode only
            'scanned_packages': [{...}],    # directory fallback only
            'has_modules': bool,
        }
    """
    apm_modules_path = apm_dir / APM_MODULES_DIR

    # Load project info
    project_name = DEFAULT_BOOTSTRAP_PROJECT_NAME
    try:
        apm_yml_path = manifest_file(apm_dir)
        if apm_yml_path.exists():
            root_package = APMPackage.from_apm_yml(apm_yml_path)
            project_name = root_package.name
    except Exception:
        pass

    result = {
        "project_name": project_name,
        "apm_modules_path": apm_modules_path,
        "source": "directory",
        "direct": [],
        "children_map": {},
        "unresolved": [],
        "scanned_packages": [],
        "has_modules": apm_modules_path.exists(),
    }

    # Try to load lockfile for accurate tree with depth/parent info
    try:
        from ...deps.lockfile import LockFile, get_lockfile_path

        lockfile_path = get_lockfile_path(apm_dir)
        if lockfile_path.exists():
            lockfile = LockFile.read(lockfile_path)
            if lockfile:
                lockfile_deps = lockfile.get_package_dependencies()
                if lockfile_deps:
                    result["source"] = "lockfile"
                    if lockfile.replacements is not None:
                        result["direct"] = [dep for dep in lockfile_deps if None in dep.parent_keys]
                        children_map: dict[str, list[LockedDependency]] = {}
                        unresolved_by_key: dict[str, LockedDependency] = {}
                        for dep in lockfile_deps:
                            for parent in dep.parent_keys:
                                if parent is None:
                                    continue
                                if parent not in lockfile.dependencies:
                                    unresolved_by_key[dep.get_unique_key()] = dep
                                    continue
                                children_map.setdefault(parent, []).append(dep)
                        result["children_map"] = children_map
                        result["unresolved"] = list(unresolved_by_key.values())
                        return result
                    result["direct"] = [d for d in lockfile_deps if d.depth <= 1]
                    placement = place_legacy_lock_parents(
                        lockfile_deps, installed_manifest_children(apm_modules_path)
                    )
                    children_map = {}
                    for dep in lockfile_deps:
                        parent = placement.parents.get(dep.get_unique_key())
                        if parent is not None:
                            children_map.setdefault(parent.get_unique_key(), []).append(dep)
                    result["children_map"] = children_map
                    result["unresolved"] = list(placement.unresolved)
                    return result
    except LockfileConflictError:
        raise
    except Exception:
        pass

    # Fallback: scan apm_modules directory (no lockfile)
    if not apm_modules_path.exists():
        return result

    scanned = []
    for candidate in sorted(apm_modules_path.rglob("*")):
        if not candidate.is_dir() or candidate.name.startswith("."):
            continue
        has_apm = manifest_file(candidate).exists()
        has_skill = (candidate / SKILL_MD_FILENAME).exists()
        if not has_apm and not has_skill:
            continue
        rel_parts = candidate.relative_to(apm_modules_path).parts
        if len(rel_parts) < 2:
            continue
        if ".apm" in rel_parts:
            continue
        if _is_nested_under_package(candidate, apm_modules_path):
            continue
        info = _get_package_display_info(candidate)
        primitives = _count_primitives(candidate)
        scanned.append(
            {
                "display_name": info["display_name"],
                "primitives": primitives,
            }
        )
    result["scanned_packages"] = scanned
    return result


@deps.command(help="Show the full dependency tree")
@click.option(
    "--global",
    "-g",
    "global_",
    is_flag=True,
    default=False,
    help="Show the dependency tree in the APM user home",
)
def tree(global_):
    """Display dependencies in hierarchical tree format using lockfile."""
    logger = CommandLogger("deps-tree")

    try:
        # Import Rich components with fallback
        from rich.tree import Tree

        from apm_cli.utils.console import new_console

        console = new_console()
        has_rich = True
    except ImportError:
        has_rich = False
        console = None

    try:
        from ...core.scope import InstallScope, get_apm_dir

        scope = InstallScope.USER if global_ else InstallScope.PROJECT
        apm_dir = get_apm_dir(scope)

        tree_data = _build_dep_tree(apm_dir)
        project_name = tree_data["project_name"]
        apm_modules_path = tree_data["apm_modules_path"]

        if tree_data["source"] == "lockfile":
            direct = tree_data["direct"]
            children_map = tree_data["children_map"]
            unresolved = tree_data.get("unresolved", [])

            if has_rich:
                root_tree = Tree(f"[bold cyan]{project_name}[/bold cyan] (local)")
                if not direct:
                    root_tree.add("[dim]No dependencies installed[/dim]")
                else:
                    for dep in direct:
                        display = _dep_display_name(dep)
                        install_key = dep.get_unique_key()
                        install_path = apm_modules_path / install_key
                        branch = root_tree.add(f"[green]{display}[/green]")
                        if install_path.exists():
                            prim_summary = _format_primitive_counts(_count_primitives(install_path))
                            if prim_summary:
                                branch.add(f"[dim]{prim_summary}[/dim]")
                        _add_tree_children(branch, dep.get_unique_key(), children_map)
                    for dep in unresolved:
                        display = _dep_display_name(dep)
                        branch = root_tree.add(
                            f"[yellow]{display} (could not place in tree; "
                            f"{DEPENDENCY_UNPLACED.clause()})[/yellow]"
                        )
                        _add_tree_children(branch, dep.get_unique_key(), children_map)
                console.print(root_tree)
            else:
                click.echo(f"{project_name} (local)")
                if not direct:
                    click.echo("+-- No dependencies installed")
                else:
                    for i, dep in enumerate(direct):
                        is_last = i == len(direct) - 1 and not unresolved
                        prefix = "+-- " if is_last else "|-- "
                        display = _dep_display_name(dep)
                        click.echo(f"{prefix}{display}")
                        sub_prefix = "    " if is_last else "|   "
                        _echo_tree_children(dep.get_unique_key(), children_map, sub_prefix)
                    for i, dep in enumerate(unresolved):
                        is_last = i == len(unresolved) - 1
                        prefix = "+-- " if is_last else "|-- "
                        click.echo(
                            f"{prefix}{_dep_display_name(dep)} "
                            "(could not place in tree; "
                            f"{DEPENDENCY_UNPLACED.clause()})"
                        )
                        sub_prefix = "    " if is_last else "|   "
                        _echo_tree_children(dep.get_unique_key(), children_map, sub_prefix)
        # Fallback: scan apm_modules directory (no lockfile)
        elif has_rich:
            root_tree = Tree(f"[bold cyan]{project_name}[/bold cyan] (local)")
            if not tree_data["has_modules"]:
                root_tree.add("[dim]No dependencies installed[/dim]")
            else:
                for pkg in tree_data["scanned_packages"]:
                    branch = root_tree.add(f"[green]{pkg['display_name']}[/green]")
                    prim_summary = _format_primitive_counts(pkg["primitives"])
                    if prim_summary:
                        branch.add(f"[dim]{prim_summary}[/dim]")
            console.print(root_tree)
        else:
            click.echo(f"{project_name} (local)")
            if not tree_data["has_modules"]:
                click.echo("+-- No dependencies installed")

    except Exception as e:
        logger.error(f"Error showing dependency tree: {e}")
        sys.exit(1)


@deps.command(help="Remove all APM dependencies")
@click.option(
    "--dry-run", is_flag=True, default=False, help="Show what would be removed without removing"
)
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt")
@serialized_lifecycle_unless("dry_run")
def clean(dry_run: bool, yes: bool):
    """Remove entire apm_modules/ directory."""
    logger = CommandLogger("deps-clean")

    project_root = Path(".")
    apm_modules_path = project_root / APM_MODULES_DIR

    if not apm_modules_path.exists():
        logger.progress("No apm_modules/ directory found - already clean")
        return

    # Count actual installed packages (not just top-level dirs like org namespaces or _local)
    from ._utils import _scan_installed_packages

    packages = _scan_installed_packages(apm_modules_path)
    package_count = len(packages)

    if dry_run:
        logger.progress(f"Dry run: would remove apm_modules/ ({package_count} package(s))")
        for pkg in sorted(packages):
            logger.progress(f"  - {pkg}")
        return

    logger.warning(
        f"This will remove the entire apm_modules/ directory ({package_count} package(s))"
    )

    # Confirmation prompt (skip if --yes provided)
    if not yes:
        try:
            from rich.prompt import Confirm

            confirm = Confirm.ask("Continue?")
        except ImportError:
            confirm = click.confirm("Continue?")

        if not confirm:
            logger.progress("Operation cancelled")
            return

    try:
        from ...utils.realpath_win import release_held

        release_held(apm_modules_path)
        shutil.rmtree(apm_modules_path)
        logger.success("Successfully removed apm_modules/ directory")
    except Exception as e:
        logger.error(f"Error removing apm_modules/: {e}")
        sys.exit(1)


@deps.command(
    help="DEPRECATED: use 'apm update' instead (strict superset). Update APM dependencies to latest refs"
)
@click.argument("packages", nargs=-1)
@click.option("--verbose", "-v", is_flag=True, help="Show detailed update information")
@click.option(
    "--force",
    is_flag=True,
    help="Overwrite locally-authored files on collision",
)
@click.option(
    "--target",
    "-t",
    type=TargetParamType(),
    default=None,
    help=(
        f"Target platform (comma-separated). {target_help_fragment('update')} "
        "'agent-skills' deploys to .agents/skills/ (cross-client). "
        "'antigravity' (alias 'agy') deploys to .agents/ and is explicit-only -- not part of 'all'. "
        f"{target_all_exclusion_help()}; "
        "combine explicit-only targets when needed. "
        "Experimental targets require their feature flags. "
        "Deprecated: run 'apm update --target' instead."
    ),
)
@click.option(
    "--parallel-downloads",
    type=int,
    default=4,
    show_default=True,
    help="Max concurrent package downloads (0 to disable parallelism)",
)
@click.option(
    "--global",
    "-g",
    "global_",
    is_flag=True,
    default=False,
    help="Update dependencies in the APM user home",
)
@click.option(
    "--legacy-skill-paths",
    "legacy_skill_paths",
    is_flag=True,
    default=False,
    help=(
        "Deploy skill files to per-client paths (e.g. .cursor/skills/) instead of "
        "the shared .agents/skills/ directory. Compatibility flag for projects that "
        "need per-client skill layouts."
    ),
)
@serialized_lifecycle
@lockfile_writer(LockfileWriter.UPDATE)
def update(packages, verbose, force, target, parallel_downloads, global_, legacy_skill_paths):
    """Update APM dependencies to latest git refs.

    Re-resolves git references (branches/tags) to their current SHAs,
    downloads updated content, re-integrates primitives, and regenerates
    the lockfile.

    \b
    Examples:
        apm deps update                    # Update all packages
        apm deps update org/repo           # Update one package
        apm deps update org/a org/b        # Update specific packages
        apm deps update --verbose          # Show detailed progress
    """
    from ...core.auth import AuthResolver
    from ...core.command_logger import InstallLogger
    from ...utils.console import _rich_warning
    from ..install import (
        _APM_IMPORT_ERROR,
        APM_DEPS_AVAILABLE,
        _install_apm_dependencies,
    )

    # Soft-deprecation (issue #1525): `apm update` is now a strict superset
    # of this command. Kept working for one release; removed in the next
    # breaking release.
    _rich_warning(deprecation_message("deps-update"), symbol="warning")

    logger = InstallLogger(verbose=verbose, partial=bool(packages))

    if not APM_DEPS_AVAILABLE:
        logger.error("APM dependency system not available")
        if _APM_IMPORT_ERROR:
            logger.progress(f"Import error: {_APM_IMPORT_ERROR}")
        sys.exit(1)

    from ...core.scope import InstallScope, get_apm_dir

    scope = InstallScope.USER if global_ else InstallScope.PROJECT
    project_root = get_apm_dir(scope)
    from ...deps.lockfile_generator import require_current_cli

    require_current_cli(project_root, command="apm deps update")
    apm_yml_path = manifest_file(project_root)

    if not apm_yml_path.exists():
        scope_hint = str(project_root) if global_ else "current directory"
        logger.error(f"No {APM_YML_FILENAME} found in {scope_hint}")
        sys.exit(1)

    try:
        apm_package = APMPackage.from_apm_yml(apm_yml_path)
    except Exception as e:
        logger.error(f"Failed to parse {APM_YML_FILENAME}: {e}")
        sys.exit(1)

    all_deps = apm_package.get_apm_dependencies() + apm_package.get_dev_apm_dependencies()
    if not all_deps:
        logger.progress("No APM dependencies defined in apm.yml")
        return

    # Validate and normalize requested packages to canonical dependency keys.
    # Shared with `apm update` (see commands/_helpers.py) so the two update
    # surfaces resolve short names identically.
    try:
        only_pkgs = resolve_requested_packages(packages, all_deps)
    except UnknownPackageError as e:
        logger.error(f"Package '{e.token}' not found in {APM_YML_FILENAME}")
        logger.progress(f"Available: {', '.join(e.available)}")
        sys.exit(1)

    # Migrate legacy lockfile first, then snapshot SHAs for before/after diff
    from ...deps.lockfile import LockFile, get_lockfile_path, migrate_lockfile_if_needed

    lockfile_path = get_lockfile_path(project_root)
    migrate_lockfile_if_needed(project_root)

    old_lockfile = LockFile.read(lockfile_path)
    had_baseline = old_lockfile is not None
    old_shas: dict = {}
    if old_lockfile:
        for key, dep in old_lockfile.dependencies.items():
            old_shas[key] = dep.resolved_commit

    auth_resolver = AuthResolver()

    noun = f"{len(packages)} package(s)" if packages else f"all {len(all_deps)} dependencies"
    # Resolve --legacy-skill-paths: CLI flag wins, then env var fallback.
    if not legacy_skill_paths:
        from ...integration.targets import should_use_legacy_skill_paths

        legacy_skill_paths = should_use_legacy_skill_paths()

    logger.start(f"Updating {noun}...")

    from ...install.service import InstallService

    try:
        # Update intent revalidates marketplace catalogs, as `apm update` does (#3961).
        with InstallService.catalog_freshness(update_refs=True, refresh=False):
            install_result = _install_apm_dependencies(
                apm_package,
                update_refs=True,
                verbose=verbose,
                only_packages=only_pkgs,
                force=force,
                parallel_downloads=parallel_downloads,
                logger=logger,
                auth_resolver=auth_resolver,
                target=target,
                scope=scope,
                legacy_skill_paths=legacy_skill_paths,
            )
    except Exception as e:
        logger.error(f"Update failed: {e}")
        if not verbose:
            logger.progress("Run with --verbose for detailed diagnostics")
        sys.exit(1)

    # Show diagnostics if any
    if install_result.diagnostics and install_result.diagnostics.has_diagnostics:
        install_result.diagnostics.render_summary()

    # Compare old vs new lockfile SHAs to show what changed
    new_lockfile = LockFile.read(lockfile_path)
    changed: list = []
    if new_lockfile:
        for key, dep in new_lockfile.dependencies.items():
            old_sha = old_shas.get(key)
            new_sha = dep.resolved_commit
            if old_sha and new_sha and old_sha != new_sha:
                changed.append((key, old_sha[:8], new_sha[:8], dep.resolved_ref or ""))

    error_count = 0
    if install_result.diagnostics:
        try:
            error_count = int(install_result.diagnostics.error_count)
        except (TypeError, ValueError):
            error_count = 0

    if changed:
        pkg_noun = "package" if len(changed) == 1 else "packages"
        if error_count > 0:
            logger.warning(f"Updated {len(changed)} {pkg_noun} with {error_count} error(s).")
        else:
            logger.success(f"Updated {len(changed)} {pkg_noun}:")
        for key, old_sha, new_sha, ref in changed:
            ref_str = f" ({ref})" if ref else ""
            click.echo(f"  {key}{ref_str}: {old_sha} -> {new_sha}")
    elif error_count > 0:
        logger.error(f"Update failed with {error_count} error(s).")
    elif not had_baseline:
        logger.success("Update complete.")
    else:
        logger.success("All packages already at latest refs.")


@deps.command(
    help="Show detailed package information (alias for 'apm view PACKAGE' for installed packages; prefer 'apm view' in new scripts)"
)
@click.argument("package", required=True)
def info(package: str):
    """Show detailed information about a specific package including context files and workflows."""
    from ..view import display_package_info, resolve_package_path

    logger = CommandLogger("deps-info")

    project_root = Path(".")
    apm_modules_path = project_root / APM_MODULES_DIR

    if not apm_modules_path.exists():
        logger.error("No apm_modules/ directory found")
        logger.progress(DEPENDENCIES_NOT_INSTALLED.sentence())
        sys.exit(1)

    package_path = resolve_package_path(package, apm_modules_path, logger)
    display_package_info(package, package_path, logger, project_root=project_root)
