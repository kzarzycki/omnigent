"""Utility helpers for APM dependency commands."""

from pathlib import Path
from typing import Any

from apm_cli.core.scope import manifest_file

from ...constants import APM_DIR, SKILL_MD_FILENAME
from ...models.apm_package import APMPackage
from ...utils.yaml_io import load_yaml


def _scan_installed_packages(apm_modules_dir: Path) -> list:
    """Scan *apm_modules_dir* for installed package paths.

    Walks the tree to find top-level directories containing ``apm.yml``,
    ``.apm``, or ``SKILL.md``, supporting aliases (1-level), GitHub (2-level), ADO (3-level),
    and subdirectory packages. Manifests nested below another package are part of that
    parent package and are excluded.

    Returns:
        List of installed relative paths, including flattened aliases.
    """
    installed: list = []
    if not apm_modules_dir.exists():
        return installed
    for candidate in apm_modules_dir.rglob("*"):
        if candidate.is_symlink() or not candidate.is_dir():
            continue
        if candidate.name.startswith(".") and candidate.parent != apm_modules_dir:
            continue
        if not (
            manifest_file(candidate).exists()
            or (candidate / APM_DIR).exists()
            or (candidate / SKILL_MD_FILENAME).is_file()
        ):
            continue
        if _is_nested_under_package(candidate, apm_modules_dir):
            continue
        rel_parts = candidate.relative_to(apm_modules_dir).parts
        installed.append("/".join(rel_parts))
    return installed


def _is_nested_under_package(candidate: Path, apm_modules_path: Path) -> bool:
    """Check if *candidate* is a sub-directory of another installed package.

    When a package ships nested package or skill manifests, the ``rglob`` scan
    would otherwise treat each sub-directory as an independent package. This
    helper walks up from *candidate* towards *apm_modules_path* and returns
    ``True`` if any intermediate parent already contains ``apm.yml``, ``.apm``, ``SKILL.md``,
    or a canonical Agent Plugin manifest -- meaning the candidate is part of
    that package, not a standalone one.
    """
    parent = candidate.parent
    while parent != apm_modules_path and parent != parent.parent:  # noqa: PLR1714
        if (
            manifest_file(parent).exists()
            or (parent / APM_DIR).exists()
            or (parent / SKILL_MD_FILENAME).is_file()
            or _is_agent_plugin_root(parent)
        ):
            return True
        parent = parent.parent
    return False


def _is_agent_plugin_root(path: Path) -> bool:
    """Return ``True`` when *path* is a canonical Agent Plugin root.

    An Agent Plugin is installed and loaded as one unit, so its ``skills/``
    and other inner directories are never independent packages -- scanning
    them as such would report false orphans and put them in prune's path.
    """
    if not (path / "plugin.json").is_file():
        return False
    from ...agent_plugins.errors import AgentPluginError
    from ...bundle.local_bundle import route_agent_plugin_package

    try:
        return route_agent_plugin_package(path) is not None
    except (AgentPluginError, OSError):
        return False


def _count_primitives(package_path: Path) -> dict[str, int]:
    """Count primitives by type in a package.

    Returns:
        dict: Counts for 'prompts', 'instructions', 'agents', 'skills'
    """
    counts = {"prompts": 0, "instructions": 0, "agents": 0, "skills": 0, "hooks": 0}

    apm_dir = package_path / APM_DIR
    if apm_dir.exists():
        for subdir, key, pattern in [
            ("prompts", "prompts", "*.prompt.md"),
            ("instructions", "instructions", "*.md"),
            ("agents", "agents", "*.md"),
        ]:
            path = apm_dir / subdir
            if path.exists() and path.is_dir():
                counts[key] += len(list(path.glob(pattern)))

        skills_path = apm_dir / "skills"
        if skills_path.exists() and skills_path.is_dir():
            counts["skills"] += len(
                [
                    d
                    for d in skills_path.iterdir()
                    if d.is_dir() and (d / SKILL_MD_FILENAME).exists()
                ]
            )

    # Also count root-level .prompt.md files
    counts["prompts"] += len(list(package_path.glob("*.prompt.md")))

    # Count root-level SKILL.md as a skill
    if (package_path / SKILL_MD_FILENAME).exists():
        counts["skills"] += 1

    # Count hooks (.json files in hooks/ or .apm/hooks/)
    for hooks_dir in [package_path / "hooks", apm_dir / "hooks" if apm_dir.exists() else None]:
        if hooks_dir and hooks_dir.exists() and hooks_dir.is_dir():
            counts["hooks"] += len(list(hooks_dir.glob("*.json")))

    return counts


def _count_package_files(package_path: Path) -> tuple[int, int]:
    """Count context files and workflows in a package.

    Returns:
        tuple: (context_count, workflow_count)
    """
    apm_dir = package_path / APM_DIR
    if not apm_dir.exists():
        # Also check root directory for .prompt.md files
        workflow_count = len(list(package_path.glob("*.prompt.md")))
        return 0, workflow_count

    context_count = 0
    context_dirs = ["instructions", "agents", "context"]

    for context_dir in context_dirs:
        context_path = apm_dir / context_dir
        if context_path.exists() and context_path.is_dir():
            context_count += len(list(context_path.glob("*.md")))

    # Count workflows in both .apm/prompts and root directory
    workflow_count = 0
    prompts_path = apm_dir / "prompts"
    if prompts_path.exists() and prompts_path.is_dir():
        workflow_count += len(list(prompts_path.glob("*.prompt.md")))

    # Also check root directory for .prompt.md files
    workflow_count += len(list(package_path.glob("*.prompt.md")))

    return context_count, workflow_count


def _count_workflows(package_path: Path) -> int:
    """Count agent workflows (.prompt.md files) in a package."""
    _, workflow_count = _count_package_files(package_path)
    return workflow_count


def _get_detailed_context_counts(package_path: Path) -> dict[str, int]:
    """Get detailed context file counts by type."""
    apm_dir = package_path / APM_DIR
    if not apm_dir.exists():
        return {"instructions": 0, "agents": 0, "contexts": 0}

    counts = {}
    context_directories = {
        "instructions": "instructions",
        "agents": "agents",
        "contexts": "context",  # Note: directory is 'context', not 'contexts'
    }

    for context_type, directory_name in context_directories.items():
        count = 0
        context_path = apm_dir / directory_name
        if context_path.exists() and context_path.is_dir():
            # Count all .md files in the directory regardless of specific naming
            count = len(list(context_path.glob("*.md")))
        counts[context_type] = count

    return counts


def _tolerant_identity(package_path: Path, apm_yml_path: Path) -> dict[str, str] | None:
    """Best-effort name/version read for the tolerant ``deps`` display paths.

    ``APMPackage.from_apm_yml`` is the strict identity authority: it rejects
    empty/non-string ``name`` and ``version`` so ``audit`` and ``policy``
    surfaces fail schema-invalid manifests. The ``deps list`` / ``deps info``
    display commands are a different surface -- they must stay tolerant so a
    manifest that merely omits or empties ``version`` still renders as
    ``@unknown`` rather than an alarming ``@error`` that masks the package.

    Returns a ``{"name", "version"}`` dict on a best-effort read, or ``None``
    only when the apm.yml cannot be parsed at all (genuinely malformed YAML),
    which the callers surface as ``error``.
    """
    try:
        data = load_yaml(apm_yml_path)
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    raw_name = data.get("name")
    name = raw_name.strip() if isinstance(raw_name, str) and raw_name.strip() else package_path.name
    raw_version = data.get("version")
    version = (
        raw_version.strip() if isinstance(raw_version, str) and raw_version.strip() else "unknown"
    )
    return {"name": name, "version": version}


def _get_package_display_info(package_path: Path) -> dict[str, str]:
    """Get package display information."""
    try:
        apm_yml_path = manifest_file(package_path)
        if apm_yml_path.exists():
            package = APMPackage.from_apm_yml(apm_yml_path)
            version_info = f"@{package.version}" if package.version else "@unknown"
            return {
                "display_name": f"{package.name}{version_info}",
                "name": package.name,
                "version": package.version or "unknown",
            }
        else:
            return {
                "display_name": f"{package_path.name}@unknown",
                "name": package_path.name,
                "version": "unknown",
            }
    except Exception:
        identity = _tolerant_identity(package_path, manifest_file(package_path))
        if identity is None:
            return {
                "display_name": f"{package_path.name}@error",
                "name": package_path.name,
                "version": "error",
            }
        return {
            "display_name": f"{identity['name']}@{identity['version']}",
            "name": identity["name"],
            "version": identity["version"],
        }


def _get_detailed_package_info(package_path: Path) -> dict[str, Any]:
    """Get detailed package information for the info command."""
    try:
        apm_yml_path = manifest_file(package_path)
        if apm_yml_path.exists():
            package = APMPackage.from_apm_yml(apm_yml_path)
            context_count, workflow_count = _count_package_files(package_path)
            primitives = _count_primitives(package_path)
            # HYBRID-aware description rendering: when apm.yml omits its
            # tagline but a SKILL.md sits alongside, surface the empty
            # apm.yml.description as `--` plus an inline annotation. The
            # SKILL.md description is intentionally NOT borrowed -- it is
            # an agent invocation matcher, not a human tagline.
            is_hybrid = (package_path / "SKILL.md").exists()
            if package.description:
                desc = package.description
            elif is_hybrid:
                desc = (
                    "--  (set 'description' in apm.yml; SKILL.md description is for agent runtime)"
                )
            else:
                desc = "No description"
            return {
                "name": package.name,
                "version": package.version or "unknown",
                "description": desc,
                "author": package.author or "Unknown",
                "source": package.source or "local",
                "install_path": str(package_path.resolve()),
                "context_files": _get_detailed_context_counts(package_path),
                "workflows": workflow_count,
                "hooks": primitives.get("hooks", 0),
            }
        else:
            context_count, workflow_count = _count_package_files(package_path)  # noqa: RUF059
            primitives = _count_primitives(package_path)
            return {
                "name": package_path.name,
                "version": "unknown",
                "description": "No apm.yml found",
                "author": "Unknown",
                "source": "unknown",
                "install_path": str(package_path.resolve()),
                "context_files": _get_detailed_context_counts(package_path),
                "workflows": workflow_count,
                "hooks": primitives.get("hooks", 0),
            }
    except Exception as e:
        identity = _tolerant_identity(package_path, manifest_file(package_path))
        if identity is not None:
            # Tolerant display: a readable manifest with incomplete identity
            # (e.g. empty/missing version) renders gracefully -- symmetric with
            # `deps list` -- instead of masking the package behind an error.
            return {
                "name": identity["name"],
                "version": identity["version"],
                "description": "apm.yml identity incomplete",
                "author": "Unknown",
                "source": "local",
                "install_path": str(package_path.resolve()),
                "context_files": _get_detailed_context_counts(package_path),
                "workflows": 0,
                "hooks": 0,
            }
        return {
            "name": package_path.name,
            "version": "error",
            "description": f"Error loading package: {e}",
            "author": "Unknown",
            "source": "unknown",
            "install_path": str(package_path.resolve()),
            "context_files": {"instructions": 0, "agents": 0, "contexts": 0},
            "workflows": 0,
            "hooks": 0,
        }
