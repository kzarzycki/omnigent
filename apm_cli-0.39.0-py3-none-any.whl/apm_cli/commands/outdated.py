"""Check for outdated locked dependencies.

Compares locked dependency commit SHAs against remote tip SHAs.
For tag-pinned deps, also shows the latest available semver tag.
For marketplace-sourced deps, checks available versions in the marketplace.
"""

import logging
import re
import sys
from collections.abc import Iterable
from dataclasses import replace

import click

from apm_cli.core.remediation import (
    OUTSIDE_CONSTRAINT_RELEASE,
)

from ..deps.lockfile import LockedDependency
from ..deps.outdated_row import OutdatedRow
from ..deps.revision_pins import (
    RevisionPinResolutionError,
    abbreviate_sha,
    dependency_ref_from_locked,
    find_latest_annotated_tag,
    is_full_revision_pin,
)
from ..deps.revision_pins import (
    package_name as revision_pin_package_name,
)
from ..models.dependency.reference import DependencyReference
from ..models.dependency.types import RemoteRef

logger = logging.getLogger(__name__)

# Fallback heuristic for _resolve_tag_pattern when inference misses plain tags.
TAG_RE = re.compile(r"^v?\d+\.\d+\.\d+")


def _unknown_row(dep) -> OutdatedRow:
    """Degraded row for a dependency whose check raised unexpectedly.

    Keeps ``apm outdated`` from crashing when a single dependency check
    fails; the dependency is surfaced as ``unknown`` instead.
    """
    return OutdatedRow(package=dep.get_unique_key(), current="(none)", latest="-", status="unknown")


def _is_tag_ref(ref: str, package_name: str | None = None) -> bool:
    """Return True when *ref* names a version tag (plain or patterned)."""
    from ..marketplace.tag_pattern import is_version_tag_ref

    return is_version_tag_ref(ref, package_name)


def _strip_v(ref: str) -> str:
    """Strip leading 'v' prefix from a version string."""
    return ref[1:] if ref and ref.startswith("v") else (ref or "")


def _package_basename(dep: LockedDependency, dep_ref: DependencyReference | None = None) -> str:
    """Return the display name used in ``{name}`` tag patterns."""
    if dep.replacement is not None:
        return revision_pin_package_name(dep_ref or dependency_ref_from_locked(dep))
    if dep.marketplace_plugin_name:
        return dep.marketplace_plugin_name
    # For virtual subdirectory packages, derive the name from the virtual path
    # (e.g. "packages/agent-dev-workflow" -> "agent-dev-workflow").
    if dep.is_virtual and dep.virtual_path:
        if dep_ref is None:
            dep_ref = dep.to_dependency_ref()
        if dep_ref.is_virtual_subdirectory():
            return revision_pin_package_name(dep_ref)
    repo = dep.repo_url or ""
    if not repo:
        return ""
    return repo.rstrip("/").split("/")[-1]


def _resolve_tag_pattern(current_ref: str, package_name: str) -> str | None:
    """Return the tag pattern for *current_ref*, or ``None`` if not a version tag."""
    from ..marketplace.tag_pattern import infer_tag_pattern

    inferred = infer_tag_pattern(current_ref, package_name)
    if inferred:
        logger.debug(
            "Resolved tag pattern %r for %s from ref %s",
            inferred,
            package_name,
            current_ref,
        )
        return inferred
    if TAG_RE.match(current_ref or ""):
        return "v{version}" if (current_ref or "").startswith("v") else "{version}"
    return None


def _semver_tag_candidates(tag_refs, pattern: str, package_name: str = ""):
    """Return ``(SemVer, tag_name)`` pairs matching *pattern*, highest first."""
    from ..marketplace.semver import SemVer, parse_semver
    from ..marketplace.tag_pattern import build_tag_regex

    tag_rx = (
        build_tag_regex(pattern, name=package_name)
        if "{name}" in pattern and package_name
        else build_tag_regex(pattern)
    )
    candidates: list[tuple[SemVer, str]] = []
    for remote_ref in tag_refs:
        match = tag_rx.match(remote_ref.name)
        if not match:
            continue
        version = match.group("version")
        parsed = parse_semver(version)
        if parsed is not None:
            candidates.append((parsed, remote_ref.name))
    candidates.sort(key=lambda pair: pair[0], reverse=True)
    return candidates


def _find_remote_tip(ref_name, remote_refs):
    """Find the tip SHA for a branch ref from remote refs.

    If *ref_name* is empty/None, falls back to common default branch
    names (main, master).
    Returns the commit SHA string or None if not found.
    """
    from ..models.dependency.types import GitReferenceType

    if not remote_refs:
        return None

    branch_refs = {
        r.name: r.commit_sha for r in remote_refs if r.ref_type == GitReferenceType.BRANCH
    }

    if ref_name:
        return branch_refs.get(ref_name)

    # No ref specified -- find the default branch
    for default in ("main", "master"):
        if default in branch_refs:
            return branch_refs[default]

    # Last resort: first branch in list
    if branch_refs:
        return next(iter(branch_refs.values()))

    return None


def _short_ref(ref: str) -> str:
    return ref[:12] if len(ref) > 12 else ref


def _check_marketplace_ref(dep, verbose):
    """Check a marketplace-sourced dep against its marketplace entry.

    Compares the installed ref (resolved_ref or resolved_commit) against
    the marketplace entry's current source ref. Returns a result tuple
    ``(package, current, latest, status, extra, source)`` or ``None``
    when the check cannot be performed (caller should fall through to
    the git-based check).
    """
    if not dep.discovered_via or not dep.marketplace_plugin_name:
        return None

    try:
        from ..marketplace.catalog_origin import require_locked_row_origin
        from ..marketplace.client import fetch_or_cache
        from ..marketplace.errors import (
            MarketplaceAuthError,
            MarketplaceError,
            MarketplaceOriginConflictError,
        )
        from ..marketplace.registry import get_marketplace_by_name
    except ImportError:
        return None

    source_label = f"marketplace: {dep.discovered_via}"
    # #3959: never compare against a catalog the alias was rebound to.
    try:
        require_locked_row_origin(dep)
    except MarketplaceOriginConflictError as conflict:
        return OutdatedRow(
            package=f"{dep.marketplace_plugin_name}@{dep.discovered_via}",
            current=_short_ref(dep.resolved_ref or dep.resolved_commit or "(none)"),
            latest="-",
            status="origin-conflict",
            source=source_label,
            error=str(conflict),
        )
    except MarketplaceError:
        pass  # Unregistered alias: handled below with the git fallback.

    try:
        source_obj = get_marketplace_by_name(dep.discovered_via)
    except MarketplaceError:
        logger.warning(
            "Marketplace '%s' not found; falling back to git check for '%s'",
            dep.discovered_via,
            dep.marketplace_plugin_name,
        )
        return None

    try:
        manifest = fetch_or_cache(source_obj)
    except MarketplaceAuthError as denied:
        # Denied catalog access is never replaced by a Git-derived answer.
        return OutdatedRow(
            package=f"{dep.marketplace_plugin_name}@{dep.discovered_via}",
            current=_short_ref(dep.resolved_ref or dep.resolved_commit or "(none)"),
            latest="-",
            status="access-denied",
            source=source_label,
            error=str(denied),
        )
    except MarketplaceError:
        logger.warning(
            "Failed to fetch marketplace '%s'; falling back to git check for '%s'",
            dep.discovered_via,
            dep.marketplace_plugin_name,
        )
        return None

    plugin = manifest.find_plugin(dep.marketplace_plugin_name)
    if not plugin:
        return None

    # Determine marketplace entry's current ref
    mkt_ref = None
    mkt_version = plugin.version or ""
    if isinstance(plugin.source, dict):
        mkt_ref = plugin.source.get("ref", "")
    else:
        # String sources are relative paths, not refs -- skip
        return None

    if not mkt_ref:
        return None

    # Determine installed ref
    installed_ref = dep.resolved_ref or dep.resolved_commit or ""
    if not installed_ref:
        return None

    package_name = f"{dep.marketplace_plugin_name}@{dep.discovered_via}"
    current_display = installed_ref[:12] if len(installed_ref) > 12 else installed_ref
    latest_display = mkt_ref[:12] if len(mkt_ref) > 12 else mkt_ref
    if mkt_version:
        latest_display = f"{mkt_version} ({latest_display})"

    if installed_ref != mkt_ref:
        return OutdatedRow(
            package=package_name,
            current=current_display,
            latest=latest_display,
            status="outdated",
            source=source_label,
        )

    return OutdatedRow(
        package=package_name,
        current=current_display,
        latest=latest_display,
        status="up-to-date",
        source=source_label,
    )


def _check_revision_pin_ref(
    *,
    current_ref: str,
    package_name: str,
    package_basename: str,
    remote_refs: Iterable[RemoteRef],
) -> OutdatedRow | None:
    """Return an outdated row for full-SHA pins, or None for other refs."""
    if not is_full_revision_pin(current_ref):
        return None
    try:
        latest = find_latest_annotated_tag(remote_refs, package_name=package_basename)
    except RevisionPinResolutionError:
        return OutdatedRow(
            package=package_name,
            current=abbreviate_sha(current_ref),
            latest="-",
            status="unknown",
            source="git tags",
        )
    latest_display = f"{latest.tag} ({abbreviate_sha(latest.commit_sha)})"
    status = "up-to-date" if latest.commit_sha.lower() == current_ref.lower() else "outdated"
    return OutdatedRow(
        package=package_name,
        current=abbreviate_sha(current_ref),
        latest=latest_display,
        status=status,
        source="git tags",
    )


def _check_one_dep(dep, downloader, verbose, registry_ctx=None):
    """Compare selected bytes while keeping original ownership in the result."""
    if dep.replacement is not None and dep.is_local_source:
        return OutdatedRow(
            package=dep.get_unique_key(),
            current="local",
            latest="-",
            status="not-comparable",
            source=f"replacement: {dep.to_dependency_ref().local_path}",
        )
    row = _check_selected_dep(dep, downloader, verbose, registry_ctx)
    if dep.replacement is not None:
        source = dependency_ref_from_locked(dep).to_display_reference()
        return replace(row, source=f"replacement: {source} ({row.source})")
    return row


def _check_selected_dep(dep, downloader, verbose, registry_ctx=None):
    """Check a single dependency against remote refs.

    Returns an ``OutdatedRow`` instance.

    This function is safe to call from a thread pool.
    """
    if dep.source == "registry":
        from ..deps.registry.outdated import check_registry_locked_dep

        return check_registry_locked_dep(dep, registry_ctx, verbose=verbose)

    # Try marketplace-based check first for marketplace-sourced deps
    marketplace_result = _check_marketplace_ref(dep, verbose) if dep.replacement is None else None
    if marketplace_result is not None:
        return marketplace_result

    from ..models.dependency.types import GitReferenceType
    from ..utils.version_checker import is_newer_version

    current_ref = dep.resolved_ref or ""
    locked_sha = dep.resolved_commit or ""
    package_name = dep.get_unique_key()

    # Build a DependencyReference to query remote refs
    try:
        # Use the lockfile rebuild path to preserve host, port, virtual path,
        # and insecure-transport metadata for authoritative upstream checks.
        dep_ref = dependency_ref_from_locked(dep)
    except Exception:
        return OutdatedRow(
            package=package_name, current=current_ref or "(none)", latest="-", status="unknown"
        )

    # Fetch only the ref families this comparison needs.
    try:
        if is_full_revision_pin(current_ref):
            remote_refs = downloader.list_remote_tag_refs(dep_ref)
        else:
            remote_refs = downloader.list_remote_refs(dep_ref)
    except Exception:
        return OutdatedRow(
            package=package_name, current=current_ref or "(none)", latest="-", status="unknown"
        )

    package_basename = _package_basename(dep, dep_ref=dep_ref)
    revision_pin_row = _check_revision_pin_ref(
        current_ref=current_ref,
        package_name=package_name,
        package_basename=package_basename,
        remote_refs=remote_refs,
    )
    if revision_pin_row is not None:
        return revision_pin_row

    tag_pattern = _resolve_tag_pattern(current_ref, package_basename)
    is_tag = tag_pattern is not None

    if is_tag:
        tag_refs = [r for r in remote_refs if r.ref_type == GitReferenceType.TAG]
        if not tag_refs:
            return OutdatedRow(
                package=package_name,
                current=current_ref,
                latest="-",
                status="unknown",
                source="git tags",
            )

        from ..marketplace.tag_pattern import parse_tag_version

        candidates = _semver_tag_candidates(tag_refs, tag_pattern, package_basename)
        if not candidates:
            return OutdatedRow(
                package=package_name,
                current=current_ref,
                latest="-",
                status="unknown",
                source="git tags",
            )

        _, latest_tag = candidates[0]
        current_ver = parse_tag_version(
            current_ref, tag_pattern, name=package_basename
        ) or _strip_v(current_ref)
        latest_ver = parse_tag_version(latest_tag, tag_pattern, name=package_basename) or _strip_v(
            latest_tag
        )

        if is_newer_version(current_ver, latest_ver):
            extra = [name for _, name in candidates[:10]] if verbose else []
            return OutdatedRow(
                package=package_name,
                current=current_ref,
                latest=latest_tag,
                status="outdated",
                extra_tags=extra,
                source="git tags",
            )
        else:
            return OutdatedRow(
                package=package_name,
                current=current_ref,
                latest=latest_tag,
                status="up-to-date",
                source="git tags",
            )
    else:
        remote_tip_sha = _find_remote_tip(current_ref, remote_refs)

        if not remote_tip_sha:
            return OutdatedRow(
                package=package_name,
                current=current_ref or "(none)",
                latest="-",
                status="unknown",
                source="git branch",
            )

        display_ref = current_ref or "(default)"
        if locked_sha and locked_sha != remote_tip_sha:
            latest_display = remote_tip_sha[:8]
            return OutdatedRow(
                package=package_name,
                current=display_ref,
                latest=latest_display,
                status="outdated",
                source="git branch",
            )
        else:
            return OutdatedRow(
                package=package_name,
                current=display_ref,
                latest=remote_tip_sha[:8],
                status="up-to-date",
                source="git branch",
            )


@click.command(name="outdated", help="Show outdated locked dependencies")
@click.option(
    "--global",
    "-g",
    "global_",
    is_flag=True,
    default=False,
    help="Check dependencies in the APM user home",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help="Show additional info (e.g., available tags for outdated deps)",
)
@click.option(
    "--parallel-checks",
    "-j",
    type=int,
    default=4,
    help="Max concurrent remote checks (default: 4, 0 = sequential)",
)
def outdated(global_, verbose, parallel_checks):
    """Show outdated locked dependencies

    Compares each locked dependency against the remote to detect staleness.
    Tag-pinned deps use semver comparison; branch-pinned deps compare commit SHAs.

    \b
    Examples:
        apm outdated             # Check project deps
        apm outdated --global    # Check user-scope deps
        apm outdated --verbose   # Show available tags
        apm outdated -j 8        # Use 8 parallel checks
    """
    from ..core.command_logger import CommandLogger
    from ..core.scope import InstallScope, get_apm_dir
    from ..deps.lockfile import LockFile, resolve_lockfile_path_for_read

    logger = CommandLogger("outdated", verbose=verbose)

    # Resolve scope and lockfile path
    scope = InstallScope.USER if global_ else InstallScope.PROJECT
    project_root = get_apm_dir(scope)

    lockfile_path = resolve_lockfile_path_for_read(project_root, read_only=True)
    lockfile = LockFile.read(lockfile_path)

    if lockfile is None:
        scope_hint = str(project_root) if global_ else "current directory"
        logger.error(f"No lockfile found in {scope_hint}")
        sys.exit(1)

    if not lockfile.dependencies:
        logger.success("No locked dependencies to check")
        return

    # Lazy-init downloader only when we have deps to check
    from ..core.auth import AuthResolver
    from ..deps.github_downloader import GitHubPackageDownloader

    auth_resolver = AuthResolver()
    downloader = GitHubPackageDownloader(auth_resolver=auth_resolver)

    # #1369: wire the tiered ref resolver here too -- outdated calls
    # downloader.resolve_git_reference() N times across a ThreadPoolExecutor,
    # which is exactly the duplicate-resolution workload the L0 cache +
    # coalesce lock are designed to collapse.
    try:
        from ..cache.git_cache import attach_persistent_git_cache
        from ..deps.tiered_ref_resolver import (
            RefFreshnessPolicy,
            build_tiered_ref_resolver,
        )

        _git_cache = attach_persistent_git_cache(downloader)
        _tiered = build_tiered_ref_resolver(
            downloader=downloader,
            git_cache=_git_cache,
            freshness_policy=RefFreshnessPolicy.CURRENT_REMOTE,
        )
        if _tiered is not None:
            downloader._tiered_resolver = _tiered
    except Exception as exc:  # pragma: no cover - never block outdated on resolver wiring
        # Non-blocking, but log so --verbose surfaces wiring failures.
        import logging as _logging

        _logging.getLogger(__name__).debug(
            "Tiered ref resolver wiring skipped for outdated (%s): %s",
            type(exc).__name__,
            exc,
        )

    # Filter to checkable deps (skip local + Artifactory)
    checkable = []
    for key, dep in lockfile.dependencies.items():
        if dep.source == "local":
            logger.verbose_detail(f"Skipping local dep: {key}")
            continue
        if dep.registry_prefix:
            logger.verbose_detail(f"Skipping Artifactory dep: {key}")
            continue
        checkable.append(dep)

    if not checkable:
        logger.success("No remote dependencies to check")
        return

    registry_ctx = None
    if any(dep.source == "registry" for dep in checkable):
        from ..deps.registry.outdated import load_registry_outdated_context

        registry_ctx = load_registry_outdated_context(project_root, lockfile)

    # Dedupe redundant ``git ls-remote`` across same-repo deps for the span
    # of this invocation (e.g. many virtual-subdirectory packages from one
    # monorepo). Mirrors the install-path RefResolver reuse (#1975); fresh
    # per run, so a newer upstream ref is still seen on the next invocation.
    from ..deps.outdated_ref_cache import OutdatedRefCache

    downloader = OutdatedRefCache(downloader)

    from ..marketplace.project_marketplaces import (
        bind_project_marketplaces,
        read_project_marketplaces,
    )

    # Marketplace rows compare against the root ``marketplaces:`` map (#2903).
    try:
        declared_marketplaces = read_project_marketplaces(project_root)
    except ValueError as exc:
        logger.error(f"Failed to parse apm.yml: {exc}")
        sys.exit(1)

    # Check deps with progress feedback and optional parallelism
    with bind_project_marketplaces(declared_marketplaces, user_scope=global_):
        rows = _check_deps_with_progress(
            checkable, downloader, verbose, parallel_checks, logger, registry_ctx
        )

    if not rows:
        logger.success("No remote dependencies to check")
        return

    # Check if everything is up-to-date
    has_outdated = any(row.status == "outdated" for row in rows)
    has_unknown = any(row.status in {"unknown", "origin-conflict", "access-denied"} for row in rows)
    has_outside_constraint = any(row.outside_constraint for row in rows)

    has_replacements = any(dep.replacement is not None for dep in checkable)
    for dep in checkable:
        if dep.replacement is not None:
            logger.verbose_detail(
                f"Replacement: {dep.get_unique_key()} "
                f"-> {dependency_ref_from_locked(dep).to_display_reference()}"
            )
    if not has_outdated and not has_unknown and not has_outside_constraint and not has_replacements:
        logger.success("All dependencies are up-to-date")
        return

    show_wanted = any(row.wanted is not None for row in rows)
    sources = [
        f"{row.source} (outside constraint)" if row.outside_constraint else row.source
        for row in rows
    ]
    # Render the table
    try:
        from apm_cli.utils.console import new_table

        from ._helpers import _get_console

        console = _get_console()
        if console is None:
            raise ImportError("Rich console not available")

        table = new_table(
            title="Dependency Status",
            show_header=True,
            header_style="bold cyan",
        )
        # Minimum widths that overflow the terminal make Rich crop whole rows
        # (the Source column lost "marketplace: <name>" at 80 columns), so
        # they apply only when they fit; every column folds instead (#3994).
        version_min = 1 if has_replacements else 10
        mins = [20, version_min, *([version_min] if show_wanted else []), version_min]
        mins += [14 if has_replacements else 12, 20]
        fits = sum(mins) + 3 * len(mins) + 1 <= console.width
        widths = iter(mins if fits else [1] * len(mins))
        # Fold, never clip: the name is what users copy into apm update.
        table.add_column("Package", style="white", min_width=next(widths), overflow="fold")
        table.add_column("Current", style="white", min_width=next(widths), overflow="fold")
        if show_wanted:
            table.add_column("Wanted", style="white", min_width=next(widths), overflow="fold")
        table.add_column("Latest", style="white", min_width=next(widths), overflow="fold")
        table.add_column("Status", min_width=next(widths), overflow="fold")
        table.add_column("Source", style="dim", min_width=next(widths), overflow="fold")

        status_styles = {
            "origin-conflict": "red",
            "access-denied": "red",
            "up-to-date": "green",
            "outdated": "yellow",
            "unknown": "dim",
            "not-comparable": "dim",
        }

        for row, source in zip(rows, sources, strict=True):
            style = status_styles.get(row.status, "white")
            table.add_row(
                row.package,
                row.current,
                *([row.wanted or "-"] if show_wanted else []),
                row.latest,
                f"[{style}]{row.status}[/{style}]",
                source,
            )

            if verbose and row.extra_tags:
                tags_str = ", ".join(row.extra_tags)
                table.add_row(
                    "", "", *([""] if show_wanted else []), f"[dim]tags: {tags_str}[/dim]", "", ""
                )

        console.print(table)

    except (ImportError, Exception):
        # Fallback: plain text output
        wanted_header = f"{'Wanted':<13}" if show_wanted else ""
        header = (
            f"{'Package':<24}{'Current':<13}{wanted_header}{'Latest':<13}{'Status':<15}{'Source'}"
        )
        click.echo(header)
        click.echo("-" * len(header))
        for row, source in zip(rows, sources, strict=True):
            wanted_cell = f"{row.wanted or '-':<13}" if show_wanted else ""
            click.echo(
                f"{row.package:<24}{row.current:<13}{wanted_cell}"
                f"{row.latest:<13}{row.status:<15}{source}"
            )
            if verbose and row.extra_tags:
                click.echo(f"{'':24}tags: {', '.join(row.extra_tags)}")

    # Summary
    outdated_count = sum(1 for row in rows if row.status == "outdated")
    if outdated_count:
        logger.warning(
            f"{outdated_count} outdated "
            f"{'dependency' if outdated_count == 1 else 'dependencies'} found"
        )
    elif has_unknown:
        logger.progress("Some dependencies could not be checked")
    if has_unknown:
        from ..deps.egress_route import EgressSurface, is_refused

        if is_refused(EgressSurface.SOURCE_ENUMERATION):
            # State the enterprise policy only; never advise lifting it (RA-014).
            logger.info(
                "Source-host checks are disabled because PROXY_REGISTRY_ONLY is set "
                "(enterprise proxy policy)."
            )
    if any(row.status == "not-comparable" for row in rows):
        logger.progress("Local replacement sources are not remotely comparable")
    if has_outside_constraint:
        logger.progress(
            "Registry Latest is published; Wanted respects the manifest constraint. "
            "'apm update' stays within that constraint. "
            f"{OUTSIDE_CONSTRAINT_RELEASE.sentence()}"
        )
    conflicts = [row for row in rows if row.status in {"origin-conflict", "access-denied"}]
    for row in conflicts:
        logger.error(row.error or f"{row.package}: marketplace origin changed")
    if conflicts:
        sys.exit(1)


def _check_deps_with_progress(
    checkable, downloader, verbose, parallel_checks, logger, registry_ctx=None
):
    """Check all deps with Rich progress bar and optional parallelism."""
    rows = []
    total = len(checkable)

    try:
        from rich.progress import (
            BarColumn,
            Progress,
            SpinnerColumn,
            TaskProgressColumn,
            TextColumn,
        )

        from apm_cli.utils.console import new_console

        # Own the Console instead of borrowing Rich's process-global singleton:
        # a caller (or a leaked test double) that poisons ``rich._console`` must
        # not be able to crash ``apm outdated``.
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]{task.description}[/cyan]"),
            BarColumn(),
            TaskProgressColumn(),
            transient=True,
            console=new_console(),
        ) as progress:
            if parallel_checks > 0 and total > 1:
                rows = _check_parallel(
                    checkable,
                    downloader,
                    verbose,
                    parallel_checks,
                    progress,
                    logger,
                    registry_ctx,
                )
            else:
                task_id = progress.add_task(
                    f"Checking {total} dependencies",
                    total=total,
                )
                for dep in checkable:
                    short = dep.get_unique_key().split("/")[-1]
                    progress.update(task_id, description=f"Checking {short}")
                    try:
                        result = _check_one_dep(dep, downloader, verbose, registry_ctx)
                    except Exception:
                        result = _unknown_row(dep)
                    rows.append(result)
                    progress.advance(task_id)
    except Exception:
        # No Rich, or the progress renderer itself blew up -- degrade to plain
        # text rather than failing the whole command over a display concern.
        rows = []
        logger.progress(f"Checking {total} dependencies...")
        if parallel_checks > 0 and total > 1:
            rows = _check_parallel_plain(
                checkable,
                downloader,
                verbose,
                parallel_checks,
                registry_ctx,
            )
        else:
            for dep in checkable:
                try:
                    rows.append(_check_one_dep(dep, downloader, verbose, registry_ctx))
                except Exception:
                    rows.append(_unknown_row(dep))

    return rows


def _check_parallel(
    checkable, downloader, verbose, max_workers, progress, logger, registry_ctx=None
):
    """Run checks in parallel with Rich progress display."""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    total = len(checkable)
    max_workers = min(max_workers, total)
    overall_id = progress.add_task(
        f"Checking {total} dependencies",
        total=total,
    )

    results = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {}
        for dep in checkable:
            short = dep.get_unique_key().split("/")[-1]
            task_id = progress.add_task(f"Checking {short}", total=None)
            fut = executor.submit(_check_one_dep, dep, downloader, verbose, registry_ctx)
            futures[fut] = (dep, task_id)

        for fut in as_completed(futures):
            dep, task_id = futures[fut]
            try:
                result = fut.result()
            except Exception:
                result = _unknown_row(dep)
            results[dep.get_unique_key()] = result
            progress.update(task_id, visible=False)
            progress.advance(overall_id)

    # Preserve original order
    return [results[dep.get_unique_key()] for dep in checkable if dep.get_unique_key() in results]


def _check_parallel_plain(checkable, downloader, verbose, max_workers, registry_ctx=None):
    """Run checks in parallel without Rich (plain fallback)."""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    max_workers = min(max_workers, len(checkable))
    results = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(_check_one_dep, dep, downloader, verbose, registry_ctx): dep
            for dep in checkable
        }
        for fut in as_completed(futures):
            dep = futures[fut]
            try:
                result = fut.result()
            except Exception:
                result = _unknown_row(dep)
            results[dep.get_unique_key()] = result

    return [results[dep.get_unique_key()] for dep in checkable if dep.get_unique_key() in results]
