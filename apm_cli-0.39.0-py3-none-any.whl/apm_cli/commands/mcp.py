"""APM mcp command group."""

import builtins
import copy
import sys

import click
from click.core import ParameterSource

from apm_cli.core.remediation import (
    MCP_REGISTRY_URL_OVERRIDE,
)

from ..core.command_logger import CommandLogger
from ..mcp_transport import (
    TRANSPORT_SSE,
    TRANSPORT_STREAMABLE_HTTP,
    canonical_remote_transport,
)
from ._helpers import _get_console

_REMOTE_DEPLOYMENT_LABELS = {
    TRANSPORT_STREAMABLE_HTTP: " Remote Streamable HTTP Endpoint",
    TRANSPORT_SSE: " Remote SSE Endpoint",
}


def _remote_transport_label(remote) -> str:
    """Canonical transport of a registry remote, or ``unknown`` when unrecognized."""
    try:
        return canonical_remote_transport(remote)
    except (ValueError, AttributeError):
        return "unknown"


# Restore builtin since a subcommand is named ``list``
list = builtins.list

MCP_REGISTRY_ENV = "MCP_REGISTRY_URL"


def _build_registry_with_diag(console, logger):
    """Construct ``RegistryIntegration`` honouring the registry URL precedence chain.

    Resolution order (MCP_REGISTRY_URL env > apm config mcp-registry-url >
    default) is owned by
    :func:`~apm_cli.registry.client.resolve_mcp_registry_url`, which the client
    applies for itself. The URL is therefore NOT pre-resolved here and passed
    in: a caller-supplied URL is by definition the ``"explicit"`` layer, so
    doing that would relabel every ambient source and leave
    ``registry_url_source`` unable to tell an env override from a persisted
    config entry.

    Emits a one-line diagnostic naming the resolved registry URL whenever
    a non-default source is in effect, so enterprise users can confirm they
    are hitting the override and not the public default. Stays silent for the
    default public registry (defaults are quiet, overrides are visible).
    """
    from ..registry.client import REGISTRY_SOURCE_LABELS, redact_mcp_registry_url
    from ..registry.integration import RegistryIntegration

    registry = RegistryIntegration()
    # The label table holds exactly the ambient layers worth announcing, so a
    # missing entry (the public default) is the "stay quiet" case -- no second
    # condition needed, and nothing can raise on an unexpected source.
    label = REGISTRY_SOURCE_LABELS.get(registry.client.registry_url_source)
    if label:
        safe_url = redact_mcp_registry_url(registry.client.registry_url)
        line = f"Registry: {safe_url} ({label})"
        if console:
            console.print(f"[muted]{line}[/muted]")
        else:
            logger.progress(line)
    return registry


def _handle_registry_network_error(exc, registry, console, logger, action):
    """Render a registry network failure with override-aware guidance.

    ``action`` is a short verb phrase like ``"reach"`` so the message reads
    naturally: ``Could not <action> MCP registry at <url>``. The hint names the
    precedence layer that actually supplied the URL, so a user who persisted it
    with ``apm config`` is not sent looking at an env var they never exported.
    Returns once the message is emitted; caller is responsible for
    ``sys.exit(1)``.
    """
    if registry is None:
        # Fell over before the registry was constructed; let the caller
        # emit its generic error path with the original exception.
        return False
    from ..registry.client import redact_mcp_registry_url

    url = redact_mcp_registry_url(registry.client.registry_url)
    source = registry.client.registry_url_source
    if source == "env":
        hint = f"{MCP_REGISTRY_ENV} is set -- verify the URL is correct and reachable."
    elif source == "config":
        hint = (
            "mcp-registry-url is set in apm config -- verify the URL is correct "
            f"and reachable, or {MCP_REGISTRY_URL_OVERRIDE.clause()}."
        )
    else:
        hint = "The registry may be temporarily unavailable. Retry shortly."

    msg = f"Could not {action} MCP registry at {url}"
    if console:
        from ..utils.console import STATUS_SYMBOLS, _rich_echo

        _rich_echo(f"\n{STATUS_SYMBOLS['error']} {msg}", color="red")
        _rich_echo(f"  -> {hint}", color="dim", err=True)
    else:
        logger.error(msg)
        logger.error(hint)
    return True


@click.group(help="Discover, inspect, and install MCP servers")
def mcp():
    """Manage MCP server discovery, inspection, and installation."""
    pass


# ``apm install`` parameters that ``apm mcp install`` shows in its help. Only
# the selection lives here: flags, type, choices, metavar and help text are
# borrowed from the ``apm install`` command itself, so help, validation and
# shell completion cannot drift from it.
_FORWARDED_INSTALL_PARAMS: tuple[str, ...] = (
    "transport",
    "url",
    "env_pairs",
    "header_pairs",
    "target",
    "registry_url",
    "mcp_version",
    "global_",
    "trust_transitive_mcp",
    "dev",
    "dry_run",
    "force",
    "verbose",
    "no_policy",
)
# Supplied by the alias itself, so it stays an unknown pass-through token.
_ALIAS_OWNED_INSTALL_PARAMS = frozenset({"mcp_name"})
_FORWARDED_RAW_KEY = "apm_cli.commands.mcp.forwarded_install_args"


class _ForwardedInstallOption(click.Option):
    """An ``apm install`` option re-declared on ``apm mcp install``.

    Click still converts and validates the value here (same errors as
    ``apm install``), but the raw command-line value is recorded so it can be
    re-emitted verbatim to ``apm install``.
    """

    @classmethod
    def from_install_option(cls, source, *, hidden=False):
        """Clone an ``apm install`` option; ``__init__`` is never called.

        A shallow copy keeps every attribute of ``source`` (flags, type,
        help, metavar), and the class swap adds only this class's methods, so
        subclass state must not depend on ``__init__``.
        """
        if source.nargs != 1:
            raise TypeError(f"Cannot forward multi-value install option {source.name!r}")
        clone = copy.copy(source)
        clone.__class__ = cls
        # Values are forwarded raw; the alias callback never receives them.
        clone.expose_value = False
        clone.hidden = hidden or source.hidden
        return clone

    def consume_value(self, ctx, opts):
        value, source = super().consume_value(ctx, opts)
        if source is ParameterSource.COMMANDLINE:
            ctx.meta.setdefault(_FORWARDED_RAW_KEY, {})[self.name] = value
        return value, source

    def to_install_args(self, raw):
        """Rebuild the ``apm install`` tokens for a raw command-line value."""
        flag = next((opt for opt in self.opts if opt.startswith("--")), self.opts[0])
        if self.is_flag:
            if raw == self.flag_value:
                return [flag]
            return self.secondary_opts[:1]
        values = raw if self.multiple else [raw]
        return [token for value in values for token in (flag, value)]


def _borrow_install_options():
    """Clone every ``apm install`` option the alias forwards.

    The selected options are shown in help and completion. The rest are
    hidden but still parsed with install's own arity, so a pass-through
    value such as ``--root --dry-run`` is never split from its option.
    """
    from .install import install as install_command

    by_name = {
        param.name: param
        for param in install_command.params
        if isinstance(param, click.Option) and param.name not in _ALIAS_OWNED_INSTALL_PARAMS
    }
    shown = [by_name[name] for name in _FORWARDED_INSTALL_PARAMS]
    hidden = [param for name, param in by_name.items() if name not in _FORWARDED_INSTALL_PARAMS]
    return [
        *(_ForwardedInstallOption.from_install_option(param) for param in shown),
        *(_ForwardedInstallOption.from_install_option(param, hidden=True) for param in hidden),
    ]


class _InstallAliasCommand(click.Command):
    """``apm mcp install``: borrows its forwarded options from ``apm install``.

    The borrowed options load on first use so ``apm`` startup keeps
    ``apm install`` lazily imported.
    """

    _forwarded_loaded = False

    def get_params(self, ctx):
        if not self._forwarded_loaded:
            self.params.extend(_borrow_install_options())
            self._forwarded_loaded = True
        return super().get_params(ctx)

    def format_options(self, ctx, formatter):
        own, forwarded = [], []
        for param in self.get_params(ctx):
            record = param.get_help_record(ctx)
            if record is not None:
                is_forwarded = isinstance(param, _ForwardedInstallOption)
                (forwarded if is_forwarded else own).append(record)
        if own:
            with formatter.section("Options"):
                formatter.write_dl(own)
        if forwarded:
            with formatter.section("Forwarded install options"):
                formatter.write_dl(forwarded)


@mcp.command(
    name="install",
    cls=_InstallAliasCommand,
    context_settings={"ignore_unknown_options": True, "allow_extra_args": True},
    help=(
        "Add an MCP server to apm.yml. Alias for 'apm install --mcp'.\n\n"
        "Examples:\n\n"
        "  apm mcp install fetch -- npx -y @modelcontextprotocol/server-fetch\n\n"
        "  apm mcp install api --transport http --url https://example.com/mcp\n\n"
        "The forwarded install options below are defined by 'apm install'; "
        "'--mcp NAME' is implied, so their '(requires --mcp)' notes are already "
        "met. Other 'apm install' options are passed through unchanged; see "
        "'apm install --help' for the full list."
    ),
)
@click.argument("name", required=True)
@click.pass_context
def mcp_install(ctx, name):
    """Forward all args to 'apm install --mcp ...'.

    Examples:
        apm mcp install fetch -- npx -y @modelcontextprotocol/server-fetch
        apm mcp install api --transport http --url https://example.com/mcp
    """
    from apm_cli.cli import cli
    from apm_cli.commands.install import (
        _get_invocation_argv,
        _split_argv_at_double_dash,
    )

    # Click strips the ``--`` separator from ``ctx.args`` even when
    # ``ignore_unknown_options`` is set, so post-``--`` tokens like
    # ``-y`` would be re-parsed as Click options when forwarded to
    # ``cli.main()``.  Re-insert the boundary by inspecting the raw
    # process argv (same seam the ``install`` command uses).
    raw_values = ctx.meta.get(_FORWARDED_RAW_KEY, {})
    option_args = [
        token
        for param in ctx.command.get_params(ctx)
        if isinstance(param, _ForwardedInstallOption) and param.name in raw_values
        for token in param.to_install_args(raw_values[param.name])
    ]
    _, post_dd = _split_argv_at_double_dash(_get_invocation_argv())
    if post_dd:
        pre_args = ctx.args[: len(ctx.args) - len(post_dd)]
        forwarded = ["install", "--mcp", name, *option_args, *pre_args, "--", *post_dd]
    else:
        forwarded = ["install", "--mcp", name, *option_args, *ctx.args]

    # Standalone mode exits through the same path as 'apm install': the install
    # outcome owner's ctx.exit(code) and Click's error rendering and exit codes.
    cli.main(args=forwarded, prog_name="apm")


@mcp.command(help="Search MCP servers in registry")
@click.argument("query", required=True)
@click.option("--limit", default=10, show_default=True, help="Number of results to show")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed output")
@click.pass_context
def search(ctx, query, limit, verbose):
    """Search for MCP servers in the registry."""
    logger = CommandLogger("mcp-search", verbose=verbose)
    registry = None
    try:
        console = _get_console()
        registry = _build_registry_with_diag(console, logger)
        servers = registry.search_packages(query)[:limit]

        if not console:
            # Fallback for non-rich environments
            logger.progress(f"Searching for: {query}", symbol="search")
            if not servers:
                logger.warning("No servers found")
                return
            for server in servers:
                click.echo(f"  {server.get('name', 'Unknown')}")
                click.echo(f"    {server.get('description', 'No description')[:80]}")
            return

        # Professional header with search context
        console.print("\n[bold cyan]MCP Registry Search[/bold cyan]")
        console.print(f"[muted]Query: {query}[/muted]")

        if not servers:
            console.print(
                f"\n[yellow][!][/yellow] No MCP servers found matching '[bold]{query}[/bold]'"
            )
            console.print("\n[muted] Try broader search terms or check the spelling[/muted]")
            return

        # Results summary
        total_shown = len(servers)
        console.print(
            f"\n[green]+[/green] Found [bold]{total_shown}[/bold] MCP server{'s' if total_shown != 1 else ''}"
        )

        # Professional results table
        from apm_cli.utils.console import new_table

        table = new_table(show_header=True, header_style="bold cyan", border_style="cyan")
        table.add_column("Name", style="bold white", no_wrap=True, min_width=20)
        table.add_column("Description", style="white", ratio=1)
        table.add_column("Latest", style="cyan", justify="center", min_width=8)

        for server in servers:
            name = server.get("name", "Unknown")
            desc = server.get("description", "No description available")
            version = server.get("version", " --")

            # Intelligent description truncation
            if len(desc) > 80:
                # Find a good break point near the limit
                truncate_pos = 77
                if " " in desc[70:85]:
                    space_pos = desc.rfind(" ", 70, 85)
                    if space_pos > 70:
                        truncate_pos = space_pos
                desc = desc[:truncate_pos] + "..."

            table.add_row(name, desc, version)

        console.print(table)

        # Helpful next steps
        console.print(
            "\n[muted] Use [bold cyan]apm mcp show <name>[/bold cyan] for detailed information[/muted]"
        )
        if total_shown == limit:
            console.print(
                f"[muted]   Use [bold cyan]--limit {limit * 2}[/bold cyan] to see more results[/muted]"
            )

    except Exception as e:
        try:
            import requests

            if isinstance(e, requests.RequestException) and _handle_registry_network_error(
                e, registry, _get_console(), logger, "reach"
            ):
                sys.exit(1)
        except ImportError:
            pass
        logger.error(f"Error searching registry: {e}")
        sys.exit(1)


@mcp.command(help="Show detailed MCP server information")
@click.argument("server_name", required=True)
@click.option("--verbose", "-v", is_flag=True, help="Show detailed output")
@click.pass_context
def show(ctx, server_name, verbose):
    """Show detailed information about an MCP server."""
    logger = CommandLogger("mcp-show", verbose=verbose)
    registry = None
    try:
        console = _get_console()
        registry = _build_registry_with_diag(console, logger)

        if not console:
            # Fallback for non-rich environments
            logger.progress(f"Getting details for: {server_name}", symbol="search")
            try:
                server_info = registry.get_package_info(server_name)
                click.echo(f"Name: {server_info.get('name', 'Unknown')}")
                click.echo(f"Description: {server_info.get('description', 'No description')}")
                click.echo(f"Repository: {server_info.get('repository', {}).get('url', 'Unknown')}")
            except ValueError:
                logger.error(f"Server '{server_name}' not found")
                sys.exit(1)
            return

        # Professional loading indicator
        console.print("\n[bold cyan]MCP Server Details[/bold cyan]")
        console.print(f"[muted]Fetching: {server_name}[/muted]")

        try:
            server_info = registry.get_package_info(server_name)
        except ValueError:
            console.print(
                f"\n[red]x[/red] MCP server '[bold]{server_name}[/bold]' not found in registry"
            )
            console.print(
                "\n[muted] Use [bold cyan]apm mcp search <query>[/bold cyan] to find available servers[/muted]"
            )
            sys.exit(1)

        # Main server information in professional table format
        name = server_info.get("name", "Unknown")
        description = server_info.get("description", "No description available")

        # Get key metadata
        version = "Unknown"
        if "version_detail" in server_info:
            version = server_info["version_detail"].get("version", "Unknown")
        elif "version" in server_info:
            version = server_info["version"]

        repo_url = "Unknown"
        if "repository" in server_info:
            repo_url = server_info["repository"].get("url", "Unknown")

        # Professional server info table with consistent styling
        from apm_cli.utils.console import new_table

        # Main server information table
        info_table = new_table(
            title=f" MCP Server: {name}",
            show_header=True,
            header_style="bold cyan",
            border_style="cyan",
        )
        info_table.add_column("Property", style="bold white", min_width=12)
        info_table.add_column("Value", style="white", min_width=40)

        info_table.add_row("Name", f"[bold white]{name}[/bold white]")
        info_table.add_row("Version", f"[cyan]{version}[/cyan]")
        info_table.add_row("Description", description)
        info_table.add_row("Repository", repo_url)
        if "id" in server_info:
            info_table.add_row("Registry ID", server_info["id"][:8] + "...")

        # Add deployment type information
        remotes = server_info.get("remotes", [])
        packages = server_info.get("packages", [])

        deployment_info = []
        for remote in remotes:
            label = _REMOTE_DEPLOYMENT_LABELS.get(_remote_transport_label(remote))
            if label and label not in deployment_info:
                deployment_info.append(label)
        if packages:
            deployment_info.append(" Local Package")

        if deployment_info:
            info_table.add_row("Deployment Type", " + ".join(deployment_info))

        console.print(info_table)

        # Show remote endpoints if available
        if remotes:
            remote_table = new_table(
                title=" Remote Endpoints",
                show_header=True,
                header_style="bold cyan",
                border_style="cyan",
            )
            remote_table.add_column("Type", style="yellow", width=16)
            remote_table.add_column("URL", style="white", min_width=40)
            remote_table.add_column("Features", style="cyan", min_width=20)

            for remote in remotes:
                transport_type = _remote_transport_label(remote)
                url = remote.get("url", "unknown")

                # Describe features/limitations of remote endpoints
                features = "Hosted by provider"
                if "github" in name.lower():
                    features = "No toolset customization"

                remote_table.add_row(transport_type.upper(), url, features)

            console.print(remote_table)

        # Installation packages in consistent table format
        if packages:
            pkg_table = new_table(
                title=" Local Packages",
                show_header=True,
                header_style="bold cyan",
                border_style="cyan",
            )
            pkg_table.add_column("Registry", style="yellow", width=10)
            pkg_table.add_column("Package", style="white", min_width=25)
            pkg_table.add_column("Runtime", style="cyan", width=8, justify="center")
            pkg_table.add_column("Features", style="green", min_width=20)

            for pkg in packages:
                registry_name = pkg.get("registry_name", "unknown")
                pkg_name = pkg.get("name", "unknown")
                runtime_hint = pkg.get("runtime_hint", " --")

                # Describe features of local packages. Registry names such as
                # io.github.<owner>/... say nothing about GitHub toolsets (#3994).
                features = "Full configuration control"

                # Truncate long package names intelligently
                if len(pkg_name) > 25:
                    pkg_name = pkg_name[:22] + "..."

                pkg_table.add_row(registry_name, pkg_name, runtime_hint, features)

            console.print(pkg_table)

        # Installation instructions in structured table format
        install_name = server_info.get("name", server_name)
        install_table = new_table(
            title="* Installation Guide",
            show_header=True,
            header_style="bold cyan",
            border_style="green",
        )
        install_table.add_column("Step", style="bold white", width=5)
        install_table.add_column("Action", style="white", min_width=30)
        install_table.add_column("Command/Config", style="cyan", min_width=25)

        install_table.add_row(
            "1",
            "Add to apm.yml dependencies",
            f"[yellow]mcp:[/yellow] [cyan]- {install_name}[/cyan]",
        )
        install_table.add_row("2", "Install dependencies", "[bold cyan]apm install[/bold cyan]")
        install_table.add_row(
            "",
            "Or add and install in one step",
            f"[bold cyan]apm install --mcp {install_name}[/bold cyan]",
        )

        console.print(install_table)

    except Exception as e:
        try:
            import requests

            if isinstance(e, requests.RequestException) and _handle_registry_network_error(
                e, registry, _get_console(), logger, "reach"
            ):
                sys.exit(1)
        except ImportError:
            pass
        logger.error(f"Error getting server details: {e}")
        sys.exit(1)


@mcp.command(help="List all available MCP servers")
@click.option("--limit", default=20, show_default=True, help="Number of results to show")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed output")
@click.pass_context
def list(ctx, limit, verbose):  # noqa: F811
    """List all available MCP servers in the registry."""
    logger = CommandLogger("mcp-list", verbose=verbose)
    registry = None
    try:
        console = _get_console()
        registry = _build_registry_with_diag(console, logger)

        if not console:
            # Fallback for non-rich environments
            logger.progress("Fetching available MCP servers...", symbol="search")
            servers = registry.list_available_packages()[:limit]
            if not servers:
                logger.warning("No servers found")
                return
            for server in servers:
                click.echo(f"  {server.get('name', 'Unknown')}")
                click.echo(f"    {server.get('description', 'No description')[:80]}")
            return

        # Professional header
        console.print("\n[bold cyan]MCP Registry Catalog[/bold cyan]")
        console.print("[muted]Discovering available servers...[/muted]")

        servers = registry.list_available_packages()[:limit]

        if not servers:
            console.print("\n[yellow][!][/yellow] No MCP servers found in registry")
            console.print("\n[muted] The registry might be temporarily unavailable[/muted]")
            return

        # Results summary with pagination info
        total_shown = len(servers)
        console.print(f"\n[green]+[/green] Showing [bold]{total_shown}[/bold] MCP servers")
        if total_shown == limit:
            console.print(
                f"[muted]Use [bold cyan]--limit {limit * 2}[/bold cyan] to see more results[/muted]"
            )

        # Professional catalog table
        from apm_cli.utils.console import new_table

        table = new_table(show_header=True, header_style="bold cyan", border_style="cyan")
        table.add_column("Name", style="bold white", no_wrap=True, min_width=25)
        table.add_column("Description", style="white", ratio=1)
        table.add_column("Latest", style="cyan", justify="center", min_width=8)

        for server in servers:
            name = server.get("name", "Unknown")
            desc = server.get("description", "No description available")
            version = server.get("version", " --")

            # Intelligent description truncation
            if len(desc) > 80:
                # Find a good break point near the limit
                truncate_pos = 77
                if " " in desc[70:85]:
                    space_pos = desc.rfind(" ", 70, 85)
                    if space_pos > 70:
                        truncate_pos = space_pos
                desc = desc[:truncate_pos] + "..."

            table.add_row(name, desc, version)

        console.print(table)

        # Helpful navigation
        console.print(
            "\n[muted] Use [bold cyan]apm mcp show <name>[/bold cyan] for detailed information[/muted]"
        )
        console.print(
            "[muted]   Use [bold cyan]apm mcp search <query>[/bold cyan] to find specific servers[/muted]"
        )

    except Exception as e:
        try:
            import requests

            if isinstance(e, requests.RequestException) and _handle_registry_network_error(
                e, registry, _get_console(), logger, "reach"
            ):
                sys.exit(1)
        except ImportError:
            pass
        logger.error(f"Error listing servers: {e}")
        sys.exit(1)
