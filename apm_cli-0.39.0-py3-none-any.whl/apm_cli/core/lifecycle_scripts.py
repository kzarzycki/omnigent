"""Lifecycle script models, runner, and discovery.

APM supports lifecycle scripts that fire at key moments during install,
update, uninstall, and compile operations.  Scripts are configured in
well-known locations discovered from three tiers:

1. Policy  -- platform-specific admin directory (JSON drop-ins, unchanged)
2. User    -- ~/.apm/apm.yml (or $APM_HOME/apm.yml) lifecycle: key
3. Project -- apm.yml lifecycle: key (repo root)

Admin tier uses {version:1, scripts:{...}} JSON files in a directory.
Project and user tiers embed scripts under a top-level lifecycle: key
in apm.yml -- the manifest is the envelope, so there is no version/scripts
wrapper inside the lifecycle block.

Two script types are supported; each entry must declare its kind via a
type field:

- type: command -- shell command (bash / command / run fields)
- type: http    -- HTTPS POST to a URL with optional headers

An optional description field may be added to any entry as a
free-text annotation (surfaced in dry-run output; otherwise ignored).

Scripts run in source order at each event.  Failures are isolated: a
script error is logged (verbose) but never aborts the CLI operation.
HTTP scripts dispatch asynchronously (daemon thread); command scripts
run synchronously and can therefore delay the operation up to their
timeout.  Use APM_NO_SCRIPTS=1 to disable all scripts for one run.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import platform
import threading
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path, PureWindowsPath
from typing import TYPE_CHECKING

from apm_cli.core.remediation import LIFECYCLE_SCRIPTS_UNTRUSTED
from apm_cli.core.scope import manifest_file

if TYPE_CHECKING:
    from collections.abc import Iterable

    from apm_cli.core.command_logger import CommandLogger
    from apm_cli.models.dependency.reference import DependencyReference

_logger = logging.getLogger(__name__)

# Supported lifecycle event names.
LIFECYCLE_EVENTS = (
    "pre-install",
    "post-install",
    "pre-update",
    "post-update",
    "pre-uninstall",
    "post-uninstall",
    "pre-compile",
)

# Supported script action types.
SCRIPT_TYPES = ("command", "http")

# Current script-file schema version (used by admin/user JSON tier only).
SCRIPT_FILE_VERSION = 1


# -- Event model -----------------------------------------------------------


@dataclass
class PackageInfo:
    """Minimal package metadata carried in lifecycle events."""

    name: str
    reference: str | None = None


@dataclass
class LifecycleEvent:
    """Data payload passed to every lifecycle script.

    HTTP scripts receive this as a JSON POST body.  Command scripts
    receive it via stdin (JSON-encoded).
    """

    schema_version: int = 1
    event: str = ""
    packages: list[PackageInfo] = field(default_factory=list)
    scope: str = "project"
    timestamp: str = ""
    cli_version: str = ""
    working_directory: str = ""

    def to_json(self) -> str:
        """Serialise the event to a compact JSON string."""
        return json.dumps(asdict(self), separators=(",", ":"))

    @staticmethod
    def create(
        event: str,
        packages: list[PackageInfo] | None = None,
        scope: str = "project",
        working_directory: str | None = None,
    ) -> LifecycleEvent:
        """Factory that auto-fills timestamp and CLI version."""
        from apm_cli.version import get_version

        return LifecycleEvent(
            event=event,
            packages=packages or [],
            scope=scope,
            timestamp=datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            cli_version=get_version(),
            working_directory=working_directory or str(Path.cwd()),
        )


def event_for_dependencies(
    event_name: str,
    dependencies: Iterable[DependencyReference],
    *,
    scope: str,
    working_directory: str | None,
) -> LifecycleEvent:
    """Build the event payload for a manifest's dependency references.

    The one place that turns dependencies into the payload's package list,
    shared by install, update and compile.
    """
    return LifecycleEvent.create(
        event=event_name,
        packages=[
            PackageInfo(
                name=getattr(dep, "repo_url", None) or str(dep),
                reference=getattr(dep, "reference", None),
            )
            for dep in dependencies
        ],
        scope=scope,
        working_directory=working_directory,
    )


# -- Script entry (one action inside a script file) ------------------------


@dataclass
class ScriptEntry:
    """One configured lifecycle script action.

    Attributes:
        script_type: command or http.
        event:       Lifecycle event name (e.g. post-install).
        bash:        Shell command for Unix (command type).
        command:     Cross-platform fallback command string.
        url:         HTTP endpoint URL (http type).
        headers:     HTTP headers dict; values support $ENV_VAR expansion.
        timeout_sec: Timeout in seconds (default 30 for commands, 10 for http).
        cwd:         Working directory for the command (relative or absolute).
        env:         Extra environment variables for the command.
        allowed_env_vars: Opt-in allowlist of env var names that may be
                     passed through / expanded even if they match the
                     credential denylist (e.g. ANALYTICS_TOKEN).
        description: Optional free-text annotation for the script entry.
                     Surfaced in dry-run output; otherwise ignored.
        source:      Where this script was defined: policy, user, or project.
        source_file: Path of the file that declared this script.
    """

    script_type: str
    event: str
    bash: str | None = None
    command: str | None = None
    url: str | None = None
    headers: dict[str, str] | None = None
    timeout_sec: int | None = None
    cwd: str | None = None
    env: dict[str, str] | None = None
    allowed_env_vars: list[str] | None = None
    description: str | None = None
    source: str = "project"
    source_file: str | None = None

    @property
    def effective_command(self) -> str | None:
        """Resolve the command to run on the current platform.

        On Windows, prefer command (cross-platform) over bash
        because bash may not be available.  On Unix, prefer bash.
        """
        if platform.system() == "Windows":
            return self.command or self.bash
        return self.bash or self.command

    @property
    def effective_timeout(self) -> int:
        """Return timeout_sec with sensible defaults per type."""
        if self.timeout_sec is not None:
            return self.timeout_sec
        return _default_timeout(self.script_type)


def _default_timeout(script_type: str) -> int:
    """Per-type default timeout in seconds (http 10, command 30)."""
    return 10 if script_type == "http" else 30


# -- Script file parsing ---------------------------------------------------


def _parse_allowed_env_vars(raw: object) -> list[str] | None:
    """Normalise the optional allowedEnvVars field to a str list."""
    if not isinstance(raw, list):
        return None
    names = [str(v) for v in raw if isinstance(v, str) and v.strip()]
    return names or None


_invalid_timeout_warned: set[tuple[str, str, int, str]] = set()


def _resolve_timeout(
    raw: dict, script_type: str, event_name: str, index: int, path: Path
) -> object:
    """Read timeoutSec (or its timeout alias), rejecting non-positive numbers.

    A non-positive numeric timeout is invalid under either spelling: it is
    dropped to None (the per-type default) with one warning naming the script.
    Commands that rediscover scripts per event (update, uninstall) reparse the
    same entry, so the warning is emitted once per process (one CLI command).
    """

    def _is_number(v: object) -> bool:
        return isinstance(v, (int, float)) and not isinstance(v, bool)

    key, value = "timeoutSec", raw.get("timeoutSec")
    if not (_is_number(value) or value):
        key, value = "timeout", raw.get("timeout")
    if _is_number(value) and value <= 0:
        warn_key = (str(path), event_name, index, key)
        if warn_key not in _invalid_timeout_warned:
            _invalid_timeout_warned.add(warn_key)
            from apm_cli.utils.console import _rich_warning

            _rich_warning(
                f"Lifecycle script {event_name}[{index}] ({script_type}) in {path}: "
                f"{key} must be positive; using the default of "
                f"{_default_timeout(script_type)}s.",
                symbol="warning",
            )
        return None
    return value


def _build_entry(
    raw: object, event_name: str, path: Path, source: str, index: int = 0
) -> ScriptEntry | None:
    """Build a single ScriptEntry from a raw mapping.

    Returns None if raw is not a dict or has an unknown type.
    """
    if not isinstance(raw, dict):
        return None
    script_type = raw.get("type")
    if script_type is None:
        script_type = "http" if raw.get("url") else "command"
    if script_type not in SCRIPT_TYPES:
        _logger.debug("Ignoring unknown script type %s in %s", script_type, path)
        return None
    # run: is an accepted alias for bash/command
    run_val = raw.get("run")
    bash_val = raw.get("bash") or (run_val if run_val and not raw.get("bash") else None)
    command_val = raw.get("command") or (run_val if run_val and not raw.get("command") else None)
    return ScriptEntry(
        script_type=script_type,
        event=event_name,
        bash=bash_val,
        command=command_val,
        url=raw.get("url"),
        headers=raw.get("headers"),
        timeout_sec=_resolve_timeout(raw, script_type, event_name, index, path),
        cwd=raw.get("cwd"),
        env=raw.get("env"),
        allowed_env_vars=_parse_allowed_env_vars(raw.get("allowedEnvVars")),
        description=raw.get("description"),
        source=source,
        source_file=str(path),
    )


def _entries_from_data(data: object, path: Path, source: str) -> list[ScriptEntry]:
    """Build ScriptEntry list from an already-parsed data dict.

    Used by the admin/user JSON tier (version+scripts wrapper required).
    Returns an empty list if data is malformed or uses an unsupported version.
    """
    if not isinstance(data, dict):
        return []

    version = data.get("version")
    if version != SCRIPT_FILE_VERSION:
        _logger.debug("Skipping script file %s: unsupported version %s", path, version)
        return []

    scripts_dict = data.get("scripts")
    if not isinstance(scripts_dict, dict):
        return []

    entries: list[ScriptEntry] = []
    for event_name, script_list in scripts_dict.items():
        if event_name not in LIFECYCLE_EVENTS:
            _logger.debug("Ignoring unknown lifecycle event %s in %s", event_name, path)
            continue
        if not isinstance(script_list, list):
            continue
        for index, raw in enumerate(script_list):
            entry = _build_entry(raw, event_name, path, source, index)
            if entry is not None:
                entries.append(entry)
    return entries


def _entries_from_lifecycle_map(lifecycle: object, path: Path, source: str) -> list[ScriptEntry]:
    """Build ScriptEntry list from the lifecycle: subtree of an apm.yml dict.

    No version check -- apm.yml has no version field for the lifecycle block.
    Returns an empty list if lifecycle is not a dict.
    """
    if not isinstance(lifecycle, dict):
        return []

    entries: list[ScriptEntry] = []
    for event_name, script_list in lifecycle.items():
        if event_name not in LIFECYCLE_EVENTS:
            _logger.debug("Ignoring unknown lifecycle event %s in %s", event_name, path)
            continue
        if not isinstance(script_list, list):
            continue
        for index, raw in enumerate(script_list):
            entry = _build_entry(raw, event_name, path, source, index)
            if entry is not None:
                entries.append(entry)
    return entries


def parse_apm_yml_lifecycle(path: Path, source: str) -> list[ScriptEntry]:
    """Parse the lifecycle: subtree from an apm.yml file.

    Used for both project (apm.yml at repo root) and user
    (~/.apm/apm.yml) tiers.  Returns an empty list if the file is
    missing, malformed, or has no lifecycle: key.
    """
    return parse_apm_yml_lifecycle_with_fingerprint(path, source)[0]


def parse_apm_yml_lifecycle_with_fingerprint(
    path: Path, source: str
) -> tuple[list[ScriptEntry], str | None]:
    """Parse the lifecycle: subtree AND fingerprint it from a single read.

    Returning both from one ``load_yaml`` call lets the trust gate
    fingerprint the EXACT content that will execute -- closing the
    TOCTOU window that exists when discovery and the trust check read
    the file independently. A non-dict top-level degrades to empty
    (no crash on a malformed/hostile manifest).
    """
    from apm_cli.core.script_trust import fingerprint_lifecycle_subtree
    from apm_cli.utils.yaml_io import load_yaml

    try:
        data = load_yaml(path)
    except Exception as e:
        _logger.debug("Failed to load apm.yml lifecycle from %s: %s", path, e)
        return [], None

    if not isinstance(data, dict):
        return [], None

    lifecycle = data.get("lifecycle")
    entries = _entries_from_lifecycle_map(lifecycle, path, source)
    return entries, fingerprint_lifecycle_subtree(lifecycle)


def parse_script_file(path: Path, source: str = "project") -> list[ScriptEntry]:
    """Parse a single JSON script file into a list of ScriptEntry.

    Used for JSON-backed sources such as the platform-specific admin policy
    tier. Returns an empty list if the file is malformed or uses an unsupported
    version.
    """
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError, RecursionError) as e:
        # ValueError subsumes JSONDecodeError and UnicodeDecodeError, plus the
        # CPython int-string conversion limit (a bare ValueError raised on a
        # >4300-digit integer literal) so a malformed policy drop-in fails
        # closed to [] instead of crashing discovery and the install fire path.
        _logger.debug("Failed to load script file %s: %s", path, e)
        return []

    return _entries_from_data(data, path, source)


def parse_project_script_file(path: Path) -> list[ScriptEntry]:
    """Parse the project-tier apm.yml lifecycle: key.

    Thin alias for parse_apm_yml_lifecycle kept for backward compatibility.
    """
    return parse_apm_yml_lifecycle(path, "project")


# -- Script discovery ------------------------------------------------------


def _get_policy_scripts_dir() -> Path:
    """Return the platform-specific policy scripts directory.

    Windows normally supplies an absolute ``ProgramData`` environment value.
    Fall back to its historical default when that value is missing or unsafe.
    """
    system = platform.system()
    if system == "Windows":
        program_data = os.environ.get("PROGRAMDATA")
        if not program_data or not PureWindowsPath(program_data).is_absolute():
            program_data = r"C:\ProgramData"
        return Path(program_data) / "APM" / "policy.d"
    return Path("/etc/apm/policy.d")


def _get_user_apm_yml() -> Path:
    """Return the user-level apm.yml path (~/.apm/apm.yml or $APM_HOME/apm.yml)."""
    from apm_cli.core.scope import InstallScope, get_manifest_path

    return get_manifest_path(InstallScope.USER)


def _get_project_apm_yml(project_root: str | None = None) -> Path:
    """Return the project-level apm.yml path at the repo root."""
    root = Path(project_root) if project_root else Path.cwd()
    return manifest_file(root)


def _is_project_tier(project_yml: Path) -> bool:
    """Whether *project_yml* is a project manifest rather than the user-scope one.

    At user scope the command's manifest is ``$APM_HOME/apm.yml``, which the
    user tier already loads; it is not a second, project tier.
    """
    from apm_cli.core.scope import is_user_scope_root

    return not is_user_scope_root(project_yml.parent)


def _load_scripts_from_dir(
    directory: Path,
    source: str,
) -> list[ScriptEntry]:
    """Load all *.json script files from directory, sorted by name."""
    if not directory.is_dir():
        return []
    entries: list[ScriptEntry] = []
    for json_file in sorted(directory.glob("*.json")):
        if json_file.is_file():
            entries.extend(parse_script_file(json_file, source=source))
    return entries


def discover_scripts(
    project_root: str | None = None,
) -> list[ScriptEntry]:
    """Discover and merge scripts from all three sources.

    Load order (all additive, policy first):
      1. Policy  -- platform-specific admin directory (JSON)
      2. User    -- ~/.apm/apm.yml (or $APM_HOME/apm.yml) lifecycle: key
      3. Project -- apm.yml lifecycle: key (repo root)
    """
    scripts = _discover_non_project_scripts(project_root)
    project_yml = _get_project_apm_yml(project_root)
    if project_yml.is_file() and _is_project_tier(project_yml):
        scripts.extend(parse_apm_yml_lifecycle(project_yml, "project"))
    return scripts


def _discover_non_project_scripts(
    project_root: str | None = None,
) -> list[ScriptEntry]:
    """Discover policy + user scripts (everything except the project tier).

    Kept separate so the firing path can read the project tier ONCE (for
    both execution and the trust fingerprint) without re-reading it here.
    """
    scripts: list[ScriptEntry] = []
    scripts.extend(_load_scripts_from_dir(_get_policy_scripts_dir(), source="policy"))

    user_yml = _get_user_apm_yml()
    if user_yml.is_file():
        scripts.extend(parse_apm_yml_lifecycle(user_yml, "user"))

    return scripts


# -- Script runner ---------------------------------------------------------


class LifecycleScriptRunner:
    """Collects scripts and fires them for lifecycle events.

    Scripts run with error isolation: a failure in one script never blocks
    the CLI or the remaining scripts.  http scripts dispatch
    asynchronously; command scripts run synchronously and may delay
    the operation up to their per-script timeout.
    """

    def __init__(
        self,
        scripts: list[ScriptEntry] | None = None,
        logger: CommandLogger | None = None,
        verbose: bool = False,
        project_root: str | None = None,
        skipped_project_scripts: int = 0,
        skipped_project_file: str | None = None,
        policy_unenforced: bool = False,
    ) -> None:
        self._scripts = scripts or []
        self._logger = logger
        self._verbose = verbose
        self._project_root = project_root
        self._skipped_project_scripts = skipped_project_scripts
        self._skipped_project_file = skipped_project_file
        self._skip_notice_emitted = False
        # Org policy was unavailable under fetch_failure_default=warn (#4913).
        self._policy_unenforced = policy_unenforced
        self._policy_notice_emitted = False

    def _emit_policy_notice(self) -> None:
        """Warn once, before scripts run, that org policy was not applied (#4913).

        Once per command logger (several runners may share one command), or
        once per runner when there is no logger.
        """
        if not self._policy_unenforced or self._policy_notice_emitted:
            return
        self._policy_notice_emitted = True
        msg = "org policy not applied to lifecycle scripts (policy unavailable; fetch_failure_default=warn)"
        if self._logger is None:
            from apm_cli.utils.console import _rich_warning

            _rich_warning(msg, symbol="warning")
            return
        if getattr(self._logger, _UNRESOLVED_POLICY_NOTED, None) is True:
            return
        emit = getattr(self._logger, "warning", None) or getattr(
            self._logger, "verbose_detail", None
        )
        if emit is not None:
            emit(msg)
        with contextlib.suppress(AttributeError):
            setattr(self._logger, _UNRESOLVED_POLICY_NOTED, True)

    def _emit_skip_notice(self) -> None:
        """Warn once that untrusted project scripts were skipped."""
        if self._skip_notice_emitted or self._skipped_project_scripts <= 0:
            return
        self._skip_notice_emitted = True
        count = self._skipped_project_scripts
        msg = (
            f"Skipped {count} untrusted project script(s). {LIFECYCLE_SCRIPTS_UNTRUSTED.sentence()}"
        )
        if self._logger is not None:
            emit = getattr(self._logger, "warning", None) or getattr(
                self._logger, "verbose_detail", None
            )
            if emit is not None:
                emit(msg)
        else:
            _logger.warning("%s", msg)

    def fire(self, event_name: str, event: LifecycleEvent) -> list[threading.Thread]:
        """Execute all scripts registered for event_name.

        Each script runs in isolation -- a failure in one script does not
        prevent subsequent scripts from running.

        Returns a list of daemon threads started by HTTP scripts so
        callers can optionally join them (e.g. for test/dry-run).
        """
        from apm_cli.core.invocation_memo import forget_invocation_memos
        from apm_cli.core.script_executors import dispatch_http_batch, execute_script

        self._emit_skip_notice()

        matching = [s for s in self._scripts if s.event == event_name]
        if not matching:
            return []
        self._emit_policy_notice()
        # Scripts run outside APM, so they must observe the committed lockfile.
        from apm_cli.deps.lockfile_write_authority import flush_lockfile_writes

        flush_lockfile_writes()

        # command scripts run synchronously (in declared order); http
        # scripts dispatch through a bounded worker pool so a file with
        # many http entries cannot spawn an unbounded number of threads.
        http_scripts: list[ScriptEntry] = []
        for script in matching:
            if script.script_type == "http":
                http_scripts.append(script)
                continue
            from apm_cli.utils.realpath_win import release_held

            release_held()  # user code may rename or delete what APM holds
            try:
                execute_script(
                    script,
                    event,
                    logger=self._logger,
                    verbose=self._verbose,
                    project_root=self._project_root,
                )
            except Exception:
                _logger.debug(
                    "Lifecycle script failed (type=%s, event=%s)",
                    script.script_type,
                    event_name,
                    exc_info=True,
                )
                if self._verbose and self._logger:
                    self._logger.verbose_detail(
                        f"[i] Lifecycle script failed: {script.script_type} for {event_name}"
                    )
            finally:
                # The script may have changed credentials or the git remote,
                # whether it succeeded, failed or raised.
                forget_invocation_memos()

        return dispatch_http_batch(
            http_scripts,
            event,
            logger=self._logger,
            verbose=self._verbose,
        )

    def scripts_for_event(self, event_name: str) -> list[ScriptEntry]:
        """Return scripts registered for event_name (public API)."""
        return [s for s in self._scripts if s.event == event_name]


# -- Convenience: build runner from file-based discovery -------------------


# Attribute a command logger carries once it printed the suppression notice.
_SUPPRESSION_NOTED = "_apm_lifecycle_suppression_noted"

# Attribute a command logger carries once it printed the unresolved-policy
# (fetch_failure_default=warn) notice, so it fires once per command (#4913).
_UNRESOLVED_POLICY_NOTED = "_apm_lifecycle_unresolved_policy_noted"


def build_runner_from_context(
    *,
    logger: CommandLogger | None = None,
    verbose: bool = False,
    project_root: str | None = None,
    events: tuple[str, ...] | None = None,
) -> LifecycleScriptRunner:
    """Create a LifecycleScriptRunner via file-based discovery.

    ``events`` limits the runner to those events, so a command whose events
    have no scripts returns before org-policy discovery.

    Scans policy (JSON), user (apm.yml lifecycle:), and project (apm.yml
    lifecycle:) script sources.

    Three safeguards are applied at this firing boundary:

    - APM_NO_SCRIPTS (env, any non-empty value) disables ALL scripts
      for the current invocation -- a blanket escape hatch for CI and
      untrusted clones.
    - Org executables.deny_all (org policy kill-switch): when set,
      suppresses all lifecycle scripts as a one-directional safety
      ceiling. A discovery error or a blocking outcome (for example
      fetch_failure_default=block, a hash mismatch, or an inheritance
      chain error) also fails CLOSED and suppresses scripts -- it never
      raises into the command; with a command *logger*, that logger
      prints an "org policy could not be enforced" notice. Under
      fetch_failure_default=warn an unavailable policy does NOT suppress
      scripts (the warn posture is unchanged), but the runner prints a
      one-time notice before the first script it runs, so the operator
      knows the org ceiling was not applied (#4913).
    - Project-source scripts (apm.yml lifecycle:) are dropped unless
      their exact lifecycle: subtree has been explicitly trusted via
      apm lifecycle trust (see apm_cli.core.script_trust). Policy and
      user scripts come from developer-controlled locations and are
      never gated.
    """
    if os.environ.get("APM_NO_SCRIPTS"):
        return LifecycleScriptRunner(
            scripts=[], logger=logger, verbose=verbose, project_root=project_root
        )

    from apm_cli.core.script_trust import is_fingerprint_trusted

    # Single read of the project tier: the entries that EXECUTE and the
    # fingerprint that GATES them come from one parse, so a swap between
    # an independent discovery read and trust read cannot run malicious
    # scripts under a stale "trusted" verdict (TOCTOU).
    scripts = _discover_non_project_scripts(project_root)
    project_yml = _get_project_apm_yml(project_root)
    project_entries: list[ScriptEntry] = []
    project_fp: str | None = None
    try:
        if project_yml.is_file() and _is_project_tier(project_yml):
            project_entries, project_fp = parse_apm_yml_lifecycle_with_fingerprint(
                project_yml, "project"
            )
    except OSError:
        # Path.is_file() only swallows ENOENT/ENOTDIR/EBADF/ELOOP; a
        # concurrent symlink swap or a hostile parent can surface
        # EINVAL/EACCES/ENAMETOOLONG here, on the firing boundary. The
        # project tier must fail CLOSED (skip project scripts) rather than
        # abort the install/update/uninstall flow.
        project_entries, project_fp = [], None
    scripts.extend(project_entries)
    if events is not None:
        scripts = [script for script in scripts if script.event in events]

    if not scripts:
        return LifecycleScriptRunner(
            scripts=[], logger=logger, verbose=verbose, project_root=project_root
        )

    # Org deny_all ceiling, resolved through the install gate's outcome
    # routing: a policy outcome that blocks install (hash mismatch,
    # fetch_failure_default=block, cached fetch_failure=block) also
    # suppresses scripts, as does a policy that cannot be resolved at all
    # (for example an inheritance chain error). Errors never raise into the
    # command.
    #
    # Under fetch_failure_default=warn an unavailable policy does NOT
    # suppress scripts (the warn posture is unchanged), but the operator
    # must still be told org policy could not be enforced before lifecycle
    # scripts run -- otherwise the scripts fire with no notice at all
    # (#4913). The runner emits it before the first script it fires.
    suppressed_reason = None
    unresolved_warn = False
    try:
        from apm_cli.install.errors import PolicyViolationError
        from apm_cli.policy.discovery import discover_policy_with_chain
        from apm_cli.policy.outcome_routing import (
            classify_discovery_outcome,
            route_discovery_outcome,
        )
        from apm_cli.policy.project_config import read_project_fetch_failure_default

        # Discovery joins paths onto the root, so a str root would raise
        # TypeError here and the except below would suppress every script.
        root = Path(project_root) if project_root else Path.cwd()
        fetch_result = discover_policy_with_chain(root)
        resolved = getattr(fetch_result, "policy", None)
        if resolved is not None and resolved.executables.deny_all:
            suppressed_reason = "org policy (executables.deny_all)"
        elif fetch_result is not None:
            fetch_failure_default = read_project_fetch_failure_default(root)
            try:
                route_discovery_outcome(
                    fetch_result,
                    logger=None,
                    fetch_failure_default=fetch_failure_default,
                )
            except PolicyViolationError:
                suppressed_reason = "org policy could not be enforced"
            else:
                # No block: under warn an unresolved policy leaves scripts
                # running, so surface a one-time notice (#4913). A resolved
                # policy or a clean "no policy" outcome (absent /
                # no_git_remote with no assertion) is not unresolved.
                route = classify_discovery_outcome(
                    fetch_result, fetch_failure_default=fetch_failure_default
                )
                unresolved_warn = (
                    fetch_failure_default != "block" and route.unresolved and route.policy is None
                )
    except Exception:
        _logger.debug("Lifecycle org-policy check failed", exc_info=True)
        suppressed_reason = "org policy could not be enforced"

    if suppressed_reason is not None:
        # One command may build several runners (update, then its install
        # pipeline); the notice is printed once per command logger (#4333).
        if logger is not None and getattr(logger, _SUPPRESSION_NOTED, None) != suppressed_reason:
            emit = getattr(logger, "warning", None) or getattr(logger, "verbose_detail", None)
            if emit is not None:
                emit(f"Lifecycle scripts suppressed by {suppressed_reason}.")
            with contextlib.suppress(AttributeError):
                setattr(logger, _SUPPRESSION_NOTED, suppressed_reason)
        return LifecycleScriptRunner(
            scripts=[], logger=logger, verbose=verbose, project_root=project_root
        )

    project_trusted = is_fingerprint_trusted(project_yml, project_fp)

    kept: list[ScriptEntry] = []
    skipped = 0
    for script in scripts:
        if script.source == "project" and not project_trusted:
            skipped += 1
            continue
        kept.append(script)

    return LifecycleScriptRunner(
        scripts=kept,
        logger=logger,
        verbose=verbose,
        project_root=project_root,
        skipped_project_scripts=skipped,
        skipped_project_file=str(project_yml) if skipped else None,
        # The runner warns only before scripts it actually fires, so an
        # unrelated event or a trust-filtered script never prints it (#4913).
        policy_unenforced=unresolved_warn,
    )
