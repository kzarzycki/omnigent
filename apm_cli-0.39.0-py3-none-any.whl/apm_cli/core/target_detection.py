"""Target detection for auto-selecting compilation and integration targets.

This module implements the auto-detection pattern for determining which agent
targets (Copilot, Claude, Cursor, OpenCode, Codex, Gemini, Antigravity, Kiro) should be used
based on existing project structure and configuration.

Detection priority (highest to lowest):
1. Explicit --target flag (always wins)
2. apm.yml target setting (top-level field)
3. Auto-detect from existing folders:
   - .github/ only -> copilot (internal: "vscode")
   - .claude/ only -> claude
   - .cursor/ only -> cursor
   - .opencode/ only -> opencode
   - .codex/ only -> codex
   - .gemini/ only -> gemini
   - Multiple target folders -> all
   - None exist -> minimal (AGENTS.md only, no folder integration)

"copilot" is the user-facing target name; "agents" is a deprecated alias.
"vscode" is a deprecated alias of "copilot" (#3866); the internal compile
family for Copilot is still spelled "vscode".
"""

import warnings
from collections.abc import Callable, Iterable, Iterator
from functools import cached_property
from pathlib import Path
from typing import Literal, Union

import click

from apm_cli.core.deprecations import deprecation_message
from apm_cli.core.target_catalog import (
    TARGET_CAPABILITIES,
    TargetCapability,
    accepted_target_values,
    canonical_target_token,
    deprecated_target_alias_message,
    expand_all,
    first_deprecated_target_alias,
    get_target_capability,
    is_vendor_target_id,
    normalize_target_name,
    target_error_values,
)


class AgentsTargetDeprecationWarning(DeprecationWarning):
    """Raised when the legacy ``--target agents`` alias is used.

    Scoped subclass so that :mod:`apm_cli.cli` can suppress *only* this
    deprecation (keeping all other ``DeprecationWarning`` s visible).
    """


# Module-level flag: set by :func:`parse_target_field` when the raw input
# contains the ``"agents"`` token, BEFORE alias resolution collapses it.
# Consumed by downstream phases (e.g. ``phases/targets.py``) that need to
# emit a formatted logger warning.  Single-threaded CLI; reset at the top
# of each :func:`parse_target_field` call.
_agents_alias_detected: bool = False


def agents_alias_was_detected() -> bool:
    """Return *True* if the most recent ``parse_target_field()`` saw ``'agents'``."""
    return _agents_alias_detected


# Valid target values (internal canonical form)
TargetType = Literal[
    "agent-skills",
    "antigravity",
    "claude",
    "codex",
    "copilot-app",
    "copilot-cowork",
    "cursor",
    "gemini",
    "grok-bot",
    "grok-build",
    "grok-cloud",
    "hermes",
    "kiro",
    "openclaw",
    "opencode",
    "vscode",
    "windsurf",
    "all",
    "minimal",
]

# Compiler families used inside a multi-target frozenset. Narrower than
# TargetType because the families are produced by _resolve_compile_target()
# (in the compile CLI) from CLI-validated target names.
#
# Family semantics:
#   "agents"  -> AGENTS.md is generated (any of copilot/vscode/agents/cursor/
#                opencode/codex was requested)
#   "vscode"  -> .github/copilot-instructions.md is generated (only when
#                copilot/vscode/agents was specifically requested -- NOT for
#                cursor/opencode/codex which use their own native config files)
#   "claude"  -> CLAUDE.md is generated
#   "gemini"  -> GEMINI.md is generated
CompileFamily = Literal["agents", "vscode", "claude", "gemini"]

# Compile target: either a single TargetType string or a frozenset of compiler
# families ({"agents", "claude", "gemini"}) for multi-target lists.
CompileTargetType = Union[TargetType, frozenset[CompileFamily]]  # noqa: UP007

# Detection reason returned by detect_target() when no integration folder is
# present. Exported as a constant so consumers can compare with equality
# instead of substring matching.
REASON_NO_TARGET_FOLDER = "no target folder found"

# User-facing target values (includes aliases accepted by CLI)
UserTargetType = Literal[
    "agent-skills",
    "agents",
    "antigravity",
    "claude",
    "codex",
    "copilot",
    "cursor",
    "gemini",
    "grok-bot",
    "grok-build",
    "hermes",
    "kiro",
    "opencode",
    "vscode",
    "windsurf",
    "all",
    "minimal",
]


def _declared_target(value: str | None) -> TargetType | None:
    """Resolve an explicit or configured target through the target catalog.

    Copilot spellings and MCP-only targets route to the internal ``vscode``
    value; every other catalog target keeps its canonical name, so targets
    without root-context output (skills-only and experimental targets) are
    honored instead of falling back to auto-detection (#3842).
    """
    if not value:
        return None
    if value == "all":
        return "all"
    try:
        capability = get_target_capability(value)
    except KeyError:
        return None
    if capability.compile_family == "vscode" or capability.mcp_only:
        return "vscode"
    return capability.name  # type: ignore[return-value]


def detect_target(  # noqa: PLR0911
    project_root: Path,
    explicit_target: str | None = None,
    config_target: str | None = None,
) -> tuple[TargetType, str]:
    """Detect the appropriate target for compilation and integration.

    Args:
        project_root: Root directory of the project
        explicit_target: Explicitly provided --target flag value
        config_target: Target from apm.yml top-level 'target' field

    Returns:
        Tuple of (target, reason) where:
        - target: The detected target type
        - reason: Human-readable explanation for the choice
    """
    # Priority 1: Explicit --target flag
    declared = _declared_target(explicit_target)
    if declared is not None:
        return declared, "explicit --target flag"

    # Priority 2: apm.yml target setting
    declared = _declared_target(config_target)
    if declared is not None:
        return declared, "apm.yml target"

    # Priority 3: Auto-detect from existing folders
    github_exists = (project_root / ".github").exists()
    claude_exists = (project_root / ".claude").exists()
    cursor_exists = (project_root / ".cursor").is_dir()
    opencode_exists = (project_root / ".opencode").is_dir()
    codex_exists = (project_root / ".codex").is_dir()
    gemini_exists = (project_root / ".gemini").is_dir()
    windsurf_exists = (project_root / ".windsurf").is_dir()
    kiro_exists = (project_root / ".kiro").is_dir()
    grok_exists = (project_root / ".grok").is_dir()
    detected = []
    if github_exists:
        detected.append(".github/")
    if claude_exists:
        detected.append(".claude/")
    if cursor_exists:
        detected.append(".cursor/")
    if opencode_exists:
        detected.append(".opencode/")
    if codex_exists:
        detected.append(".codex/")
    if gemini_exists:
        detected.append(".gemini/")
    if windsurf_exists:
        detected.append(".windsurf/")
    if kiro_exists:
        detected.append(".kiro/")
    if grok_exists:
        detected.append(".grok/")

    if len(detected) >= 2:
        return "all", f"detected {' and '.join(detected)} folders"
    elif github_exists:
        return "vscode", "detected .github/ folder"
    elif claude_exists:
        return "claude", "detected .claude/ folder"
    elif cursor_exists:
        return "cursor", "detected .cursor/ folder"
    elif opencode_exists:
        return "opencode", "detected .opencode/ folder"
    elif codex_exists:
        return "codex", "detected .codex/ folder"
    elif gemini_exists:
        return "gemini", "detected .gemini/ folder"
    elif windsurf_exists:
        return "windsurf", "detected .windsurf/ folder"
    elif kiro_exists:
        return "kiro", "detected .kiro/ folder"
    elif grok_exists:
        return "grok-build", "detected .grok/ folder"
    else:
        return "minimal", REASON_NO_TARGET_FOLDER


def should_compile_agents_md(target: CompileTargetType) -> bool:
    """Check if AGENTS.md should be compiled.

    AGENTS.md is generated for vscode, cursor, opencode, codex, gemini,
    claude, windsurf, kiro, antigravity, grok-build, hermes, all, and minimal
    targets. Gemini and Claude need it because GEMINI.md and CLAUDE.md import
    AGENTS.md.

    Args:
        target: The detected or configured target. May be a string or a
            frozenset of compiler families for multi-target lists.

    Returns:
        bool: True if AGENTS.md should be generated
    """
    if isinstance(target, frozenset):
        return bool(target & {"agents", "gemini", "claude"})
    return target in (
        "vscode",
        "claude",
        "cursor",
        "opencode",
        "codex",
        "gemini",
        "antigravity",
        "grok-build",
        "windsurf",
        "kiro",
        "hermes",
        "all",
        "minimal",
    )


def target_without_compile_output(target: CompileTargetType | None) -> TargetCapability | None:
    """Return the catalog capability when *target* has no root-context output.

    Derived from ``TargetCapability.compile_family``: targets without a compile
    family (skills-only and experimental targets) make ``apm compile`` a
    successful no-op, so new catalog targets inherit the behavior.
    """
    if not isinstance(target, str):
        return None
    try:
        capability = get_target_capability(target)
    except KeyError:
        return None
    return capability if capability.compile_family is None else None


def should_compile_claude_md(target: CompileTargetType) -> bool:
    """Check if CLAUDE.md should be compiled.

    Args:
        target: The detected or configured target. May be a string or a
            frozenset of compiler families for multi-target lists.

    Returns:
        bool: True if CLAUDE.md should be generated
    """
    if isinstance(target, frozenset):
        return "claude" in target
    return target in ("claude", "all")


def should_compile_gemini_md(target: CompileTargetType) -> bool:
    """Check if GEMINI.md should be compiled.

    Args:
        target: The detected or configured target. May be a string or a
            frozenset of compiler families for multi-target lists.

    Returns:
        bool: True if GEMINI.md should be generated
    """
    if isinstance(target, frozenset):
        return "gemini" in target
    return target in ("gemini", "all")


def should_compile_copilot_instructions_md(target: CompileTargetType) -> bool:
    """Check if .github/copilot-instructions.md should be compiled.

    Only the Copilot-native targets (copilot/vscode/agents alias) and "all"
    trigger generation.  cursor, opencode, and codex use their own native
    configuration files and must NOT receive copilot-instructions.md, even
    when combined in a multi-target list.

    Args:
        target: The detected or configured target. May be a string or a
            frozenset of compiler families for multi-target lists.

    Returns:
        bool: True if Copilot root instructions should be generated
    """
    if isinstance(target, frozenset):
        # "vscode" family is added to the frozenset by _resolve_compile_target()
        # ONLY when copilot/vscode/agents was in the original list. Checking
        # "agents" would over-fire because cursor/opencode/codex also map to
        # the "agents" family for AGENTS.md generation.
        return "vscode" in target
    return target in ("vscode", "all")


def get_dedup_rules_dir(target: CompileTargetType) -> tuple[str, str] | None:
    """Get the deployed-instruction directory and target key for dedup.

    Args:
        target: The detected or configured target. May be a string or a
            frozenset of compiler families for multi-target lists.

    Returns:
        tuple[str, str] | None: Relative path (e.g., '.agents/rules' or
        '.github/instructions') and canonical target key for expected filename
        mapping, or None when the target does not support instruction
        deduplication.
    """
    if isinstance(target, frozenset):
        # Conservative policy: only dedup when the target set is exactly
        # {"vscode"} (Copilot alone). Any additional family -- including
        # "agents" -- means at least one consumer that does not read
        # .github/instructions/ may be present, so we keep instructions
        # in AGENTS.md to be safe.
        if target == frozenset({"vscode"}):
            return ".github/instructions", "copilot"
        return None
    if isinstance(target, str):
        target = TARGET_ALIASES.get(target, target)
    if target in ("vscode", "copilot", "agents"):
        # "vscode" is the internal Copilot compile family.
        return ".github/instructions", "copilot"
    if target == "antigravity":
        return ".agents/rules", "antigravity"
    return None


def can_dedup_agents_md_instructions(target: CompileTargetType) -> bool:
    """Check if instruction dedup is safe for AGENTS.md.

    Returns True only when the target that reads AGENTS.md also reads its
    respective deployed rules directory (``.github/instructions/`` for Copilot
    or ``.agents/rules/`` for Antigravity) -- meaning instructions can safely
    be omitted from AGENTS.md without losing context for any consumer.

    Today Copilot (vscode) and Antigravity support this native rules reading.
    Codex, OpenCode, Windsurf, Gemini, and Kiro rely on AGENTS.md as
    their sole instruction source and must always receive instruction content
    (issue #1678).

    Args:
        target: The detected or configured target.  May be a string or a
            frozenset of compiler families for multi-target lists.

    Returns:
        bool: True if instructions can be omitted from AGENTS.md.
    """
    return get_dedup_rules_dir(target) is not None


def get_target_description(target: UserTargetType) -> str:
    """Get a human-readable description of what will be generated for a target.

    Accepts both internal target types and user-facing aliases.

    Args:
        target: The target type (internal or user-facing alias)

    Returns:
        str: Description of output files
    """
    # Normalize aliases to internal value for lookup
    normalized = "vscode" if target in ("copilot", "agents") else target
    descriptions = {
        "agent-skills": ".agents/skills/ only (cross-client shared skills -- no agents, hooks, or commands)",
        "antigravity": "AGENTS.md + .agents/rules/ + .agents/skills/ + .agents/hooks.json + .agents/mcp_config.json (explicit --target only)",
        "claude": "AGENTS.md + CLAUDE.md + .claude/commands/ + .claude/agents/ + .claude/skills/",
        "codex": "AGENTS.md + .agents/skills/ + .codex/agents/ + .codex/hooks.json",
        "cursor": ".cursor/agents/ + .agents/skills/ + .cursor/rules/",
        "gemini": "GEMINI.md + .gemini/commands/ + .agents/skills/ + .gemini/settings.json (MCP/hooks)",
        "grok-bot": "agent-data/workflows/ (project) or ~/agent-data/workflows/ (--global) -- skills only, explicit --target only",
        "grok-build": "AGENTS.md + .grok/rules/ + .grok/agents/ + .grok/commands/ + .grok/skills/",
        "hermes": "AGENTS.md + .agents/skills/ (project) or $HERMES_HOME/skills/ + $HERMES_HOME/config.yaml MCP (explicit --target only)",
        "kiro": "AGENTS.md + .kiro/steering/ + .kiro/skills/ + .kiro/hooks/ + .kiro/settings/mcp.json",
        "openclaw": ".agents/skills/ (project) or ~/.openclaw/skills/ (--global) -- experimental",
        "opencode": "AGENTS.md + .opencode/agents/ + .opencode/commands/ + .agents/skills/",
        "vscode": "AGENTS.md + .github/copilot-instructions.md + .github/prompts/ + .github/agents/",
        "windsurf": "AGENTS.md + .windsurf/rules/ + .agents/skills/ + .windsurf/workflows/ + .windsurf/hooks.json",
        "all": "AGENTS.md + CLAUDE.md + GEMINI.md + .github/copilot-instructions.md + .github/ + .claude/ + .cursor/ + .opencode/ + .codex/ + .gemini/ + .windsurf/ + .kiro/ + .agents/",
        "minimal": "AGENTS.md only (create .github/, .claude/, or .gemini/ for full integration)",
    }
    return descriptions.get(normalized, "unknown target")


# ---------------------------------------------------------------------------
# Multi-target helpers (used by active_targets() in the integration layer)
# ---------------------------------------------------------------------------

#: The complete set of real (non-pseudo) canonical targets.
#: "minimal" is intentionally excluded -- it is a fallback pseudo-target.
ALL_CANONICAL_TARGETS = frozenset(expand_all("install"))

#: Targets that the parser must accept but that are gated at runtime by
#: ``is_enabled()`` in ``core/experimental.py`` and ``_flag_gated()`` in
#: ``integration/targets.py``.  They are NOT included in the
#: ``parse_target_arg("all")`` expansion -- explicit opt-in only.
EXPERIMENTAL_TARGETS: frozenset[str] = frozenset(
    capability.name
    for capability in TARGET_CAPABILITIES.values()
    if capability.experimental_flag is not None
)

#: Stable targets excluded from "all" expansion (cross-client deploy
#: locations). Unlike EXPERIMENTAL_TARGETS, these are GA -- they just do
#: not represent a single client tool.  Antigravity is explicit-only
#: because its workspace config lives under the SHARED ``.agents/`` root,
#: so there is no Antigravity-unique signal to auto-detect on.
EXPLICIT_ONLY_TARGETS: frozenset[str] = frozenset(
    capability.name for capability in TARGET_CAPABILITIES.values() if capability.explicit_only
)

#: MCP-only pseudo-targets that have a client adapter but no
#: ``KNOWN_TARGETS`` entry (they map to a canonical target for primitive
#: deployment via ``RUNTIME_TO_CANONICAL_TARGET``).  They must be accepted
#: by ``--target`` so the CLI validates them, but they are excluded from
#: ``"all"`` expansion and do not participate in target-profile machinery.
MCP_ONLY_TARGETS: frozenset[str] = frozenset(
    capability.name for capability in TARGET_CAPABILITIES.values() if capability.mcp_only
)

#: Alias mapping: user-facing name -> canonical internal name.
TARGET_ALIASES: dict[str, str] = {
    value: (
        capability.compile_family
        if capability.compile_family in capability.aliases
        else capability.name
    )
    for capability in TARGET_CAPABILITIES.values()
    for value in (capability.name, *capability.aliases)
    if capability.aliases
    and (value != capability.name or capability.compile_family in capability.aliases)
}


def normalize_target_list(
    value: str | list[str] | None,
) -> list[str] | None:
    """Normalize a user-provided target value to a list of canonical names.

    Handles:
    - ``None`` -> ``None`` (auto-detect)
    - ``"claude"`` -> ``["claude"]``
    - ``"agents"`` -> ``["copilot"]``  (alias resolution)
    - ``"all"`` -> every stable target in ``expand_all("install")``
    - ``["claude", "copilot"]`` -> ``["claude", "copilot"]``
    - Deduplicates while preserving first-seen order.

    Args:
        value: A single target string, a list of target strings, or ``None``.

    Returns:
        A deduplicated list of canonical target names, or ``None`` if the
        input was ``None`` (meaning "auto-detect").
    """
    if value is None:
        return None

    raw: list[str] = [value] if isinstance(value, str) else list(value)

    # "all" anywhere in the input means "every target" -- expand to the
    # full sorted list of canonical targets.
    if "all" in raw:
        return list(expand_all("install"))

    seen: set[str] = set()
    result: list[str] = []
    for item in raw:
        capability = get_target_capability(item)
        canonical = (
            capability.compile_family
            if capability.compile_family in capability.aliases
            else normalize_target_name(item)
        )
        if canonical not in seen:
            seen.add(canonical)
            result.append(canonical)
    return result


# ---------------------------------------------------------------------------
# Click parameter type for --target (comma-separated multi-target support)
# ---------------------------------------------------------------------------

#: All values accepted by the ``--target`` CLI option.
#: Derived from canonical targets, alias keys, and the ``"all"`` keyword.
VALID_TARGET_VALUES: frozenset[str] = accepted_target_values()

#: Stable user-facing projection of every value accepted by ``--target``.
TARGET_VALUES_HELP = ", ".join(sorted(accepted_target_values()))


class UnknownTargetValueError(ValueError):
    """A target value holds a token outside the accepted vocabulary.

    ``token`` is that one token, so a multi-target error names it rather
    than the whole list (RA-040).
    """

    def __init__(self, token: str, message: str) -> None:
        super().__init__(message)
        self.token = token


def parse_target_field(
    value: str | list[str] | None,
    *,
    source_path: Path | None = None,
) -> str | list[str] | None:
    """Parse, validate, and normalize a target value from any entry point.

    Single source of truth for the ``target`` field, shared by the
    ``--target`` CLI flag (via :class:`TargetParamType`) and ``apm.yml``'s
    top-level ``target:`` (via :func:`APMPackage.from_apm_yml`).  The
    output may differ from the input in case (lowercased), order
    (preserved but deduplicated), and shape (single-element multi-token
    inputs collapse to ``str``).  Aliases are resolved for multi-token
    input only; see the *Returns* section below for the exact rules.

    Accepted input shapes:

    * ``None`` -> ``None`` (auto-detect at consumption time -- this is the
      "field absent" path; an apm.yml without ``target:`` lands here).
    * Single token (``"claude"``) -> the same lowercased token as ``str``.
      Aliases are NOT resolved for solo input -- ``"agents"`` returns
      ``"agents"`` to match the long-standing CLI contract; downstream
      consumers handle the alias set explicitly. The deprecated ``vscode``
      alias is the exception: it always resolves to ``copilot``.
    * CSV string (``"claude,copilot"``) -> deduplicated ``List[str]`` with
      aliases resolved to canonical names. Collapses to a bare ``str`` if
      after dedup only one canonical token remains.
    * List input (``["claude", "copilot"]``) goes through the same path as
      the CSV form -- single-element lists collapse to ``str``.
    * Literal ``"all"`` -> ``"all"`` (exclusive; cannot be combined).

    Args:
        value: The raw value -- ``str``, ``List[str]``, or ``None``.
        source_path: Optional path to the apm.yml that produced ``value``.
            When supplied, ValueError messages name the file so users can
            jump to it directly.

    Returns:
        ``None`` for unset, a ``str`` for a single token (or ``"all"``),
        or a deduplicated ``List[str]`` for multi-target input.

    Raises:
        ValueError: When the value is an empty / whitespace-only / commas-only
            string, an empty list, a non-string non-list type, contains a
            token that is not in :data:`VALID_TARGET_VALUES`, or mixes
            ``"all"`` with other targets.  An empty *string* is treated as
            user error (the "field absent" path is ``None``, supplied by
            the YAML loader for a missing key).
    """
    if value is None:
        return None

    global _agents_alias_detected
    _agents_alias_detected = False

    # ---- collect raw tokens ----
    if isinstance(value, str):
        # Empty / whitespace-only / comma-only strings are user error -- a
        # missing field comes through as ``None`` from the YAML loader, so
        # an empty *string* means the user typed something invalid.
        raw_parts = [v.strip().lower() for v in value.split(",") if v.strip()]
    elif isinstance(value, list):
        raw_parts = []
        for item in value:
            if not isinstance(item, str):
                raise ValueError(
                    _target_error(
                        f"each entry must be a string, got {type(item).__name__}",
                        source_path,
                    )
                )
            if item.strip():
                raw_parts.append(item.strip().lower())
    else:
        raise ValueError(
            _target_error(
                f"expected string or list of strings, got {type(value).__name__}",
                source_path,
            )
        )

    if not raw_parts:
        raise ValueError(_target_error("target value must not be empty", source_path))

    # Deprecated aliases (``vscode``) select their replacement exactly.
    raw_parts = [canonical_target_token(p) for p in raw_parts]

    # ---- validate every token ----
    for p in raw_parts:
        if p not in accepted_target_values() and not is_vendor_target_id(p):
            raise UnknownTargetValueError(
                p,
                _target_error(
                    f"'{p}' is not a valid target. "
                    f"Choose from: {', '.join(sorted(accepted_target_values()))}",
                    source_path,
                ),
            )

    # ---- deprecation warning for legacy "agents" alias (once per call) ----
    # Only a CLI token is a flag; a manifest value (``source_path`` set) is
    # warned once by the manifest owner with manifest wording (C5a, #3967).
    if "agents" in raw_parts and source_path is None:
        _agents_alias_detected = True
        warnings.warn(
            deprecation_message("target-agents"),
            AgentsTargetDeprecationWarning,
            stacklevel=2,
        )

    # ---- "all" handling ----
    if "all" in raw_parts:
        non_all_tokens = {t for t in raw_parts if t != "all"}
        if non_all_tokens - EXPLICIT_ONLY_TARGETS - MCP_ONLY_TARGETS:
            raise ValueError(
                _target_error(
                    "'all' cannot be combined with other targets",
                    source_path,
                )
            )
        if not non_all_tokens:
            return "all"
        # "all" + explicit-only tokens (e.g. "all,agent-skills"):
        # expand "all" to canonical targets and append the explicit-only ones.
        expanded = sorted(ALL_CANONICAL_TARGETS) + sorted(non_all_tokens)
        return expanded

    # Single-token input is returned as-is (no alias resolution).  This
    # preserves the long-standing CLI contract where ``--target agents``
    # yields ``"agents"`` rather than ``"copilot"``; every
    # downstream consumer (active_targets, agents_compiler,
    # _CROSS_TARGET_MAPS, _get_target_prefixes) already accepts both alias
    # spellings, so resolving here would be a visible behaviour change
    # with zero functional benefit and would break the CLI test suite
    # (~10 ``test_single_*`` cases).  This is the one asymmetry #820's
    # "shared normalization" intentionally leaves in place; collapsing it
    # is an independent decision tracked separately from this fix.
    if len(raw_parts) == 1:
        return raw_parts[0]

    # Multi-token: resolve every alias to its canonical profile.
    seen: set[str] = set()
    result: list[str] = []
    for p in raw_parts:
        canonical = normalize_target_name(p)
        if canonical not in seen:
            seen.add(canonical)
            result.append(canonical)

    if len(result) == 1:
        return result[0]
    return result


def _target_error(message: str, source_path: Path | None) -> str:
    """Format a target validation error, naming the source file when known."""
    if source_path is not None:
        return f"Invalid 'target' in {source_path}: {message}"
    return f"Invalid target: {message}"


_deprecated_flag_aliases_warned: set[str] = set()


def warn_deprecated_target_alias_flag(
    value: str | list[str] | None, *, flag: str = "--target"
) -> None:
    """Warn once per process when a CLI target flag uses a deprecated alias."""
    tokens = value.split(",") if isinstance(value, str) else list(value or ())
    alias = first_deprecated_target_alias(tokens)
    if alias is None or alias in _deprecated_flag_aliases_warned:
        return
    _deprecated_flag_aliases_warned.add(alias)
    from apm_cli.utils.console import _rich_warning

    _rich_warning(deprecated_target_alias_message(alias, where=flag), symbol="warning", err=True)


def canonical_runtime_option(
    ctx: click.Context | None, param: click.Parameter | None, value: str | None
) -> str | None:
    """Click callback: read a deprecated alias passed as ``--runtime`` as its target."""
    if value is None:
        return value
    warn_deprecated_target_alias_flag(value, flag="--runtime")
    return canonical_target_token(value.strip().lower())


def install_runtime_option(func):
    """``apm install --runtime``: the legacy single-value spelling of ``--target``."""
    from apm_cli.core.target_catalog import target_help_fragment

    return click.option(
        "--runtime",
        callback=canonical_runtime_option,
        help=(
            "Target a specific runtime only. Legacy alias for --target (single value only; "
            f"prefer --target). {target_help_fragment('install')}"
        ),
    )(func)


class TargetParamType(click.ParamType):
    """Click parameter type accepting comma-separated target values.

    Delegates to :func:`parse_target_field`, which is the shared validator
    used by ``apm.yml``'s ``target:`` field as well -- so ``--target X`` and
    ``target: X`` always resolve identically and reject the same inputs.

    Examples::

        -t claude             -> "claude"
        -t claude,copilot     -> ["claude", "copilot"]
        -t all                -> "all"
        -t copilot,agents     -> "copilot"  (deduped aliases)
        -t vscode             -> "copilot"  (deprecated alias; warns once)
    """

    name = "target"

    def convert(
        self,
        value: str | list[str] | None,
        param: click.Parameter | None,
        ctx: click.Context | None,
    ) -> str | list[str] | None:
        try:
            parsed = parse_target_field(value)
            warn_deprecated_target_alias_flag(value)
        except ValueError as e:
            # Use the v2 three-section error renderer for unknown targets
            # so that CLI, apm.yml, and auto-detect all share the same
            # error format (#1154).
            from apm_cli.core.errors import UnknownTargetError, render_unknown_target_error

            err_msg = str(e)
            if isinstance(e, UnknownTargetValueError):
                command = ctx.command.name if ctx is not None and ctx.command.name else "install"
                rendered = render_unknown_target_error(
                    e.token,
                    list(target_error_values(command)),
                    command=command,
                )
                raise UnknownTargetError(rendered) from None
            # Click idiom: route validation errors through self.fail so the
            # user sees a clean "Invalid value for '--target': ..." message
            # rather than a Python traceback.
            self.fail(err_msg, param, ctx)
        tokens = parsed if isinstance(parsed, list) else [parsed] if parsed else []
        vendor = [token for token in tokens if is_vendor_target_id(token)]
        if vendor:
            # A vendor target parses, but no vendor handler is registered (#4251).
            self.fail(
                f"vendor target '{vendor[0]}' has no registered handler in this APM version",
                param,
                ctx,
            )
        return parsed


# ---------------------------------------------------------------------------
# v2 Resolution algorithm (#1154)
# ---------------------------------------------------------------------------

from dataclasses import dataclass  # noqa: E402


@dataclass(frozen=True)
class Signal:
    """A filesystem marker that indicates a harness is present."""

    target: str  # canonical target name: 'claude', 'copilot', etc.
    source: str  # human-readable: 'CLAUDE.md', '.github/copilot-instructions.md'


@dataclass(frozen=True)
class ResolvedTargets:
    """Result of target resolution -- the single source of truth."""

    targets: list[str]  # sorted canonical target names
    source: str  # '--target flag' | 'apm.yml' | 'auto-detect from <csv>'
    auto_create: bool  # always True after resolution (three-guard collapse)


def _target_capabilities(
    value: str | list[str] | None,
) -> Iterator[tuple[str, TargetCapability]]:
    """Yield expanded target spellings with their catalog capabilities."""
    raw_targets = [value] if isinstance(value, str) else list(value or [])
    for raw_target in raw_targets:
        expanded = expand_all("install") if raw_target == "all" else (raw_target,)
        for target in expanded:
            yield target, get_target_capability(target)


def _canonical_profile(target: str, capability: TargetCapability) -> str:
    """Return the native profile a target spelling selects.

    Aliases resolve to their capability name and MCP-only targets map to the
    primitive profile they configure; an MCP-only target without one fails
    closed instead of escaping policy under its own name.
    """
    if not capability.mcp_only:
        return normalize_target_name(target)
    if capability.primitive_profile is None:
        raise RuntimeError(f"MCP-only target '{target}' has no canonical policy mapping")
    return capability.primitive_profile


def canonical_policy_target_names(
    values: str | Iterable[str] | None,
) -> tuple[str, ...] | None:
    """Canonicalize a policy target list so it compares against decisions.

    ``all`` means unrestricted and yields ``None``. Known spellings resolve
    through the same profile mapping as
    :attr:`EffectiveTargetDecision.canonical_targets`; unknown spellings are kept
    verbatim so they can never match a real target.
    """
    if values is None:
        return None
    spellings = [values] if isinstance(values, str) else list(values)
    names: list[str] = []
    for raw in spellings:
        spelling = str(raw).strip().lower()
        if not spelling:
            continue
        if spelling == "all":
            return None
        try:
            name = _canonical_profile(spelling, get_target_capability(spelling))
        except KeyError:
            name = spelling
        if name not in names:
            names.append(name)
    return tuple(names)


def canonical_policy_target_name(value: str | None) -> str | None:
    """Canonicalize one policy target (``enforce``); ``all`` stays ``all``."""
    if value is None:
        return None
    spelling = str(value).strip().lower()
    if spelling == "all":
        return spelling
    names = canonical_policy_target_names(spelling)
    return names[0] if names else None


# Provenance label of a decision taken from the manifest's ``targets:``.
MANIFEST_TARGET_SOURCE = "apm.yml"
# Provenance label of a decision the user passed on the command line.
FLAG_TARGET_SOURCE = "--target flag"


@dataclass(frozen=True)
class EffectiveTargetDecision:
    """One install-time target decision shared by package, MCP, and LSP phases."""

    value: str | list[str] | None
    source: str

    @property
    def from_manifest(self) -> bool:
        """True when the manifest's own ``targets:`` made this decision."""
        return self.source == MANIFEST_TARGET_SOURCE

    @property
    def from_flag(self) -> bool:
        """True when ``--target`` narrowed this run, whatever the manifest selects."""
        return self.source == FLAG_TARGET_SOURCE

    @cached_property
    def canonical_targets(self) -> tuple[str, ...] | None:
        """Return the selected native target profiles, or None when unrestricted."""
        if self.value is None:
            return None

        canonical: list[str] = []
        seen: set[str] = set()
        for target, capability in _target_capabilities(self.value):
            name = _canonical_profile(target, capability)
            if name not in seen:
                seen.add(name)
                canonical.append(name)
        return tuple(canonical)

    @cached_property
    def runtime_targets(self) -> tuple[str, ...] | None:
        """Return MCP runtime identifiers represented by this target decision."""
        if self.value is None:
            return None

        runtimes: list[str] = []
        seen: set[str] = set()
        for _target, capability in _target_capabilities(self.value):
            runtime = (
                capability.name
                if capability.name in capability.runtimes
                else capability.compile_family
                if capability.compile_family in capability.runtimes
                else capability.runtimes[0]
                if capability.runtimes
                else capability.name
            )
            if runtime not in seen:
                seen.add(runtime)
                runtimes.append(runtime)
        return tuple(runtimes)

    def runtime_targets_for_scope(self, *, user_scope: bool) -> tuple[str, ...] | None:
        """Return MCP runtime identifiers adjusted for project or user scope."""
        targets = self.runtime_targets
        if not user_scope or targets is None:
            return targets

        from apm_cli.core.experimental import is_enabled

        eligible: list[str] = []
        for runtime in targets:
            capability = get_target_capability(runtime)
            if capability.experimental_flag and not is_enabled(capability.experimental_flag):
                continue
            eligible.append(runtime)
        return tuple(eligible)

    @cached_property
    def runtime_equivalents(self) -> tuple[str, ...] | None:
        """Return canonical and adapter runtime spellings for exclusions."""
        if self.value is None:
            return None
        equivalents: set[str] = set()
        for _target, capability in _target_capabilities(self.value):
            equivalents.add(capability.name)
            equivalents.update(capability.runtimes)
        return tuple(sorted(equivalents))

    @cached_property
    def lsp_targets(self) -> tuple[str, ...] | None:
        """Return native target profiles eligible for LSP configuration."""
        if self.value is None:
            return None

        targets: list[str] = []
        seen: set[str] = set()
        for target, capability in _target_capabilities(self.value):
            if capability.mcp_only:
                continue
            canonical = normalize_target_name(target)
            if canonical not in seen:
                seen.add(canonical)
                targets.append(canonical)
        return tuple(targets)


def resolve_effective_target_decision(
    project_root: Path,
    *,
    explicit_target: str | list[str] | None,
    manifest_target: str | list[str] | None,
    user_scope: bool = False,
    auto_detect: bool = True,
    create_config: bool = True,
) -> EffectiveTargetDecision:
    """Choose the effective install target once using the public precedence.

    Explicit CLI selection wins, followed by a validated manifest selection,
    then the saved ``apm config target`` default. Project auto-detection runs
    only when none of those restrictions exists. User-scope runtime discovery
    remains unrestricted in that final case because it probes user-capable
    runtimes rather than project harness markers.
    """
    if explicit_target is not None:
        return EffectiveTargetDecision(explicit_target, FLAG_TARGET_SOURCE)

    if manifest_target:
        return EffectiveTargetDecision(manifest_target, MANIFEST_TARGET_SOURCE)

    from apm_cli.config import get_install_target

    configured_target = get_install_target(create_config=create_config)
    if configured_target is not None:
        return EffectiveTargetDecision(configured_target, "apm config target")

    if user_scope or not auto_detect:
        return EffectiveTargetDecision(None, "auto-detect")

    resolved = resolve_targets(project_root)
    return EffectiveTargetDecision(list(resolved.targets), resolved.source)


def resolve_package_target_decision(
    project_root: Path,
    *,
    package: object | None,
    explicit_target: str | list[str] | None,
    user_scope: bool = False,
    auto_detect: bool = True,
    create_config: bool = True,
) -> EffectiveTargetDecision:
    """Resolve one effective target decision from a parsed package manifest."""
    from apm_cli.models.apm_package import package_target_selection

    return resolve_effective_target_decision(
        project_root,
        explicit_target=explicit_target,
        manifest_target=package_target_selection(package) if package is not None else None,
        user_scope=user_scope,
        auto_detect=auto_detect,
        create_config=create_config,
    )


def resolve_deployment_target_decision(
    *,
    manifest_target: str | list[str] | None,
    recorded_targets: tuple[str, ...],
    fallback: Callable[[], EffectiveTargetDecision] | None = None,
) -> EffectiveTargetDecision:
    """Reconcile current manifest intent with an existing deployment's recorded targets.

    Shared by commands that act on what APM already deployed (``apm audit``,
    uninstall-time LSP reconciliation): the manifest's ``targets:`` wins, as
    it does for install, then the targets the lockfile records. A saved
    install default and harness autodetection never retarget an existing
    deployment; *fallback* (default: unrestricted ``auto-detect``) runs only
    when nothing is declared or recorded.
    """
    if manifest_target:
        return EffectiveTargetDecision(manifest_target, MANIFEST_TARGET_SOURCE)
    if recorded_targets:
        return EffectiveTargetDecision(list(recorded_targets), "deployment ledger")
    if fallback is not None:
        return fallback()
    return EffectiveTargetDecision(None, "auto-detect")


def resolve_audit_target_decision(
    *,
    manifest_target: str | list[str] | None,
    recorded_targets: tuple[str, ...],
) -> EffectiveTargetDecision:
    """Reconcile current manifest intent with the recorded installation.

    A saved install default is not a request to retarget an existing deployment.
    Without declared or recorded intent, preserve audit's discovery fallback.
    """
    return resolve_deployment_target_decision(
        manifest_target=manifest_target, recorded_targets=recorded_targets
    )


def read_manifest_target(project_root: Path) -> list[str] | None:
    """Read audit's manifest target hint; manifest checks own parse failures."""
    from apm_cli.core.scope import manifest_file
    from apm_cli.models.manifest_targets import read_manifest_target_declaration

    declaration = read_manifest_target_declaration(manifest_file(project_root), lenient=True)
    if declaration is None:
        return None
    try:
        return declaration.restriction()
    except (ValueError, TypeError, click.UsageError):
        return None


def resolve_manifest_target_decision(
    project_root: Path,
    *,
    manifest_path: Path,
    explicit_target: str | list[str] | None,
    user_scope: bool = False,
    auto_detect: bool = True,
    create_config: bool = True,
) -> EffectiveTargetDecision:
    """Resolve one effective target decision from an optional manifest path."""
    package = None
    if manifest_path.is_file():
        from apm_cli.models.apm_package import APMPackage

        package = APMPackage.from_apm_yml(manifest_path)
    return resolve_package_target_decision(
        project_root,
        package=package,
        explicit_target=explicit_target,
        user_scope=user_scope,
        auto_detect=auto_detect,
        create_config=create_config,
    )


# Detection signal whitelist.
# (target, check_type, path)
# check_type: 'dir' = is_dir(), 'file' = is_file()
SIGNAL_WHITELIST: list[tuple[str, str, str]] = [
    ("claude", "dir", ".claude"),
    ("claude", "file", "CLAUDE.md"),
    ("cursor", "dir", ".cursor"),
    ("cursor", "file", ".cursorrules"),  # legacy; .cursor/ is canonical
    ("copilot", "file", ".github/copilot-instructions.md"),
    # Copilot CLI still reads a user's MCP file under .github/, so it stays a
    # copilot signal although APM now writes .mcp.json (#3866). The root
    # .mcp.json is not a signal: Claude Code reads it too.
    ("copilot", "file", ".github/mcp.json"),  # architecture-authority-exempt: detection signal
    ("copilot", "dir", ".github/instructions"),
    ("copilot", "dir", ".github/agents"),
    ("copilot", "dir", ".github/prompts"),
    ("copilot", "dir", ".github/hooks"),
    ("codex", "dir", ".codex"),
    ("gemini", "dir", ".gemini"),
    ("gemini", "file", "GEMINI.md"),
    ("grok-build", "dir", ".grok"),
    ("opencode", "dir", ".opencode"),
    ("windsurf", "dir", ".windsurf"),
    ("kiro", "dir", ".kiro"),
]

# Ordered list of targets for display (excludes agent-skills meta-target).
CANONICAL_TARGETS_ORDERED: list[str] = [
    "claude",
    "copilot",
    "cursor",
    "codex",
    "gemini",
    "grok-build",
    "opencode",
    "windsurf",
    "kiro",
]

# Canonical deploy directories for each target.
CANONICAL_DEPLOY_DIRS: dict[str, str] = {
    "claude": ".claude/",
    "copilot": ".github/",
    "cursor": ".cursor/",
    "codex": ".codex/",
    "gemini": ".gemini/",
    "grok-build": ".grok/",
    "opencode": ".opencode/",
    "windsurf": ".windsurf/",
    "kiro": ".kiro/",
}

# The primary (lowest-friction) signal for each target, used in
# "needs <path>" display for inactive targets.
CANONICAL_SIGNAL: dict[str, str] = {
    "claude": "CLAUDE.md",
    "copilot": ".github/copilot-instructions.md",
    "cursor": ".cursor/",
    "codex": ".codex/",
    "gemini": "GEMINI.md",
    "grok-build": ".grok/",
    "opencode": ".opencode/",
    "windsurf": ".windsurf/",
    "kiro": ".kiro/",
}


def detect_signals(project_root: Path) -> list[Signal]:
    """Scan project_root for harness markers per SIGNAL_WHITELIST."""
    found: list[Signal] = []
    for target, check_type, rel_path in SIGNAL_WHITELIST:
        full = project_root / rel_path
        if check_type == "dir" and full.is_dir():
            found.append(Signal(target=target, source=rel_path + "/"))
        elif check_type == "file" and full.is_file():
            found.append(Signal(target=target, source=rel_path))
    return found


def _validate_canonical_v2(tokens: list[str]) -> None:
    """Validate every token is a known canonical target."""
    from apm_cli.core.apm_yml import CANONICAL_TARGETS
    from apm_cli.core.errors import UnknownTargetError, render_unknown_target_error

    for token in tokens:
        if token not in CANONICAL_TARGETS:
            from apm_cli.core.target_catalog import advertised_manifest_target_names

            raise UnknownTargetError(
                render_unknown_target_error(token, sorted(advertised_manifest_target_names()))
            )


def resolve_targets(
    project_root: Path,
    *,
    flag: str | list[str] | None = None,
    yaml_targets: list[str] | None = None,
    flag_source: str = "--target flag",
) -> ResolvedTargets:
    """Resolve effective targets. Raises on error.

    Priority: flag > yaml_targets > auto-detect signals.

    ``flag_source`` labels the provenance reported when ``flag`` wins. It
    defaults to ``"--target flag"`` (an explicit CLI selector) but callers
    pass a different label -- e.g. ``"apm config target"`` -- when the flag
    value originated from a configured default rather than the CLI, so the
    provenance line does not misattribute a config default to ``--target``.
    """
    from apm_cli.core.errors import (
        AmbiguousHarnessError,
        NoHarnessError,
        render_ambiguous_error,
        render_no_harness_error,
    )

    # Priority 1: --target flag
    if flag is not None:
        tokens = [flag] if isinstance(flag, str) else list(flag)
        tokens = list(dict.fromkeys(canonical_target_token(token) for token in tokens))
        _validate_canonical_v2(tokens)
        return ResolvedTargets(
            targets=sorted(tokens),
            source=flag_source,
            auto_create=True,
        )

    # Priority 2: apm.yml targets (already validated by parse_targets_field)
    if yaml_targets is not None and len(yaml_targets) > 0:
        return ResolvedTargets(
            targets=sorted(yaml_targets),
            source="apm.yml",
            auto_create=True,
        )

    # Priority 3: auto-detect from signals
    signals = detect_signals(project_root)

    # Dedupe by target (e.g. .claude/ + CLAUDE.md both -> 'claude')
    target_set = sorted({s.target for s in signals})
    signal_sources = sorted({s.source for s in signals})

    if len(target_set) == 0:
        raise NoHarnessError(render_no_harness_error(project_root))

    if len(target_set) >= 2:
        raise AmbiguousHarnessError(render_ambiguous_error(project_root, target_set))

    # Exactly 1 target detected
    return ResolvedTargets(
        targets=target_set,
        source=f"auto-detect from {', '.join(signal_sources)}",
        auto_create=True,
    )


def expand_all_targets(
    project_root: Path,
    *,
    yaml_targets: list[str] | None = None,
) -> list[str]:
    """Expand 'all' to (signals union yaml_targets). Raises NoHarnessError if empty."""
    from apm_cli.core.errors import NoHarnessError, render_no_harness_error

    signals = detect_signals(project_root)
    signal_set = {s.target for s in signals}

    yaml_set = set(yaml_targets) if yaml_targets else set()

    combined = sorted(signal_set | yaml_set)

    if not combined:
        raise NoHarnessError(render_no_harness_error(project_root))

    return combined


def format_provenance(resolved: ResolvedTargets) -> str:
    """Format provenance line for CLI output.

    Returns the message portion (without the [i] prefix, since
    _rich_info adds it).

    # Double-space between target list and metadata is intentional and
    # canonical. Test assertions match this exact spacing. Do not collapse.
    """
    return provenance_line(resolved.targets, resolved.source)


def provenance_line(targets: Iterable[str], source: str) -> str:
    """Render the canonical ``Targets: X  (source: Y)`` line for any caller."""
    return f"Targets: {', '.join(targets)}  (source: {source})"
