"""Installation scope resolution for APM packages.

Defines where packages are deployed based on scope:

- **project** (default): Deploy to the current working directory.
  Manifest, lockfile, and modules live at the project root.
- **user**: Deploy to user-level directories (``~/.claude/``, etc.).
  Manifest, lockfile, and modules live under ``$APM_HOME`` (default
  ``~/.apm/``).

User-scope support varies by target -- see ``TargetProfile.user_supported``
in ``apm_cli.integration.targets`` for the canonical registry.

Source-root override
--------------------
``set_source_root_override`` pins the source root (where ``apm.yml``
and local-path packages resolve from) to an explicit directory.  The
``apm install --root`` flow uses this together with ``os.chdir(root)``
so existing call-sites that hardcode ``Path.cwd()`` automatically
resolve to the deploy root, while sources continue to read from the
captured original working directory.

Write helpers (:func:`get_deploy_root`, :func:`get_apm_dir`,
:func:`get_modules_dir`, :func:`get_lockfile_dir`) intentionally do
NOT consult the override -- after ``chdir`` they already point to the
deploy root.  Source helpers (:func:`get_source_root`,
:func:`get_manifest_path`) consult it.
"""

from __future__ import annotations

import contextvars
import os
from enum import Enum
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

USER_APM_DIR = ".apm"
"""Directory under ``$HOME`` for user-scope metadata."""


def _startup_cwd() -> Path | None:
    try:
        return Path(os.getcwd())
    except OSError:
        return None


_STARTUP_CWD = _startup_cwd()
"""Working directory captured at import, used to anchor a relative ``APM_HOME``.

Global commands such as ``apm lock -g`` ``chdir`` into the APM home; anchoring
once keeps every later lookup on the same directory instead of nesting it.
"""


def get_apm_home() -> Path:
    """Return the canonical root for APM-owned user metadata.

    ``APM_HOME`` overrides the default ``~/.apm`` location.  An unset or
    empty value preserves the platform default.  A leading ``~`` is expanded
    and a relative value is anchored to the directory the process started in.
    Target deployment roots are deliberately resolved elsewhere and are not
    affected by this helper.
    """
    configured = os.environ.get("APM_HOME")
    if configured:
        home = Path(configured).expanduser()
        if not home.is_absolute():
            if _STARTUP_CWD is None:
                raise ValueError(
                    f"APM_HOME={configured!r} is relative, but the starting directory is "
                    "unavailable. Set an absolute APM_HOME or start APM from an existing "
                    "directory."
                )
            home = _STARTUP_CWD / home
        return home
    return Path.home() / USER_APM_DIR


def ensure_apm_home() -> Path:
    """Return ``APM_HOME``, creating it as 0700 when it does not exist yet (#5257).

    Only a directory APM creates here is made private to the user; an existing
    ``APM_HOME`` keeps its mode. Missing parents are created with the umask's mode.
    """
    home = get_apm_home()
    if os.path.lexists(home):
        return home
    home.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.mkdir(home, 0o700)
    except FileExistsError:
        return home  # created concurrently: whoever created it chose its mode
    os.chmod(home, 0o700)  # exact, whatever bits the umask cleared
    return home


# ---------------------------------------------------------------------------
# Enum
# ---------------------------------------------------------------------------


class InstallScope(Enum):
    """Controls where packages are deployed."""

    PROJECT = "project"
    USER = "user"


def is_user_scope(scope: object) -> bool:
    """Return whether *scope* is the canonical user installation scope."""
    return scope is InstallScope.USER


# ---------------------------------------------------------------------------
# Source-root override (managed by the ``--root`` flag handlers)
# ---------------------------------------------------------------------------
#
# Backed by ``contextvars.ContextVar`` rather than a module-global so the
# override is isolated per execution context: nested / sequential CLI
# invocations and test cases never observe each other's pins, and there is
# no cross-test leakage to reset.  ``ContextVar`` is NOT inherited by
# ``ThreadPoolExecutor`` download workers, which is intentional and safe:
# the override is consulted only by the source-read helpers below
# (:func:`get_source_root` / :func:`get_manifest_path`), all of which run
# on the main thread during the resolve phase.  Deploy-side redirection is
# carried by the process-global ``os.chdir`` in ``install_root_redirect``,
# which every thread observes regardless of this ContextVar.


_SOURCE_ROOT_OVERRIDE: contextvars.ContextVar[Path | None] = contextvars.ContextVar(
    "apm_source_root_override", default=None
)


def set_source_root_override(path: Path | None) -> None:
    """Pin the project-scope source root to *path*.

    Used by ``apm install --root`` (and any command that ``chdir``s
    into a deploy directory) to remember the user's original working
    directory so :func:`get_source_root` and :func:`get_manifest_path`
    keep reading sources from there.

    Pass ``None`` to clear the override.  Command handlers should
    always clear in a ``try/finally`` block so the override never
    leaks across CLI invocations.
    """
    _SOURCE_ROOT_OVERRIDE.set(path.resolve() if path is not None else None)


def get_source_root_override() -> Path | None:
    """Return the active source-root override, or ``None`` when unset."""
    return _SOURCE_ROOT_OVERRIDE.get()


# ---------------------------------------------------------------------------
# Path resolution
# ---------------------------------------------------------------------------


def get_source_root(scope: InstallScope) -> Path:
    """Return the directory used to read project sources.

    Project scope: the active source-root override when set, otherwise
    ``Path.cwd()``.  User scope: ``Path.home()``.

    Sources resolved from this root: ``apm.yml``, ``.apm/`` local
    primitives, and the resolution base for local-path package
    references.
    """
    if scope is InstallScope.USER:
        return Path.home()
    override = _SOURCE_ROOT_OVERRIDE.get()
    if override is not None:
        return override
    return Path.cwd()


def get_deploy_root(scope: InstallScope) -> Path:
    """Return the root used to construct deployment paths.

    For project scope this is ``Path.cwd()`` -- callers that want to
    redirect deployment should ``chdir`` into the target directory and
    use :func:`set_source_root_override` to remember the original
    source root.  For user scope this is ``Path.home()``.
    """
    if scope is InstallScope.USER:
        return Path.home()
    return Path.cwd()


def get_workspace_deploy_root(workspace_root: Path) -> Path:
    """Return the live deployment root for an APM metadata workspace."""
    workspace_root = workspace_root.resolve()
    if workspace_root == get_apm_dir(InstallScope.USER).resolve():
        return get_deploy_root(InstallScope.USER).resolve()
    return workspace_root


def get_apm_dir(scope: InstallScope) -> Path:
    """Return the directory that holds APM metadata (lockfile, modules).

    * Project scope: ``<cwd>/`` (the active deploy root)
    * User scope: ``$APM_HOME/`` (default ``~/.apm/``)
    """
    if scope is InstallScope.USER:
        return get_apm_home()
    return Path.cwd()


def manifest_file(directory: Path) -> Path:
    """Return the ``apm.yml`` inside *directory* (a project, package or APM home).

    The single place the manifest file name is joined onto a directory; a
    relative *directory* stays relative (``Path(".")`` yields ``apm.yml``).
    """
    from ..constants import APM_YML_FILENAME

    return Path(directory) / APM_YML_FILENAME


def manifest_root(project_root: Path, *, user_scope: bool) -> Path:
    """Return the directory whose ``apm.yml`` is a command's scope manifest.

    At user scope the deploy root is ``$HOME`` but the manifest, its
    ``executables`` grants and its ``policy:`` settings live in
    ``$APM_HOME`` (default ``~/.apm/``).
    """
    return get_apm_home() if user_scope else Path(project_root)


def scope_manifest_path(project_root: Path, *, user_scope: bool) -> Path:
    """Return the scope manifest for a command rooted at *project_root*."""
    return manifest_file(manifest_root(project_root, user_scope=user_scope))


def is_user_scope_root(root: Path) -> bool:
    """Return whether *root* is the user-scope manifest directory (``$APM_HOME``).

    User scope has no project repository, so callers that derive project
    facts (such as an org from a git remote) skip this root.
    """
    try:
        return Path(root).resolve() == get_apm_home().resolve()
    except (OSError, ValueError):
        return False


def policy_discovery_uses_git_remote(root: Path) -> bool:
    """Return whether org policy is auto-discovered from *root*'s git remote.

    The single user-scope policy decision: user scope (``-g``, rooted at
    ``$APM_HOME``) has no project repository, so it discovers no org policy
    from a git remote. An explicit ``--policy-source`` still applies.
    """
    return not is_user_scope_root(root)


def get_modules_dir(scope: InstallScope) -> Path:
    """Return the ``apm_modules`` directory for *scope*."""
    from ..constants import APM_MODULES_DIR

    return get_apm_dir(scope) / APM_MODULES_DIR


def get_manifest_path(scope: InstallScope) -> Path:
    """Return the ``apm.yml`` path for *scope*.

    The manifest is a SOURCE -- its location follows
    :func:`get_source_root`, which honours
    :func:`set_source_root_override`.  This keeps ``apm install --root``
    reading the manifest from the user's original working directory
    rather than from the (typically empty) deploy root.

    User scope delegates to :func:`get_apm_dir` so the user-level
    location can't drift between this helper and the dir helper.
    """
    if scope is InstallScope.USER:
        return manifest_file(get_apm_dir(scope))
    return manifest_file(get_source_root(scope))


def get_lockfile_dir(scope: InstallScope) -> Path:
    """Return the directory containing the lockfile for *scope*.

    The lockfile is a WRITE -- it is regenerated by ``apm install`` and
    co-located with ``apm_modules/``, so it follows
    :func:`get_apm_dir` (which honours
    :func:`set_source_root_override` via ``Path.cwd()`` after
    ``install_root_redirect`` chdirs into the deploy root).

    Contrast with :func:`get_manifest_path`, which follows
    :func:`get_source_root` because the manifest is a source file.  If
    you add a new metadata helper, pick the side deliberately: source
    files go through :func:`get_source_root`; generated / deployed
    artifacts go through :func:`get_apm_dir`.
    """
    return get_apm_dir(scope)


def ensure_user_dirs() -> Path:
    """Create the user APM root and its ``apm_modules/`` directory.

    Returns ``$APM_HOME`` when configured, otherwise ``~/.apm/``.
    """
    from ..constants import APM_MODULES_DIR

    user_root = get_apm_home()
    user_root.mkdir(parents=True, exist_ok=True)
    (user_root / APM_MODULES_DIR).mkdir(exist_ok=True)
    return user_root


# ---------------------------------------------------------------------------
# Per-target user-scope helpers
#
# These functions query ``KNOWN_TARGETS`` in ``targets.py`` for user-scope
# metadata.  No parallel registry is needed -- TargetProfile carries
# ``user_supported``, ``user_root_dir``, and ``unsupported_user_primitives``.
# ---------------------------------------------------------------------------


def get_unsupported_targets() -> list[str]:
    """Return target names that do not support user-scope deployment."""
    from ..integration.targets import KNOWN_TARGETS

    return [name for name, profile in KNOWN_TARGETS.items() if profile.user_supported is False]


def warn_unsupported_user_scope(targets) -> str:
    """Return a warning naming primitives user scope skips for *targets*.

    Only the selected targets are named: a Claude-only global install is
    not warned about Windsurf (#3994). Returns an empty string when every
    selected target deploys all of its primitives at user scope.
    """
    from ..integration.targets import KNOWN_TARGETS

    skipped: list[str] = []
    for name in dict.fromkeys(targets):
        profile = KNOWN_TARGETS.get(name)
        if profile is None:
            continue
        if profile.user_supported is False:
            skipped.append(f"{name} (all primitives)")
        elif profile.unsupported_user_primitives:
            skipped.append(f"{name} ({', '.join(profile.unsupported_user_primitives)})")
    if not skipped:
        return ""
    return "User scope does not deploy these primitives: " + "; ".join(skipped)
