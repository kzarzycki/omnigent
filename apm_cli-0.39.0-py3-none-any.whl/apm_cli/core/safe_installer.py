"""Safe MCP server installation with conflict detection."""

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..factory import ClientFactory
from .command_logger import library_logger
from .conflict_detector import MCPConflictDetector


@dataclass
class InstallationSummary:
    """Summary of MCP server installation results."""

    def __init__(self):
        self.installed = []
        self.skipped = []
        self.failed = []
        self.native_hashes: dict[str, str] = {}

    def add_installed(self, server_ref: str):
        """Add a server to the installed list."""
        self.installed.append(server_ref)

    def add_skipped(self, server_ref: str, reason: str):
        """Add a server to the skipped list."""
        self.skipped.append({"server": server_ref, "reason": reason})

    def add_failed(self, server_ref: str, reason: str):
        """Add a server to the failed list."""
        self.failed.append({"server": server_ref, "reason": reason})

    def has_any_changes(self) -> bool:
        """Check if any installations or failures occurred."""
        return len(self.installed) > 0 or len(self.failed) > 0

    def log_summary(self, logger=None):
        """Log a summary of installation results."""
        logger = logger or library_logger()
        if self.installed:
            logger.success(f"Installed: {', '.join(self.installed)}")
        for item in self.skipped:
            logger.warning(f"Skipped {item['server']}: {item['reason']}")
        for item in self.failed:
            logger.error(f"Failed {item['server']}: {item['reason']}")


class SafeMCPInstaller:
    """Safe MCP server installation with conflict detection."""

    def __init__(
        self,
        runtime: str,
        logger=None,
        project_root: Path | str | None = None,
        user_scope: bool = False,
    ):
        """Initialize the safe installer.

        Args:
            runtime: Target runtime (copilot, codex, vscode).
            logger: Optional CommandLogger for structured output.
            project_root: Optional project root for repo-local runtime configs.
            user_scope: Whether runtime config should resolve in user scope.
        """
        self.runtime = runtime
        self.adapter = ClientFactory.create_client(
            runtime,
            project_root=project_root,
            user_scope=user_scope,
        )
        self.conflict_detector = MCPConflictDetector(self.adapter)
        self.logger = logger or library_logger()

    def install_servers(
        self,
        server_references: list[str],
        env_overrides: dict[str, str] = None,  # noqa: RUF013
        server_info_cache: dict[str, Any] = None,  # noqa: RUF013
        runtime_vars: dict[str, str] = None,  # noqa: RUF013
        replace_existing: bool = False,
        managed_fields: set[str] | None = None,
    ) -> InstallationSummary:
        """Install MCP servers with conflict detection.

        Args:
            server_references: List of server references to install.
            env_overrides: Optional dictionary of environment variable overrides.
            server_info_cache: Optional pre-fetched server info to avoid duplicate registry calls.
            runtime_vars: Optional dictionary of runtime variable values.
            replace_existing: Configure matching entries instead of skipping them.

        Returns:
            InstallationSummary with detailed results.
        """
        summary = InstallationSummary()

        for server_ref in server_references:
            cached_info = (server_info_cache or {}).get(server_ref)
            exists_kwargs = {"server_info": cached_info} if cached_info else {}
            if not replace_existing and self.conflict_detector.check_server_exists(
                server_ref, **exists_kwargs
            ):
                summary.add_skipped(server_ref, "already configured")
                self._log_skip(server_ref)
                continue

            try:
                # Pass environment overrides, server info cache, and runtime variables if provided
                kwargs = {}
                if env_overrides is not None:
                    kwargs["env_overrides"] = env_overrides
                if server_info_cache is not None:
                    kwargs["server_info_cache"] = server_info_cache
                if runtime_vars is not None:
                    kwargs["runtime_vars"] = runtime_vars
                if server_ref.startswith("@") and server_ref.count("/") == 1:
                    kwargs["server_name"] = server_ref
                if self.runtime == "claude" and replace_existing and managed_fields:
                    kwargs["managed_fields"] = managed_fields

                result = self.adapter.configure_mcp_server(server_ref, **kwargs)

                if result:
                    from ..install.mcp.ownership import written_native_hash

                    summary.add_installed(server_ref)
                    fingerprint = written_native_hash(
                        self.adapter,
                        server_ref,
                        requested_info=cached_info,
                        existing_configs=self.conflict_detector.get_existing_server_configs(),
                    )
                    if fingerprint is not None:
                        summary.native_hashes[server_ref] = fingerprint
                    self._log_success(server_ref)
                else:
                    summary.add_failed(server_ref, "configuration failed")
                    self._log_failure(server_ref)
            except Exception as e:
                summary.add_failed(server_ref, str(e))
                self._log_error(server_ref, e)

        return summary

    def _log_skip(self, server_ref: str):
        """Log when a server is skipped due to existing configuration."""
        self.logger.warning(f"  {server_ref} already configured, skipping")

    def _log_success(self, server_ref: str):
        """Log successful server installation."""
        # The integrator's install tree reports success once (#3994).
        self.logger.verbose_detail(f"  + {server_ref}")

    def _log_failure(self, server_ref: str):
        """Log failed server installation."""
        # One line per runtime, so name it: the same server fails once per target.
        self.logger.warning(f"  x {server_ref} installation failed for {self.runtime}")

    def _log_error(self, server_ref: str, error: Exception):
        """Log error during server installation."""
        self.logger.error(f"  x {server_ref}: {error}")

    def check_conflicts_only(self, server_references: list[str]) -> dict[str, Any]:
        """Check for conflicts without installing.

        Args:
            server_references: List of server references to check.

        Returns:
            Dictionary with conflict information for each server.
        """
        conflicts = {}

        for server_ref in server_references:
            conflicts[server_ref] = self.conflict_detector.get_conflict_summary(server_ref)

        return conflicts
