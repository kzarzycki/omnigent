"""Centralized token management for different AI runtimes and git platforms.

This module handles the complex token environment setup required by different
AI CLI tools, each of which expects different environment variable names for
authentication and API access.

Token Architecture:
- GITHUB_COPILOT_PAT: User-scoped PAT specifically for Copilot
- GITHUB_APM_PAT: Fine-grained PAT for APM module access (GitHub)
- ADO_APM_PAT: PAT for APM module access (Azure DevOps)
- GITHUB_TOKEN: User-scoped PAT for GitHub Models API access

Platform Token Selection:
- GitHub-class: GITHUB_APM_PAT -> GITHUB_TOKEN -> GH_TOKEN -> gh auth token -> git credential helpers
- GitLab-class: GITLAB_APM_PAT -> GITLAB_TOKEN -> git credential helpers
- Generic FQDN hosts: git credential helpers only (no GitHub/GitLab platform env vars)
- Azure DevOps: ADO_APM_PAT

Runtime Requirements:
- Codex CLI: Uses GITHUB_TOKEN (must be user-scoped for GitHub Models)
"""

import logging
import os
import subprocess
import sys
from collections.abc import Mapping
from dataclasses import dataclass, field
from urllib.parse import urlparse

from apm_cli.utils.git_env import get_gh_executable, get_git_executable
from apm_cli.utils.github_host import (
    default_host,
    is_azure_devops_hostname,
    is_github_hostname,
    is_valid_fqdn,
)

logger = logging.getLogger(__name__)


def _format_credential_host(host: str, port: int | None) -> str:
    """Embed a custom port into the git credential ``host`` field.

    Per ``gitcredentials(7)``, there is no standalone ``port=`` attribute in
    the credential protocol -- port must be embedded into the host field as
    ``host:port``. Sending a separate ``port=`` line is silently ignored by
    helpers, collapsing two different services into one credential entry.

    Uses ``is not None`` (not truthy) so that ``None`` is the only sentinel
    for "no port", matching the rest of the port-handling logic.
    """
    return f"{host}:{port}" if port is not None else host


def _sanitize_credential_path(path: str) -> str:
    """Strip leading ``/``, reject control chars, allowlist URL schemes.

    The git credential protocol is line-oriented: a stray newline in the
    ``path`` value would let an attacker inject arbitrary attribute lines
    (``\\nusername=...`` etc.) into the credential request. Even though
    ``path`` originates from a parsed dependency reference (already
    constrained to URL components), we defensively reject any value that
    contains control characters or whitespace, returning an empty string
    so the caller skips the ``path=`` line entirely. This preserves the
    pre-disambiguation request rather than ever sending a malformed one.

    We also guard against accidental full-URL inputs (``https://...``).
    Today every caller passes ``owner/repo``, but if a future caller ever
    passes a full URL the naive ``lstrip('/')`` would yield
    ``https:/host/owner/repo`` which GCM silently ignores. Detect this
    via ``urlparse`` and use the URL's path component instead.

    Schemes are allowlisted to ``https``/``http``/``ssh`` (and the
    schemeless owner/repo case). ``urlparse`` is greedy about consuming
    embedded characters in non-hierarchical schemes (notably ``data:``
    and ``file:``), which would let those URI families bypass the
    char-scan -- the ``parsed.path`` after such schemes can still embed
    bytes the scan would otherwise reject. Reject anything off-allowlist.
    """
    parsed = urlparse(path)
    scheme = parsed.scheme.lower()
    if scheme and scheme not in ("https", "http", "ssh"):
        return ""
    cleaned = parsed.path.lstrip("/") if scheme else path.lstrip("/")
    if not cleaned:
        return ""
    for ch in cleaned:
        if ord(ch) < 0x20 or ord(ch) == 0x7F or ch.isspace():
            return ""
    return cleaned


@dataclass(frozen=True)
class GitHelperCredential:
    """One credential returned by ``git credential fill``.

    Keeps the request coordinates (``protocol``/``host``/``port``/``path``)
    next to the answer so the credential can be presented exactly as Git
    would. ``description`` is the attribute list fill printed, kept verbatim
    because ``git credential approve``/``reject`` must be fed that same
    description (https://git-scm.com/docs/git-credential, "TYPICAL USE OF
    GIT CREDENTIAL", step 4). It is empty for a credential APM did not
    obtain from fill, and such a credential is never reported back.
    """

    host: str
    password: str = field(repr=False)
    username: str | None = None
    port: int | None = None
    path: str | None = None
    protocol: str = "https"
    description: tuple[tuple[str, str], ...] = field(default=(), repr=False, compare=False)

    @property
    def basic_username(self) -> str:
        """Username for HTTP Basic; empty when the helper returned none."""
        return self.username or ""

    @property
    def host_field(self) -> str:
        """The ``host`` attribute fill was asked for (port embedded)."""
        return _format_credential_host(self.host, self.port)


def _parse_credential_description(stdout: str) -> tuple[tuple[str, str], ...]:
    """Return fill's ``key=value`` lines in order; empty when any line is malformed."""
    attributes: list[tuple[str, str]] = []
    for line in stdout.split("\n"):
        if not line:
            continue
        key, separator, value = line.partition("=")
        if not separator or not key or "\x00" in line or "\r" in line:
            return ()
        attributes.append((key, value))
    return tuple(attributes)


def _is_valid_credential_username(username: str) -> bool:
    """Reject usernames that could not be sent in a Basic header."""
    if not username or len(username) > 256:
        return False
    if ":" in username:
        return False
    return all(0x20 < ord(ch) < 0x7F for ch in username)


def _truthy_env(value: str | None) -> bool:
    return bool(value) and value.strip().lower() not in {"0", "false", "no", "off"}


def _stdin_is_interactive() -> bool:
    stream = sys.stdin
    if stream is None:
        return False
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError, OSError):
        return False


def credential_fill_env(base_env: Mapping[str, str]) -> dict[str, str]:
    """Return the environment for one non-prompting ``git credential fill``.

    ``GIT_TERMINAL_PROMPT=0`` blocks terminal prompts. Git Credential Manager
    gates browser and dialog flows separately through ``GCM_INTERACTIVE``;
    it is disabled when stdin is not a terminal or ``CI`` is set, so an
    unattended run never waits on an interactive sign-in.
    """
    env = dict(base_env)
    env["GIT_TERMINAL_PROMPT"] = "0"
    env["GIT_ASKPASS"] = "" if sys.platform != "win32" else "echo"
    if _truthy_env(env.get("CI")) or not _stdin_is_interactive():
        env["GCM_INTERACTIVE"] = "0"
    return env


# Upper bound for a ``git credential fill`` password accepted by
# ``GitHubTokenManager._is_valid_credential_token``. Enterprise IdP tokens
# issued through Git Credential Manager carry extra claims and exceed 2600
# characters, so the cap only guards against unbounded garbage output.
MAX_CREDENTIAL_TOKEN_LENGTH = 16384


class GitHubTokenManager:
    """Manages GitHub token environment setup for different AI runtimes."""

    # Diagnostic source label for bearer-resolved tokens (AAD via az CLI).
    # Used by AuthResolver and downstream diagnostics to identify bearer auth.
    ADO_BEARER_SOURCE = "AAD_BEARER_AZ_CLI"

    # Define token precedence for different use cases
    TOKEN_PRECEDENCE = {  # noqa: RUF012
        "copilot": ["GITHUB_COPILOT_PAT", "GITHUB_TOKEN", "GITHUB_APM_PAT"],
        "models": [
            "GITHUB_TOKEN",
            "GITHUB_APM_PAT",
        ],  # GitHub Models prefers user-scoped PAT, falls back to APM PAT
        "modules": ["GITHUB_APM_PAT", "GITHUB_TOKEN", "GH_TOKEN"],  # GitHub-class module access
        "gitlab_modules": [
            "GITLAB_APM_PAT",
            "GITLAB_TOKEN",
        ],  # GitLab SaaS / self-managed API + git HTTPS
        "generic_modules": [],  # Non-GitHub / non-GitLab FQDN: env PATs deferred to credential fill only
        "ado_modules": ["ADO_APM_PAT"],  # APM module access (Azure DevOps)
        "artifactory_modules": ["ARTIFACTORY_APM_TOKEN"],  # APM module access (JFrog Artifactory)
    }

    # Runtime-specific environment variable mappings
    RUNTIME_ENV_VARS = {  # noqa: RUF012
        "copilot": ["COPILOT_GITHUB_TOKEN", "GH_TOKEN", "GITHUB_PERSONAL_ACCESS_TOKEN"],
        "codex": ["GITHUB_TOKEN"],  # Uses GITHUB_TOKEN directly
        "llm": ["GITHUB_MODELS_KEY"],  # LLM-specific variable for GitHub Models
    }

    def __init__(self, preserve_existing: bool = True):
        """Initialize token manager.

        Args:
            preserve_existing: If True, never overwrite existing environment variables
        """
        self.preserve_existing = preserve_existing
        # Keyed by (host, port): same hostname on different ports may have
        # distinct credentials, so a host-only key would cross-contaminate.
        self._credential_cache: dict[tuple[str, int | None], str | None] = {}

    @staticmethod
    def _is_valid_credential_token(token: str) -> bool:
        """Validate that a credential-fill token looks like a real credential.

        Rejects garbage values that can appear when GIT_ASKPASS or credential
        helpers return prompt text instead of actual tokens.
        """
        if not token:
            return False
        if len(token) > MAX_CREDENTIAL_TOKEN_LENGTH:
            return False
        if any(c in token for c in (" ", "\t", "\n", "\r")):
            return False
        prompt_fragments = ("Password for", "Username for", "password for", "username for")
        if any(fragment in token for fragment in prompt_fragments):  # noqa: SIM103
            return False
        return True

    @staticmethod
    def _supports_gh_cli_host(host: str | None) -> bool:
        """Return True when *host* should use gh CLI fallback."""
        if not host:
            return False
        if is_github_hostname(host):
            return True

        configured_host = default_host().lower()
        host_lower = host.lower()
        if host_lower != configured_host:
            return False
        if configured_host == "github.com" or configured_host.endswith(".ghe.com"):
            return False
        if is_azure_devops_hostname(configured_host):
            return False
        return is_valid_fqdn(configured_host)

    # `git credential fill` may invoke OS credential helpers that show
    # interactive dialogs (e.g. Windows Credential Manager account picker).
    # The 60s default prevents false negatives on slow helpers.
    DEFAULT_CREDENTIAL_TIMEOUT = 60
    MAX_CREDENTIAL_TIMEOUT = 180
    # approve/reject is advisory; never wait on a slow helper as long as fill.
    CREDENTIAL_REPORT_TIMEOUT = 10

    @classmethod
    def _get_credential_timeout(cls) -> int:
        """Return timeout (seconds) for ``git credential fill``.

        Configurable via ``APM_GIT_CREDENTIAL_TIMEOUT`` (1-180).
        """
        raw = os.environ.get("APM_GIT_CREDENTIAL_TIMEOUT", "").strip()
        if not raw:
            return cls.DEFAULT_CREDENTIAL_TIMEOUT
        try:
            val = int(raw)
        except ValueError:
            return cls.DEFAULT_CREDENTIAL_TIMEOUT
        return max(1, min(val, cls.MAX_CREDENTIAL_TIMEOUT))

    @staticmethod
    def resolve_credential_from_git(
        host: str,
        port: int | None = None,
        path: str | None = None,
        *,
        env: dict[str, str] | None = None,
    ) -> str | None:
        """Resolve a credential from the git credential store.

        Uses `git credential fill` to query the user's configured credential
        helpers (macOS Keychain, Windows Credential Manager, gh CLI, etc.).
        This is the same mechanism git clone uses internally.

        Args:
            host: The git host to resolve credentials for (e.g., "github.com")
            port: Optional non-standard git port (e.g. 7999 for Bitbucket DC).
                Embedded into the ``host`` field per ``gitcredentials(7)`` --
                a standalone ``port=`` line is not part of the protocol.
            path: Optional repository path (``org/repo``). When provided,
                a ``path=`` line is appended to the credential request so
                helpers configured with ``credential.useHttpPath = true``
                (notably Git Credential Manager for multi-account users)
                can disambiguate the target URL and pick the right
                stored account without prompting.

        Returns:
            The password/token from the credential store, or None if unavailable
        """
        credential = GitHubTokenManager.resolve_git_helper_credential(
            host,
            port=port,
            path=path,
            env=env,
        )
        return credential.password if credential is not None else None

    @staticmethod
    def resolve_git_helper_credential(
        host: str,
        port: int | None = None,
        path: str | None = None,
        *,
        env: dict[str, str] | None = None,
    ) -> GitHelperCredential | None:
        """Run ``git credential fill`` and keep the full credential record.

        Returns the helper's username and password together with the exact
        (host, port, path) the helper was asked for, so callers present the
        credential the way Git would (``Basic username:password``). Only the
        auth chain reports the outcome back (:meth:`report_git_helper_credential`).
        """
        host_field = _format_credential_host(host, port)
        stdin_lines = ["protocol=https", f"host={host_field}"]
        sanitized_path = _sanitize_credential_path(path) if path else ""
        if sanitized_path:
            stdin_lines.append(f"path={sanitized_path}")
        stdin = "\n".join(stdin_lines) + "\n\n"
        try:
            result = subprocess.run(
                [get_git_executable(), "credential", "fill"],
                input=stdin,
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=GitHubTokenManager._get_credential_timeout(),
                env=credential_fill_env(os.environ if env is None else env),
            )
            if result.returncode != 0:
                return None

            description = _parse_credential_description(result.stdout)
            username: str | None = None
            password: str | None = None
            for line in result.stdout.splitlines():
                if line.startswith("username=") and username is None:
                    username = line[len("username=") :]
                elif line.startswith("password=") and password is None:
                    password = line[len("password=") :]
            if not password or not GitHubTokenManager._is_valid_credential_token(password):
                return None
            if username is not None and not _is_valid_credential_username(username):
                username = None
            return GitHelperCredential(
                host=host,
                port=port,
                path=sanitized_path or None,
                username=username or None,
                password=password,
                description=description,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            return None

    @staticmethod
    def report_git_helper_credential(
        credential: GitHelperCredential,
        *,
        accepted: bool,
        env: dict[str, str] | None = None,
    ) -> bool:
        """Tell the user's credential helpers whether a fill credential worked.

        Step 4 of the git-credential contract
        (https://git-scm.com/docs/git-credential, "TYPICAL USE OF GIT
        CREDENTIAL"): ``approve`` after the credential allowed the operation,
        ``reject`` after it was rejected, each fed the description fill
        returned. Only the auth chain decides when to call this. Runs with the
        same non-interactive environment as fill and at most a 10s timeout,
        writes the description on stdin only, and never raises: a helper
        failure is logged at debug level and the operation result stands.
        """
        description = credential.description
        attributes = dict(description)
        if (
            attributes.get("protocol") != "https"
            or attributes.get("host", "").lower() != credential.host_field.lower()
            or attributes.get("password") != credential.password
            or attributes.get("username") != credential.username
            or ("path" in attributes and attributes["path"] != credential.path)
        ):
            logger.debug("Skipping git credential report: description does not match the request")
            return False
        action = "approve" if accepted else "reject"
        stdin = "".join(f"{key}={value}\n" for key, value in description) + "\n"
        try:
            result = subprocess.run(
                [get_git_executable(), "credential", action],
                input=stdin,
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=min(
                    GitHubTokenManager._get_credential_timeout(),
                    GitHubTokenManager.CREDENTIAL_REPORT_TIMEOUT,
                ),
                env=credential_fill_env(os.environ if env is None else env),
            )
        except (subprocess.TimeoutExpired, OSError) as exc:
            logger.debug(
                "git credential %s for %s failed: %s",
                action,
                credential.host_field,
                type(exc).__name__,
            )
            return False
        if result.returncode != 0:
            # Helper stderr may echo the description it was given; never log it.
            logger.debug(
                "git credential %s for %s exited %d",
                action,
                credential.host_field,
                result.returncode,
            )
            return False
        return True

    @staticmethod
    def resolve_credential_from_gh_cli(
        host: str | None, *, env: Mapping[str, str] | None = None
    ) -> str | None:
        """Resolve a token from the active gh CLI account for *host*.

        Uses ``gh auth token --hostname <host>`` as a non-interactive fallback
        before invoking OS credential helpers that may display UI.

        Eligibility is gated by :meth:`_supports_gh_cli_host` so all callers
        share one path: hosts the gh CLI does not support (None/empty, ADO,
        unrelated FQDNs) return ``None`` immediately without spawning a
        subprocess. A non-zero exit, invalid output, missing ``gh`` binary,
        or timeout all return ``None``; ``stderr`` is debug-logged on
        non-zero exit so ``--verbose`` users can see why the call missed.
        *env* replaces the inherited environment (strict host credentials
        pass one without GitHub-class tokens).
        """
        if not GitHubTokenManager._supports_gh_cli_host(host):
            return None
        try:
            result = subprocess.run(
                [get_gh_executable(), "auth", "token", "--hostname", host],
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=GitHubTokenManager._get_credential_timeout(),
                stdin=subprocess.DEVNULL,
                env={
                    **(os.environ if env is None else env),
                    "GH_PROMPT_DISABLED": "1",
                    "GH_NO_UPDATE_NOTIFIER": "1",
                },
            )
            if result.returncode != 0:
                logger.debug(
                    "gh auth token failed for %s: %s",
                    host,
                    (result.stderr or "").strip()[:200],
                )
                return None

            token = result.stdout.strip()
            if token and GitHubTokenManager._is_valid_credential_token(token):
                return token
            return None
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
            logger.debug("gh auth token errored for %s: %s", host, exc)
            return None

    def setup_environment(self, env: dict[str, str] | None = None) -> dict[str, str]:
        """Set up complete token environment for all runtimes.

        Args:
            env: Environment dictionary to modify (defaults to os.environ.copy())

        Returns:
            Updated environment dictionary with all required tokens set
        """
        if env is None:
            env = os.environ.copy()

        # Get available tokens
        available_tokens = self._get_available_tokens(env)

        # Set up tokens for each runtime without overwriting existing values
        self._setup_copilot_tokens(env, available_tokens)
        self._setup_codex_tokens(env, available_tokens)
        self._setup_llm_tokens(env, available_tokens)

        return env

    def get_token_for_purpose(self, purpose: str, env: dict[str, str] | None = None) -> str | None:
        """Get the best available token for a specific purpose.

        Args:
            purpose: Token purpose ('copilot', 'models', 'modules')
            env: Environment to check (defaults to os.environ)

        Returns:
            Best available token for the purpose, or None if not available
        """
        if env is None:
            env = os.environ

        source = self.get_token_env_var_for_purpose(purpose, env)
        return env[source] if source is not None else None

    def get_token_env_var_for_purpose(
        self, purpose: str, env: dict[str, str] | None = None
    ) -> str | None:
        """Return the selected environment variable name without revealing its value.

        The selected name follows the same precedence as
        :meth:`get_token_for_purpose`. Caller-specific compatibility sources
        are selected by AuthResolver, not by this low-level lookup.
        """
        if env is None:
            env = os.environ

        if purpose not in self.TOKEN_PRECEDENCE:
            raise ValueError(f"Unknown purpose: {purpose}")

        for token_var in self.TOKEN_PRECEDENCE[purpose]:
            if env.get(token_var):
                return token_var

        return None

    def get_token_with_credential_fallback(
        self,
        purpose: str,
        host: str,
        env: dict[str, str] | None = None,
        *,
        port: int | None = None,
    ) -> str | None:
        """Get token for a purpose, falling back to git credential helpers.

        Tries environment variables first (via get_token_for_purpose), then
        checks the active gh CLI account, then queries the git credential
        store as a last resort. Results are cached per ``(host, port)`` to
        avoid repeated subprocess calls while keeping same-host-different-port
        credentials separate.

        Args:
            purpose: Token purpose ('modules', etc.)
            host: Git host to resolve credentials for (e.g., "github.com")
            env: Environment to check (defaults to os.environ)
            port: Optional non-standard git port. Flows through to
                ``resolve_credential_from_git`` so credential helpers can
                return port-specific credentials.

        Returns:
            Best available token, or None if not available from any source
        """
        token = self.get_token_for_purpose(purpose, env)
        if token:
            return token

        cache_key = (host, port)
        if cache_key in self._credential_cache:
            return self._credential_cache[cache_key]

        gh_token = None
        if self._supports_gh_cli_host(host):
            gh_token = self.resolve_credential_from_gh_cli(host)
        if gh_token:
            self._credential_cache[cache_key] = gh_token
            return gh_token

        credential = self.resolve_credential_from_git(host, port=port)
        self._credential_cache[cache_key] = credential
        return credential

    def validate_tokens(self, env: dict[str, str] | None = None) -> tuple[bool, str]:
        """Validate that required tokens are available.

        Args:
            env: Environment to check (defaults to os.environ)

        Returns:
            Tuple of (is_valid, error_message)
        """
        if env is None:
            env = os.environ

        # Check for at least one valid token
        has_any_token = any(
            self.get_token_for_purpose(purpose, env) for purpose in ["copilot", "models", "modules"]
        )

        if not has_any_token:
            return False, (
                "No tokens found. Set one of:\n"
                "- GITHUB_TOKEN (user-scoped PAT for GitHub Models)\n"
                "- GITHUB_APM_PAT (fine-grained PAT for APM modules on GitHub)\n"
                "- ADO_APM_PAT (PAT for APM modules on Azure DevOps)"
            )

        # Warn about GitHub Models access if only fine-grained PAT is available
        models_token = self.get_token_for_purpose("models", env)
        if not models_token:
            has_fine_grained = env.get("GITHUB_APM_PAT")
            if has_fine_grained:
                return True, (
                    "Warning: Only fine-grained PAT available. "
                    "GitHub Models requires GITHUB_TOKEN (user-scoped PAT)"
                )

        return True, "Token validation passed"

    def _get_available_tokens(self, env: dict[str, str]) -> dict[str, str]:
        """Get all available GitHub tokens from environment."""
        tokens = {}
        for purpose, token_vars in self.TOKEN_PRECEDENCE.items():  # noqa: B007
            for token_var in token_vars:
                if env.get(token_var):
                    tokens[token_var] = env[token_var]
        return tokens

    def _setup_copilot_tokens(self, env: dict[str, str], available_tokens: dict[str, str]):
        """Set up tokens for Copilot."""
        copilot_token = self.get_token_for_purpose("copilot", available_tokens)
        if not copilot_token:
            return

        for env_var in self.RUNTIME_ENV_VARS["copilot"]:
            if self.preserve_existing and env_var in env:
                continue
            env[env_var] = copilot_token

    def _setup_codex_tokens(self, env: dict[str, str], available_tokens: dict[str, str]):
        """Set up tokens for Codex CLI (preserve existing tokens)."""
        # Codex script checks for both GITHUB_TOKEN and GITHUB_APM_PAT
        # Set up GITHUB_TOKEN if not present
        if not (self.preserve_existing and "GITHUB_TOKEN" in env):
            models_token = self.get_token_for_purpose("models", available_tokens)
            if models_token and "GITHUB_TOKEN" not in env:
                env["GITHUB_TOKEN"] = models_token

        # Ensure GITHUB_APM_PAT is available if we have it
        if not (self.preserve_existing and "GITHUB_APM_PAT" in env):
            apm_token = available_tokens.get("GITHUB_APM_PAT")
            if apm_token and "GITHUB_APM_PAT" not in env:
                env["GITHUB_APM_PAT"] = apm_token

    def _setup_llm_tokens(self, env: dict[str, str], available_tokens: dict[str, str]):
        """Set up tokens for LLM CLI."""
        # LLM uses GITHUB_MODELS_KEY, prefer GITHUB_TOKEN if available
        if self.preserve_existing and "GITHUB_MODELS_KEY" in env:
            return

        models_token = self.get_token_for_purpose("models", available_tokens)
        if models_token:
            env["GITHUB_MODELS_KEY"] = models_token


# Convenience functions for common use cases
def setup_runtime_environment(env: dict[str, str] | None = None) -> dict[str, str]:
    """Set up complete runtime environment for all AI CLIs."""
    manager = GitHubTokenManager()
    return manager.setup_environment(env)


def validate_github_tokens(env: dict[str, str] | None = None) -> tuple[bool, str]:
    """Validate GitHub token setup."""
    manager = GitHubTokenManager()
    return manager.validate_tokens(env)


def get_github_token_for_runtime(runtime: str, env: dict[str, str] | None = None) -> str | None:
    """Get the appropriate GitHub token for a specific runtime."""
    manager = GitHubTokenManager()

    # Map runtime names to purposes
    runtime_to_purpose = {
        "copilot": "copilot",
        "codex": "models",
        "llm": "models",
    }

    purpose = runtime_to_purpose.get(runtime)
    if not purpose:
        raise ValueError(f"Unknown runtime: {runtime}")

    return manager.get_token_for_purpose(purpose, env)
