"""Base adapter interface for MCP clients."""

import functools
import json
import os
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any, ClassVar

from ...core.command_logger import library_logger
from ...core.remediation import MCP_ENV_VARS_UNRESOLVED
from ...models.dependency.mcp import _EXTRA_DENYLIST, TrustedEnvLiteral
from ...utils.atomic_io import umask_file_mode
from ...utils.json_config import json_config_text, write_json_config
from ...utils.path_security import has_symlink_component, user_config_crosses_link
from .config_journal import journal_config_write, journal_config_written

_INPUT_VAR_RE = re.compile(r"\$\{input:([^}]+)\}")

# Matches ${VAR} and ${env:VAR}, capturing VAR. Intentionally does NOT match
# ${input:VAR} (the optional ``env:`` group cannot also satisfy ``input:``),
# nor GitHub Actions ``${{ ... }}`` templates (the second ``{`` fails the
# identifier class). This keeps env-var handling fully disjoint from input
# variable handling, so existing _INPUT_VAR_RE call sites are unaffected.
_ENV_VAR_RE = re.compile(r"\$\{(?:env:)?([A-Za-z_][A-Za-z0-9_]*)\}")

# Superset of _ENV_VAR_RE that also matches the legacy ``<VAR>`` syntax
# (uppercase identifier only). Used as the single-pass translation target so
# resolved values are NOT re-scanned -- a literal value whose text happens to
# contain ``${...}`` does not get recursively expanded. ``${input:...}`` is
# intentionally not matched here so input-variable handling stays disjoint.
_ENV_PLACEHOLDER_RE = re.compile(r"<([A-Z_][A-Z0-9_]*)>|" + _ENV_VAR_RE.pattern)

# Detects the legacy ``<VAR>`` placeholder syntax only. Used to aggregate
# deprecation warnings across all servers in a single install run.
_LEGACY_ANGLE_VAR_RE = re.compile(r"<([A-Z_][A-Z0-9_]*)>")
_RUNTIME_TEMPLATE_VARIABLE_RE = re.compile(r"(?<!\$)\{([a-zA-Z_][a-zA-Z0-9_]*)\}")

# MCP Registry v0.1 names the container registry type ``oci``; the adapters
# below key their launcher dispatch on ``docker`` (the vocabulary the legacy
# registry shape used, and what ``_infer_registry_name`` derives from a
# ``docker`` runtime hint or an image-shaped package name). Without this
# mapping an ``oci`` package matches no launcher branch and falls through to
# the generic ``npx`` default, which hands the image reference to npm as a
# package name -- a dependency-confusion exposure, not just a broken config
# (#2376). Keyed on the lowercased registry type; unlisted values pass through
# untouched.
_REGISTRY_TYPE_ALIASES = {"oci": "docker"}
_DOCKER_RUN_OPTIONS_WITH_VALUES = frozenset(
    {
        "--add-host",
        "--annotation",
        "--attach",
        "--blkio-weight",
        "--blkio-weight-device",
        "--cap-add",
        "--cap-drop",
        "--cgroup-parent",
        "--cgroupns",
        "--cidfile",
        "--cpu-count",
        "--cpu-percent",
        "--cpu-period",
        "--cpu-quota",
        "--cpu-rt-period",
        "--cpu-rt-runtime",
        "--cpu-shares",
        "--cpus",
        "--cpuset-cpus",
        "--cpuset-mems",
        "--detach-keys",
        "--device",
        "--device-cgroup-rule",
        "--device-read-bps",
        "--device-read-iops",
        "--device-write-bps",
        "--device-write-iops",
        "--dns",
        "--dns-opt",
        "--dns-option",
        "--dns-search",
        "--domainname",
        "--entrypoint",
        "--env",
        "--env-file",
        "--expose",
        "--gpus",
        "--group-add",
        "--health-cmd",
        "--health-interval",
        "--health-retries",
        "--health-start-interval",
        "--health-start-period",
        "--health-timeout",
        "--hostname",
        "--io-maxbandwidth",
        "--io-maxiops",
        "--ip",
        "--ip6",
        "--ipc",
        "--isolation",
        "--kernel-memory",
        "--label",
        "--label-file",
        "--link",
        "--link-local-ip",
        "--log-driver",
        "--log-opt",
        "--mac-address",
        "--memory",
        "--memory-reservation",
        "--memory-swap",
        "--memory-swappiness",
        "--mount",
        "--name",
        "--net",
        "--net-alias",
        "--network",
        "--network-alias",
        "--oom-score-adj",
        "--pid",
        "--pids-limit",
        "--platform",
        "--publish",
        "--pull",
        "--restart",
        "--runtime",
        "--security-opt",
        "--shm-size",
        "--stop-signal",
        "--stop-timeout",
        "--storage-opt",
        "--sysctl",
        "--tmpfs",
        "--ulimit",
        "--user",
        "--userns",
        "--uts",
        "--volume",
        "--volume-driver",
        "--volumes-from",
        "--workdir",
        "-a",
        "-c",
        "-e",
        "-h",
        "-l",
        "-m",
        "-p",
        "-u",
        "-v",
        "-w",
    }
)


def _docker_image_repository(reference: str) -> str:
    """Return the repository component of a container image reference.

    Drops an ``@sha256:...`` digest and a trailing ``:tag`` so that two
    references to the same repository compare equal regardless of how each
    side is pinned. A ``host:port/`` prefix is preserved, since a tag can
    only appear in the final path segment.

    Docker Hub is also folded to its short form: a registry commonly
    publishes a fully qualified ``identifier`` while the run arguments it
    ships use the implicit spelling, and treating those as different
    repositories would append a second image operand.
    """
    repository = reference.split("@", 1)[0]
    last_segment = repository.rsplit("/", 1)[-1]
    tag_at = last_segment.find(":")
    if tag_at != -1:
        repository = repository[: len(repository) - len(last_segment) + tag_at]
    for default_registry in ("docker.io/", "index.docker.io/"):
        if repository.startswith(default_registry):
            repository = repository[len(default_registry) :]
            break
    # Only meaningful once the implicit registry is stripped: ``library/`` is
    # where Docker Hub keeps official images, so ``library/redis`` is ``redis``.
    if repository.startswith("library/"):
        repository = repository[len("library/") :]
    return repository


# Config keys that ``_extra`` passthrough must NEVER set on a rendered harness
# config. Covers the modeled MCP fields (imported single-source from the model)
# plus harness-specific aliases that mirror a modeled field under a different
# name -- e.g. Codex emits ``http_headers`` for remote auth headers, which must
# not be injectable via passthrough. Enforced unconditionally per adapter path
# (NOT guarded by "key absent from config"), so it also closes paths that do not
# pre-set the key. Security boundary for PR #1765 / issue #1670.
@dataclass(frozen=True)
class _MCPLauncherArgumentGroup:
    """One atomic registry argument and its rendered argv values."""

    kind: str
    values: tuple[str, ...]


def registry_field_is_required(field: dict[str, Any]) -> bool:
    """Return True unless registry metadata explicitly marks a field optional."""
    return field.get("required", field.get("is_required", True)) is not False


def _translate_env_placeholder(value):
    """Pure-textual translation of env-var placeholders to the canonical
    ``${VAR}`` runtime-substitution syntax.

    Security-critical helper for issue #1152: MUST NOT read ``os.environ``
    and MUST NOT resolve placeholders to literal values. Runtimes that
    support runtime substitution (Copilot CLI) resolve ``${VAR}`` from the
    host environment at server-start, so APM emits placeholders verbatim
    rather than baking secrets to disk.

    Translations:
        ``${env:VAR}``     -> ``${VAR}``     (strip ``env:`` prefix)
        ``${VAR}``         -> ``${VAR}``     (no-op)
        ``<VAR>``          -> ``${VAR}``     (legacy syntax migration)
        ``${VAR:-default}``-> passthrough    (regex doesn't match)
        ``$VAR`` (bare)    -> passthrough    (regex doesn't match)
        ``${input:foo}``   -> passthrough    (regex doesn't match)
        non-string         -> passthrough

    Idempotent: applying twice yields the same result as applying once.
    """
    if not isinstance(value, str):
        return value

    def _to_brace(match):
        # group(1) = legacy <VAR>; group(2) = ${VAR} / ${env:VAR}
        var_name = match.group(1) or match.group(2)
        return "${" + var_name + "}"

    return _ENV_PLACEHOLDER_RE.sub(_to_brace, value)


def _extract_legacy_angle_vars(value):
    """Return the set of legacy ``<VAR>`` names present in *value*.

    Used to aggregate deprecation warnings across all servers in a single
    install run, so authors see one helpful list instead of one warning per
    occurrence.
    """
    if not isinstance(value, str):
        return set()
    return set(_LEGACY_ANGLE_VAR_RE.findall(value))


def _has_env_placeholder(value):
    """True if *value* is a string containing any recognised env-var
    placeholder syntax (``${VAR}``, ``${env:VAR}``, or legacy ``<VAR>``).

    Used to distinguish placeholder-sourced env values (which translate)
    from hardcoded literal defaults (which stay literal).
    """
    if not isinstance(value, str):
        return False
    return bool(_ENV_PLACEHOLDER_RE.search(value))


def _stringify_env_literal(value):
    """Return MCP env literal values in the manifest ``map<string, string>`` shape."""
    if isinstance(value, bool):
        return str(value).lower()
    return str(value)


_SYMLINKED_MCP_CONFIG = (
    "Skipped {path}: APM does not write MCP config through symlinks. "
    "Replace the symlink or configure this server manually."
)


# Config paths already reported unreadable in this process (#4332): one install
# reads a client config more than once, but the user needs one warning per file.
_UNREADABLE_CONFIGS_WARNED: set[str] = set()


def warn_unreadable_config_once(logger, config_path: Path, exc: Exception) -> None:
    """Log ``Could not read <path>: <exc>`` once per config path per process."""
    key = str(config_path)
    if key in _UNREADABLE_CONFIGS_WARNED:
        logger.debug("Could not read %s: %s", config_path, exc)
        return
    _UNREADABLE_CONFIGS_WARNED.add(key)
    logger.warning("Could not read %s: %s", config_path, exc)


def _warn_symlinked_mcp_config(config_path: Path) -> None:
    library_logger().warning(_SYMLINKED_MCP_CONFIG.format(path=config_path), symbol="warning")


class MCPClientAdapter(ABC):
    """Base adapter for MCP clients."""

    # Identifier matching the corresponding ``KNOWN_TARGETS`` entry name.
    # Subclasses MUST override this so target-aware code can look up
    # per-target metadata via ``KNOWN_TARGETS[adapter.target_name]``
    # instead of sniffing class names.  The ``vscode`` adapter is the
    # only MCP-only pseudo-target (no entry in ``KNOWN_TARGETS``), so
    # downstream code that joins on this field must tolerate misses.
    target_name: str = ""

    # Top-level config key under which this adapter's MCP server entries
    # live (``"mcpServers"``, ``"mcp_servers"``, ``"servers"``, ...).
    # Subclasses MUST override this; ``MCPConflictDetector`` reads it to
    # extract existing server configs without classname dispatch.
    # The adapter is the canonical owner of its config schema, so this
    # field lives here rather than on ``TargetProfile`` (which is
    # primitive-focused) and applies uniformly to MCP-only adapters
    # (e.g. ``VSCodeClientAdapter``) that have no ``KNOWN_TARGETS`` entry.
    mcp_servers_key: str = ""
    # Native JSON configs keep the byte layout each harness has always had
    # (only Claude Code ends its JSON configs with a newline).
    json_config_trailing_newline: bool = False

    # Whether an existing native entry with the requested name is compared by
    # content before writing, so a differing user connection is preserved and
    # reported as a conflict instead of "already configured" (#3239, #3681).
    # Consumed only through ``install.mcp.ownership.native_comparison_clients``.
    compares_native_connections: bool = True

    # Whether an unchanged declaration still rewrites an APM-written entry whose
    # render now differs only through the install environment (credential
    # source precedence, resolved values). Claude and Codex reconcile those; the
    # other adapters keep their written entry until the declaration changes.
    refreshes_environment_renders: bool = False

    # Render-time state owned by ``_remote_shapes``: a retired shape while
    # ``legacy_managed_renders`` reproduces an earlier APM render, and the
    # nesting depth of comparison renders (which raise instead of warning on
    # an unsupported transport).
    _remote_shape_override: Any = None
    _comparison_render_depth: int = 0

    @staticmethod
    def _merge_extra(config: dict, server_info: dict) -> dict:
        """Merge harness-specific ``_extra`` keys from server_info into config.

        Two guards apply:

        * Denylist (unconditional): a key naming a modeled MCP field -- or a
          harness alias of one (see ``_EXTRA_DENYLIST``) -- is dropped on EVERY
          path, even when the config does not already carry it. This stops a
          passthrough value from shadowing/redirecting a modeled field on
          adapter paths that start empty or set only a subset of keys.
        * Shadow guard: a non-reserved key is appended only when absent, so it
          never overwrites a value the adapter set itself.
        """
        extra = server_info.get("_extra")
        if extra and isinstance(extra, dict):
            for k, v in extra.items():
                if k in _EXTRA_DENYLIST:
                    continue
                if k not in config:
                    config[k] = v
        return config

    # Whether this adapter's config path is user/global-scoped (e.g.
    # ``~/.copilot/``) rather than workspace-scoped (e.g. ``.vscode/``).
    # Adapters that target a global path should override this to ``True``
    # so that ``apm install --global`` can install MCP servers to them.
    supports_user_scope: bool = False

    # Display path of a user-wide config that even a project install writes,
    # because the runtime has no workspace MCP config (Windsurf). Install
    # output names it so the account-wide effect is never silent (#3994).
    user_wide_config_display: str | None = None

    # Whether the target runtime resolves ``${VAR}`` placeholders from the
    # host environment at server-start time. Adapters that opt in (Copilot
    # CLI) emit placeholders verbatim so secrets never touch disk; legacy
    # adapters resolve to literal values at install time via env_overrides
    # -> os.environ -> optional interactive prompt. See issue #1152.
    _supports_runtime_env_substitution: bool = False

    # Native project-root reference a project-scope config uses for an authored
    # ``${CLAUDE_PLUGIN_ROOT}`` inside the project (#3825). ``None`` writes the
    # absolute package path: the harness documents no portable form.
    plugin_root_project_reference: ClassVar[str | None] = None

    def __init_subclass__(cls, **kwargs):
        """Finalize the project-root reference after every subclass formatter."""
        super().__init_subclass__(**kwargs)
        formatter = cls.__dict__.get("_format_server_config")
        if formatter is None or getattr(formatter, "_finalizes_plugin_root", False):
            return

        @functools.wraps(formatter)
        def _format_with_plugin_root(self, *args, **kwargs):
            from ...deps.plugin_root_render import finalize_project_root

            return finalize_project_root(
                formatter(self, *args, **kwargs), self._plugin_root_reference()
            )

        _format_with_plugin_root._finalizes_plugin_root = True
        cls._format_server_config = _format_with_plugin_root

    def _plugin_root_reference(self) -> str | None:
        """Return this scope's project-root reference; user scope stays absolute."""
        return None if self.user_scope else self.plugin_root_project_reference

    def _self_defined_stdio(self, server_info: dict) -> dict | None:
        """Return the self-defined stdio launcher with its plugin root rendered.

        The only reader of ``_raw_stdio`` in adapters, so every target expands
        an authored ``${CLAUDE_PLUGIN_ROOT}`` through one rule.
        """
        from ...deps.plugin_root_render import PLUGIN_ROOT_INFO_KEY, render_plugin_root

        raw = server_info.get("_raw_stdio")
        return render_plugin_root(
            raw,
            plugin_root=server_info.get(PLUGIN_ROOT_INFO_KEY),
            project_root=self.project_root,
            project_relative=self._plugin_root_reference() is not None,
        )

    def __init__(
        self,
        project_root: Path | str | None = None,
        user_scope: bool = False,
    ):
        """Initialize the adapter with optional scope-aware path context.

        Args:
            project_root: Project root used to resolve project-local config paths.
                When not provided, adapters fall back to the current working
                directory for project-scoped paths.
            user_scope: Whether the adapter should resolve user-scope config
                paths instead of project-local paths when supported.
        """
        self._project_root = Path(project_root) if project_root is not None else None
        self.user_scope = user_scope
        self.written_mcp_hashes: dict[str, str] = {}
        # Per-server tracking populated by the env-resolution helpers and
        # consumed by ``configure_mcp_server`` for the post-install summary
        # and the aggregated legacy-syntax deprecation warning. Defined on
        # the base so every adapter has the attributes regardless of which
        # subclass path constructed it.
        self._last_env_placeholder_keys: set[str] = set()
        self._last_legacy_angle_vars: set[str] = set()

    def _format_runtime_env_placeholder(self, name: str) -> str:
        """Return the target runtime's env-var placeholder syntax for *name*."""
        return "${" + name + "}"

    def _translate_env_placeholder_for_runtime(self, value):
        """Translate env-var placeholders to this adapter's runtime syntax."""
        if not isinstance(value, str):
            return value

        def _to_runtime(match):
            var_name = match.group(1) or match.group(2)
            return self._format_runtime_env_placeholder(var_name)

        return _ENV_PLACEHOLDER_RE.sub(_to_runtime, value)

    @property
    def project_root(self) -> Path:
        """Return the explicit project root or the current working directory."""
        if self._project_root is not None:
            return self._project_root
        return Path(os.getcwd())

    def render_server_config(
        self,
        server_info: dict,
        *,
        env_overrides: dict | None = None,
        runtime_vars: dict | None = None,
    ) -> dict:
        """Render one native server entry for exact baseline comparisons."""
        # A comparison render reports an unsupported transport by raising,
        # so only the install itself warns about the skip.
        self._comparison_render_depth += 1
        try:
            rendered = self._format_server_config(
                server_info,
                env_overrides=env_overrides or {},
                runtime_vars=runtime_vars or {},
            )
        finally:
            self._comparison_render_depth -= 1
        if isinstance(rendered, tuple):
            rendered = rendered[0]
        if not isinstance(rendered, dict):
            raise ValueError("Adapter did not produce a native MCP server mapping")
        return rendered

    def legacy_managed_renders(
        self,
        server_info: dict,
        *,
        env_overrides: dict | None = None,
        runtime_vars: dict | None = None,
    ) -> tuple[dict, ...]:
        """Renders earlier APM releases wrote for the same declaration.

        Rendered with each retired remote shape of this adapter's row
        (``_remote_shapes``), so the ownership owner can recognize, heal or
        retire an APM-written entry in a shape APM no longer writes.
        """
        from ._remote_shapes import remote_shape_of, requested_remote_transport

        shape = remote_shape_of(self)
        if not shape.retired or requested_remote_transport(self, server_info) is None:
            return ()
        kwargs = {"env_overrides": env_overrides, "runtime_vars": runtime_vars}
        try:
            current = self.render_server_config(server_info, **kwargs)
        except ValueError:
            current = None
        renders: list[dict] = []
        for spec in shape.retired:
            self._remote_shape_override = spec
            try:
                candidate = self.render_server_config(server_info, **kwargs)
            except ValueError:
                continue
            finally:
                self._remote_shape_override = None
            if candidate != current and candidate not in renders:
                renders.append(candidate)
        return tuple(renders)

    @staticmethod
    def json_identical(left: object, right: object) -> bool:
        """Compare native JSON values by type as well as value.

        Python equality treats ``True == 1`` and ``1 == 1.0``; native configs
        must not, or a changed JSON type would read as already configured.
        """
        try:
            return json.dumps(left, sort_keys=True) == json.dumps(right, sort_keys=True)
        except (TypeError, ValueError):
            return left == right

    def matches_managed_server_config(self, native: object, expected: dict) -> bool:
        """Compare the native connection with the adapter's rendered baseline."""
        return self.json_identical(native, expected)

    def matches_legacy_managed_server_config(
        self, native: object, expected: dict, *, recorded_write: bool | None = None
    ) -> bool:
        """Recognize an earlier APM write of a connection the lockfile claims.

        ``recorded_write`` is ``True`` or ``False`` when the lockfile holds a
        fingerprint of the earlier write that does or does not match *native*,
        and ``None`` when no fingerprint was recorded. The fingerprint is the
        proof, even when the entry no longer renders identically (for example a
        resolved env value that changed since). Without one, only an entry equal
        to the current render is accepted.
        """
        if recorded_write is not None:
            return recorded_write
        return self.matches_managed_server_config(native, expected)

    def native_conflict_guidance(self, name: str, expected: dict) -> str | None:
        """Extra target-specific guidance for a preserved conflicting entry."""
        return None

    def managed_server_config(self, native: dict) -> dict:
        """Return connection data for an actual-write fingerprint."""
        return dict(native)

    def project_managed_server_config(
        self, native: object, *, baseline: dict, requested: dict
    ) -> object:
        """Return a comparison-only view for an already recorded managed connection."""
        return native

    @abstractmethod
    def get_config_path(self):
        """Get the path to the MCP configuration file."""
        pass

    @abstractmethod
    def update_config(self, config_updates) -> bool | None:
        """Update the MCP configuration.

        Returns ``False`` or ``None`` when the config write was skipped
        (for example because the existing file could not be parsed safely).
        """
        pass

    @abstractmethod
    def get_current_config(self):
        """Get the current MCP configuration."""
        pass

    def validate_config_for_install(self) -> bool:
        """Allow adapters to refuse unsafe configs before existing-server shortcuts."""
        return True

    def _read_json_config_for_update(self, config_path: Path) -> dict | None:
        """Return the JSON object at *config_path* before a merge-and-write.

        A missing or blank file yields ``{}``.  Returns ``None`` after a
        warning when rewriting the file could lose data, so the caller skips
        the write: the existing content is not a JSON object (for example
        JSONC comments), or the path runs through a symlink (under ``$HOME``
        at user scope), which stale cleanup refuses to rewrite later.
        """
        if self.user_scope and self._is_linked_config(config_path):
            _warn_symlinked_mcp_config(config_path)
            return None
        return self._parse_json_config_for_update(config_path)

    def _parse_json_config_for_update(self, config_path: Path) -> dict | None:
        """Parse *config_path* for a merge-and-write.

        Adapters whose user-scope file may live outside ``$HOME`` (for
        example ``CLAUDE_CONFIG_DIR`` or ``COPILOT_HOME``) use this half of
        :meth:`_read_json_config_for_update`, which skips only the
        ``$HOME`` symlink policy. Project-scope configs that are, or are
        reached through, a symbolic link are refused here, so every entry
        point applies it. Same contract: ``{}`` for a missing or blank file,
        ``None`` after a warning when a rewrite could lose data.
        """
        if self._is_linked_project_config(config_path):
            _warn_symlinked_mcp_config(config_path)
            return None
        try:
            raw = config_path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return {}
        except (OSError, UnicodeError) as exc:
            if str(config_path) not in _UNREADABLE_CONFIGS_WARNED:
                _UNREADABLE_CONFIGS_WARNED.add(str(config_path))
                library_logger().warning(
                    f"Could not read {config_path}: {exc} -- skipping config write; "
                    "fix the file's permissions or encoding, or add this server manually",
                    symbol="warning",
                )
            return None
        if not raw.strip():
            return {}
        try:
            config = json.loads(raw)
        except json.JSONDecodeError:
            config = None
        if not isinstance(config, dict):
            library_logger().warning(
                f"Could not parse {config_path} as a JSON object -- skipping config "
                "write to avoid data loss (comments and trailing commas are not "
                "preserved); fix the file or add this server manually",
                symbol="warning",
            )
            return None
        if self.mcp_servers_key in config and not isinstance(config[self.mcp_servers_key], dict):
            library_logger().warning(
                f"Could not parse {config_path}: {self.mcp_servers_key} must be "
                "a JSON object -- skipping config write to avoid data loss; "
                "fix the file or add this server manually",
                symbol="warning",
            )
            return None
        return config

    def _is_linked_config(self, config_path: Path, *, user_root: Path | None = None) -> bool:
        """The one MCP config link policy (project, user under $HOME, relocated user root)."""
        if user_root is None and not self.user_scope:
            return self._is_linked_project_config(config_path)
        return user_config_crosses_link(config_path, user_root or config_path.parent)

    def _is_linked_project_config(self, config_path: Path) -> bool:
        """Return whether a project-scope config path is or crosses a symlink.

        Components below the project root are checked; a path outside it
        (an adapter-specific location) is checked for its final component.
        """
        if self.user_scope:
            return False
        try:
            config_path.relative_to(self.project_root)
        except ValueError:
            return config_path.is_symlink()
        return has_symlink_component(self.project_root, config_path)

    def _is_project_config_path(self, config_path: Path) -> bool:
        """Return whether *config_path* is a project file rather than a home config."""
        if self.user_scope:
            return False
        root = Path(os.path.abspath(self.project_root))
        return Path(os.path.abspath(config_path)).is_relative_to(root)

    def _write_json_config(self, config_path: Path, config: dict, *, shared: bool = False) -> None:
        """Atomically write *config* as JSON and keep the file owner-only.

        Entries can carry env values resolved at install time. ``shared``
        marks a committed project config file: it keeps its existing or
        umask mode instead; paths outside the project stay owner-only. A
        project-scope path that is, or is reached
        through, a symbolic link is refused with ``OSError``.
        """
        if self._is_linked_project_config(config_path):
            raise OSError(_SYMLINKED_MCP_CONFIG.format(path=config_path))
        trailing_newline = self.json_config_trailing_newline
        journal_config_write(
            config_path,
            json_config_text(config_path, config, default_trailing_newline=trailing_newline),
        )
        from ...integration.config_file_provenance import recorded_install_write

        project = shared and self._is_project_config_path(config_path)
        if not project and config_path.is_file():
            os.chmod(config_path, 0o600)  # tighten first: the atomic write keeps the mode
        mode = umask_file_mode(config_path) if project else 0o600
        # The config file record (#4867) lands before the journal seals the write (#5009).
        with recorded_install_write(config_path, self.project_root, self.user_scope):
            write_json_config(
                config_path, config, default_trailing_newline=trailing_newline, new_file_mode=mode
            )
        if not project:
            os.chmod(config_path, 0o600)
        journal_config_written(config_path)

    @abstractmethod
    def configure_mcp_server(
        self,
        server_url,
        server_name=None,
        enabled=True,
        env_overrides=None,
        server_info_cache=None,
        runtime_vars=None,
    ):
        """Configure an MCP server in the client configuration.

        Args:
            server_url (str): URL of the MCP server.
            server_name (str, optional): Name of the server. Defaults to None.
            enabled (bool, optional): Whether to enable the server. Defaults to True.
            env_overrides (dict, optional): Environment variable overrides. Defaults to None.
            server_info_cache (dict, optional): Pre-fetched server info to avoid duplicate registry calls.
            runtime_vars (dict, optional): Runtime variable values. Defaults to None.

        Returns:
            bool: True if successful, False otherwise.
        """
        pass

    @staticmethod
    def _infer_registry_name(package):
        """Infer the registry type from package metadata.

        The MCP registry API often returns empty ``registry_name``.  This
        method derives the registry from explicit fields first, then falls
        back to heuristics on the package name.

        Args:
            package (dict): A single package entry from the registry.

        Returns:
            str: Inferred registry name (e.g. "npm", "pypi", "docker") or "".
            Spec spellings that name the same registry as an APM launcher
            branch are canonicalized via ``_REGISTRY_TYPE_ALIASES`` (v0.1
            ``oci`` -> ``docker``). Malformed explicit values fail closed
            before any package-manager launcher is selected.
        """
        if not package:
            return ""

        explicit = package.get("registry_name", "")
        if not isinstance(explicit, str):
            # Registry payloads are untrusted. A malformed explicit value must
            # fail closed rather than miss every launcher branch and reach the
            # generic npx fallback with an untrusted package name.
            raise ValueError("MCP package registry_name must be a string")
        if explicit and not explicit.strip():
            raise ValueError("MCP package registry_name must not be whitespace")
        if explicit:
            canonical = explicit.strip().lower()
            return _REGISTRY_TYPE_ALIASES.get(canonical, canonical)

        name = package.get("name", "")
        runtime_hint = package.get("runtime_hint", "")

        # Infer from runtime_hint
        if runtime_hint in ("npx", "npm"):
            return "npm"
        if runtime_hint in ("uvx", "pip", "pipx"):
            return "pypi"
        if runtime_hint == "docker":
            return "docker"
        if runtime_hint in ("dotnet", "dnx"):
            return "nuget"

        # Infer from package name patterns
        if name.startswith("@") and "/" in name:
            return "npm"  # scoped npm package, e.g. @azure/mcp
        if name.startswith(("ghcr.io/", "mcr.microsoft.com/", "docker.io/")):
            return "docker"
        if name.startswith("https://") and name.endswith(".mcpb"):
            return "mcpb"
        # PascalCase with dots usually means nuget (e.g. Azure.Mcp)
        if "." in name and not name.startswith("http") and name[0].isupper():
            return "nuget"

        return ""

    def _parse_non_container_argument_groups(
        self,
        arguments: object,
        *,
        resolved_env: dict[str, str] | None = None,
        runtime_vars: dict[str, object] | None = None,
        runtime_variable_fallbacks: dict[str, str] | None = None,
        secret_variable_fallbacks: dict[str, str] | None = None,
        package_name: str = "",
    ) -> list[_MCPLauncherArgumentGroup]:
        """Parse registry arguments without losing named-group boundaries.

        Typed v0.1 entries read ``value`` while untyped legacy entries read
        ``value_hint``. Named arguments remain one atomic group so package
        identity matching cannot confuse a flag value with the package operand.
        Optional groups with unresolved variables are omitted as a whole;
        malformed or unresolved required entries fail closed.

        Args:
            arguments: Raw ``runtime_arguments`` or ``package_arguments`` value.
            resolved_env: Target-native environment placeholder mapping.
            runtime_vars: Values collected for registry argument variables.
            runtime_variable_fallbacks: Target-native fallbacks for variables
                such as VS Code's ``workspaceFolder``.
            secret_variable_fallbacks: Target-native indirections for secret
                values that must not be written literally.
            package_name: Package identity included in actionable diagnostics.

        Returns:
            Ordered atomic launcher argument groups.

        Raises:
            ValueError: If registry argument metadata is malformed or a required
                variable cannot be resolved.
        """
        if arguments is None:
            return []
        if not isinstance(arguments, list):
            raise ValueError("MCP package arguments must be a list")

        groups: list[_MCPLauncherArgumentGroup] = []
        for entry in arguments:
            if not isinstance(entry, dict):
                raise ValueError("MCP package argument entries must be objects")

            raw_type = entry.get("type", "")
            if not isinstance(raw_type, str):
                raise ValueError("MCP package argument type must be a string")
            arg_type = raw_type.strip().lower()
            if arg_type not in ("", "positional", "named"):
                raise ValueError("MCP package argument type must be 'positional' or 'named'")

            required_marker = entry.get(
                "is_required",
                entry.get("isRequired", entry.get("required")),
            )
            if required_marker is not None and not isinstance(required_marker, bool):
                raise ValueError("MCP package argument required marker must be a boolean")
            required = True if required_marker is None else required_marker

            variables = entry.get("variables")
            if variables is not None and not isinstance(variables, dict):
                raise ValueError("MCP package argument variables must be an object")
            if not required and "variables" not in entry:
                continue

            if arg_type:
                raw_value = entry.get("value", entry.get("default"))
            else:
                raw_value = entry.get(
                    "value_hint",
                    entry.get("value", entry.get("default")),
                )

            name = entry.get("name")
            if arg_type == "named" and not isinstance(name, str):
                raise ValueError("MCP package argument name must be a string")
            if arg_type == "named" and not name:
                raise ValueError("MCP package argument name must not be empty")

            if raw_value is None or raw_value == "":
                if arg_type == "named" and name:
                    if required:
                        groups.append(_MCPLauncherArgumentGroup("named", (name,)))
                elif required:
                    raise ValueError(
                        f"MCP package argument for '{package_name or 'unknown'}' "
                        "is missing a required positional value"
                    )
                continue
            if not isinstance(raw_value, str):
                raise ValueError("MCP package argument value must be a string")

            rendered, unresolved_variable = self._resolve_non_container_argument_value(
                raw_value,
                variables=variables or {},
                resolved_env=resolved_env or {},
                runtime_vars=runtime_vars or {},
                runtime_variable_fallbacks=runtime_variable_fallbacks or {},
                secret_variable_fallbacks=secret_variable_fallbacks or {},
            )
            if rendered is None:
                if required:
                    raise ValueError(
                        "Could not resolve required MCP package argument variable "
                        f"'{unresolved_variable or 'unknown'}' for "
                        f"'{package_name or 'unknown'}'"
                    )
                continue

            if arg_type == "named" and name:
                groups.append(_MCPLauncherArgumentGroup("named", (name, rendered)))
            else:
                kind = "positional" if arg_type == "positional" else "legacy"
                groups.append(_MCPLauncherArgumentGroup(kind, (rendered,)))
        return groups

    def _resolve_non_container_argument_value(
        self,
        template: str,
        *,
        variables: dict[object, object],
        resolved_env: dict[str, str],
        runtime_vars: dict[str, object],
        runtime_variable_fallbacks: dict[str, str],
        secret_variable_fallbacks: dict[str, str],
    ) -> tuple[str | None, str | None]:
        """Resolve one argument value and identify any absent variable."""
        for variable_name, variable_info in variables.items():
            if not isinstance(variable_name, str):
                raise ValueError("MCP package argument variable names must be strings")
            if not isinstance(variable_info, dict):
                raise ValueError("MCP package argument variable metadata must be an object")
            placeholder = f"{{{variable_name}}}"
            if placeholder not in template:
                continue
            secret_marker = variable_info.get(
                "isSecret",
                variable_info.get("is_secret", False),
            )
            if not isinstance(secret_marker, bool):
                raise ValueError("MCP package argument variable isSecret marker must be a boolean")
            if secret_marker:
                replacement = secret_variable_fallbacks.get(variable_name)
                if replacement is None and self._supports_runtime_env_substitution:
                    replacement = self._format_runtime_env_placeholder(variable_name)
            else:
                supplied = runtime_vars.get(variable_name)
                if supplied is not None and str(supplied) != "":
                    replacement = str(supplied)
                else:
                    configured = variable_info.get(
                        "value",
                        variable_info.get("default"),
                    )
                    if configured is not None and not isinstance(configured, str):
                        raise ValueError("MCP package argument variable value must be a string")
                    replacement = configured or runtime_variable_fallbacks.get(variable_name)
            if replacement is None:
                return None, variable_name
            template = template.replace(placeholder, replacement)

        string_runtime_vars = {
            key: str(value) for key, value in runtime_vars.items() if value is not None
        }
        return (
            self._resolve_variable_placeholders(
                template,
                resolved_env,
                string_runtime_vars,
            ),
            None,
        )

    @staticmethod
    def _package_runtime_variable_metadata(
        package: dict[str, Any] | None,
    ) -> dict[str, dict] | None:
        """Return one validated runtime-variable declaration map for a package.

        Registry metadata may declare a variable on one argument and reference it
        later without repeating the declaration. Keeping this map package-scoped
        makes those references resolve consistently while rejecting malformed
        secret metadata before an adapter can render a collected value.
        """
        metadata_by_name: dict[str, dict] = {}
        for field_name in ("runtime_arguments", "package_arguments"):
            for argument in (package or {}).get(field_name) or []:
                if not isinstance(argument, dict):
                    continue
                variables = argument.get("variables")
                if variables is None:
                    continue
                if not isinstance(variables, dict):
                    return None
                for name, metadata in variables.items():
                    if not isinstance(name, str) or not isinstance(metadata, dict):
                        return None
                    secret_marker = metadata.get("isSecret", metadata.get("is_secret", False))
                    if not isinstance(secret_marker, bool):
                        return None
                    existing = metadata_by_name.get(name)
                    if existing is not None and existing != metadata:
                        return None
                    metadata_by_name[name] = metadata
        return metadata_by_name

    @staticmethod
    def _substitute_runtime_variables(
        template: str,
        variables: dict[object, object] | None,
        runtime_vars: dict[str, object] | None,
        runtime_variable_fallbacks: dict[str, str] | None = None,
        secret_variable_fallbacks: dict[str, str] | None = None,
    ) -> str | None:
        """Resolve every APM runtime variable in one registry argument template.

        Variable metadata may appear on an earlier argument while later
        arguments reference the same value. Collected values therefore apply to
        every template, not only the metadata-bearing entry. Target-specific
        fallbacks are used only for declared variables with no collected value.
        """
        secret_fallbacks = secret_variable_fallbacks or {}
        values: dict[str, str] = dict(secret_fallbacks)
        for name, value in (runtime_vars or {}).items():
            if (
                isinstance(name, str)
                and name not in secret_fallbacks
                and value is not None
                and str(value) != ""
            ):
                values[name] = str(value)

        fallbacks = runtime_variable_fallbacks or {}
        for name, metadata in (variables or {}).items():
            if not isinstance(name, str) or not isinstance(metadata, dict):
                return None
            placeholder = f"{{{name}}}"
            if placeholder not in template or name in values:
                continue
            secret_marker = metadata.get("isSecret", metadata.get("is_secret", False))
            if not isinstance(secret_marker, bool):
                return None
            if secret_marker is True:
                return None
            fallback = fallbacks.get(name)
            if fallback is not None:
                values[name] = fallback
                continue
            configured = metadata.get("value", metadata.get("default"))
            if isinstance(configured, str) and configured:
                values[name] = configured
            elif configured is not None:
                return None

        for name, value in values.items():
            template = template.replace(f"{{{name}}}", value)

        if _RUNTIME_TEMPLATE_VARIABLE_RE.search(template):
            return None
        return template

    @staticmethod
    def _processed_non_container_argument_groups(
        arguments: list[object],
    ) -> list[_MCPLauncherArgumentGroup]:
        """Wrap already-processed compatibility inputs as positional groups."""
        return [_MCPLauncherArgumentGroup("legacy", (str(argument),)) for argument in arguments]

    @staticmethod
    def _flatten_non_container_argument_groups(
        groups: list[_MCPLauncherArgumentGroup],
    ) -> list[str]:
        """Flatten ordered atomic groups without changing their contents."""
        return [value for group in groups for value in group.values]

    @staticmethod
    def _build_non_container_launcher_argv(
        package_name: str,
        runtime_groups: list[_MCPLauncherArgumentGroup],
        package_groups: list[_MCPLauncherArgumentGroup],
        *,
        launcher_prefix: tuple[str, ...] = (),
    ) -> list[str]:
        """Merge one package identity into a typed non-container launcher argv.

        Package detection is semantic and type-aware. The first non-option
        typed positional group can satisfy package identity; named groups are
        atomic and their values never count. Untyped legacy runtime argv are
        searched for the identifier because their historical shape carries no
        stronger type signal. Package groups never satisfy launcher identity;
        they are arguments to the package binary. This preserves a legitimate
        flag value equal to the package name while avoiding duplicate package
        operands.

        Args:
            package_name: Registry package identifier.
            runtime_groups: Ordered runtime argument groups.
            package_groups: Ordered package argument groups appended last.
            launcher_prefix: Default launcher operands preceding the package,
                such as npm's ``-y``.

        Returns:
            Complete ordered launcher argv.

        Raises:
            ValueError: If the package identifier is missing or malformed.
        """
        if not isinstance(package_name, str) or not package_name:
            raise ValueError("MCP package name must be a non-empty string")

        identity_present = any(
            group.kind == "legacy"
            and len(group.values) == 1
            and MCPClientAdapter._package_identity_matches(
                group.values[0],
                package_name,
            )
            for group in runtime_groups
        )
        for group in runtime_groups:
            if identity_present:
                break
            if group.kind != "positional" or len(group.values) != 1:
                continue
            candidate = group.values[0]
            if candidate in launcher_prefix or candidate.startswith("-"):
                continue
            if MCPClientAdapter._package_identity_matches(candidate, package_name):
                identity_present = True
            break

        leading_prefix_groups = 0
        for expected, group in zip(launcher_prefix, runtime_groups, strict=False):
            if group.kind == "named" or group.values != (expected,):
                break
            leading_prefix_groups += 1
        has_leading_prefix = leading_prefix_groups == len(launcher_prefix)

        runtime_values = MCPClientAdapter._flatten_non_container_argument_groups(runtime_groups)
        package_values = MCPClientAdapter._flatten_non_container_argument_groups(package_groups)
        if identity_present:
            if launcher_prefix and not has_leading_prefix:
                runtime_values = [*launcher_prefix, *runtime_values]
        elif launcher_prefix and has_leading_prefix:
            insertion = len(launcher_prefix)
            runtime_values = [
                *runtime_values[:insertion],
                package_name,
                *runtime_values[insertion:],
            ]
        else:
            runtime_values = [
                *launcher_prefix,
                package_name,
                *runtime_values,
            ]
        return [*runtime_values, *package_values]

    @staticmethod
    def _package_identity_matches(candidate: str, package_name: str) -> bool:
        """Return whether a positional operand identifies the package."""
        if candidate == package_name:
            return True
        version_prefix = f"{package_name}@"
        return candidate.startswith(version_prefix) and len(candidate) > len(version_prefix)

    @staticmethod
    def _docker_image_references_match(left: Any, right: Any) -> bool:
        """Return whether two strings name the same image repository."""
        return (
            isinstance(left, str)
            and isinstance(right, str)
            and _docker_image_repository(left) == _docker_image_repository(right)
        )

    @staticmethod
    def _docker_option_requires_value(argument: Any) -> bool:
        """Return whether a Docker run option needs a separate value."""
        if not isinstance(argument, str) or "=" in argument:
            return False
        if argument.startswith("--"):
            return argument in _DOCKER_RUN_OPTIONS_WITH_VALUES
        if not argument.startswith("-") or argument == "-":
            return False
        short_options = argument[1:]
        for index, short_name in enumerate(short_options):
            if f"-{short_name}" in _DOCKER_RUN_OPTIONS_WITH_VALUES:
                return index == len(short_options) - 1
        return False

    @classmethod
    def _docker_image_arg_index(
        cls,
        runtime_args: list[Any],
        image: str | None,
    ) -> int | None:
        """Return the matching Docker image operand index, or None."""
        if not image or not runtime_args or runtime_args[0] != "run":
            return None
        index = 1
        while index < len(runtime_args):
            argument = runtime_args[index]
            if argument == "--":
                index += 1
                break
            if isinstance(argument, str) and argument.startswith("--"):
                option = argument.split("=", 1)[0]
                consumes_next = "=" not in argument and option in _DOCKER_RUN_OPTIONS_WITH_VALUES
                if consumes_next and index + 1 >= len(runtime_args):
                    raise ValueError(f"Docker run option '{option}' requires a value")
                index += 2 if consumes_next else 1
                continue
            if isinstance(argument, str) and argument.startswith("-") and argument != "-":
                consumes_next = cls._docker_option_requires_value(argument)
                if consumes_next and index + 1 >= len(runtime_args):
                    raise ValueError(f"Docker run option '{argument}' requires a value")
                index += 2 if consumes_next else 1
                continue
            break
        if index >= len(runtime_args):
            return None
        candidate = runtime_args[index]
        if cls._docker_image_references_match(candidate, image):
            return index
        return None

    @classmethod
    def _is_options_only(cls, args: list[Any]) -> bool:
        """Return True if args contains only options and their values.

        An argument list is considered options-only if every non-option token
        is consumed as the value of a preceding option that requires an
        argument, and no positional subcommands or operands are present.
        """
        if not args:
            return True
        index = 0
        while index < len(args):
            arg = args[index]
            if not isinstance(arg, str):
                return False
            if arg == "--":
                return False
            if arg.startswith("--"):
                option = arg.split("=", 1)[0]
                consumes_next = "=" not in arg and option in _DOCKER_RUN_OPTIONS_WITH_VALUES
                if consumes_next:
                    if index + 1 >= len(args):
                        return False
                    index += 2
                else:
                    index += 1
                continue
            next_arg = args[index + 1] if index + 1 < len(args) else None
            if arg.startswith("-") and arg != "-":
                consumes_next = cls._docker_option_requires_value(arg)
                if arg in ("-v", "--version") and next_arg == "run":
                    consumes_next = False
                if consumes_next:
                    if index + 1 >= len(args):
                        return False
                    index += 2
                else:
                    index += 1
                continue
            return False
        return True

    @classmethod
    def _is_docker_package(cls, package: dict | None) -> bool:
        """Return whether the package resolves to a Docker/container launcher."""
        if not package:
            return False
        runtime_hint = package.get("runtime_hint", "")
        registry_name = cls._infer_registry_name(package)
        return runtime_hint == "docker" or registry_name == "docker"

    @classmethod
    def _ensure_docker_run_args(
        cls,
        runtime_args: list[Any] | None,
    ) -> list[Any]:
        """Return runtime arguments with Docker's 'run' subcommand and stdio flags.

        If runtime_args is empty, defaults to ['run', '-i', '--rm'].
        If runtime_args contains options without a leading 'run' subcommand
        (e.g. options-only metadata from OCI registries), prepends 'run' and
        ensures '-i' and '--rm' are present unless already specified.
        Otherwise, returns runtime_args as is to preserve authored invocations
        (such as ['container', 'run', ...]).

        Args:
            runtime_args: Resolved runtime arguments from the package entry.

        Returns:
            list: Arguments with leading 'run', '-i', '--rm' and any options,
            or authored arguments preserved as is.
        """
        if not runtime_args:
            return ["run", "-i", "--rm"]
        args = list(runtime_args)
        if not cls._is_options_only(args):
            return args

        has_interactive = False
        has_rm = False
        index = 0
        while index < len(args):
            arg = args[index]
            if arg in ("-i", "--interactive") or (
                isinstance(arg, str)
                and arg.startswith("-")
                and not arg.startswith("--")
                and "i" in arg[1:]
                and not cls._docker_option_requires_value(arg)
            ):
                has_interactive = True
                index += 1
            elif arg == "--rm":
                has_rm = True
                index += 1
            elif isinstance(arg, str) and arg.startswith("--"):
                option = arg.split("=", 1)[0]
                consumes_next = "=" not in arg and option in _DOCKER_RUN_OPTIONS_WITH_VALUES
                index += 2 if consumes_next else 1
            elif isinstance(arg, str) and arg.startswith("-") and arg != "-":
                consumes_next = cls._docker_option_requires_value(arg)
                index += 2 if consumes_next else 1
            else:
                index += 1

        prefix = ["run"]
        if not has_interactive:
            prefix.append("-i")
        if not has_rm:
            prefix.append("--rm")
        return [*prefix, *args]

    @classmethod
    def _ensure_docker_image_arg(
        cls,
        runtime_args: list[Any],
        image: str | None,
    ) -> list[Any]:
        """Return *runtime_args* with the container image operand present.

        ``docker run [OPTIONS] IMAGE`` needs the image after the run options.
        Registries that list it as the last ``runtime_arguments`` entry already
        satisfy that; registries that expose it only as the package
        ``identifier`` leave the resolved args ending at the last option, which
        would render an image-less ``docker run`` that fails on invocation
        (#2376).

        The image is appended only when no argument already references the same
        repository. Comparison is on the repository component, so a digest- or
        tag-pinned identifier still matches a differently-pinned argument
        instead of being appended a second time -- a duplicate operand would be
        parsed by Docker as the container command and break a launcher that
        previously worked.

        Args:
            runtime_args (list): Resolved registry runtime arguments.
            image (str): Container image reference from the package entry.

        Returns:
            list: A new list of ``docker run`` arguments.
        """
        runtime_args = list(runtime_args)
        if not image:
            return runtime_args
        if cls._docker_image_arg_index(runtime_args, image) is not None:
            return runtime_args
        runtime_args.append(image)
        return runtime_args

    @classmethod
    def _select_best_package(cls, packages):
        """Select the best package for installation from available packages.

        Prioritizes packages in order: npm, docker, pypi, homebrew, others.
        Uses ``_infer_registry_name`` so selection works even when the
        registry API returns empty ``registry_name``.

        Args:
            packages (list): List of package dictionaries.

        Returns:
            dict: Best package to use, or None if no suitable package found.
        """
        priority_order = ["npm", "docker", "pypi", "homebrew"]

        for target in priority_order:
            for package in packages:
                if cls._infer_registry_name(package) == target:
                    return package

        # If no priority package found, return the first one
        return packages[0] if packages else None

    @classmethod
    def selected_remote(cls, server_info) -> dict | None:
        """Return the remote entry this adapter renders for *server_info*, if any."""
        if not isinstance(server_info, dict) or server_info.get("_raw_stdio"):
            return None
        remotes = server_info.get("remotes") or []
        if not remotes:
            return None
        remote = cls._select_remote_with_url(remotes) or remotes[0]
        return remote if isinstance(remote, dict) else None

    @staticmethod
    def _select_remote_with_url(remotes):
        """Return the first remote entry that has a non-empty URL.

        Args:
            remotes (list): Candidate remote entries from the registry.

        Returns:
            dict or None: The first usable remote, or None if none qualify.
        """
        for remote in remotes:
            url = (remote.get("url") or "").strip()
            if url:
                return remote
        return None

    @staticmethod
    def _warn_input_variables(mapping, server_name, runtime_label):
        """Emit a warning for each ``${input:...}`` reference found in *mapping*.

        Runtimes that do not support VS Code-style input prompts (Copilot CLI,
        Codex CLI, etc.) should call this so users know their placeholders
        will not be resolved at runtime.

        Args:
            mapping (dict): Header or env dict to scan.
            server_name (str): Server name for the warning message.
            runtime_label (str): Human-readable runtime name (e.g. "Copilot CLI").
        """
        if not mapping:
            return
        seen: set = set()
        for value in mapping.values():
            if not isinstance(value, str):
                continue
            for match in _INPUT_VAR_RE.finditer(value):
                var_id = match.group(1)
                if var_id in seen:
                    continue
                seen.add(var_id)
                library_logger().warning(
                    f"${{input:{var_id}}} in server "
                    f"'{server_name}' will not be resolved -- "
                    f"{runtime_label} does not support input variable prompts"
                )

    def normalize_project_arg(self, value):
        """Normalize workspace placeholders for project-local runtimes."""
        if (
            not self.user_scope
            and isinstance(value, str)
            and value in {"${workspaceFolder}", "${projectRoot}", "${workspaceRoot}"}
        ):
            return "."
        return value

    # -- Env-var placeholder resolution -------------------------------------
    # GitHub MCP server defaults: not secrets, preserved literal in translate
    # mode and used as fallbacks in legacy mode. The defaults apply regardless
    # of which client CLI runs the server, so they live on the base.
    _DEFAULT_GITHUB_ENV: ClassVar[dict[str, str]] = {
        "GITHUB_TOOLSETS": "context",
        "GITHUB_DYNAMIC_TOOLSETS": "1",
    }

    @staticmethod
    def _should_skip_env_prompts(env_overrides):
        """True when the caller has already collected env vars (managed mode),
        when APM_E2E_TESTS is set, or when stdin/stdout is not a TTY.

        Centralising this policy keeps the resolver paths consistent and
        avoids subtle drift between ``_resolve_environment_variables`` and
        ``_resolve_env_variable``.
        """
        import sys

        if env_overrides:
            return True
        if os.getenv("APM_E2E_TESTS") == "1":
            return True
        return not (sys.stdin.isatty() and sys.stdout.isatty())

    def _resolve_explicit_environment_values(
        self,
        env_vars: dict[str, object],
        env_overrides: dict[str, str] | None = None,
    ) -> dict[str, str]:
        """Translate authored references while preserving explicit env literals.

        Resets placeholder tracking; mid-render callers must preserve prior keys.
        """
        resolved: dict[str, str] = {}
        self._last_env_placeholder_keys = set()
        for name, value in env_vars.items():
            if not name or value is None:
                continue
            if isinstance(value, TrustedEnvLiteral):
                resolved[name] = value
            elif isinstance(value, str):
                resolved[name] = self._resolve_env_variable(name, value, env_overrides)
            else:
                resolved[name] = _stringify_env_literal(value)
        return resolved

    def _resolve_environment_variables(self, env_vars, env_overrides=None):
        """Resolve (or translate) declared environment variables.

        Behaviour follows ``self._supports_runtime_env_substitution``:
        translate-mode (Copilot CLI) emits ``${VAR}`` placeholders verbatim
        so the runtime resolves them at server-start (see issue #1152);
        legacy-mode resolves placeholders to literal values via env_overrides
        -> os.environ -> optional interactive prompt.

        Args:
            env_vars: Either a ``dict[name, value-or-placeholder]`` from a
                self-defined stdio dep (``_raw_stdio["env"]``), or a
                ``list[{name, description, required}]`` from the registry.
            env_overrides: Pre-collected env-var overrides (ignored in
                translate mode).

        Returns:
            dict: ``{name: value}`` -- placeholder string in translate
            mode, literal value in legacy mode.
        """
        # ---- translate mode, dict shape (self-defined stdio in apm.yml) ----
        if isinstance(env_vars, dict) and self._supports_runtime_env_substitution:
            # Value type is intentionally untyped: most entries are translated
            # placeholder strings, but non-string values (e.g. an int/bool
            # YAML scalar) are passed through verbatim and serialised by the
            # adapter's config writer (JSON/TOML).
            translated: dict = {}
            placeholder_keys: list[str] = []
            for name, raw_value in env_vars.items():
                if not name:
                    continue
                if not isinstance(raw_value, str):
                    translated[name] = raw_value
                    continue
                if isinstance(raw_value, TrustedEnvLiteral):
                    translated[name] = raw_value
                elif _has_env_placeholder(raw_value):
                    self._last_legacy_angle_vars.update(_extract_legacy_angle_vars(raw_value))
                    translated[name] = self._translate_env_placeholder_for_runtime(raw_value)
                    placeholder_keys.extend(
                        m.group(1) for m in _ENV_VAR_RE.finditer(translated[name])
                    )
                elif (
                    name in self._DEFAULT_GITHUB_ENV and raw_value == self._DEFAULT_GITHUB_ENV[name]
                ):
                    translated[name] = raw_value
                else:
                    # Literal value present in apm.yml -- replace with a
                    # runtime placeholder so the secret never touches disk.
                    translated[name] = self._format_runtime_env_placeholder(name)
                    placeholder_keys.append(name)
            self._last_env_placeholder_keys = set(placeholder_keys)
            return translated

        # ---- translate mode, registry list shape ----
        if self._supports_runtime_env_substitution:
            resolved: dict[str, str] = {}
            placeholder_keys: list[str] = []
            for env_var in env_vars:
                if not isinstance(env_var, dict):
                    continue
                name = env_var.get("name", "")
                if not name:
                    continue
                if name in self._DEFAULT_GITHUB_ENV:
                    resolved[name] = self._DEFAULT_GITHUB_ENV[name]
                else:
                    resolved[name] = self._format_runtime_env_placeholder(name)
                    placeholder_keys.append(name)
            self._last_env_placeholder_keys = set(placeholder_keys)
            return resolved

        # ---- legacy mode, dict shape (self-defined stdio in apm.yml) ----
        # Issue #1266 / #1222: ``_raw_stdio["env"]`` is a plain dict. Each
        # value is resolved via the same single-value pipeline used for
        # header values so all three placeholder syntaxes (``<VAR>``,
        # ``${VAR}``, ``${env:VAR}``) behave consistently across adapters.
        #
        # Note the deliberate semantic divergence from the legacy-list branch
        # below: empty strings authored in apm.yml are preserved as-is and
        # ``_DEFAULT_GITHUB_ENV`` fallbacks are NOT applied, because a value
        # explicitly written by the user expresses intent, whereas an empty
        # value coming from ``env_overrides`` / ``os.environ`` for a
        # registry-declared schema entry means "no value supplied, use the
        # default if one exists".
        if isinstance(env_vars, dict):
            resolved = {}
            for name, value in env_vars.items():
                if not name:
                    continue
                if isinstance(value, str):
                    resolved[name] = self._resolve_env_variable(
                        name, value, env_overrides=env_overrides
                    )
                elif value is not None:
                    resolved[name] = str(value)
            return resolved

        # ---- legacy mode, registry list shape ----
        from rich.prompt import Prompt

        env_overrides = env_overrides or {}
        skip_prompting = self._should_skip_env_prompts(env_overrides)

        # Variables explicitly provided with empty values mean "use the default".
        empty_value_vars = {k for k, v in env_overrides.items() if not v or not v.strip()}

        resolved = {}
        for env_var in env_vars:
            if not isinstance(env_var, dict):
                continue
            name = env_var.get("name", "")
            if not name:
                continue
            required = registry_field_is_required(env_var)

            value = env_overrides.get(name) or os.getenv(name)
            if not value and required and not skip_prompting:
                prompt_text = f"Enter value for {name}"
                if description := env_var.get("description", ""):
                    prompt_text += f" ({description})"
                value = Prompt.ask(
                    prompt_text,
                    password="token" in name.lower() or "key" in name.lower(),
                )

            if value and value.strip():
                resolved[name] = value
            elif name in self._DEFAULT_GITHUB_ENV and (
                name in empty_value_vars or not required or skip_prompting
            ):
                resolved[name] = self._DEFAULT_GITHUB_ENV[name]

        return resolved

    def _resolve_env_variable(self, name, value, env_overrides=None):
        """Resolve (or translate) a single env-var value.

        Used for header values and for individual entries in dict-shape
        env blocks. The ``name`` parameter is currently unused by the
        method body but kept in the signature because every call site
        (headers, dict iteration) already has the name in hand, and
        passing it preserves call-site symmetry with future hooks that
        may want to dispatch on it.

        Args:
            name: Env-var name (currently unused, see above).
            value: Env-var value possibly containing placeholders.
            env_overrides: Pre-collected overrides (ignored in translate mode).
        """
        if self._supports_runtime_env_substitution:
            legacy_keys = _extract_legacy_angle_vars(value)
            self._last_legacy_angle_vars.update(legacy_keys)
            self._last_env_placeholder_keys.update(legacy_keys)
            for match in _ENV_VAR_RE.finditer(value):
                self._last_env_placeholder_keys.add(match.group(1))
            return self._translate_env_placeholder_for_runtime(value)

        from rich.prompt import Prompt

        env_overrides = env_overrides or {}
        skip_prompting = self._should_skip_env_prompts(env_overrides)

        # Three accepted placeholder syntaxes resolved against
        # env_overrides -> os.environ -> optional interactive prompt.
        # Single-pass substitution preserves the legacy ``<VAR>`` semantics:
        # resolved values are NOT re-scanned for further expansion.
        def _replace(match):
            env_name = match.group(1) or match.group(2)
            env_value = env_overrides.get(env_name) or os.getenv(env_name)
            if not env_value and not skip_prompting:
                env_value = Prompt.ask(
                    f"Enter value for {env_name}",
                    password="token" in env_name.lower() or "key" in env_name.lower(),
                )
            return env_value if env_value else match.group(0)

        return _ENV_PLACEHOLDER_RE.sub(_replace, value)

    def _resolve_variable_placeholders(self, value, resolved_env, runtime_vars):
        """Resolve env-var and APM template placeholders in argument strings.

        Translate mode rewrites all three env-var placeholder syntaxes to
        ``${VAR}`` (so the runtime can resolve them at server-start); legacy
        mode resolves only the legacy ``<VAR>`` form against ``resolved_env``
        and leaves the newer ``${VAR}`` / ``${env:VAR}`` syntaxes untouched
        for backward compatibility. APM template variables (``{runtime_var}``)
        are always resolved at install time because they are an APM-internal
        concept the target runtime cannot interpret.

        Args:
            value: String possibly containing placeholders.
            resolved_env: Resolved env-var literals (legacy mode) or
                placeholder strings (translate mode).
            runtime_vars: Resolved APM template variables.

        Returns:
            str: ``value`` with placeholders translated or resolved.
        """
        if not value:
            return value

        processed = str(value)

        if self._supports_runtime_env_substitution:
            self._last_legacy_angle_vars.update(_extract_legacy_angle_vars(processed))
            processed = self._translate_env_placeholder_for_runtime(processed)
        else:
            # Resolve only the legacy ``<VAR>`` form; newer syntaxes are
            # preserved verbatim for backward compatibility.
            def _replace_legacy_angle(match):
                return resolved_env.get(match.group(1), match.group(0))

            processed = _LEGACY_ANGLE_VAR_RE.sub(_replace_legacy_angle, processed)

        # Resolve APM ``{runtime_var}`` template variables. The negative
        # lookbehind on ``$`` ensures we never accidentally match the brace
        # of an already-translated ``${VAR}`` env placeholder.
        if runtime_vars:
            runtime_pattern = re.compile(r"(?<!\$)\{([a-zA-Z_][a-zA-Z0-9_]*)\}")

            def _replace_runtime(match):
                return runtime_vars.get(match.group(1), match.group(0))

            processed = runtime_pattern.sub(_replace_runtime, processed)

        return processed

    def _resolve_env_placeholders(self, value, resolved_env):
        """Legacy thin wrapper for backward compatibility.

        Kept because external callers and the phase-3 test suite invoke
        the pre-#1277 name. Delegates to ``_resolve_variable_placeholders``
        with an empty ``runtime_vars`` map. New code should call
        ``_resolve_variable_placeholders`` directly.
        """
        return self._resolve_variable_placeholders(value, resolved_env, {})

    # ------------------------------------------------------------------
    # Shared server-info helpers (used by all adapter subclasses)
    # ------------------------------------------------------------------

    def _fetch_server_info(self, server_url: str, server_info_cache: dict | None) -> dict | None:
        """Look up *server_url* in *server_info_cache* or fetch from registry.

        Prints a user-visible error and returns ``None`` when the server is
        not found, so callers can do a simple ``if server_info is None: return False``
        guard and the error message stays consistent across adapters.

        Args:
            server_url: Registry reference (``owner/repo`` or full URL).
            server_info_cache: Optional pre-fetched cache; ``None`` skips
                the cache lookup.

        Returns:
            Server-info dict on success; ``None`` when not found.
        """
        if server_info_cache and server_url in server_info_cache:
            return server_info_cache[server_url]
        server_info = self.registry_client.find_server_by_reference(server_url)
        if not server_info:
            library_logger().error(f"MCP server '{server_url}' not found in registry")
            return None
        return server_info

    @staticmethod
    def determine_config_key(
        server_url: str,
        server_name: str | None,
        server_info: dict | None = None,
    ) -> str:
        """Return the configuration key to use for *server_url*/*server_name*.

        The caller-supplied *server_name* takes precedence. If it is absent,
        preserve self-defined names and npm-style scoped names such as
        ``@scope/name`` (one slash by npm convention) while keeping the historical
        ``owner/repo -> repo`` fallback for registry paths.

        This is the canonical owner of MCP config-key derivation; all call
        sites (install, ownership, cleanup) must route through it.

        Args:
            server_url: Registry reference used as fallback source.
            server_name: Explicit caller-supplied name, if any.
            server_info: Optional resolved or synthetic server info dict.

        Returns:
            Non-empty configuration key string.
        """
        if server_name:
            return server_name
        # ``is_self_defined`` / ``_raw_stdio`` are APM-synthetic markers. Return
        # the caller's reference, never ``server_info["name"]``, so a registry
        # response carrying these keys cannot choose an arbitrary config key.
        if server_info and (server_info.get("is_self_defined") or "_raw_stdio" in server_info):
            return server_url
        if server_url.startswith("@") and server_url.count("/") == 1:
            return server_url
        if "/" in server_url:
            return server_url.split("/")[-1]
        return server_url

    @classmethod
    def _apply_pypi_homebrew_generic_config(
        cls,
        config: dict,
        registry_name: str,
        package_name: str,
        runtime_hint: str,
        processed_runtime_args: list,
        processed_package_args: list,
        resolved_env: dict,
        runtime_argument_groups: list[_MCPLauncherArgumentGroup] | None = None,
        package_argument_groups: list[_MCPLauncherArgumentGroup] | None = None,
    ) -> None:
        """Apply pypi / homebrew / generic (uvx / brew / npx) run config to *config*.

        Mutates *config* in-place with ``command``, ``args``, and optionally
        ``env`` keys appropriate for the detected registry type.

        Args:
            config: Mutable server-config dict to populate.
            registry_name: Registry identifier (``"pypi"``, ``"homebrew"``,
                ``"npm"``, or any other string treated as generic).
            package_name: Base package / formula / module name.
            runtime_hint: Caller-specified runtime hint (e.g. ``"uvx"``).
            processed_runtime_args: Fully resolved positional args for the
                runtime launcher.
            processed_package_args: Fully resolved positional args appended
                after the package name.
            resolved_env: Pre-resolved environment variables dict; an empty
                dict is omitted.
            runtime_argument_groups: Optional typed runtime groups. Compatibility
                callers may omit them and supply processed strings only.
            package_argument_groups: Optional typed package groups appended
                after runtime groups.
        """
        runtime_groups = runtime_argument_groups
        if runtime_groups is None:
            runtime_groups = cls._processed_non_container_argument_groups(processed_runtime_args)
        package_groups = package_argument_groups
        if package_groups is None:
            package_groups = cls._processed_non_container_argument_groups(processed_package_args)

        if registry_name == "pypi":
            launcher = runtime_hint or "uvx"
            config["command"] = launcher
            config["args"] = cls._build_non_container_launcher_argv(
                package_name,
                runtime_groups,
                package_groups,
            )
        elif registry_name == "homebrew":
            formula_name = package_name.split("/")[-1] if "/" in package_name else package_name
            config["command"] = formula_name
            config["args"] = processed_runtime_args + processed_package_args
        else:
            launcher = runtime_hint or "npx"
            config["command"] = launcher
            prefix = ("-y",) if launcher in ("npx", "bunx") else ()
            config["args"] = cls._build_non_container_launcher_argv(
                package_name,
                runtime_groups,
                package_groups,
                launcher_prefix=prefix,
            )
        if resolved_env:
            config["env"] = resolved_env

    def _apply_auth_and_headers_impl(
        self,
        config: dict,
        remote: dict,
        server_info: dict,
        env_overrides: dict,
        runtime_label: str,
        token_manager_class,
    ) -> None:
        """Core implementation of GitHub-token injection and header merging.

        Factored out so that each concrete adapter subclass can supply its own
        *token_manager_class* (looked up from the subclass module's namespace),
        allowing :func:`unittest.mock.patch` to intercept the class at the
        right module scope in tests.

        Args:
            config: Mutable config dict updated in place.
            remote: Registry remote entry (headers may be records or a mapping).
            server_info: Registry server metadata used for name / URL lookup.
            env_overrides: Caller-supplied env-var override mapping.
            runtime_label: Label for diagnostic messages.
            token_manager_class: The ``GitHubTokenManager`` class (or mock) to
                instantiate.  Passed by the caller so tests can patch the right
                module-level name.
        """
        from ...core.auth import AuthResolver
        from ...models.dependency.mcp import ManifestHeaderValue

        server_name = server_info.get("name", "")
        is_github_server = self._is_github_server(server_name, remote.get("url", ""))
        local_token_injected = False
        headers = remote.get("headers", []) or []
        if isinstance(headers, dict):
            headers = [{"name": name, "value": value} for name, value in headers.items()]
        explicit_authorization = any(
            isinstance(header, dict)
            and isinstance(header.get("name"), str)
            and header["name"].casefold() == "authorization"
            and isinstance(header.get("value"), ManifestHeaderValue)
            and bool(header.get("value"))
            for header in headers
        )
        if is_github_server and not explicit_authorization:
            resolver = AuthResolver(
                token_manager=token_manager_class(), allow_external_fallback=False
            )
            selected = resolver.resolve_github_mcp_token(
                source_only=self._supports_runtime_env_substitution
            )
            if selected:
                credential = (
                    self._format_runtime_env_placeholder(selected)
                    if self._supports_runtime_env_substitution
                    else selected
                )
                config.setdefault("headers", {})["Authorization"] = f"Bearer {credential}"
                local_token_injected = True
        if headers:
            if "headers" not in config:
                config["headers"] = {}
            for header in headers:
                header_name = header.get("name", "")
                header_value = header.get("value", "")
                if header_name and header_value:
                    if header_name.casefold() == "authorization":
                        if local_token_injected or (
                            explicit_authorization
                            and not isinstance(header_value, ManifestHeaderValue)
                        ):
                            continue
                        for key in list(config["headers"]):
                            if key.casefold() == "authorization":
                                del config["headers"][key]
                    resolved_value = self._resolve_env_variable(
                        header_name, header_value, env_overrides
                    )
                    config["headers"][header_name] = resolved_value
        if config.get("headers"):
            self._warn_input_variables(
                config["headers"], server_info.get("name", ""), runtime_label
            )

    @staticmethod
    def _resolve_env_vars_with_prompting(
        env_vars: list,
        env_overrides: dict,
        default_github_env: dict,
    ) -> dict:
        """Resolve *env_vars* from overrides, environment, or interactive prompts.

        Identical logic shared between
        :meth:`CopilotClientAdapter._process_environment_variables` and
        :meth:`CodexClientAdapter._process_environment_variables`.

        All imports are deferred so that ``rich.prompt`` (an optional
        dependency) is never imported at module load time.

        Args:
            env_vars: List of env-var descriptor dicts from the registry.
            env_overrides: Pre-collected ``{name: value}`` overrides (empty
                dict when none).
            default_github_env: Mapping of well-known GitHub variable names
                to their preferred environment-variable lookup names.

        Returns:
            ``resolved`` dict mapping each env-var name to its resolved value
            (empty string when unresolvable).
        """
        import sys

        env_overrides = env_overrides or {}
        resolved: dict = {}

        # Determine whether interactive prompting is available.
        # If env_overrides is provided the CLI has already collected variables -- never prompt again.
        skip_prompting = (
            bool(env_overrides)
            or bool(os.getenv("CI"))
            or bool(os.getenv("APM_E2E_TESTS"))
            or not sys.stdout.isatty()
            or not sys.stdin.isatty()
        )

        # First pass: identify variables with empty values to warn the user.
        empty_value_vars = [
            ev for ev in env_vars if registry_field_is_required(ev) and not ev.get("value")
        ]
        if empty_value_vars and skip_prompting:
            var_names = [ev.get("name") for ev in empty_value_vars]
            library_logger().warning(
                f"Required environment variables have no default value and cannot be "
                f"prompted in non-interactive mode: {var_names}. "
                + MCP_ENV_VARS_UNRESOLVED.bind(names="them").sentence()
            )

        for env_var in env_vars:
            name = env_var.get("name", "")
            if not name:
                continue

            # Priority 1: caller-supplied override.
            # An explicit empty (or whitespace-only) value is treated as
            # "user cleared this". For names with a GitHub-style default the
            # logic falls through so the literal default wins; for names
            # without a default the entry is dropped from the resolved map.
            if name in env_overrides:
                override_value = env_overrides[name]
                if isinstance(override_value, str) and not override_value.strip():
                    if name not in default_github_env:
                        continue
                else:
                    resolved[name] = override_value
                    continue

            # Priority 2: check GitHub-specific defaults (values are literal defaults, not env-var names)
            if name in default_github_env:
                resolved[name] = os.getenv(name) or default_github_env[name]
                continue

            # Priority 3: environment variable with the same name
            env_val = os.getenv(name, "")
            if env_val:
                resolved[name] = env_val
                continue

            # Priority 4: interactive prompt
            default_value = env_var.get("value", "")
            required = registry_field_is_required(env_var)

            if not skip_prompting and required:
                from rich.prompt import Prompt

                description = env_var.get("description", "")
                prompt_text = f"Enter value for {name}"
                if description:
                    prompt_text += f" ({description})"
                is_secret = "token" in name.lower() or "key" in name.lower()
                user_input = Prompt.ask(
                    prompt_text,
                    default=default_value,
                    password=True  # noqa: SIM210
                    if is_secret
                    else False,
                )
                resolved[name] = user_input
            elif default_value:
                resolved[name] = default_value
            elif required:
                library_logger().warning(
                    f"Required environment variable '{name}' could not be resolved. "
                    "The MCP server may not function correctly. "
                    + MCP_ENV_VARS_UNRESOLVED.bind(names=name).sentence()
                )
                resolved[name] = ""

        return resolved
